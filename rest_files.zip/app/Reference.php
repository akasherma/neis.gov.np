<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Reference extends Model
{
    
    protected $table = 'reference';
    
    protected $fillable = [
        'name', 'email', 'address', 'contact', 'status'
    ];
    
}
