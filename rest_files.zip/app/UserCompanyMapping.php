<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserCompanyMapping extends Model
{
    
    protected $table = 'user_company_mapping';
    
    protected $fillable = [
        'user_id', 'company_id', 'entered_by'
    ];
    
}
