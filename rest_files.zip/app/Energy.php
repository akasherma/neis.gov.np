<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Energy extends Model
{

    protected $table = 'energy';

    protected $fillable = ['energy_name', 'energy_slug', 'energy_desc', 'energy_type_id','fuel_type_id', 'status'];

}
