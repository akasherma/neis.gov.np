<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EnergyFormMeta extends Model
{

    protected $table = 'energy_form_meta';

    protected $fillable = [
        'energy_form_id',
        'energy_form_topic',
        'energy_id',
        'energy_topic',
        'energy_topic_id',
        'natural_qty',
        'natural_unit',
        'scientific_qty',
        'scientific_unit',
        'status'
    ];

}
