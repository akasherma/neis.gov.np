<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password', 'phone', 'address', 'designation', 'organization_name', 'user_group_id', 'is_admin','status'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public static function getStaticUserInfo($userId){

        $currentUser = User::find($userId);
        return $currentUser->name;

    }

    public function getUserLevel($user_id){

        $this_user = User::find($user_id);

        $route = 'edit';

        if(!empty($this_user->user_group_id) && $this_user->user_group_id != 0){

            $this_user_group = UserGroup::find($this_user->user_group_id);

            if($this_user_group->user_level == 'entry'){
                $route = 'edit';
            }elseif($this_user_group->user_level == 'check'){
                $route = 'check';
            }else{
                $route = 'approve';
            }

        }

        return $route;

    }

    public static function getUserStatus($user_id){

        $this_user = User::find($user_id);

        $user_status = 'Admin';

        if(!empty($this_user->user_group_id) && $this_user->user_group_id != 0){

            $this_user_group = UserGroup::find($this_user->user_group_id);

            if($this_user_group->user_level == 'entry'){
                $user_status = 'Data Entry';
            }elseif($this_user_group->user_level == 'check'){
                $user_status = 'Quality Check';
            }else{
                $user_status = 'Supervisor';
            }

        }

        return $user_status;

    }

    public function getUserArray($userId){

        $currentUser = \App\User::find($userId);
        $parent_id = (!empty($currentUser->parent_id))?$currentUser->parent_id:$userId;

        $users = User::where('parent_id', $parent_id)->select('id')->get();

        $user_arr = array();

        foreach ($users as $the_user)
            array_push($user_arr, $the_user->id);

        array_push($user_arr, $parent_id);

        return $user_arr;

    }

    public static function getParentList($userId){

        $currentUser = \App\User::find($userId);
        $parent_id = (!empty($currentUser->parent_id))?$currentUser->parent_id:$userId;

//        return $parent_id.'---';

        if($parent_id != $userId)
            return '';
        else
            return '<li class=" nav-item"><a href="'.url("/").'/user/dashboard/user"><i class="ft-layers"></i><span class="menu-title" data-i18n="">General Users</span></a></li>';

    }

    public static function getParentId($userId){

        $currentUser = \App\User::find($userId);
        $parent_id = (!empty($currentUser->parent_id))?$currentUser->parent_id:$userId;

        return $parent_id;

    }

    public static function getStaticUserHeaderInfo($userId){

        $currentUser = \App\User::find($userId);
        $parent_id = (!empty($currentUser->parent_id))?$currentUser->parent_id:$userId;

        $currentUser = User::find($parent_id);
        return $currentUser;

    }

}
