<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EntryStatusMeta extends Model
{
    
    protected $table = 'entry_status_meta';
    
    protected $fillable = [
        'entry_status_id', 'entry_status_type', 'entry_status_label', 'entry_status_key', 'entry_status_default_value', 'entry_status_order', 'status'
    ];
    
}
