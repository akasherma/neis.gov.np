<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Unit extends Model
{

    protected $table = 'unit';

    protected $fillable = ['unit_name', 'unit_slug', 'unit_short_form', 'unit_desc', 'status'];

}
