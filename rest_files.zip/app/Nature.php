<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Nature extends Model
{
    //
    protected $table = 'nature';

    protected $fillable = [
        'nature_name', 'nature_slug', 'nature_desc', 'status'
    ];
}
