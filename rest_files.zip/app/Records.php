<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Records extends Model
{
    //
    protected $table = 'records';

    protected $fillable = [
        'record_name', 'record_slug', 'record_desc', 'record_type', 'address', 'menu_id', 'lat', 'lang', 'capacity', 'unit', 'status'
    ];
}
