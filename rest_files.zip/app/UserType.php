<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserType extends Model
{
    protected $table = 'user_type';
    
    protected $fillable = [
        'user_type_name', 'user_type_slug', 'user_type_desc', 'status'
    ];
    
}
