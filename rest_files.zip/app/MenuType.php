<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MenuType extends Model
{
    protected $table = 'menu_type';

    protected $fillable = [
        'menu_type_name', 'menu_type_slug', 'menu_type_desc','status'
    ];
}
