<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Source extends Model
{
    //
    protected $table = 'sources';

    protected $fillable = [
        'source_name', 'source_slug', 'source_desc', 'status'
    ];
}
