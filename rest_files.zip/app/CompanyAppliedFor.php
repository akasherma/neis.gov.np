<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CompanyAppliedFor extends Model
{
    
    protected $table = 'company_applied_for';
    
    protected $fillable = [
        'company_applied_for_name', 'company_applied_for_slug', 'company_applied_for_desc', 'country_id', 'status'
    ];
    
}
