<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class River extends Model
{
    //
    protected $table = 'river';

    protected $fillable = [
        'river_name','river_slug','river_desc', 'entry_order','status'
    ];
}
