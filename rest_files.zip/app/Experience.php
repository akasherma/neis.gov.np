<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Experience extends Model
{

    protected $table = 'experience';

    protected $fillable = [
        'candidate_id', 'gcc_exp', 'exp_from', 'exp_to', 'country_id', 'no_of_exp_in_years', 'company_id', 'designation', 'job_details', 'status'
    ];

}
