<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class QualificationType extends Model
{

    protected $table = 'qualification_type';

    protected $fillable = [
        'candidate_id', 'qualification_type_name', 'qualification_type_slug', 'status'
    ];

}

