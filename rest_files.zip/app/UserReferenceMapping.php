<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserReferenceMapping extends Model
{
    
    protected $table = 'user_reference_mapping';
    
    protected $fillable = [
        'user_id', 'reference_id', 'entered_by', 'status'
    ];
    
}
