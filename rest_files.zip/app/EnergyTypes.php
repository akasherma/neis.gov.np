<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EnergyTypes extends Model
{
    // energy_type_name`, `energy_type_slug`, `energy_type_desc
    protected $table = 'energy_type';

    protected $fillable = [
        'energy_type_name', 'energy_type_slug', 'energy_type_desc', 'status'
    ];
}
