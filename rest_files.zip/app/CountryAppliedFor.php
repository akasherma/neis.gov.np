<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CountryAppliedFor extends Model
{
    
    protected $table = 'country_applied_for';
    
    protected $fillable = [
        'country_applied_for_name', 'country_applied_for_slug', 'country_applied_for_desc', 'status'
    ];
    
}
