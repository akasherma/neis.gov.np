<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Menu extends Model
{
    protected $table = 'menu';

    protected $fillable = [
        'menu_name', 'menu_slug', 'menu_desc', 'menu_order','menu_type_id','status'
    ];
    public static function getMenu(){
        $menu2 = Menu::where('status','Y')->orderBy('menu_order','asc')->get();
        return $menu2;

    }

    public static function getSidebarMenuForAdmin($userId){

//        $result = DB::table('menu')
//            ->where('status', '1')
//            ->get();

//        $userId = 11;

//        $usertypeId = $usertype->id;

        $this_user = User::find($userId);

        if($this_user->user_group_id > 0){

            $result = DB::table('menu as m')
                ->join('user_group_menu_mapping as ugmp', 'ugmp.menu_id', '=', 'm.id')
                ->join('menu_type as mt', 'm.menu_type_id', '=', 'mt.id')
                ->where('mt.menu_type_slug', 'dashboard-menu')
                ->where('ugmp.user_group_id', $this_user->user_group_id)
                ->where('m.status', 'Y')
                ->select('m.*')
                ->orderBy('m.menu_order', 'ASC')
                ->get()
                ->toArray();

        }else{

            $result = DB::table('menu as m')
                ->join('menu_type as mt', 'm.menu_type_id', '=', 'mt.id')
                ->where('mt.menu_type_slug', 'dashboard-menu')
                ->select('m.*')
                ->where('m.status', 'Y')
                ->orderBy('m.menu_order', 'ASC')
                ->get()
                ->toArray();

        }
        return $result;
    }

    public static function getSidebarMenuForAdminSetting($userId){

        $this_user = User::find($userId);

        $result = array();

        if($this_user->user_group_id > 0){

            $result = DB::table('menu as m')
                ->join('user_group_menu_mapping as ugmp', 'ugmp.menu_id', '=', 'm.id')
                ->join('menu_type as mt', 'm.menu_type_id', '=', 'mt.id')
                ->where('mt.menu_type_slug', 'settings')
                ->where('ugmp.user_group_id', $this_user->user_group_id)
                ->where('m.status', 'Y')
                ->select('m.*')
                ->orderBy('m.menu_order', 'ASC')
                ->get()
                ->toArray();

        }else{

            $result = DB::table('menu as m')
                ->join('menu_type as mt', 'm.menu_type_id', '=', 'mt.id')
                ->where('mt.menu_type_slug', 'settings')
                ->select('m.*')
                ->where('m.status', 'Y')
                ->orderBy('m.menu_order', 'ASC')
                ->get()
                ->toArray();

        }

        return $result;
    }

    public static function getSidebarMenuForEntryForm($userId){

        $this_user = User::find($userId);

        $result = array();

        if($this_user->user_group_id > 0){

            $result = DB::table('menu as m')
                ->join('user_group_menu_mapping as ugmp', 'ugmp.menu_id', '=', 'm.id')
                ->join('menu_type as mt', 'm.menu_type_id', '=', 'mt.id')
                ->where('mt.menu_type_slug', 'settings')
                ->where('ugmp.user_group_id', $this_user->user_group_id)
                ->where('m.status', 'Y')
                ->select('m.*')
                ->orderBy('m.menu_order', 'ASC')
                ->get()
                ->toArray();

        }else{

            $result = DB::table('menu as m')
                ->join('menu_type as mt', 'm.menu_type_id', '=', 'mt.id')
                ->where('mt.menu_type_slug', 'entry-form')
                ->select('m.*')
                ->where('m.status', 'Y')
                ->orderBy('m.menu_order', 'ASC')
                ->get()
                ->toArray();

        }

        return $result;
    }

    public static function getSidebarMenuForEntryFormNew($userId){

        $this_user = User::find($userId);

        $result = array();

        if($this_user->user_group_id > 0){

            $result = DB::table('menu as m')
                ->join('user_group_menu_mapping as ugmp', 'ugmp.menu_id', '=', 'm.id')
                ->join('menu_type as mt', 'm.menu_type_id', '=', 'mt.id')
                ->where('mt.menu_type_slug', 'entry-form-new')
                ->where('ugmp.user_group_id', $this_user->user_group_id)
                ->where('m.status', 'Y')
                ->select('m.*')
                ->orderBy('m.menu_order', 'ASC')
                ->get()
                ->toArray();

        }else{

            $result = DB::table('menu as m')
                ->join('menu_type as mt', 'm.menu_type_id', '=', 'mt.id')
                ->where('mt.menu_type_slug', 'entry-form-new')
                ->select('m.*')
                ->where('m.status', 'Y')
                ->orderBy('m.menu_order', 'ASC')
                ->get()
                ->toArray();

        }

        return $result;
    }

    public static function getSidebarMenuForReportNew($userId){

        $this_user = User::find($userId);

        $result = array();

        if($this_user->user_group_id > 0){

            $result = DB::table('menu as m')
                ->join('user_group_menu_mapping as ugmp', 'ugmp.menu_id', '=', 'm.id')
                ->join('menu_type as mt', 'm.menu_type_id', '=', 'mt.id')
                ->where('mt.menu_type_slug', 'report-new')
                ->where('ugmp.user_group_id', $this_user->user_group_id)
                ->where('m.status', 'Y')
                ->select('m.*')
                ->orderBy('m.menu_order', 'ASC')
                ->get()
                ->toArray();

        }else{

            $result = DB::table('menu as m')
                ->join('menu_type as mt', 'm.menu_type_id', '=', 'mt.id')
                ->where('mt.menu_type_slug', 'report-new')
                ->select('m.*')
                ->where('m.status', 'Y')
                ->orderBy('m.menu_order', 'ASC')
                ->get()
                ->toArray();

        }

        return $result;
    }

    public static function getSidebarMenuForRecords($userId){

        $this_user = User::find($userId);

        $result = array();

        if($this_user->user_group_id > 0){

            $result = DB::table('menu as m')
                ->join('user_group_menu_mapping as ugmp', 'ugmp.menu_id', '=', 'm.id')
                ->join('menu_type as mt', 'm.menu_type_id', '=', 'mt.id')
                ->where('mt.menu_type_slug', 'records')
                ->where('ugmp.user_group_id', $this_user->user_group_id)
                ->where('m.status', 'Y')
                ->select('m.*')
                ->orderBy('m.menu_order', 'ASC')
                ->get()
                ->toArray();

        }else{

            $result = DB::table('menu as m')
                ->join('menu_type as mt', 'm.menu_type_id', '=', 'mt.id')
                ->where('mt.menu_type_slug', 'records')
                ->select('m.*')
                ->where('m.status', 'Y')
                ->orderBy('m.menu_order', 'ASC')
                ->get()
                ->toArray();

        }

        return $result;
    }

    public static function getFooterLinks($page_slug = 'footer-links'){

        $result = Page::where('page_slug', $page_slug)->first();

        return $result;
    }


    public static function recordList(){

        $recordlist = Menu::join('menu_type', 'menu_type.id', '=', 'menu.menu_type_id')
            ->select('menu.*')
            ->where('menu_type.menu_type_slug', '=', 'records')
            ->where('menu.status', '=', 'Y')
            ->get();

        $result = array();

        foreach($recordlist as $the_result){
            $result[$the_result->menu_slug] = $the_result->menu_name;
        }


        return $result;


    }

}
