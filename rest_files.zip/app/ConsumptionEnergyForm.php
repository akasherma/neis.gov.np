<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ConsumptionEnergyForm extends Model
{

    protected $table = 'consumption_energy_form';

    protected $fillable = ['energy_id', 'central_id', 'province_id', 'district_id', 'local_gov_id', 'entered_by', 'qa_by', 'published_by', 'from_date', 'to_date', 'status'];

}
