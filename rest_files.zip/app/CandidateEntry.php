<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class CandidateEntry extends Model
{
    
    protected $table = 'candidate_entry';
    
    protected $fillable = [
        'entry_reg_no', 'demand_id', 'first_name', 'middle_name', 'last_name', 'passport_no', 'dob', 'address', 'district', 'qualification','experience', 'passport_expiry_date', 'passport_issue_date', 'place_of_issue', 'next_to_kin', 'relation_with_kin', 'reference_by', 'country_applied_for', 'company_applied_for', 'position_applied_for', 'contact_no', 'attachment', 'certificates', 'photographs', 'remarks', 'parent_id', 'entered_by', 'entry_status', 'status'
    ];

    public function createNewField($table, $table_field, $name, $userId){

        $id = DB::table($table)->insertGetId(
            [$table_field => str_replace("-", " ", $name), 'status' => 'Y']
        );

        if($table == 'company_applied_for'){
            DB::table('user_company_mapping')->insert(
                ['company_id' => $id, 'user_id' => $userId, 'entered_by' => $userId ]
            );
        }elseif($table == 'reference'){
            DB::table('user_reference_mapping')->insert(
                ['reference_id' => $id, 'user_id' => $userId, 'entered_by' => $userId ]
            );
        }

        return '<option value="'.$id.'" selected="selected">'.str_replace("-", " ", $name).'</option>';

    }
    
}
