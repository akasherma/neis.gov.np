<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EnergyTypeTopicMapping extends Model
{

    protected $table = 'energy_type_topic_mapping';

    protected $fillable = [
        'energy_type_topic', 'energy_id', 'energy_field_topic', 'status'
    ];



}
