<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CandidateEntryMeta extends Model
{
    
    protected $table = 'candidate_entry_meta';
    
    protected $fillable = [
        'candidate_entry_id', 'entry_status_id', 'candidate_entry_meta_key', 'candidate_entry_meta_value', 'source', 'status'
    ];
    
}
