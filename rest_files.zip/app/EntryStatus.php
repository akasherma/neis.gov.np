<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class EntryStatus extends Model
{
    
    protected $table = 'entry_status';
    
    protected $fillable = [
        'entry_status_name', 'entry_status_slug', 'entry_status_desc', 'entry_status_order', 'status', 'list_status'
    ];

    public function getEntryStatus($user_arr){
        $result = DB::table('entry_status')
            ->leftJoin('candidate_entry_meta', 'entry_status.id', '=', 'candidate_entry_meta.entry_status_id')
            ->leftJoin('candidate_entry', function($join) use ($user_arr)
            {
                $join->on('candidate_entry.id', '=', 'candidate_entry_meta.candidate_entry_id');
                $join->whereIn('candidate_entry.entered_by', $user_arr);
            })
            ->select('entry_status.entry_status_slug', 'entry_status.entry_status_name', DB::raw('count(distinct(candidate_entry.id)) as status_cnt'))
            ->groupBy( 'entry_status.entry_status_slug', 'entry_status.entry_status_name')
            ->orderBy('entry_status.entry_status_order')
            ->get();

        return $result;

//        echo '<pre>';
//        print_r(json_decode($result));
//        echo '</pre>';
//        exit();

    }
    
}
