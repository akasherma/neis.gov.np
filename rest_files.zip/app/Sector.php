<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sector extends Model
{
    //sector_name`, `sector_slug`, `sector_order`, `status
        protected $table = 'sector';

        protected $fillable = [
            'sector_name', 'sector_slug', 'entry_order', 'status'
        ];
}
