<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class EnergyYear extends Model
{

    protected $table = 'energy_year';

    protected $fillable = ['energy_year_start', 'energy_year_end', 'is_completed', 'status'];

    public static function getEnergyYear(){

        $result = array();

        $result = DB::table('energy_year as ey')
            ->where('ey.status', 'Y')
            ->orderBy('ey.energy_year_start', 'DESC')
            ->pluck('ey.energy_year_start')
            ->toArray();

        return $result;
    }

}
