<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LogTable extends Model
{

    protected $table = 'log';

    protected $fillable = [
        'log_details', 'menu_name', 'created_by'
    ];

    public function insertIntoLogTable($data){
        LogTable::create($data);

//        log_details`, `menu_name`, `created_by
    }

}
