<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FuelType extends Model
{
    //`id`, `fuel_type_name`, `fuel_type_slug`, `fuel_type_desc`, `parent_id`, 'is_last_child', `status`
    protected $table = 'fuel_type';

    protected $fillable = [
        'fuel_type_name',
        'fuel_type_slug',
        'geographic_region_desc',
        'parent_id',
        'status'
    ];
}
