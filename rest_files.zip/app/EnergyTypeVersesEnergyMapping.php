<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EnergyTypeVersesEnergyMapping extends Model
{

    protected $table = 'energy_type_verses_energy_mapping';

    protected $fillable = [
        'energy_type_id', 'energy_id', 'status'
    ];

}
