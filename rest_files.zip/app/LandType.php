<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LandType extends Model
{
    //
    protected $table = 'land_type';

    protected $fillable = [
        'land_type_name','land_type_slug','land_type_desc', 'entry_order','status'
    ];
}
