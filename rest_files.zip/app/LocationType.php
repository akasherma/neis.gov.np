<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LocationType extends Model
{
    //
    protected $table = 'location_type';

    protected $fillable = [
        'location_type_name', 'location_type_slug', 'location_type_desc', 'child_id', 'status'
    ];
}
