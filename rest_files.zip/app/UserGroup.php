<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserGroup extends Model
{
    protected $table = 'user_group';

    protected $fillable = [
        'user_group_name', 'user_group_slug', 'user_group_desc', 'user_level', 'status'
    ];
}
