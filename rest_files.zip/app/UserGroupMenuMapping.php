<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class UserGroupMenuMapping extends Model
{
    //user_group_id`, `menu_id`, `status`, `created_at`, `updated_at` FROM `wecs`.`user_group_menu_mapping

    protected $table = 'user_group_menu_mapping';

    protected $fillable = [
        'user_group_id', 'menu_id', 'status'
    ];

    public function userGroupMenuPolicy($user_id, $menu_slug){

//        exit();

        $this_menu = Menu::where('menu_slug', $menu_slug)->first();

        $this_user = User::find($user_id);

        $data = 1;

        if($this_user->is_admin != 'Y' && !empty($this_menu) && !empty($this_user)){

            $result = Menu::join('user_group_menu_mapping', 'user_group_menu_mapping.menu_id', '=', 'menu.id')
                ->join('user_group', 'user_group.id', '=', 'user_group_menu_mapping.user_group_id')
                ->where('user_group.id', $this_user->user_group_id)
                ->where('user_group_menu_mapping.menu_id', $this_menu->id)
                ->count();

            $data = (!empty($result))?$result:0;
//
//                ->select('menu.*')
//                ->groupBy('menu.id')
//                ->orderBy('menu.menu_order', 'asc')
//                ->get();

        }

        return $data;

    }

}
