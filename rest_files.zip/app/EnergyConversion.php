<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EnergyConversion extends Model
{
    // energy_id`, `natural_unit`, `natural_qty`, `scientific_unit`, `scientific_qty`, `status, energy_conversion
    protected $table = 'energy_conversion';

    protected $fillable = [
        'energy_id',
        'natural_unit',
        'natural_qty',
        'scientific_unit',
        'scientific_qty',
        'status'
    ];
}
