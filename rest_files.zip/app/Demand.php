<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Demand extends Model
{
    protected $table = 'demand';

    protected $fillable = ['pre_approval_date', 'lot_number', 'chalani_no', 'country_id', 'company_id', 'demand_no', 'demandentry', 'expiry_date', 'status'];
}
