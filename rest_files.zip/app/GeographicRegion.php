<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GeographicRegion extends Model
{
    //id`, `geographic_region_name`, `geographic_region_slug`, `geographic_region_desc`, `status`
    protected $table = 'geographic_region';

    protected $fillable = [
        'geographic_region_name',
        'geographic_region_slug',
        'geographic_region_desc',
        'entry_order',
        'status'
    ];
}
