<?php

namespace App\Http\Controllers\user;

use App\EntryStatus;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class EntryStatusController extends Controller
{

    public function index(Request $request){
        $userId = $request->session()->get('user_id');
        if(is_null($userId)){
            return redirect('user')->with('error', 'Please Login..');
        }else{
            $result = EntryStatus::get();
            return view('frontend.entry_status_list')->with('datas', $result);
        }
    }

    public function create(){
        $objMenu = new \stdClass();
        $objMenu->id = '';
        $objMenu->entry_status_name = '';
        $objMenu->entry_status_desc = '';
        $objMenu->entry_status_order = '';
        return view('frontend/add_entry_status')
            ->with('data', $objMenu)
            ->with('route', 'add');
    }

    public function postCreate(Request $request) {
        $formdata = $request->formdata;

        $entry_status_slug = str_replace(" ","-", strtolower($formdata['entry_status_name']));

        $objEntryStatus = new EntryStatus();
        $objEntryStatus->entry_status_name = $formdata['entry_status_name'];
        $objEntryStatus->entry_status_slug = $entry_status_slug;
        $objEntryStatus->entry_status_desc = $formdata['entry_status_desc'];
        $objEntryStatus->entry_status_order = $formdata['entry_status_order'];
        $objEntryStatus->status = 'Y';


        if($objEntryStatus->save())
            return redirect('user/dashboard/entry_status')->with('success', 'Entry Status added successfully!');
        else
            return redirect('user/dashboard/entry_status')->with('error', 'Entry Status cannot be added!');

    }

    public function update($entry_status_id){
        $objMenu = EntryStatus::find($entry_status_id);
        return view('frontend/add_entry_status')
            ->with('data', $objMenu)
            ->with('route', 'edit');
    }

    public function postUpdate(Request $request) {
        $formdata = $request->formdata;

        $entry_status_slug = str_replace(" ","-", strtolower($formdata['entry_status_name']));

        $objEntryStatus = EntryStatus::find($formdata['id']);
        $objEntryStatus->entry_status_name = $formdata['entry_status_name'];
        $objEntryStatus->entry_status_slug = $entry_status_slug;
        $objEntryStatus->entry_status_desc = $formdata['entry_status_desc'];
        $objEntryStatus->entry_status_order = $formdata['entry_status_order'];
        $objEntryStatus->status = 'Y';

        if($objEntryStatus->save())
            return redirect('user/dashboard/entry_status')->with('success', 'Entry Status updated successfully!');
        else
            return redirect('user/dashboard/entry_status')->with('error', 'Entry Status cannot be updated!');

    }

}
