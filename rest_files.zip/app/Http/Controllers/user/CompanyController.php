<?php

namespace App\Http\Controllers\user;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\CompanyAppliedFor;
use App\UserCompanyMapping;

class CompanyController extends Controller
{
    
    public function index(Request $request){
        $userId = $request->session()->get('user_id');
        if(is_null($userId)){
            return redirect('user')->with('error', 'Please Login..');
        }else{
            
//            $currentUser = \App\User::find($userId);
//            $company_user_id = (!empty($currentUser->parent_id))?$currentUser->parent_id:$userId;

            $objUser = new User();
            $user_arr = $objUser->getUserArray($userId);

            $result = CompanyAppliedFor::join('user_company_mapping', 'company_applied_for.id', '=', 'user_company_mapping.company_id')
                    ->whereIn('user_company_mapping.user_id', $user_arr)
                    ->select('company_applied_for.*')
                    ->get();
            
            return view('frontend.companylist')->with('datas', $result);
        }
    }

    public function create(){
        $objMenu = new \stdClass();
        $objMenu->id = '';
//        ', 'company_applied_for_slug', '
        $objMenu->company_applied_for_name = '';
        $objMenu->company_applied_for_desc = '';
        $objMenu->country_id = '';
        $objMenu->status = '';
        
        return view('frontend/add_company')
            ->with('data', $objMenu)
            ->with('route', 'add');
    }
    public function postCreate(Request $request) {
        $userId = $request->session()->get('user_id');
        $currentUser = \App\User::find($userId);
        $company_user_id = (!empty($currentUser->parent_id))?$currentUser->parent_id:$userId;
        
        $formdata = $request->formdata;

//         echo '<pre>';
//         print_r($formdata);
//         echo '</pre>';
//         exit();

        $company_applied_for_slug = str_replace(" ","-", strtolower($formdata['company_applied_for_name']));
        
        $objCompanyAppliedFor = new CompanyAppliedFor();
        $objCompanyAppliedFor->company_applied_for_name = $formdata['company_applied_for_name'];
        $objCompanyAppliedFor->company_applied_for_slug = $company_applied_for_slug;
        $objCompanyAppliedFor->company_applied_for_desc = $formdata['company_applied_for_desc'];
        $objCompanyAppliedFor->country_id = $formdata['country_id'];
        $objCompanyAppliedFor->status = 'Y';
        
        
        if($objCompanyAppliedFor->save()):
            $objUserCompanyMapping = new UserCompanyMapping();
            $objUserCompanyMapping->user_id = $company_user_id;
            $objUserCompanyMapping->company_id = $objCompanyAppliedFor->id;
            $objUserCompanyMapping->save();
            
            return redirect('user/dashboard/company')->with('success', 'Company added successfully!');
        else:
            return redirect('user/dashboard/company')->with('error', 'Company cannot be added!');
        endif;
        
    }
    
}
