// <?php

// namespace App\Http\Controllers\user;

// use App\Menu;
// use App\User;
// use App\Usertype;
// use Illuminate\Http\Request;
// use App\Http\Controllers\Controller;

// class UserController extends Controller
// {
//     public function index(Request $request){

//         $userId = $request->session()->get('user_id');


// //        echo '<pre>';
// //        print_r($userId);
// //        echo '</pre>';
// //        exit();


//         $objMenu = new Menu();
//         $menu = $objMenu->getSideBarMenu($userId);

// //        foreach ($menu as $menus){
// //        echo '<pre>';
// //        print_r($menus->user_type_name);
// //        echo '</pre>';
// //        }
//         exit();
//         return view('front/menu')
//             ->with('data', $menu)
//             ->with('');



//     }
//     public function login(Request $request){
//         $userID = $request->session()->get('user_id');
//         $clientId = User::where('id', $userID)->first();
// //        echo '<pre>';
// //        print_r($clientId);
// //        echo '</pre>';
// //        exit();
//         if (is_null($userID)){
//             return view('frontend/login');
//         }elseif
//         ($clientId->user_types_id == 2 ) {

//             return redirect('/teacher/dashboard');
//         } elseif
//         ($clientId->user_types_id == 3 ){
//             return redirect('/student/dashboard');
//         }else{
//             return view('frontend/login');
//         }
//     }
//     public function postlogin(Request $request){

// //        echo '<pre>';
// //        print_r($request->password);
// //        echo '</pre>';
// //        exit();
//         $password = md5($request->password);
//         $userId = User::where('email', $request->email)
//             ->where('password', $password)
//             ->first();
// //
// //        echo '<pre>';
// //        print_r($userId);
// //        echo '</pre>';
// //        exit();
//         if (is_null($userId)) {
//             return redirect('user')->with('error', 'No such UserName or Password Found!');
//         } elseif
//         ($userId->user_types_id == 2) {
//             session(['user_id' => $userId->id]);
//             return redirect('/teacher/dashboard');
//         } elseif
//         ($userId->user_types_id == 3) {
//             session(['user_id' => $userId->id]);
//             return redirect('/student/dashboard');
//         }

//     }
//     public function userLogout(Request $request)
//     {
//         $request->session()->forget('user_id');
//         return redirect('user')->with('success','Successfully Logged Out');
//     }
//     public function forgotpassword(){
//         return view('frontend/forgotpassword');
//     }

//     public function postforgotpassword(Request $request){

//         $to = $request->email;

//         $route = 'login';

//         $res_user = User::where('email', $to)->first();
        
//             // echo '<pre>';
//             // print_r($res_user);
//             // echo '</pre>';
//             // exit();

//         $user_type_id = $res_user->user_types_id;

// //       echo '<pre>';
// //       print_r($user_type_id);
// //       echo '</pre>';
// //       exit();

//         if($user_type_id > 1)
//             $route = 'user';

//         $subject = "Reset code for ".$to;

//         $msg = '';

//         $time_plus = strtotime(date('Y-m-d H:i:s')) + 60*60;

//         $encode = base64_encode($to.'-'.$time_plus);

//         $message = "
//       <html>
//       <head>
//       <title>".$subject."</title>
//       </head>
//       <body>
//       <strong>Dear</strong>
//       <p>Reset your activation code using<a href='".url('/').'/resetcode/'.$encode."'>".url('/').'/resetcode/'.$encode."</a></p>
//       <p>Thank you,</p>
//       </body>
//       </html>
//       ";

//         // Always set content-type when sending HTML email
//         $headers = "MIME-Version: 1.0" . "\r\n";
//         $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

//         // More headers
//         $headers .= 'From: <info@nepaeducation.com>' . "\r\n";
//         $headers .= 'Cc: prabin2046@gmail.com' . "\r\n";

//         if(mail($to,$subject,$message,$headers)){
//             $status = 'success';
//             $msg = 'Mail has been sent to your email. Please check it out!';

//             return redirect($route)->with($status, $msg);

//         }else{
//             $status = 'warning';
//             $msg = 'Mail has been sent to your email. Please check it out!';

//             return redirect($route)->with($status, $msg);

//         }

//     }
// }
