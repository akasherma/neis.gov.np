<?php

namespace App\Http\Controllers\user;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\CountryAppliedFor;

class CountryController extends Controller
{
    
    public function index(Request $request){
        $userId = $request->session()->get('user_id');
        if(is_null($userId)){
            return redirect('user')->with('error', 'Please Login..');
        }else{
            $result = CountryAppliedFor::get();
            return view('frontend.countrylist')->with('datas', $result);
        }
    }

    public function create(){
        $objMenu = new \stdClass();
        $objMenu->id = '';
        $objMenu->country_applied_for_name = '';
        $objMenu->country_applied_for_desc = '';
        return view('frontend/add_country')
            ->with('data', $objMenu)
            ->with('route', 'add');
    }
    public function postCreate(Request $request) {
        $formdata = $request->formdata;

//         echo '<pre>';
//         print_r($formdata);
//         echo '</pre>';
//         exit();

        $country_applied_for_slug = str_replace(" ","-", strtolower($formdata['country_applied_for_name']));
        
        $objCountryAppliedFor = new CountryAppliedFor();
        $objCountryAppliedFor->country_applied_for_name = $formdata['country_applied_for_name'];
        $objCountryAppliedFor->country_applied_for_slug = $country_applied_for_slug;
        $objCountryAppliedFor->country_applied_for_desc = $formdata['country_applied_for_desc'];
        $objCountryAppliedFor->status = 'Y';
        
        
        if($objCountryAppliedFor->save())
            return redirect('user/dashboard/country')->with('success', 'Country added successfully!');
        else
            return redirect('user/dashboard/country')->with('error', 'Country cannot be added!');

    }
}
