<?php

namespace App\Http\Controllers\user;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class SearchController extends Controller
{
    public function index(Request $request){

        $company = (!empty($request->get('company')))?$request->get('company'):'';
        $demand = (!empty($request->get('demand')))?$request->get('demand'):'';
        $passport = (!empty($request->get('passport')))?$request->get('passport'):'';



        echo '<pre>';
        print_r($company);
        print_r($demand);
        print_r($passport);
        echo '</pre>';
        return 1;

        $candidates = \App\CandidateEntry::where('entered_by', '=', $userId)->get();

        return view('frontend.search_list')
            ->with('candidates', $candidates);

    }

    public function postIndex(Request $request){
        $searchform = $request->searchform;
//        echo '<pre>';
//        print_r($searchform);
//        echo '</pre>';
        $url = 'user/dashboard/search?company='.$searchform["company"].'&demand='.$searchform["demand"].'&passport='.$searchform["passport"];
        return redirect($url);
    }
}
