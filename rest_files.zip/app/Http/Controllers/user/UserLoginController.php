<?php

namespace App\Http\Controllers\user;

use App\CompanyAppliedFor;
use App\Menu;
use App\Post;
use App\User;
use App\Usertype;
use App\Posttype;
use App\Examboard;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use PhpMyAdmin\Session;

class UserLoginController extends Controller
{

    public function __construct(){

    }

    public function dashboard(Request $request){
        $userId = $request->session()->get('user_id');
        if(empty($userId)){
            return redirect('user')->with('error', 'Please Login..');
        }else{

            $objUser = new User();
            $user_arr = $objUser->getUserArray($userId);

            $companies = CompanyAppliedFor::join('user_company_mapping', 'company_applied_for.id', '=', 'user_company_mapping.company_id')
                ->whereIn('user_company_mapping.user_id', $user_arr)
                ->select('company_applied_for.*')
                ->get();

//            $user = User::find($userId);
                
//            $utid = $user->user_types_id;
//            
//            $usertype = Usertype::where('id', $utid)
//                ->select('user_type_slug')
//                ->first();
            
//            $objMenu = new Menu();
//            $menu = $objMenu->getSideBarMenu($userId);         
            
            // return view('frontend.userdashboard')->with('menu', $menu)->with('user', $user)->with('usertype', $usertype);
        
            return view('frontend.userdashboard')->with('companies', $companies);
            
        }

//        echo '<pre>';
//        print_r($userId);
//        echo '</pre>';
//        exit();

    }
    public function load(Request $request){
        $userId = $request->session()->get('user_id');
        $objMenu = new Menu();
        $menu = $objMenu->getSideBarMenu($userId);
        return view('front/menu')
            ->with('data', $menu);
    }
    public function login(Request $request){
        $userID = $request->session()->get('user_id');

        if (empty($userID)){
            return view('frontend/userlogin');
        }elseif(!empty($userID)) {
            return redirect('user/dashboard');
        }else{
            return view('frontend/login');
        }
    }
    public function postlogin(Request $request){

//        echo '<pre>';
//        print_r($request->password);
//        echo '</pre>';
//        exit();
        $password = Hash::make($request->password);
        $userId = User::where('email', $request->email)
            ->where('password', $password)
            ->where('status', 'Y')
            ->first();
//
//        echo '<pre>';
//        print_r($userId);
//        echo '</pre>';
//        exit();
        if (is_null($userId)) {
            return redirect('user')->with('error', 'No such UserName or Password Found or Consult with administrator!');
        } elseif(!is_null($userId)) {
            session(['user_id' => $userId->id]);
            return redirect('user/dashboard');
        }
    }
    public function register(){
        return view('frontend.usersignup');
    }
    public function postRegister(Request $request){

        $formdata = $request->formdata;
        $userId = User::where('email', $formdata['email'])->first();

//        echo '<pre>';
//        print_r($formdata['email']);
//        echo '</pre>';
//        exit();
        if(!is_null($userId)){
            return redirect('user')
                ->with('error', 'Your email address has already Registered!');
        }

        $objReg = new User();
        $objReg->name = $formdata['name'];
        $objReg->email = $formdata['email'];
        $objReg->company_name = $formdata['company_name'];
        $objReg->password = Hash::make('1234567890a');
        $objReg->email = $formdata['email'];
        $objReg->phone_no = $formdata['phone_no'];

        $objReg->status = 'N';
        $objReg->save();
        
        $time_plus = strtotime(date('Y-m-d H:i:s')) + 60*60;

        $encode = base64_encode($formdata['email'].'-'.$time_plus);

        $subject = "Registration of WECS!";

        $to = 'mukeshkchaudhary@gmail.com';

        $message = "
            <html>
            <head>
            <title>".$subject."</title>
            </head>
            <body>
            <strong>Dear Super Admin, </strong>
            <p>We have got user request on wecs.gov.np.</p>
            <p>Full Name: ".$formdata['name']."</p>
            <p>Email: ".$formdata['email']."</p>
            <p>Company: ".$formdata['company_name']."</p>
            <p>Phone: ".$formdata['phone_no']."</p>
            <p>Now click here to activate the 
            account as: <a href='".url('/')."/resetcode/".$encode."' target='_blank'></a>".url('/')."/resetcode/".$encode."</a></p>
            <p>Thank you,</p>
            </body>
            </html>
            ";

        // Always set content-type when sending HTML email
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

        // More headers
        $headers .= 'From: <info@wecs.gov.np>' . "\r\n";
        $headers .= 'Cc: akasherma.shakha@gmail.com' . "\r\n";

        if(mail($to,$subject,$message,$headers)){
            $status = 'success';
            $msg = 'Success, We receive your registration request, we will call or mail you after admin approval!';
        }else{
            $status = 'warning';
            $msg = 'Sorry, No mail sent!';

        }
        
        return redirect('user')->with($status, $msg);
        
    }
    public function userLogout(Request $request)
    {
        $request->session()->forget('user_id');
        $request->session()->forget('session_time');
        return redirect('user')->with('success','Successfully Logged Out');
    }
    public function forgotpassword(){
        return view('frontend/forgotpassword');
    }

    public function postforgotpassword(Request $request){

        $to = $request->email;

        $route = 'user';

        $res_user = User::where('email', $to)->where('status', 'Y')->first();

        if(!empty($res_user)){

        $user_type_id = 2;

//       echo '<pre>';
//       print_r($user_type_id);
//       echo '</pre>';
//       exit();

        $subject = "Reset code for ".$to;

        $msg = '';

        $time_plus = strtotime(date('Y-m-d H:i:s')) + 60*60;

        $encode = base64_encode($to.'-'.$time_plus);

        $message = "
      <html>
      <head>
      <title>".$subject."</title>
      </head>
      <body>
      <strong>Dear</strong>
      <p>Reset your activation code using <a href='".url('/').'/resetcode/'.$encode."'>".url('/').'/resetcode/'.$encode."</a></p>
      <p>Thank you,</p>
      </body>
      </html>
      ";

        // Always set content-type when sending HTML email
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

        // More headers
        $headers .= 'From: <info@wecs.gov.np>' . "\r\n";
        $headers .= 'Cc: akasherma.shakha@gmail.com' . "\r\n";

        if(mail($to,$subject,$message,$headers)){
            $status = 'success';
            $msg = 'Mail has been sent to your email. Please check it out!';

            return redirect($route)->with($status, $msg);

        }else{
            $status = 'warning';
            $msg = 'Mail has been sent to your email. Please check it out!';

            return redirect($route)->with($status, $msg);

        }

        }else{

            $status = 'warning';
            $msg = 'Please consult with the administrator!';

            return redirect($route)->with($status, $msg);

        }

    }
    
    public function resetcode($code=''){
        if($code != ''){
          $decode = base64_decode($code);
          $arr = explode('-', $decode);
          $email = $arr[0];
          // echo '<hr />';
          $expiry_time = $arr[1];
          
    //       exit();
          
          if(strtotime(date('Y-m-d H:i:s')) < $expiry_time){
            return view('frontend/resetpassword')->with('email', $email);
          }else{
            return redirect('forgotpassword')->with('error', 'Time Expired !');
          }
          
        }else{
          return redirect('forgotpassword')->with('error', 'Try Again !');
        }
      }
      
    public function postresetpwd(Request $request){
    $email = $request->email;
    //     echo '<hr />';
    $password = $request->password;
    $this_profile = User::where('email', $email)->first();
      
        $route = 'user';

        $this_profile->password = Hash::make($password);
        $this_profile->status = 'Y';
          $this_profile->save();
          
      return redirect($route)->with('success', 'Password changed successfully! LogIn now.');
    
    }
    public function profile(Request $request){
        $userId = $request->session()->get('user_id');
        $user = User::where('id', $userId)
            ->first();
            
        $utid = $user->user_types_id;
        
        $usertype = Usertype::where('id', $utid)
            ->select('user_type_slug')
            ->first();
        $objMenu = new Menu();
        $menu = $objMenu->getSideBarMenu($userId);

        if($usertype->user_type_slug == 'teacher' ) {
            return view('vendor.profile')
                ->with('menu', $menu)
                ->with('data', $user);
        }elseif($usertype->user_type_slug == 'student' ) {
            return view('student.profile')
            ->with('menu', $menu)
            ->with('data', $user);
        }else{
            return redirect('user')->with('error', 'Please Login..');
        }
    }
    public function update(Request $request){
        $userId = $request->session()->get('user_id');
        $user = User::where('id', $userId)
            ->first();
            
        $utid = $user->user_types_id;
        
        $usertype = Usertype::where('id', $utid)
            ->select('user_type_slug')
            ->first();
        $objMenu = new Menu();
        $menu = $objMenu->getSideBarMenu($userId);

        if($usertype->user_type_slug == 'teacher' ) {
            return view('vendor.profileupdate')
                ->with('menu', $menu)
                ->with('data', $user);
        }elseif($usertype->user_type_slug == 'student' ) {
            return view('student.profileupdate')
            ->with('menu', $menu)
            ->with('data', $user);
        }else{
            return redirect('user')->with('error', 'Please Login..');
        }
    }
    public function postUpdate(Request $request){
        // echo '<pre>';
        // print_r($request->image);
        // echo '</pre>';
        // exit();
        $formdata = $request->formdata;
        $objUser = User::find($formdata['id']);

        if(!is_null($request->image)){

            $this->validate($request, [
              'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            ]);

            $image = $request->file('image');
            $input['imagename'] = time().'.'.$image->getClientOriginalExtension();
            $destinationPath = public_path('/images');
            $image->move($destinationPath, $input['imagename']);

            $objUser->image = $input['imagename'];

        }

        $objUser->f_name = $formdata['f_name'];
        $objUser->m_name = $formdata['m_name'];
        $objUser->l_name = $formdata['l_name'];
        $objUser->phone = $formdata['phone'];
        $objUser->address = $formdata['address'];
        $objUser->college = $formdata['college'];
        $objUser->save();
        return redirect('user/profile')->with('success', 'Profile updated successfully!');
    }
    public function feedback(Request $request){
        $userId = $request->session()->get('user_id');
        $user = User::where('id', $userId)
            ->first();

        $utid = $user->user_types_id;

        $usertype = Usertype::where('id', $utid)
            ->select('user_type_slug')
            ->first();
        $objMenu = new Menu();
        $menu = $objMenu->getSideBarMenu($userId);
        if(is_null($userId)){
            return redirect('user')->with('error', 'Please Login..');
        }else{
            return view('frontend.feedback')
                ->with('data', $user)
                ->with('menu', $menu);

        }

    }
    public function postFeedback(Request $request){
        $formdata = $request->formdata;

        $posttype = Posttype::where('post_type_slug', 'feedback')->first();

//        echo '<pre>';
//        print_r($posttype->id);
//        echo '</pre>';
//        exit;

        $objPost = new Post();
        $objPost->post_description =$formdata['description'];
//        $objPost->post_designation =$formdata['phone'];
        $objPost->post_by =$formdata['id'];
        $objPost->post_title =$formdata['subject'];
//        $objPost->post_to =$formdata['post_to'];
//        $objPost->parent_post =$formdata['parent_post'];
        $objPost->post_types_id = $posttype->id;
//        $objPost->status =$formdata['status'];
        $objPost->save();

        return redirect('user/feedback')->with('success', 'Your Feedback is send successfully!');
    }
    public function changepwd(Request $request){
        $userId = $request->session()->get('user_id');
        $user = User::where('id', $userId)
            ->first();
        $objMenu = new Menu();
        $menu = $objMenu->getSideBarMenu($userId);
        if(is_null($userId)){
            return redirect('user')->with('error', 'Please Login..');
        }else{
            return view('frontend.changepassword')
                ->with('data', $user)
                ->with('menu', $menu);

        }
    }
    public function postChangepwd(Request $request){
        $formdata = $request->formdata;

        if($formdata['password'] != $formdata['conf-password']){
            return redirect('user/changepassword')->with('error', 'Retype your password!');
        }else{
//        echo '<pre>';
//        print_r($formdata);
//        echo '</pre>';
//        exit;

        $objUser = User::find($formdata['id']);
        $objUser->password = Hash::make($formdata['password']);
        $objUser->save();

        return redirect('user/changepassword')->with('success', 'Your password has changed!');
        }
    }
    public function forum(Request $request){

        $posttype = Posttype::where('post_type_slug', 'forum')->first();
        // echo $posttype->id;
        $forum_collection = Post::where('post_types_id', $posttype->id)->where('status', '=', '1')->where('parent_post', '<', 1)->orderBy('id', 'desc')->get();
        // dd($forum_collection);

        $data = array();
        
        foreach($forum_collection as $forum){
            $arr = array();
            $forum_collection_child = Post::where('post_types_id', $posttype->id)->where('status', '=', '1')->where('parent_post', '=', $forum->id)->orderBy('id', 'asc')->get()->toArray();
            $arr['parent'] = json_decode($forum);
            $arr['child'] = $forum_collection_child;
            array_push($data, $arr);
        }
        
        // echo '<pre>';
        // print_r($data);
        // echo '</pre>';
        // exit;

        return view('student.forum')->with('forum_collection', $data);
    }
    public function addforum(Request $request){
        $exam_board = Examboard::where('status', '1')->get();
        return view('student.addforum')->with('exam_board', $exam_board);
    }
    public function forumpost(Request $request){
        $forum_topic = $request->forum_topic;
        $exam_board_id = $request->exam_board_id;
        $userId = $request->session()->get('user_id');

        $posttype = Posttype::where('post_type_slug', 'forum')->first();

//        echo '<pre>';
//        print_r($posttype->id);
//        echo '</pre>';
//        exit;

        $objPost = new Post();
        $objPost->post_by = $userId;
        $objPost->post_title = $forum_topic;
        $objPost->post_types_id = $posttype->id;
        $objPost->exam_board_id = $exam_board_id;
        $objPost->status = '1';
        $objPost->save();

        return redirect('user/forum')->with('success', 'New Forum added successfully!');
    }
    public function forumcommentpost($parent, Request $request){

        // forum_topic_;
        
        // echo $parent;
        // echo '<hr />';
        $forum_topic = $request->forum_topic;
        $post_description = $request->post_description;

        // print_r($forum_topic);
        // echo '<hr />';

        // echo $forum_topic[$parent];
        // echo '<hr />';
        // echo $post_description[$parent];

        $userId = $request->session()->get('user_id');

        $posttype = Posttype::where('post_type_slug', 'forum')->first();

        $objPost = new Post();
        $objPost->post_by = $userId;
        $objPost->post_title = $forum_topic[$parent];
        $objPost->parent_post = $parent;
        $objPost->post_description = $post_description[$parent];
        $objPost->post_types_id = $posttype->id;
        $objPost->status = '1';
        $objPost->save();

        // exit();

        // $exam_board_id = $request->exam_board_id;

//        echo '<pre>';
//        print_r($posttype->id);
//        echo '</pre>';
//        exit;


        return redirect('user/forum')->with('success', 'New Forum added successfully!');
    }
}
