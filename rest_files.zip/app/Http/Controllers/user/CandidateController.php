<?php

namespace App\Http\Controllers\user;

use App\CandidateEntryMeta;
use App\Demand;
use App\DemandEntry;
use App\EntryStatus;
use App\EntryStatusMeta;
use App\Experience;
use App\Qualification;
use App\QualificationType;
use App\Reference;
use App\User;
use Faker\Provider\Company;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\CandidateEntry;
use App\CountryAppliedFor;
use App\CompanyAppliedFor;
use App\Position;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;


class CandidateController extends Controller
{
    public function index(Request $request){
        
        $userId = $request->session()->get('user_id');

        $objUser = new User();
        $user_arr = $objUser->getUserArray($userId);

        if(is_null($userId)){
            return redirect('user')->with('error', 'Please Login..');
        }else{

            $candidates = CandidateEntry::leftJoin('reference', 'candidate_entry.reference_by', '=', 'reference.id')
                ->leftJoin('position', 'position.id', '=', 'candidate_entry.position_applied_for')
                ->leftJoin('company_applied_for', 'company_applied_for.id', '=', 'candidate_entry.company_applied_for')
                ->leftJoin('entry_status', 'entry_status.id', '=', 'candidate_entry.entry_status')
                ->select('reference.reference_name', 'position.position_name', 'entry_status.entry_status_name', 'company_applied_for.company_applied_for_name', 'candidate_entry.*')
                ->whereIn('candidate_entry.entered_by', $user_arr)
                ->where('candidate_entry.status', 'Y')
                ->where('candidate_entry.entry_reg_no','!=', '')->get();

//            echo '<pre>';
//            print_r($user_arr);
//            echo '</pre>';
//
//            echo '<pre>';
//            print_r(json_decode($candidates));
//            echo '</pre>';
//            exit();
            
//            $user = User::find($userId);
                
//            $utid = $user->user_types_id;
//            
//            $usertype = Usertype::where('id', $utid)
//                ->select('user_type_slug')
//                ->first();
            
//            $objMenu = new Menu();
//            $menu = $objMenu->getSideBarMenu($userId);         
            
            // return view('frontend.userdashboard')->with('menu', $menu)->with('user', $user)->with('usertype', $usertype);
        
            return view('frontend.candidate_list')
                ->with('candidates', $candidates);

        }
    }

    public function search(Request $request){

        $userId = $request->session()->get('user_id');

        $objUser = new User();
        $user_arr = $objUser->getUserArray($userId);

//        ->whereIn('entered_by', $user_arr)->get();

//        $currentUser = \App\User::find($userId);
//        $company_user_id = (!empty($currentUser->parent_id))?$currentUser->parent_id:$userId;

        $positions = Position::where('status', 'Y')->get();

        $reference_list = Reference::join('user_reference_mapping', 'reference.id', '=', 'user_reference_mapping.reference_id')
            ->whereIn('user_reference_mapping.user_id', $user_arr)
            ->select('reference.*')
            ->get();

        $demand_list = Demand::whereIn('entered_by', $user_arr)->get();

        $entry_status_lists = EntryStatus::where('status', 'Y')->where('list_status', 'Y')->orderBy('entry_status_order', 'asc')->get();

        $entry_status_meta = array();

        if(!empty($entry_status_lists)){
            foreach($entry_status_lists as $entry_status_list){

                $objEntryStatusMeta = EntryStatusMeta::where('entry_status_id', $entry_status_list->id)->where('status', 'Y')->orderBy('entry_status_order', 'asc')->get();

                $entry_status_meta[$entry_status_list->id] = json_decode($objEntryStatusMeta);

            }
        }

        $company_applied_for = CompanyAppliedFor::join('user_company_mapping', 'company_applied_for.id', '=', 'user_company_mapping.company_id')
            ->whereIn('user_company_mapping.user_id', $user_arr)
            ->select('company_applied_for.*')
            ->get();

        $country_applied_for = CountryAppliedFor::where('status', 'Y')->get();

//        echo '<pre>';
//        print_r(json_decode($entry_status_lists));
//        echo '<hr />';
//        print_r($entry_status_meta);
//        echo '</pre>';
//        exit();

        if(is_null($userId)){
            return redirect('user')->with('error', 'Please Login..');
        }else{

            $search_for_company = (!empty($request->get('company')))?$request->get('company'):''; // from company table
            $search_for_demand_ref = (!empty($request->get('demand_ref')))?$request->get('demand_ref'):''; // from demand table
            $search_for_candidate = (!empty($request->get('candidate')))?$request->get('candidate'):''; // from candidate_entry
            $search_for_passport_no = (!empty($request->get('passport_no')))?$request->get('passport_no'):''; // from candidate_entry
            $search_for_position = (!empty($request->get('position')))?$request->get('position'):''; // from position
            $search_for_referred_by = (!empty($request->get('referred_by')))?$request->get('referred_by'):''; // from reference table

            $company = str_replace(" ", '%', $search_for_company);
            // $company = str_replace("+", '%', $company);
            $demand_ref = str_replace(" ", '%', $search_for_demand_ref);
            $candidate = $search_for_candidate;
            $passport_no = str_replace(" ", '%', $search_for_passport_no);
            $position = str_replace(" ", '%', $search_for_position);
            $referred_by = str_replace(" ", '%', $search_for_referred_by);

            $candidates_pp_return = CandidateEntry::join('candidate_entry_meta', 'candidate_entry.id', '=', 'candidate_entry_meta.candidate_entry_id')
                ->join('entry_status', 'entry_status.id', '=', 'candidate_entry_meta.entry_status_id')
                ->join('company_applied_for', 'company_applied_for.id', '=', 'candidate_entry.company_applied_for')
                ->join('position', 'position.id', '=', 'candidate_entry.position_applied_for')
                ->join('reference', 'reference.id', '=', 'candidate_entry.reference_by')
                ->where('candidate_entry.status', 'Y')
                ->where('entry_status.entry_status_slug', 'pp-return')
                ->whereIn('candidate_entry.entered_by', $user_arr)
                ->where(DB::raw("CONCAT_WS(candidate_entry.first_name,' ',candidate_entry.middle_name, ' ',candidate_entry.last_name)"), 'like', '%'.$candidate.'%')
                ->where('company_applied_for.company_applied_for_name','like', '%'.$company.'%')
                ->where('candidate_entry.passport_no','like', '%'.$passport_no.'%')
                ->where('position.position_name', 'like', '%'.$position.'%')
                ->where('reference.reference_name', 'like', '%'.$referred_by.'%')
                ->pluck('candidate_entry.id')
                ->toArray();

            // echo '<pre>';
            // print_r($candidates_pp_return);
            // echo '</pre>';
            // exit();
            
            $candidates_pp_return = (is_array($candidates_pp_return) && count($candidates_pp_return) > 0)?$candidates_pp_return:array(0);

            if($demand_ref != ''){

                $candidates = CandidateEntry::join('demand', 'demand.id', '=', 'candidate_entry.demand_id')
                    ->join('company_applied_for', 'company_applied_for.id', '=', 'candidate_entry.company_applied_for')
                    ->join('position', 'position.id', '=', 'candidate_entry.position_applied_for')
                    ->join('reference', 'reference.id', '=', 'candidate_entry.reference_by')
                    ->select('candidate_entry.*', 'company_applied_for.company_applied_for_name', 'position.position_name', 'reference.reference_name', 'demand.demand_no')
                    ->where('candidate_entry.status', 'Y')
                    ->whereIn('candidate_entry.entered_by', $user_arr)
                    ->where('demand.demand_no', 'like', '%'.$demand_ref.'%')
                    ->where(DB::raw("CONCAT_WS(candidate_entry.first_name,' ',candidate_entry.middle_name, ' ',candidate_entry.last_name)"), 'like', '%'.$candidate.'%')
                    ->where('company_applied_for.company_applied_for_name','like', '%'.$company.'%')
                    ->where('candidate_entry.passport_no','like', '%'.$passport_no.'%')
                    ->where('position.position_name', 'like', '%'.$position.'%')
                    ->where('reference.reference_name', 'like', '%'.$referred_by.'%')
                    ->whereNotIn('candidate_entry.id', $candidates_pp_return)
                    ->get();

            }else{

                $candidates = CandidateEntry::join('company_applied_for', 'company_applied_for.id', '=', 'candidate_entry.company_applied_for')
                    ->join('position', 'position.id', '=', 'candidate_entry.position_applied_for')
                    ->join('reference', 'reference.id', '=', 'candidate_entry.reference_by')
                    ->leftJoin('demand', 'demand.id', '=', 'candidate_entry.demand_id')
                    ->select('candidate_entry.*', 'company_applied_for.company_applied_for_name', 'position.position_name', 'reference.reference_name', 'demand.demand_no')
                    ->where('candidate_entry.status', 'Y')
                    ->whereIn('candidate_entry.entered_by', $user_arr)
                    ->where(DB::raw("CONCAT_WS(candidate_entry.first_name,' ',candidate_entry.middle_name, ' ',candidate_entry.last_name)"), 'like', '%'.$candidate.'%')
                    ->where('company_applied_for.company_applied_for_name','like', '%'.$company.'%')
                    ->where('candidate_entry.passport_no','like', '%'.$passport_no.'%')
                    ->where('position.position_name', 'like', '%'.$position.'%')
                    ->where('reference.reference_name', 'like', '%'.$referred_by.'%')
                    ->whereNotIn('candidate_entry.id', $candidates_pp_return)
                    ->get();

            }

            return view('frontend.search_list')
                ->with('candidates', $candidates)
                ->with('reference_list', $reference_list)
                ->with('entry_status_lists', $entry_status_lists)
                ->with('entry_status_meta', $entry_status_meta)
                ->with('position', $positions)
                ->with('demand_list', $demand_list)
                ->with('company_applied_for', $company_applied_for)
                ->with('country_applied_for', $country_applied_for)
                ->with('search_for_company', $search_for_company)
                ->with('search_for_demand_ref', $search_for_demand_ref)
                ->with('search_for_candidate', $search_for_candidate)
                ->with('search_for_passport_no', $search_for_passport_no)
                ->with('search_for_position', $search_for_position)
                ->with('search_for_referred_by', $search_for_referred_by);

        }
    }

    public function create(Request $request){

        $userId = $request->session()->get('user_id');

        $objUser = new User();
        $user_arr = $objUser->getUserArray($userId);

//        $demands = Demand::whereIn('entered_by', $user_arr)->get();

        if(is_null($userId))
            return redirect('user')->with('error', 'Please Login..');

        $candidates = CandidateEntry::whereIn('entered_by', $user_arr)
            ->where('entry_reg_no', '>', 0)->orderBy('entry_reg_no', 'DESC')->first();

        $entry_reg_no = (!empty(($candidates->entry_reg_no)))?(((int)$candidates->entry_reg_no) + 1):1;

//        echo '<pre>';
//        print_r(json_decode($candidates));

        $objCandidateEntry = new CandidateEntry();
//        $objCandidateEntry->entry_reg_no = $entry_reg_no;
        $objCandidateEntry->entered_by = $userId;
        $objCandidateEntry->status = 'N';
        $objCandidateEntry->save();

//        echo '<pre>';
//        print_r(json_decode($objCandidateEntry));
//
//        exit();

        if($objCandidateEntry->save())
            return redirect('/user/dashboard/candidate/edit/'.$objCandidateEntry->id);

//        echo '<pre>';
//        print_r($candidates);
//        echo '</pre>';
//
//        echo $entry_reg_no = $candidates;
//        exit();

//        $objCandidate = new \stdClass();
//        $objCandidate->id = '';
//        $objCandidate->entry_reg_no = '';
//        $objCandidate->first_name = '';
//        $objCandidate->middle_name = '';
//        $objCandidate->last_name = '';
//        $objCandidate->passport_no = '';
//        $objCandidate->dob = '';
//        $objCandidate->address = '';
//        $objCandidate->district = '';
//        $objCandidate->qualification = '';
//        $objCandidate->experience = '';
//        $objCandidate->passport_expiry_date = '';
//        $objCandidate->passport_issue_date = '';
//        $objCandidate->place_of_issue = '';
//        $objCandidate->next_to_kin = '';
//        $objCandidate->relation_with_kin = '';
//        $objCandidate->reference_by = '';
//        $objCandidate->country_applied_for = '';
//        $objCandidate->company_applied_for = '';
//        $objCandidate->position_applied_for = '';
//        $objCandidate->contact_no = '';
//        $objCandidate->attachment = '';
//        $objCandidate->certificates = '';
//        $objCandidate->photographs = '';
//        $objCandidate->remarks = '';
//        $objCandidate->entry_by = '';
//        $objCandidate->entry_status = '';
//        $objCandidate->status = '';
//
//        $candidate_entry = CandidateEntry::where('status', '=', 'Y')->whereIn('entered_by', $user_arr)->get()->toArray();
//
//        $country_applied_for = CountryAppliedFor::where('status', 'Y')->get();
//
//        $qualification_type = QualificationType::where('status', 'Y')->get();
//
//        $position = Position::where('status', 'Y')->orderBy('position_name')->get();
//
//        $company_applied_for = CompanyAppliedFor::join('user_company_mapping', 'company_applied_for.id', '=', 'user_company_mapping.company_id')
//            ->whereIn('user_company_mapping.user_id', $user_arr)
//            ->select('company_applied_for.*')
//            ->get();
//
//        $reference_list = Reference::join('user_reference_mapping', 'reference.id', '=', 'user_reference_mapping.reference_id')
//            ->whereIn('user_reference_mapping.user_id', $user_arr)
//            ->select('reference.*')
//            ->get();
//
//        return view('frontend.add_candidate')
//            ->with('candidate_entry', $candidate_entry)
//            ->with('demands', $demands)
//            ->with('company_applied_for', $company_applied_for)
//            ->with('country_applied_for', $country_applied_for)
//            ->with('qualification_type', $qualification_type)
//            ->with('position', $position)
//            ->with('reference_list', $reference_list);
    }

    public function update(Request $request, $candidate_id){

        $userId = $request->session()->get('user_id');

        $objUser = new User();
        $user_arr = $objUser->getUserArray($userId);

        $demands = Demand::whereIn('entered_by', $user_arr)->get();

        if(is_null($userId))
            return redirect('user')->with('error', 'Please Login..');

        $candidate_entry = CandidateEntry::find($candidate_id);

//        echo '<pre>';
//        print_r(json_decode($candidate_entry));
//        echo '</pre>';
//
//        exit();

        $country_applied_for = CountryAppliedFor::where('status', 'Y')->orderBy('country_applied_for_name', 'ASC')->get();

        $qualification_type = QualificationType::where('status', 'Y')->get();

        $position = Position::where('status', 'Y')->orderBy('position_name', 'ASC')->get();

        $entry_status = EntryStatus::where('status', 'Y')->get();

        $company_applied_for = CompanyAppliedFor::join('user_company_mapping', 'company_applied_for.id', '=', 'user_company_mapping.company_id')
            ->whereIn('user_company_mapping.user_id', $user_arr)
            ->select('company_applied_for.*')
            ->orderBy('company_applied_for.company_applied_for_name', 'ASC')
            ->get();

        $reference_list = Reference::join('user_reference_mapping', 'reference.id', '=', 'user_reference_mapping.reference_id')
            ->whereIn('user_reference_mapping.user_id', $user_arr)
            ->select('reference.*')
            ->orderBy('reference.reference_name', 'ASC')
            ->get();

        $qualifications = Qualification::where('candidate_id', $candidate_id)->get();

        $experiences = Experience::where('candidate_id', $candidate_id)->get();

        $additionals = array();

        $objAdditional = CandidateEntryMeta::where('candidate_entry_id', $candidate_id)
            ->where('source', 'additional')
            ->where('status', 'Y')
            ->get();

        if(!empty($objAdditional)){
            foreach($objAdditional as $additional){
                $additionals[$additional->candidate_entry_meta_key] = $additional->candidate_entry_meta_value;
            }
        }

        $attachments = array();

        $objAttachment = CandidateEntryMeta::where('candidate_entry_id', $candidate_id)
            ->where('source', 'attachment')
            ->where('status', 'Y')
            ->get();

        if(!empty($objAttachment)){
            foreach($objAttachment as $attachment){
                $attachments[$attachment->candidate_entry_meta_key] = $attachment->candidate_entry_meta_value;
            }
        }

//        echo '<pre>';
//        print_r($additionals);
//        echo '</pre>';
//        exit();

        return view('frontend.edit_candidate')
            ->with('candidate_entry', $candidate_entry)
            ->with('entry_status', $entry_status)
            ->with('experiences', $experiences)
            ->with('additionals', $additionals)
            ->with('attachments', $attachments)
            ->with('qualifications', $qualifications)
            ->with('demands', $demands)
            ->with('company_applied_for', $company_applied_for)
            ->with('country_applied_for', $country_applied_for)
            ->with('qualification_type', $qualification_type)
            ->with('position', $position)
            ->with('reference_list', $reference_list);
    }

    public function view(Request $request, $candidate_id){

        $userId = $request->session()->get('user_id');

        $userinfo = User::find($userId);

        $objUser = new User();
        $user_arr = $objUser->getUserArray($userId);

        $parent_id = $objUser->getParentId($userId);

        $company_info = User::find($parent_id);

        $demands = Demand::whereIn('entered_by', $user_arr)->get();

        if(is_null($userId))
            return redirect('user')->with('error', 'Please Login..');

//        $candidate_entry = CandidateEntry::find($candidate_id);

        $candidate_entry = CandidateEntry::leftJoin('company_applied_for', 'company_applied_for.id', '=', 'candidate_entry.company_applied_for')
            ->leftJoin('reference', 'reference.id', '=', 'candidate_entry.reference_by')
            ->leftJoin('position', 'position.id', '=', 'candidate_entry.position_applied_for')
            ->select('candidate_entry.*', 'reference.reference_name', 'position.position_name', 'company_applied_for.company_applied_for_name')
            ->where('candidate_entry.status', 'Y')
            ->where('candidate_entry.id', $candidate_id)
            ->first();

//        echo '<pre>';
//        print_r(json_decode($candidate_entry));
//        echo '</pre>';
//        exit();

        $country_applied_for = CountryAppliedFor::where('status', 'Y')->get();

        $qualification_type = QualificationType::where('status', 'Y')->get();

        $position = Position::where('status', 'Y')->get();

        $entry_status = EntryStatus::where('status', 'Y')->get();

        $company_applied_for = CompanyAppliedFor::join('user_company_mapping', 'company_applied_for.id', '=', 'user_company_mapping.company_id')
            ->whereIn('user_company_mapping.user_id', $user_arr)
            ->select('company_applied_for.*')
            ->get();

        $reference_list = Reference::join('user_reference_mapping', 'reference.id', '=', 'user_reference_mapping.reference_id')
            ->whereIn('user_reference_mapping.user_id', $user_arr)
            ->select('reference.*')
            ->get();

        $qualifications = Qualification::join('qualification_type', 'qualification_type.id', '=', 'qualification.qualification_type_id')
            ->select('qualification.*', 'qualification_type.qualification_type_name')
            ->where('qualification.candidate_id', $candidate_id)->get();

        $experiences = Experience::where('candidate_id', $candidate_id)->get();

        $additionals = array();

        $objAdditional = CandidateEntryMeta::where('candidate_entry_id', $candidate_id)
            ->where('source', 'additional')
            ->where('status', 'Y')
            ->get();

        if(!empty($objAdditional)){
            foreach($objAdditional as $additional){
                $additionals[$additional->candidate_entry_meta_key] = $additional->candidate_entry_meta_value;
            }
        }

        $attachments = array();

        $objAttachment = CandidateEntryMeta::where('candidate_entry_id', $candidate_id)
            ->where('source', 'attachment')
            ->where('status', 'Y')
            ->get();

        if(!empty($objAttachment)){
            foreach($objAttachment as $attachment){
                $attachments[$attachment->candidate_entry_meta_key] = $attachment->candidate_entry_meta_value;
            }
        }

//        echo '<pre>';
//        print_r($attachments);
//        echo '</pre>';
//        exit();

        return view('frontend.view_candidate')
            ->with('candidate_entry', $candidate_entry)
            ->with('entry_status', $entry_status)
            ->with('experiences', $experiences)
            ->with('additionals', $additionals)
            ->with('attachments', $attachments)
            ->with('qualifications', $qualifications)
            ->with('demands', $demands)
            ->with('company_applied_for', $company_applied_for)
            ->with('country_applied_for', $country_applied_for)
            ->with('qualification_type', $qualification_type)
            ->with('position', $position)
            ->with('company_info', $company_info)
            ->with('userinfo', $userinfo)
            ->with('reference_list', $reference_list);
    }

    public function postCreate(Request $request) {

//        echo $user_id = Auth::user()->id;

        $user_id = $request->session()->get('user_id');

        $formdata = $request->formdata;

        $qualification = $request->qualification;

        $experience = $request->experience;

        $additional = $request->additional;

        $attachment = $request->attachment;

//        echo '<pre>';
//        print_r($formdata);
//        print_r($qualification);
//        print_r($experience);
//        print_r($additional);
//        print_r($attachment);
//        echo '</pre>';
//        exit();

        $objCandidateEntry = new CandidateEntry();
        $objCandidateEntry->first_name = $formdata['first_name'];
        $objCandidateEntry->middle_name = $formdata['middle_name'];
        $objCandidateEntry->last_name = $formdata['last_name'];
//        $objCandidateEntry->demand_id = $formdata['demand_id'];
        $objCandidateEntry->passport_no = $formdata['passport_no'];
        $objCandidateEntry->dob = date('Y-m-d', strtotime($formdata['dob']));
        $objCandidateEntry->address = $formdata['address'];
        $objCandidateEntry->gender = $formdata['gender'];
        $objCandidateEntry->passport_expiry_date = date('Y-m-d', strtotime($formdata['passport_expiry_date']));
        $objCandidateEntry->passport_issue_date = date('Y-m-d', strtotime($formdata['passport_issue_date']));
        $objCandidateEntry->place_of_issue = $formdata['place_of_issue'];
        $objCandidateEntry->next_to_kin = $formdata['next_to_kin'];
        $objCandidateEntry->relation_with_kin = $formdata['relation_with_kin'];
        $objCandidateEntry->reference_by = $formdata['reference_by'];
        $objCandidateEntry->country_applied_for = $formdata['country_applied_for'];
        $objCandidateEntry->company_applied_for = $formdata['company_applied_for'];
        $objCandidateEntry->position_applied_for = $formdata['position_applied_for'];
        $objCandidateEntry->contact_no = $formdata['contact_no'];
        $objCandidateEntry->email = $formdata['email'];
        $objCandidateEntry->remarks = $formdata['remarks'];
        $objCandidateEntry->entered_by = $user_id;
        $objCandidateEntry->status = 'Y';

        if($objCandidateEntry->save()){
            $objCandidateEntryRegNo = CandidateEntry::find($objCandidateEntry->id);
            $objCandidateEntryRegNo->entry_reg_no = $formdata['entry_reg_no'];
            $objCandidateEntryRegNo->save();

            if(!empty($qualification) && is_array($qualification)){
                $qualification_type_id = (!empty($qualification['qualification_type_id']))?$qualification['qualification_type_id']:array();
                $board = (!empty($qualification['board']))?$qualification['board']:array();
                $year = (!empty($qualification['year']))?$qualification['year']:array();
                $division = (!empty($qualification['division']))?$qualification['division']:array();

                if(!empty($qualification_type_id) && is_array($qualification_type_id)){
                    for($i = 0; $i < count($qualification_type_id); $i++){
                        $objQualification = new Qualification();
                        $objQualification->candidate_id = $objCandidateEntry->id;
                        $objQualification->qualification_type_id = (!empty($qualification_type_id[$i]))?$qualification_type_id[$i]:0;
                        $objQualification->board = (!empty($board[$i]))?$board[$i]:'';
                        $objQualification->year = (!empty($year[$i]))?$year[$i]:'';
                        $objQualification->division = (!empty($division[$i]))?$division[$i]:'';
                        $objQualification->status = 'Y';
                        $objQualification->save();
                    }
                }
            }

            if(!empty($experience) && is_array($experience)){

                $gcc_exp = (!empty($experience['gcc_exp']))?$experience['gcc_exp']:array();
                $exp_from = (!empty($experience['exp_from']))?$experience['exp_from']:array();
                $exp_to = (!empty($experience['exp_to']))?$experience['exp_to']:array();
                $no_of_exp_in_years = (!empty($experience['no_of_exp_in_years']))?$experience['no_of_exp_in_years']:array();
                $country = (!empty($experience['country']))?$experience['country']:array();
                $company = (!empty($experience['company']))?$experience['company']:array();
                $designation = (!empty($experience['designation']))?$experience['designation']:array();
                $job_details = (!empty($experience['job_details']))?$experience['job_details']:array();

                if(!empty($designation) && is_array($designation)){
                    for($i = 0; $i < count($designation); $i++){
                        $objExperience = new Experience();
                        $objExperience->candidate_id = $objCandidateEntry->id;
                        $objExperience->gcc_exp = (!empty($gcc_exp))?$gcc_exp:'';
                        $objExperience->exp_from = (!empty($exp_from[$i]))?$exp_from[$i]:'';
                        $objExperience->exp_to = (!empty($exp_to[$i]))?$exp_to[$i]:'';
                        $objExperience->no_of_exp_in_years = (!empty($no_of_exp_in_years[$i]))?$no_of_exp_in_years[$i]:0;
                        $objExperience->country = (!empty($country[$i]))?$country[$i]:'';
                        $objExperience->company = (!empty($company[$i]))?$company[$i]:'';
                        $objExperience->designation = (!empty($designation[$i]))?$designation[$i]:'';
                        $objExperience->job_details = (!empty($job_details[$i]))?$job_details[$i]:'';
                        $objExperience->status = 'Y';
                        $objExperience->save();
                    }

                }
            }

            if(!empty($additional) && is_array($additional)){
                foreach($additional as $key=>$value){
                    $objCandidateEntryMeta = new CandidateEntryMeta();
                    $objCandidateEntryMeta->candidate_entry_id = $objCandidateEntry->id;
                    $objCandidateEntryMeta->candidate_entry_meta_key = $key;
                    $objCandidateEntryMeta->candidate_entry_meta_value = $value;
                    $objCandidateEntryMeta->source = 'additional';
                    $objCandidateEntryMeta->status = 'Y';

                }
            }

            if(!empty($attachment) && is_array($attachment)){
                $title = (!empty($attachment['title']))?$attachment['title']:array();
                $file = (!empty($attachment['file']))?$attachment['file']:array();

                // $file = $attachment['file'];

                if(!empty($file) && is_array($file)){
                    for($i = 0; $i < count($file); $i++){

                        $objCandidateEntryMeta = new CandidateEntryMeta();
                        $objCandidateEntryMeta->candidate_entry_id = $objCandidateEntry->id;
                        $objCandidateEntryMeta->candidate_entry_meta_key = (!empty($title[$i]))?$title[$i]:'';
                        $objCandidateEntryMeta->source = 'attachment';
                        $objCandidateEntryMeta->status = 'Y';

                        if(!empty($file[$i])){

                            $image = $file[$i];
                            $input['imagename'] = 'img-'.$i.time().'.'.$image->getClientOriginalExtension();
                            $destinationPath = public_path('/images');
                            $image->move($destinationPath, $input['imagename']);
//                            $arr['post_image'] = $input['imagename'];
                            $objCandidateEntryMeta->candidate_entry_meta_value = $input['imagename'];

                        }

                        $objCandidateEntryMeta->save();

                    }

                }
            }

            return redirect('user/dashboard/candidate/edit/'.$objCandidateEntry->id)->with('success', 'candidate added successfully!');


        }else{
            return redirect('user/dashboard/candidate')->with('error', 'candidate cannot be added!');
        }


    }

    public function postUpdate(Request $request) {

//        echo $user_id = Auth::user()->id;

        $user_id = $request->session()->get('user_id');

        $objUser = new User();
        $user_arr = $objUser->getUserArray($user_id);

        $formdata = $request->formdata;

        $qualification = $request->qualification;

        $experience = $request->experience;

        $additional = $request->additional;

        $attachment = $request->attachment;

        $check_entry_reg_no = CandidateEntry::find($formdata['id']);

//        echo '<pre>';
//        print_r($formdata);
//        print_r($qualification);
//        print_r($experience);
//        print_r($additional);
//        print_r($attachment);
//        echo '</pre>';
//        exit();

        $objCandidateEntry = CandidateEntry::find($formdata['id']);
        $objCandidateEntry->first_name = $formdata['first_name'];
        $objCandidateEntry->middle_name = $formdata['middle_name'];
        $objCandidateEntry->last_name = $formdata['last_name'];
//        $objCandidateEntry->demand_id = $formdata['demand_id'];

        if(empty($check_entry_reg_no->entry_reg_no)){

            $candidates = CandidateEntry::whereIn('entered_by', $user_arr)
                ->where('entry_reg_no', '>', 0)->orderBy('entry_reg_no', 'DESC')->first();

            $entry_reg_no = (!empty(($candidates->entry_reg_no)))?(((int)$candidates->entry_reg_no) + 1):1;

            $objCandidateEntry->entry_reg_no = $entry_reg_no;
        }


        $objCandidateEntry->passport_no = $formdata['passport_no'];

        $formdata['dob'] = $formdata['dob_y'].'-'.$formdata['dob_m'].'-'.$formdata['dob_d'];

        $objCandidateEntry->dob = date('Y-m-d', strtotime($formdata['dob']));

        $objCandidateEntry->address = $formdata['address'];
        $objCandidateEntry->gender = $formdata['gender'];

        $formdata['passport_expiry_date'] = $formdata['passport_expiry_date_y'].'-'.$formdata['passport_expiry_date_m'].'-'.$formdata['passport_expiry_date_d'];

        $objCandidateEntry->passport_expiry_date = date('Y-m-d', strtotime($formdata['passport_expiry_date']));

        $formdata['passport_issue_date'] = $formdata['passport_issue_date_y'].'-'.$formdata['passport_issue_date_m'].'-'.$formdata['passport_issue_date_d'];

        $objCandidateEntry->passport_issue_date = date('Y-m-d', strtotime($formdata['passport_issue_date']));

        $objCandidateEntry->place_of_issue = $formdata['place_of_issue'];
        $objCandidateEntry->next_to_kin = $formdata['next_to_kin'];
        $objCandidateEntry->relation_with_kin = $formdata['relation_with_kin'];
        $objCandidateEntry->reference_by = $formdata['reference_by'];
        $objCandidateEntry->country_applied_for = $formdata['country_applied_for'];
        $objCandidateEntry->company_applied_for = $formdata['company_applied_for'];
        $objCandidateEntry->position_applied_for = $formdata['position_applied_for'];
        $objCandidateEntry->contact_no = $formdata['contact_no'];
        $objCandidateEntry->email = $formdata['email'];
        $objCandidateEntry->remarks = $formdata['remarks'];
        $objCandidateEntry->entered_by = $user_id;
        $objCandidateEntry->status = 'Y';

        if($objCandidateEntry->save()){

            Qualification::where('candidate_id', $formdata['id'])->delete();

            if(!empty($qualification) && is_array($qualification)){
                $qualification_type_id = (!empty($qualification['qualification_type_id']))?$qualification['qualification_type_id']:array();
                $board = (!empty($qualification['board']))?$qualification['board']:array();
                $year = (!empty($qualification['year']))?$qualification['year']:array();
                $division = (!empty($qualification['division']))?$qualification['division']:array();

                if(!empty($qualification_type_id) && is_array($qualification_type_id)){
                    for($i = 0; $i < count($qualification_type_id); $i++){
                        if((!empty($qualification_type_id[$i]))){
                            $objQualification = new Qualification();
                            $objQualification->candidate_id = $objCandidateEntry->id;
                            $objQualification->qualification_type_id = $qualification_type_id[$i];
                            $objQualification->board = (!empty($board[$i]))?$board[$i]:'';
                            $objQualification->year = (!empty($year[$i]))?$year[$i]:'';
                            $objQualification->division = (!empty($division[$i]))?$division[$i]:'';
                            $objQualification->status = 'Y';
                            $objQualification->save();

                        }
                    }
                }
            }

            Experience::where('candidate_id', $formdata['id'])->delete();

            if(!empty($experience) && is_array($experience)){

                $gcc_exp = (!empty($experience['gcc_exp']))?$experience['gcc_exp']:array();
                $exp_from = (!empty($experience['exp_from']))?$experience['exp_from']:array();
                $exp_to = (!empty($experience['exp_to']))?$experience['exp_to']:array();
                $no_of_exp_in_years = (!empty($experience['no_of_exp_in_years']))?$experience['no_of_exp_in_years']:array();
                $country = (!empty($experience['country']))?$experience['country']:array();
                $company = (!empty($experience['company']))?$experience['company']:array();
                $designation = (!empty($experience['designation']))?$experience['designation']:array();
                $job_details = (!empty($experience['job_details']))?$experience['job_details']:array();

                if(!empty($designation) && is_array($designation)){
                    for($i = 0; $i < count($designation); $i++){
                        if(!empty($designation[$i])){
                            $objExperience = new Experience();
                            $objExperience->candidate_id = $objCandidateEntry->id;
                            $objExperience->gcc_exp = (!empty($gcc_exp))?$gcc_exp:'';
                            $objExperience->exp_from = (!empty($exp_from[$i]))?$exp_from[$i]:'';
                            $objExperience->exp_to = (!empty($exp_to[$i]))?$exp_to[$i]:'';
                            $objExperience->no_of_exp_in_years = (!empty($no_of_exp_in_years[$i]))?$no_of_exp_in_years[$i]:0;
                            $objExperience->country = (!empty($country[$i]))?$country[$i]:'';
                            $objExperience->company = (!empty($company[$i]))?$company[$i]:'';
                            $objExperience->designation = (!empty($designation[$i]))?$designation[$i]:'';
                            $objExperience->job_details = (!empty($job_details[$i]))?$job_details[$i]:'';
                            $objExperience->status = 'Y';
                            $objExperience->save();
                        }
                    }

                }
            }

            CandidateEntryMeta::where('candidate_entry_id', $formdata['id'])->where('source', 'additional')->delete();

            if(!empty($additional) && is_array($additional)){
                foreach($additional as $key=>$value){
                    $objCandidateEntryMeta = new CandidateEntryMeta();
                    $objCandidateEntryMeta->candidate_entry_id = $objCandidateEntry->id;
                    $objCandidateEntryMeta->candidate_entry_meta_key = $key;
                    $objCandidateEntryMeta->candidate_entry_meta_value = $value;
                    $objCandidateEntryMeta->source = 'additional';
                    $objCandidateEntryMeta->status = 'Y';
                }
            }

            CandidateEntryMeta::where('candidate_entry_id', $formdata['id'])->where('source', 'attachment')->delete();

            if(!empty($attachment) && is_array($attachment)){
                $title = (!empty($attachment['title']))?$attachment['title']:array();
                $title_txt = (!empty($attachment['title_txt']))?$attachment['title_txt']:array();
                $file = (!empty($attachment['file']))?$attachment['file']:array();
                $file_txt = (!empty($attachment['file_txt']))?$attachment['file_txt']:array();

                // $file = $attachment['file'];

                if(!empty($file) && is_array($file)){
                    for($i = 0; $i < count($file); $i++){

                        $objCandidateEntryMeta = new CandidateEntryMeta();
                        $objCandidateEntryMeta->candidate_entry_id = $objCandidateEntry->id;
                        $objCandidateEntryMeta->candidate_entry_meta_key = (!empty($title[$i]))?$title[$i]:'';
                        $objCandidateEntryMeta->source = 'attachment';
                        $objCandidateEntryMeta->status = 'Y';

                        if(!empty($file[$i])){

                            $image = $file[$i];
                            $input['imagename'] = 'img-'.$i.time().'.'.$image->getClientOriginalExtension();
                            $destinationPath = public_path('/images');
                            $image->move($destinationPath, $input['imagename']);
//                            $arr['post_image'] = $input['imagename'];
                            $objCandidateEntryMeta->candidate_entry_meta_value = $input['imagename'];

                        }

                        $objCandidateEntryMeta->save();

                    }

                }else if(!empty($file_txt) && is_array($file_txt)){
                    for($i = 0; $i < count($file_txt); $i++){

                        $objCandidateEntryMeta = new CandidateEntryMeta();
                        $objCandidateEntryMeta->candidate_entry_id = $objCandidateEntry->id;
                        $objCandidateEntryMeta->candidate_entry_meta_key = (!empty($title_txt[$i]))?$title_txt[$i]:'';
                        $objCandidateEntryMeta->candidate_entry_meta_value = (!empty($file_txt[$i]))?$file_txt[$i]:'';
                        $objCandidateEntryMeta->source = 'attachment';
                        $objCandidateEntryMeta->status = 'Y';

                        $objCandidateEntryMeta->save();

                    }
                }
            }

            return redirect('user/dashboard/candidate/edit/'.$formdata['id'])->with('success', 'Candidate updated successfully!');

        }else{
            return redirect('user/dashboard/candidate')->with('error', 'Candidate cannot be added!');
        }


    }

    public function demandlist(Request $request){

        $userId = $request->session()->get('user_id');

        $currentUser = \App\User::find($userId);
        $parent_id = (!empty($currentUser->parent_id))?$currentUser->parent_id:$userId;

        $objUser = new User();
        $user_arr = $objUser->getUserArray($userId);

//        ->whereIn('entered_by', $user_arr)->get();

//        echo '<pre>';
//        print_r($user_arr);
//        echo '</pre>';
//        exit();

        if(is_null($userId)){
            return redirect('user')->with('error', 'Please Login..');
        }else{

//            $candidates = \App\CandidateEntry::whereIn('entered_by', $user_arr)->get();

            $demands = Demand::join('company_applied_for as caf', 'caf.id', '=', 'demand.company_id')
                ->select('demand.*', 'caf.company_applied_for_name')
                ->whereIn('demand.entered_by', $user_arr)
                ->orderBy('demand.status', 'desc')
                ->get();

            $the_demands = array();

            if(!empty($demands)){
                foreach($demands as $the_demand){
                    $demand_entry = DemandEntry::join('position', 'position.id', '=', 'demand_entry.position_id')
                        ->select('position.*', 'demand_entry.required_qty')
                        ->where('demand_entry.demand_id', $the_demand->id)
                        ->get();
                    $comma = '';
                    $job_position = '';
                    if(!empty($demand_entry)){
                        foreach($demand_entry as $the_demand_entry){
                            $job_position .= $comma.$the_demand_entry->position_name.' ('.(int)$the_demand_entry->required_qty.')';
                            $comma = ', ';
                        }
                    }

                    $the_demand->job_position = $job_position;

//                    echo '<pre>';
//                    print_r(json_decode($the_demand));
//                    echo '</pre>';
//                    exit();

                    array_push($the_demands, $the_demand);

                }
            }

//        echo '<pre>';
//        print_r($demands);
//        echo '</pre>';
//        exit();

//            $user = User::find($userId);

//            $utid = $user->user_types_id;
//
//            $usertype = Usertype::where('id', $utid)
//                ->select('user_type_slug')
//                ->first();

//            $objMenu = new Menu();
//            $menu = $objMenu->getSideBarMenu($userId);

            // return view('frontend.userdashboard')->with('menu', $menu)->with('user', $user)->with('usertype', $usertype);

            return view('frontend.demand_list')
                ->with('parent_id', $parent_id)
                ->with('user_id', $userId)
                ->with('demands', $the_demands);

        }
    }

    public function demandreportlist(Request $request){

        $userId = $request->session()->get('user_id');

        $currentUser = \App\User::find($userId);
        $parent_id = (!empty($currentUser->parent_id))?$currentUser->parent_id:$userId;

        $objUser = new User();
        $user_arr = $objUser->getUserArray($userId);

//        ->whereIn('entered_by', $user_arr)->get();

//        echo '<pre>';
//        print_r($user_arr);
//        echo '</pre>';
//        exit();

        if(is_null($userId)){
            return redirect('user')->with('error', 'Please Login..');
        }else{

//            $candidates = \App\CandidateEntry::whereIn('entered_by', $user_arr)->get();

            $demands = Demand::join('company_applied_for as caf', 'caf.id', '=', 'demand.company_id')
                ->select('demand.*', 'caf.company_applied_for_name')
                ->whereIn('demand.entered_by', $user_arr)
                ->orderBy('demand.status', 'desc')
                ->get();

            $the_demands = array();

            if(!empty($demands)){
                foreach($demands as $the_demand){
                    $demand_entry = DemandEntry::join('position', 'position.id', '=', 'demand_entry.position_id')
                        ->select('position.*', 'demand_entry.required_qty')
                        ->where('demand_entry.demand_id', $the_demand->id)
                        ->get();
                    $comma = '';
                    $job_position = '';
                    if(!empty($demand_entry)){
                        foreach($demand_entry as $the_demand_entry){
                            $job_position .= $comma.$the_demand_entry->position_name.' ('.(int)$the_demand_entry->required_qty.')';
                            $comma = ', ';
                        }
                    }

                    $the_demand->job_position = $job_position;

//                    echo '<pre>';
//                    print_r(json_decode($the_demand));
//                    echo '</pre>';
//                    exit();

                    array_push($the_demands, $the_demand);

                }
            }

//        echo '<pre>';
//        print_r($demands);
//        echo '</pre>';
//        exit();

//            $user = User::find($userId);

//            $utid = $user->user_types_id;
//
//            $usertype = Usertype::where('id', $utid)
//                ->select('user_type_slug')
//                ->first();

//            $objMenu = new Menu();
//            $menu = $objMenu->getSideBarMenu($userId);

            // return view('frontend.userdashboard')->with('menu', $menu)->with('user', $user)->with('usertype', $usertype);

            return view('frontend.demandreport_list')
                ->with('parent_id', $parent_id)
                ->with('user_id', $userId)
                ->with('demands', $the_demands);

        }
    }

    public function checkPassportNo(Request $request, $ppno){

        $userId = $request->session()->get('user_id');

        $objUser = new User();
        $user_arr = $objUser->getUserArray($userId);

        $candidate_entry = CandidateEntry::whereIn('entered_by', $user_arr)->where('passport_no', $ppno)->where('status', 'Y')->count();

        return $candidate_entry;

    }

    public function createdemand(Request $request){

        $userId = $request->session()->get('user_id');

        $objUser = new User();
        $user_arr = $objUser->getUserArray($userId);

        if(is_null($userId))
            return redirect('user')->with('error', 'Please Login..');

        $country_applied_for = CountryAppliedFor::where('status', 'Y')->get();

        $positions = Position::where('status', 'Y')->get();

        $company_applied_for = CompanyAppliedFor::join('user_company_mapping', 'company_applied_for.id', '=', 'user_company_mapping.company_id')
            ->whereIn('user_company_mapping.user_id', $user_arr)
            ->select('company_applied_for.*')
            ->get();

        return view('frontend.add_demand')
            ->with('company_applied_for', $company_applied_for)
            ->with('country_applied_for', $country_applied_for)
            ->with('positions', $positions);
    }

    public function updatedemand(Request $request, $demand_id){

        $userId = $request->session()->get('user_id');

        $objUser = new User();
        $user_arr = $objUser->getUserArray($userId);

        if(is_null($userId))
            return redirect('user')->with('error', 'Please Login..');

        $demand = Demand::find($demand_id);

        $demand_entry = DemandEntry::where('demand_id', $demand_id)->get();

        $country_applied_for = CountryAppliedFor::where('status', 'Y')->get();

        $positions = Position::where('status', 'Y')->get();

        $company_applied_for = CompanyAppliedFor::join('user_company_mapping', 'company_applied_for.id', '=', 'user_company_mapping.company_id')
            ->whereIn('user_company_mapping.user_id', $user_arr)
            ->select('company_applied_for.*')
            ->get();

        return view('frontend.edit_demand')
            ->with('demand', $demand)
            ->with('demand_entry', $demand_entry)
            ->with('company_applied_for', $company_applied_for)
            ->with('country_applied_for', $country_applied_for)
            ->with('positions', $positions);
    }

    public function postCreateDemand(Request $request) {

//        echo $user_id = Auth::user()->id;

        $user_id = $request->session()->get('user_id');

        $demanddata = $request->demand;

        $demandentrydata = $request->demandentry;

//        $attachment = $request->attachment;

//        echo '<pre>';
//        print_r($demanddata);
//        print_r($demandentrydata);
//        echo '</pre>';
//        exit();

        $result_count = Demand::where('company_id', $demanddata['company_applied_for'])->count();

        $result_company = CompanyAppliedFor::find($demanddata['company_applied_for']);

        $company_name_arr = explode(" ", $result_company->company_applied_for_name);

        $demand_no = $demanddata['demand_no'];

        if($result_count > 0) {
            $demand_no = strtolower($company_name_arr[0]);
            $demand_no .= strtolower((!empty($company_name_arr[1])) ? $company_name_arr[1] : 'abc');
            $demand_no .= ((int)$result_count + 1);
        }

        $objDemand = new Demand();
        $objDemand->pre_approval_date = $demanddata['pre_approval_date'];
        $objDemand->lot_number = $demanddata['lot_number'];
        $objDemand->chalani_no = $demanddata['chalani_no'];
        $objDemand->country_id = $demanddata['country_applied_for'];
        $objDemand->company_id = $demanddata['company_applied_for'];
        $objDemand->remarks = $demanddata['remarks'];
        $objDemand->demand_no = $demand_no;
        $objDemand->entered_by = $user_id;

        $objDemand->status = 'Y';

        if($objDemand->save()) {
            $position_ids = $demandentrydata['position_id'];
            if(is_array($position_ids) && count($position_ids) > 0){
                for($i = 0; $i < count($position_ids); $i++){

                    $objDemandEntry = new DemandEntry();
                    $objDemandEntry->demand_id = $objDemand->id;
                    $objDemandEntry->position_id = (!empty($demandentrydata['position_id'][$i])?$demandentrydata['position_id'][$i]:1);
                    $objDemandEntry->required_qty = (!empty($demandentrydata['required_qty'][$i])?$demandentrydata['required_qty'][$i]:1);
                    $objDemandEntry->basic_salary = (!empty($demandentrydata['basic_salary'][$i])?$demandentrydata['basic_salary'][$i]:0);
                    $objDemandEntry->duty_hours = (!empty($demandentrydata['duty_hours'][$i])?$demandentrydata['duty_hours'][$i]:'');
                    $objDemandEntry->lodging = (!empty($demandentrydata['lodging'][$i])?$demandentrydata['lodging'][$i]:'');
                    $objDemandEntry->fooding = (!empty($demandentrydata['fooding'][$i])?$demandentrydata['fooding'][$i]:'');
                    $objDemandEntry->overtime = (!empty($demandentrydata['overtime'][$i])?$demandentrydata['overtime'][$i]:'');
                    $objDemandEntry->air_ticket = (!empty($demandentrydata['air_ticket'][$i])?$demandentrydata['air_ticket'][$i]:'');
                    $objDemandEntry->qualification = (!empty($demandentrydata['qualification'][$i])?$demandentrydata['qualification'][$i]:'');
                    $objDemandEntry->position_id_actual = (!empty($demandentrydata['position_id_actual'][$i])?$demandentrydata['position_id_actual'][$i]:0);
                    $objDemandEntry->remarks = (!empty($demandentrydata['remarks'][$i])?$demandentrydata['remarks'][$i]:'');

                    $objDemandEntry->save();

                }
            }

            return redirect('user/dashboard/demand')->with('success', 'Demand Entry added successfully!');

        }else {
            return redirect('user/dashboard/demand')->with('error', 'Demand Entry cannot be added!');
        }
    }


    public function postUpdateDemand(Request $request) {

//        echo $user_id = Auth::user()->id;

        $user_id = $request->session()->get('user_id');

        $demanddata = $request->demand;

        $demandentrydata = $request->demandentry;

//        echo '<pre>';
//        print_r($demanddata);
//        print_r($demandentrydata);
//        echo '</pre>';
//        exit();

//        $result_count = Demand::where('company_id', $demanddata['company_applied_for'])->count();

//        $result_company = CompanyAppliedFor::find($demanddata['company_applied_for']);

//        $company_name_arr = explode(" ", $result_company->company_applied_for_name);

//        $demand_no = $demanddata['demand_no'];
//
//        if($result_count > 0) {
//            $demand_no = strtolower($company_name_arr[0]);
//            $demand_no .= strtolower((!empty($company_name_arr[1])) ? $company_name_arr[1] : 'abc');
//            $demand_no .= ((int)$result_count + 1);
//        }

        $objDemand = Demand::find($demanddata['id']);
        $objDemand->pre_approval_date = $demanddata['pre_approval_date'];
        $objDemand->lot_number = $demanddata['lot_number'];
        $objDemand->chalani_no = $demanddata['chalani_no'];
        $objDemand->country_id = $demanddata['country_applied_for'];
        $objDemand->company_id = $demanddata['company_applied_for'];
        $objDemand->remarks = $demanddata['remarks'];
        $objDemand->demand_no = $demanddata['demand_no'];
        $objDemand->status = $demanddata['status'];

//        $objDemand->entered_by = $user_id;

//        $objDemand->status = 'Y';

        if($objDemand->save()) {

            DemandEntry::where('demand_id', $demanddata['id'])->delete();

            $position_ids = $demandentrydata['position_id'];
            if(is_array($position_ids) && count($position_ids) > 0){
                for($i = 0; $i < count($position_ids); $i++){
                    if((!empty($demandentrydata['position_id'][$i]))){
                        $objDemandEntry = new DemandEntry();
                        $objDemandEntry->demand_id = $objDemand->id;
                        $objDemandEntry->position_id = $demandentrydata['position_id'][$i];
                        $objDemandEntry->required_qty = (!empty($demandentrydata['required_qty'][$i]) ? $demandentrydata['required_qty'][$i] : 1);
                        $objDemandEntry->basic_salary = (!empty($demandentrydata['basic_salary'][$i]) ? $demandentrydata['basic_salary'][$i] : 0);
                        $objDemandEntry->duty_hours = (!empty($demandentrydata['duty_hours'][$i]) ? $demandentrydata['duty_hours'][$i] : '');
                        $objDemandEntry->lodging = (!empty($demandentrydata['lodging'][$i]) ? $demandentrydata['lodging'][$i] : '');
                        $objDemandEntry->fooding = (!empty($demandentrydata['fooding'][$i]) ? $demandentrydata['fooding'][$i] : '');
                        $objDemandEntry->overtime = (!empty($demandentrydata['overtime'][$i]) ? $demandentrydata['overtime'][$i] : '');
                        $objDemandEntry->air_ticket = (!empty($demandentrydata['air_ticket'][$i]) ? $demandentrydata['air_ticket'][$i] : '');
                        $objDemandEntry->qualification = (!empty($demandentrydata['qualification'][$i]) ? $demandentrydata['qualification'][$i] : '');
                        $objDemandEntry->remarks = (!empty($demandentrydata['remarks'][$i]) ? $demandentrydata['remarks'][$i] : '');
                        $objDemandEntry->position_id_actual = (!empty($demandentrydata['position_id_actual'][$i])?$demandentrydata['position_id_actual'][$i]:0);

                        $objDemandEntry->save();
                    }

                }
            }

            return redirect('user/dashboard/demand/edit/'.$demanddata["id"])->with('success', 'Demand Entry updated successfully!');

        }else {
            return redirect('user/dashboard/demand')->with('error', 'Demand Entry cannot be added!');
        }
    }

    public function deleteDemand(Request $request, $demand_id){

        $user_id = $request->session()->get('user_id');

        $currentUser = \App\User::find($user_id);
        $parent_id = (!empty($currentUser->parent_id))?$currentUser->parent_id:$user_id;

        $objUser = new User();
        $user_arr = $objUser->getUserArray($user_id);

        $demand_del = Demand::where('id', $demand_id)->whereIn('entered_by', $user_arr)->count();

//        echo $parent_id.'-'.$demand_del.'-'.$user_id;
//
//        exit();

        if($parent_id == $user_id && $demand_del>0){
            $objDemand = Demand::find($demand_id);
            $objDemand->status = 'N';
            $objDemand->save();
            return redirect('user/dashboard/demand')->with('success', 'Demand Entry removed successfully!');
        }else{
            return redirect('user/dashboard/demand')->with('error', 'You are not eligible to remove this Demand!');
        }


    }

    public function statusEntryPost(Request $request){

        $candidate_ids = $request->candidate_ids;
        $formdata = $request->formdata;
        $entry_status_id = $request->entry_status_id;

//        $medical_organization_name = $request->medical_organization_name;
//        $medical_date = $request->medical_date;
//        $medical_status = $request->medical_status;
//        $reason = $request->reason;

        if(is_array($candidate_ids)){
            for ($i=0; $i<count($candidate_ids); $i++){

                CandidateEntryMeta::where('candidate_entry_id', $candidate_ids[$i])
                    ->where('entry_status_id', $entry_status_id)
                    ->delete();

                if(is_array($formdata)){
                    foreach ($formdata as $key=>$value){

                        $objCandidateEntryMeta = new CandidateEntryMeta();
                        $objCandidateEntryMeta->candidate_entry_id = $candidate_ids[$i];
                        $objCandidateEntryMeta->entry_status_id = $entry_status_id;
                        $objCandidateEntryMeta->candidate_entry_meta_key = $key;
                        $objCandidateEntryMeta->candidate_entry_meta_value = $value;
                        $objCandidateEntryMeta->status = 'Y';

                        $objCandidateEntryMeta->save();

                    }

                }
            }
        }

        $msg = 'Status Entry added successfully!';

        return redirect('user/dashboard/search')->with('success', $msg);



//        echo '<pre>';
//        print_r($candidate_ids);
//        print_r($formdata);
//        echo '</pre>';
//        exit();

    }


    public function visaEntryPost(Request $request){

//        echo '1';
//        exit();

        $visa_status_arr = $request->visa_status;

        if(is_array($visa_status_arr)){
            $candidate_id_arr = (!empty($visa_status_arr['candidate_id'])?$visa_status_arr['candidate_id']:array());
            $entry_permit_no_arr = (!empty($visa_status_arr['entry_permit_no'])?$visa_status_arr['entry_permit_no']:array());
            $date_of_issue_arr = (!empty($visa_status_arr['date_of_issue'])?$visa_status_arr['date_of_issue']:array());
            $valid_upto_arr = (!empty($visa_status_arr['valid_upto'])?$visa_status_arr['valid_upto']:array());
            $uid_no_arr = (!empty($visa_status_arr['uid_no'])?$visa_status_arr['uid_no']:array());
            $remarks_arr = (!empty($visa_status_arr['remarks'])?$visa_status_arr['remarks']:array());

//            echo '<pre>';
//            print_r($candidate_id_arr);
//            print_r($entry_permit_no_arr);
//            print_r($date_of_issue_arr);
//            print_r($valid_upto_arr);
//            print_r($uid_no_arr);
//            print_r($remarks_arr);
//            echo '</pre>';
//            exit();

            for ($i=0; $i<count($candidate_id_arr); $i++){

                if(is_array($entry_permit_no_arr) && !empty($entry_permit_no_arr[$i])){
                    $objCandidateEntryMeta = new CandidateEntryMeta();
                    $objCandidateEntryMeta->candidate_entry_id = $candidate_id_arr[$i];
                    $objCandidateEntryMeta->entry_status_id = 4;
                    $objCandidateEntryMeta->candidate_entry_meta_key = 'entry_permit_no';
                    $objCandidateEntryMeta->candidate_entry_meta_value = $entry_permit_no_arr[$i];
                    $objCandidateEntryMeta->status = 'Y';
                    $objCandidateEntryMeta->save();
                }

                if(is_array($date_of_issue_arr) && !empty($date_of_issue_arr[$i])){
                    $objCandidateEntryMeta = new CandidateEntryMeta();
                    $objCandidateEntryMeta->candidate_entry_id = $candidate_id_arr[$i];
                    $objCandidateEntryMeta->entry_status_id = 4;
                    $objCandidateEntryMeta->candidate_entry_meta_key = 'date_of_issue';
                    $objCandidateEntryMeta->candidate_entry_meta_value = $date_of_issue_arr[$i];
                    $objCandidateEntryMeta->status = 'Y';
                    $objCandidateEntryMeta->save();
                }

                if(is_array($valid_upto_arr) && !empty($valid_upto_arr[$i])){

                        $objCandidateEntryMeta = new CandidateEntryMeta();
                        $objCandidateEntryMeta->candidate_entry_id = $candidate_id_arr[$i];
                        $objCandidateEntryMeta->entry_status_id = 4;
                        $objCandidateEntryMeta->candidate_entry_meta_key = 'valid_upto';
                        $objCandidateEntryMeta->candidate_entry_meta_value = $valid_upto_arr[$i];
                        $objCandidateEntryMeta->status = 'Y';
                        $objCandidateEntryMeta->save();

                }

                if(is_array($uid_no_arr) && !empty($uid_no_arr[$i])){

                        $objCandidateEntryMeta = new CandidateEntryMeta();
                        $objCandidateEntryMeta->candidate_entry_id = $candidate_id_arr[$i];
                        $objCandidateEntryMeta->entry_status_id = 4;
                        $objCandidateEntryMeta->candidate_entry_meta_key = 'uid_no';
                        $objCandidateEntryMeta->candidate_entry_meta_value = $uid_no_arr[$i];
                        $objCandidateEntryMeta->status = 'Y';
                        $objCandidateEntryMeta->save();
                }

                if(is_array($remarks_arr) && !empty($remarks_arr[$i])){

                        $objCandidateEntryMeta = new CandidateEntryMeta();
                        $objCandidateEntryMeta->candidate_entry_id = $candidate_id_arr[$i];
                        $objCandidateEntryMeta->entry_status_id = 4;
                        $objCandidateEntryMeta->candidate_entry_meta_key = 'remarks';
                        $objCandidateEntryMeta->candidate_entry_meta_value = $remarks_arr[$i];
                        $objCandidateEntryMeta->status = 'Y';
                        $objCandidateEntryMeta->save();
                }
            }
        }

//        exit();

        $msg = 'Status Entry added successfully!';

        return redirect('user/dashboard/search')->with('success', $msg);

    }

    public function setDemandPost(Request $request){

        $demand_arr = $request->demand;

//        echo '<pre>';
//        print_r($demand_arr);
//        echo '</pre>';
//        exit();

        $company_applied_for = (!empty($demand_arr['company_applied_for']))?$demand_arr['company_applied_for']:null;
        $demand_id = (!empty($demand_arr['demand_id']))?$demand_arr['demand_id']:null;

        $candidate_ids = (!empty($demand_arr['candidate_ids']))?$demand_arr['candidate_ids']:array();

        if(is_array($candidate_ids)) {
            foreach($candidate_ids as $candidate_id){
                $objCandidate = CandidateEntry::find($candidate_id);
                if($company_applied_for != null)
                $objCandidate->company_applied_for = $company_applied_for;
                if($demand_id != null)
                $objCandidate->demand_id = $demand_id;
                $objCandidate->save();
            }

            return redirect('user/dashboard/search')->with('success', 'Successfully updated!');

        }else{

            return redirect('user/dashboard/search')->with('success', 'Candidate cannot be updated!');

        }

    }

    public function setCompanyPositionPost(Request $request){

        $demand_arr = $request->demand;

        $company_applied_for = (!empty($demand_arr['company_applied_for']))?$demand_arr['company_applied_for']:null;
        $country_applied_for = (!empty($demand_arr['country_applied_for']))?$demand_arr['country_applied_for']:null;
        $position_applied_for = (!empty($demand_arr['position_applied_for']))?$demand_arr['position_applied_for']:null;

        $candidate_ids = (!empty($demand_arr['candidate_ids']))?$demand_arr['candidate_ids']:array();

//        echo '<pre>';
//        print_r($demand_arr);
//        print_r($candidate_ids);
//        echo '</pre>';
//        exit();

        if(is_array($candidate_ids)) {
            foreach($candidate_ids as $candidate_id){
                $objCandidate = CandidateEntry::find($candidate_id);
                if($company_applied_for != null)
                $objCandidate->company_applied_for = $company_applied_for;
                if($country_applied_for != null)
                $objCandidate->country_applied_for = $country_applied_for;
                if($position_applied_for != null)
                $objCandidate->position_applied_for = $position_applied_for;
                $objCandidate->save();
            }

            return redirect('user/dashboard/search')->with('success', 'Successfully updated!');

        }else{

            return redirect('user/dashboard/search')->with('success', 'Candidate cannot be updated!');

        }

    }

    public function getCompanyDemand($company_id) {

        $result = '';

        $result_count = Demand::where('company_id', $company_id)->count();

        $result_company = CompanyAppliedFor::find($company_id);

        $company_name_arr = explode(" ", $result_company->company_applied_for_name);

//        $company_name = substr($result_company->company_applied_for_name, 0, 2);

        if($result_count > 0) {
            $result = strtolower($company_name_arr[0]);
            $result .= strtolower((!empty($company_name_arr[1])) ? $company_name_arr[1] : 'abc');
            $result .= ((int)$result_count + 1);
        }else {
            $result = strtolower($company_name_arr[0]);
            $result .= strtolower((!empty($company_name_arr[1])) ? $company_name_arr[1] : 'abc');
            $result .= '1';
        }
        return $result;

    }

    public function createTableName(Request $request, $table, $name){

        $userId = $request->session()->get('user_id');

        $table_field = $table.'_name';
        $objCandidate = new CandidateEntry();
        return $objCandidate->createNewField($table, $table_field, $name, $userId);

    }

}
