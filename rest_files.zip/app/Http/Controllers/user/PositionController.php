<?php

namespace App\Http\Controllers\user;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class PositionController extends Controller
{
    
    public function index(Request $request){
        $userId = $request->session()->get('user_id');
        if(is_null($userId)){
            return redirect('user')->with('error', 'Please Login..');
        }else{
            $result = \App\CompanyAppliedFor::get();
            return view('frontend.positionlist')->with('datas', $result);
        }
    }

    public function create(){
        $objMenu = new \stdClass();
        $objMenu->id = '';
        $objMenu->position_name = '';
        $objMenu->position_desc = '';
        $objMenu->status = '';
        
        return view('frontend/add_position')
            ->with('data', $objMenu)
            ->with('route', 'add');
    }
    public function postCreate(Request $request) {
        $formdata = $request->formdata;

//         echo '<pre>';
//         print_r($formdata);
//         echo '</pre>';
//         exit();

        $position_slug = str_replace(" ","-", strtolower($formdata['position_name']));
        
        $objPosition = new \App\CompanyAppliedFor();
        $objPosition->position_name = $formdata['position_name'];
        $objPosition->position_slug = $position_slug;
        $objPosition->position_desc = $formdata['position_desc'];
        $objPosition->status = 'Y';
        
        
        if($objPosition->save())
            return redirect('user/dashboard/position')->with('success', 'Position added successfully!');
        else
            return redirect('user/dashboard/position')->with('error', 'Position cannot be added!');

    }
}
