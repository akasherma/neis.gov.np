<?php

namespace App\Http\Controllers\user;

use App\CandidateEntry;
use App\Demand;
use App\DemandEntry;
use App\EntryStatus;
use App\Exports\ReportExport;
use App\Position;
use App\Reference;
use App\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Excel;

class DashboardController extends Controller
{
    public function report(Request $request){

        $userId = $request->session()->get('user_id');

        if(is_null($userId))
            return redirect('user')->with('error', 'Please Login..');

        $objUser = new User();
        $user_arr = $objUser->getUserArray($userId);



//        $demand_entries = EntryStatus::select('entry_status.*', 'entry_status.entry_status_name', DB::raw('count(entry_status.entry_status_name) as cnt'))
//            ->leftJoin('candidate_entry_meta', 'entry_status.id', '=', 'candidate_entry_meta.entry_status_id')
//            ->leftJoin('candidate_entry', 'candidate_entry.id', '=', 'candidate_entry_meta.candidate_entry_id')
//            ->whereIn('candidate_entry.entered_by', $user_arr)
//            ->groupBy('entry_status.entry_status_name')
//            ->get();

        $objEntryStatus = new EntryStatus();

        $demand_entries = $objEntryStatus->getEntryStatus($user_arr);

//            echo '<pre>';
//            print_r(json_decode($demand_entries));
//            echo '</pre>';
//            exit();

//            $user = User::find($userId);

//            $utid = $user->user_types_id;
//
//            $usertype = Usertype::where('id', $utid)
//                ->select('user_type_slug')
//                ->first();

//            $objMenu = new Menu();
//            $menu = $objMenu->getSideBarMenu($userId);

        // return view('frontend.userdashboard')->with('menu', $menu)->with('user', $user)->with('usertype', $usertype);

        return view('frontend.reportdashboard')->with('demand_entries', $demand_entries);




    }


    public function entryReport(Request $request, $entry_status_slug){

        $entry_status_this = EntryStatus::where('entry_status_slug', $entry_status_slug)->first();

        $userId = $request->session()->get('user_id');

        $objUser = new User();
        $user_arr = $objUser->getUserArray($userId);

//        ->whereIn('entered_by', $user_arr)->get();

//        $currentUser = \App\User::find($userId);
//        $company_user_id = (!empty($currentUser->parent_id))?$currentUser->parent_id:$userId;

//        $positions = Position::where('status', 'Y')->orderBy('position_name', 'asc')->get();
//
//        $reference_list = Reference::join('user_reference_mapping', 'reference.id', '=', 'user_reference_mapping.reference_id')
//            ->whereIn('user_reference_mapping.user_id', $user_arr)
//            ->select('reference.*')
//            ->orderBy('reference_name', 'asc')
//            ->get();

        if(is_null($userId) && empty($entry_status_this)){
            return redirect('user')->with('error', 'Please Login..');
        }else{

//            $search_for_company = (!empty($request->get('company')))?$request->get('company'):''; // from company table
//            $search_for_demand_ref = (!empty($request->get('demand_ref')))?$request->get('demand_ref'):''; // from demand table
//            $search_for_candidate = (!empty($request->get('candidate')))?$request->get('candidate'):''; // from candidate_entry
//            $search_for_passport_no = (!empty($request->get('passport_no')))?$request->get('passport_no'):''; // from candidate_entry
//            $search_for_position = (!empty($request->get('position')))?$request->get('position'):''; // from position
//            $search_for_referred_by = (!empty($request->get('referred_by')))?$request->get('referred_by'):''; // from reference table
//
//            $company = str_replace(" ", '%', $search_for_company);
//            $demand_ref = str_replace(" ", '%', $search_for_demand_ref);
//            $candidate = $search_for_candidate;
//            $passport_no = str_replace(" ", '%', $search_for_passport_no);
//            $position = str_replace(" ", '%', $search_for_position);
//            $referred_by = str_replace(" ", '%', $search_for_referred_by);
//
////             echo '<pre>';
////             print_r($demand_ref);
////             echo '</pre>';
////             exit();
//
//            if($company != '' && $demand_ref != '' && $position != ''){
//
////                echo 'com plus dem plus pos';
//
//                $candidates = CandidateEntry::join('demand', 'demand.id', '=', 'candidate_entry.demand_id')
//                    ->join('company_applied_for', 'company_applied_for.id', '=', 'candidate_entry.company_applied_for')
//                    ->leftJoin('country_applied_for', 'country_applied_for.id', '=', 'candidate_entry.country_applied_for')
//                    ->join('position', 'position.id', '=', 'candidate_entry.position_applied_for')
//                    ->join('reference', 'reference.id', '=', 'candidate_entry.reference_by')
//                    ->join('candidate_entry_meta', 'candidate_entry_meta.candidate_entry_id', '=', 'candidate_entry.id')
//                    ->select('candidate_entry.*', 'demand.demand_no', 'company_applied_for.company_applied_for_name', 'country_applied_for.country_applied_for_name')
//                    ->distinct()
//                    ->where('candidate_entry.status', 'Y')
//                    ->whereIn('candidate_entry.entered_by', $user_arr)
//                    ->where('demand.demand_no', 'like', '%'.$demand_ref.'%')
//                    ->where('company_applied_for.company_applied_for_name', 'like', '%'.$company.'%')
//                    ->where(DB::raw("CONCAT(candidate_entry.first_name,' ',candidate_entry.middle_name, ' ',candidate_entry.last_name)"), 'like', '%'.$candidate.'%')
//                    ->where('candidate_entry.passport_no','like', '%'.$passport_no.'%')
//                    ->where('position.position_name', 'like', '%'.$position.'%')
//                    ->where('reference.reference_name', 'like', '%'.$referred_by.'%')
//                    ->where('candidate_entry_meta.entry_status_id', '=', $entry_status_this->id)
//                    ->get();
//
//            }elseif($company != '' && $demand_ref != '' && $position == ''){
//
////                echo 'com plus dem plus no pos';
////
////                echo '<pre>';
////                print_r($demand_ref);
////                echo '</pre>';
////                exit();
//
//                $candidates = CandidateEntry::join('demand', 'demand.id', '=', 'candidate_entry.demand_id')
//                    ->join('company_applied_for', 'company_applied_for.id', '=', 'candidate_entry.company_applied_for')
//                    ->leftJoin('reference', 'reference.id', '=', 'candidate_entry.reference_by')
//                    ->join('candidate_entry_meta', 'candidate_entry_meta.candidate_entry_id', '=', 'candidate_entry.id')
//                    ->leftJoin('country_applied_for', 'country_applied_for.id', '=', 'candidate_entry.country_applied_for')
//                    ->select('candidate_entry.*', 'demand.demand_no', 'company_applied_for.company_applied_for_name', 'country_applied_for.country_applied_for_name')
//                    ->distinct()
//                    ->where('candidate_entry.status', 'Y')
//                    ->whereIn('candidate_entry.entered_by', $user_arr)
//                    ->where('demand.demand_no', 'like', '%'.$demand_ref.'%')
//                    ->where('company_applied_for.company_applied_for_name', 'like', '%'.$company.'%')
//                    ->where(DB::raw("CONCAT(candidate_entry.first_name,' ',candidate_entry.middle_name, ' ',candidate_entry.last_name)"), 'like', '%'.$candidate.'%')
//                    ->where('candidate_entry_meta.entry_status_id', '=', $entry_status_this->id)
//                    ->get();
//
//            }elseif($company != '' && $position != '' && $demand_ref == ''){
//
////                echo 'com plus pos no dem';
//
//                $candidates = CandidateEntry::join('company_applied_for', 'company_applied_for.id', '=', 'candidate_entry.company_applied_for')
//                    ->join('position', 'position.id', '=', 'candidate_entry.position_applied_for')
//                    ->join('reference', 'reference.id', '=', 'candidate_entry.reference_by')
//                    ->join('candidate_entry_meta', 'candidate_entry_meta.candidate_entry_id', '=', 'candidate_entry.id')
//                    ->leftJoin('demand', 'demand.id', '=', 'candidate_entry.demand_id')
//                    ->leftJoin('country_applied_for', 'country_applied_for.id', '=', 'candidate_entry.country_applied_for')
//                    ->select('candidate_entry.*', 'demand.demand_no', 'company_applied_for.company_applied_for_name', 'country_applied_for.country_applied_for_name')
//                    ->distinct()
//                    ->where('candidate_entry.status', 'Y')
//                    ->whereIn('candidate_entry.entered_by', $user_arr)
//                    ->where('demand.demand_no', 'like', '%'.$demand_ref.'%')
//                    ->where('company_applied_for.company_applied_for_name', 'like', '%'.$company.'%')
//                    ->where(DB::raw("CONCAT(candidate_entry.first_name,' ',candidate_entry.middle_name, ' ',candidate_entry.last_name)"), 'like', '%'.$candidate.'%')
//                    ->where('candidate_entry.passport_no','like', '%'.$passport_no.'%')
//                    ->where('position.position_name', 'like', '%'.$position.'%')
//                    ->where('reference.reference_name', 'like', '%'.$referred_by.'%')
//                    ->where('candidate_entry_meta.entry_status_id', '=', $entry_status_this->id)
//                    ->get();
//
//            }elseif($demand_ref != '' && $position != '' && $company == ''){
//
////                echo 'dem plus pos no com';
//
//                $candidates = CandidateEntry::lefJoin('company_applied_for', 'company_applied_for.id', '=', 'candidate_entry.company_applied_for')
//                    ->join('demand', 'demand.id', '=', 'candidate_entry.demand_id')
//                    ->join('position', 'position.id', '=', 'candidate_entry.position_applied_for')
//                    ->join('reference', 'reference.id', '=', 'candidate_entry.reference_by')
//                    ->join('candidate_entry_meta', 'candidate_entry_meta.candidate_entry_id', '=', 'candidate_entry.id')
//                    ->leftJoin('country_applied_for', 'country_applied_for.id', '=', 'candidate_entry.country_applied_for')
//                    ->select('candidate_entry.*', 'demand.demand_no', 'company_applied_for.company_applied_for_name', 'country_applied_for.country_applied_for_name')
//                    ->distinct()
//                    ->where('candidate_entry.status', 'Y')
//                    ->whereIn('candidate_entry.entered_by', $user_arr)
//                    ->where('demand.demand_no', 'like', '%'.$demand_ref.'%')
//                    ->where(DB::raw("CONCAT(candidate_entry.first_name,' ',candidate_entry.middle_name, ' ',candidate_entry.last_name)"), 'like', '%'.$candidate.'%')
//                    ->where('candidate_entry.passport_no','like', '%'.$passport_no.'%')
//                    ->where('position.position_name', 'like', '%'.$position.'%')
//                    ->where('reference.reference_name', 'like', '%'.$referred_by.'%')
//                    ->where('candidate_entry_meta.entry_status_id', '=', $entry_status_this->id)
//                    ->get();
//
//            }elseif($company != ''){
//
////                echo 'com';
//
//                $candidates = CandidateEntry::join('company_applied_for', 'company_applied_for.id', '=', 'candidate_entry.company_applied_for')
//                    ->join('candidate_entry_meta', 'candidate_entry_meta.candidate_entry_id', '=', 'candidate_entry.id')
//                    ->leftJoin('country_applied_for', 'country_applied_for.id', '=', 'candidate_entry.country_applied_for')
//                    ->leftJoin('demand', 'demand.id', '=', 'candidate_entry.demand_id')
//                    ->select('candidate_entry.*', 'demand.demand_no', 'company_applied_for.company_applied_for_name', 'country_applied_for.country_applied_for_name')
//                    ->distinct()
//                    ->where('candidate_entry.status', 'Y')
//                    ->whereIn('candidate_entry.entered_by', $user_arr)
//                    ->where('candidate_entry.passport_no','like', '%'.$passport_no.'%')
//                    ->where(DB::raw("CONCAT(candidate_entry.first_name,' ',candidate_entry.middle_name, ' ',candidate_entry.last_name)"), 'like', '%'.$candidate.'%')
//                    ->where('company_applied_for.company_applied_for_name', 'like', '%'.$company.'%')
//                    ->where('candidate_entry_meta.entry_status_id', '=', $entry_status_this->id)
//                    ->get();
//
//            }elseif($demand_ref != ''){
//
////                echo '$demand_ref';
//
//                $candidates = CandidateEntry::join('candidate_entry_meta', 'candidate_entry_meta.candidate_entry_id', '=', 'candidate_entry.id')
//                    ->join('demand', 'demand.id', '=', 'candidate_entry.demand_id')
//                    ->join('company_applied_for', 'company_applied_for.id', '=', 'candidate_entry.company_applied_for')
//                    ->leftJoin('country_applied_for', 'country_applied_for.id', '=', 'candidate_entry.country_applied_for')
//                    ->select('candidate_entry.*', 'demand.demand_no', 'company_applied_for.company_applied_for_name', 'country_applied_for.country_applied_for_name')
//                    ->distinct()
//                    ->where('candidate_entry.status', 'Y')
//                    ->whereIn('candidate_entry.entered_by', $user_arr)
//                    ->where('candidate_entry.passport_no','like', '%'.$passport_no.'%')
//                    ->where('demand.demand_no', 'like', '%'.$demand_ref.'%')
//                    ->where('candidate_entry_meta.entry_status_id', '=', $entry_status_this->id)
//                    ->where(DB::raw("CONCAT(candidate_entry.first_name,' ',candidate_entry.middle_name, ' ',candidate_entry.last_name)"), 'like', '%'.$candidate.'%')
//                    ->get();
//
//            }elseif($position != ''){
//
////                echo '$position';
//
//                $candidates = CandidateEntry::join('position', 'position.id', '=', 'candidate_entry.position_applied_for')
//                    ->join('candidate_entry_meta', 'candidate_entry_meta.candidate_entry_id', '=', 'candidate_entry.id')
//                    ->leftJoin('company_applied_for', 'company_applied_for.id', '=', 'candidate_entry.company_applied_for')
//                    ->leftJoin('country_applied_for', 'country_applied_for.id', '=', 'candidate_entry.country_applied_for')
//                    ->leftJoin('demand', 'demand.id', '=', 'candidate_entry.demand_id')
//                    ->select('candidate_entry.*', 'demand.demand_no', 'company_applied_for.company_applied_for_name', 'country_applied_for.country_applied_for_name')
//                    ->distinct()
//                    ->where('candidate_entry.status', 'Y')
//                    ->whereIn('candidate_entry.entered_by', $user_arr)
//                    ->where(DB::raw("CONCAT(candidate_entry.first_name,' ',candidate_entry.middle_name, ' ',candidate_entry.last_name)"), 'like', '%'.$candidate.'%')
//                    ->where('candidate_entry.passport_no','like', '%'.$passport_no.'%')
//                    ->where('position.position_name', 'like', '%'.$position.'%')
//                    ->where('reference.reference_name', 'like', '%'.$referred_by.'%')
//                    ->where('candidate_entry_meta.entry_status_id', '=', $entry_status_this->id)
//                    ->get();
//
//            }elseif($candidate != ''){
//
////                echo '$candidate'.$candidate; exit();
//
//                $candidates = CandidateEntry::join('candidate_entry_meta', 'candidate_entry_meta.candidate_entry_id', '=', 'candidate_entry.id')->leftJoin('company_applied_for', 'company_applied_for.id', '=', 'candidate_entry.company_applied_for')
//                    ->leftJoin('country_applied_for', 'country_applied_for.id', '=', 'candidate_entry.country_applied_for')
//                    ->leftJoin('demand', 'demand.id', '=', 'candidate_entry.demand_id')
//                    ->select('candidate_entry.*', 'demand.demand_no', 'company_applied_for.company_applied_for_name', 'country_applied_for.country_applied_for_name')
//                    ->distinct()
//                    ->where('candidate_entry.status', 'Y')
//                    ->whereIn('candidate_entry.entered_by', $user_arr)
//                    ->where('candidate_entry.passport_no','like', '%'.$passport_no.'%')
//                    ->where('candidate_entry_meta.entry_status_id', '=', $entry_status_this->id)
//                    ->where(DB::raw("CONCAT(candidate_entry.first_name,' ',candidate_entry.middle_name, ' ',candidate_entry.last_name)"), 'like', '%'.$candidate.'%')
////                    ->where('candidate_entry.middle_name', $candidate)
////                    ->whereIn('candidate_entry.last_name', $candidate)
//                    ->get();
//
//            }elseif($passport_no != ''){
//
//                $candidates = CandidateEntry::join('candidate_entry_meta', 'candidate_entry_meta.candidate_entry_id', '=', 'candidate_entry.id')->leftJoin('company_applied_for', 'company_applied_for.id', '=', 'candidate_entry.company_applied_for')
//                    ->leftJoin('country_applied_for', 'country_applied_for.id', '=', 'candidate_entry.country_applied_for')
//                    ->leftJoin('demand', 'demand.id', '=', 'candidate_entry.demand_id')
//                    ->select('candidate_entry.*', 'demand.demand_no', 'company_applied_for.company_applied_for_name', 'country_applied_for.country_applied_for_name')
//                    ->distinct()
//                    ->where('candidate_entry.status', 'Y')
//                    ->where('candidate_entry.passport_no','like', '%'.$passport_no.'%')
//                    ->whereIn('candidate_entry.entered_by', $user_arr)
//                    ->where('candidate_entry_meta.entry_status_id', '=', $entry_status_this->id)
//                    ->where(DB::raw("CONCAT(candidate_entry.first_name,' ',candidate_entry.middle_name, ' ',candidate_entry.last_name)"), 'like', '%'.$candidate.'%')
//                    ->get();
//
//            }else{
//
//                $candidates = CandidateEntry::join('candidate_entry_meta', 'candidate_entry_meta.candidate_entry_id', '=', 'candidate_entry.id')
//                    ->leftJoin('company_applied_for', 'company_applied_for.id', '=', 'candidate_entry.company_applied_for')
//                    ->leftJoin('country_applied_for', 'country_applied_for.id', '=', 'candidate_entry.country_applied_for')
//                    ->leftJoin('reference', 'reference.id', '=', 'candidate_entry.reference_by')
//                    ->leftJoin('position', 'position.id', '=', 'candidate_entry.position_applied_for')
//                    ->leftJoin('demand', 'demand.id', '=', 'candidate_entry.demand_id')
//                    ->select('candidate_entry.*', 'demand.demand_no', 'reference.reference_name', 'position.position_name', 'company_applied_for.company_applied_for_name', 'country_applied_for.country_applied_for_name')
//                    ->distinct()
//                    ->where('candidate_entry.status', 'Y')
//                    ->where('candidate_entry_meta.entry_status_id', $entry_status_this->id)
//                    ->whereIn('candidate_entry.entered_by', $user_arr)
//                    ->get();
//            }

            $table_fields = EntryStatus::join('entry_status_meta', 'entry_status_meta.entry_status_id', '=', 'entry_status.id')
                ->select('entry_status_meta.entry_status_key', 'entry_status_meta.entry_status_label')
                ->groupBy('entry_status_meta.entry_status_key', 'entry_status_meta.entry_status_label')
                ->where('entry_status.id', $entry_status_this->id)
                ->get();

//            echo '<pre>';
//            print_r(json_decode($table_fields));
//            echo '</pre>';
//            exit();

//            echo $entry_status_this->id.'<pre>';
//            print_r($table_fields);
//            echo '</pre>';
//            exit();

            $candidate_arr = array();

            $candidates = CandidateEntry::join('candidate_entry_meta', 'candidate_entry_meta.candidate_entry_id', '=', 'candidate_entry.id')
                ->leftJoin('company_applied_for', 'company_applied_for.id', '=', 'candidate_entry.company_applied_for')
                ->leftJoin('reference', 'reference.id', '=', 'candidate_entry.reference_by')
                ->leftJoin('position', 'position.id', '=', 'candidate_entry.position_applied_for')
                ->leftJoin('demand', 'demand.id', '=', 'candidate_entry.demand_id')
                ->select('candidate_entry.*', 'candidate_entry_meta.entry_status_id', 'candidate_entry_meta.candidate_entry_meta_key', 'candidate_entry_meta.candidate_entry_meta_value', 'demand.demand_no', 'reference.reference_name', 'position.position_name', 'company_applied_for.company_applied_for_name')
                ->where('candidate_entry.status', 'Y')
                ->where('candidate_entry_meta.entry_status_id', $entry_status_this->id)
                ->whereIn('candidate_entry.entered_by', $user_arr)
                ->distinct()
                ->get()->toArray();

//                echo '<pre>';
//                print_r($candidates);
//                echo '</pre>';
//                exit();

            if(!empty($candidates)){
                foreach ($candidates as $candidate):
//
//                    echo '<pre>';
//                    print_r($candidate);
//                    echo '</pre>';
//                    exit();

                    $table_fields_this = EntryStatus::join('entry_status_meta', 'entry_status_meta.entry_status_id', '=', 'entry_status.id')
                        ->join('candidate_entry_meta', 'candidate_entry_meta.entry_status_id', '=', 'entry_status.id')
                        ->select('candidate_entry_meta.candidate_entry_meta_key', 'candidate_entry_meta.candidate_entry_meta_value', 'entry_status_meta.entry_status_label')
                        ->groupBy('candidate_entry_meta.candidate_entry_meta_key', 'candidate_entry_meta.candidate_entry_meta_value','entry_status_meta.entry_status_label')
                        ->where('entry_status.id', $entry_status_this->id)
                        ->where('candidate_entry_meta.candidate_entry_id', $candidate["id"])
                        ->get();
//
//                    echo '<pre>';
//                    print_r(json_decode($table_fields));
//                    echo '</pre>';
//                    exit();

//                        echo '<pre>';
//                        print_r($candidate);
//                        echo '</pre>';
//                        exit();

                    if(!empty(json_decode($table_fields_this))){
                        foreach($table_fields_this as $table_field){
                            $candidate[$table_field->candidate_entry_meta_key] = $table_field->candidate_entry_meta_value;
                        }
//                        array_push($candidate_arr, $candidate);

                        $candidate_arr[$candidate["id"]] = $candidate;

//                        echo '<pre>';
////                        print_r($table_fields);
//                        print_r($candidate_arr);
//                        echo '</pre>';
//                        exit();

                    }

                endforeach;
            }

//            echo '<pre>';
//            print_r($candidate_arr);
//            echo '</pre>';
//            exit();

            return view('frontend.entry_status_viewlist')
                ->with('entry_status_name', $entry_status_this->entry_status_name)
                ->with('entry_status_slug', $entry_status_slug)
                ->with('table_fields', json_decode($table_fields))
                ->with('candidates', $candidate_arr);

        }
    }

    public function excel() {

//            $assessment = User::all();

//            Excel::create();
//
//            Excel::create('Laravel Excel', function($excel) use ($assessment) {
//
//                $excel->sheet('Excel sheet', function($sheet) use ($assessment) {
//                    $sheet->loadView('contents.assessment_details')->with('assessment',$assessment);
//                    $sheet->setOrientation('landscape');
//                });
//            })->export('xls');

//        return Excel::download(new ReportExport, 'report.xlsx');
    }

}
