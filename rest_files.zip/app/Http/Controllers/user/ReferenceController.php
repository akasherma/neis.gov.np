<?php

namespace App\Http\Controllers\user;

use App\Reference;
use App\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ReferenceController extends Controller
{
    
    public function index(Request $request){
        $userId = $request->session()->get('user_id');
        if(is_null($userId)){
            return redirect('user')->with('error', 'Please Login..');
        }else{
//            $currentUser = \App\User::find($userId);
//            $company_user_id = (!empty($currentUser->parent_id))?$currentUser->parent_id:$userId;

            $objUser = new User();
            $user_arr = $objUser->getUserArray($userId);
            
            $result = \App\Reference::join('user_reference_mapping', 'reference.id', '=', 'user_reference_mapping.reference_id')
                ->whereIn('user_reference_mapping.user_id', $user_arr)
                ->select('reference.*')
                ->get();
            
            return view('frontend.referencelist')->with('datas', $result);
        }
    }

    public function create(){
        $objMenu = new \stdClass();
        $objMenu->id = '';
        $objMenu->reference_name = '';
        $objMenu->reference_email = '';
        $objMenu->reference_phone = '';
        $objMenu->reference_desc = '';

        return view('frontend/add_reference')
            ->with('data', $objMenu)
            ->with('route', 'add');
    }
    public function postCreate(Request $request) {
        $userId = $request->session()->get('user_id');
        $currentUser = \App\User::find($userId);
        $company_user_id = (!empty($currentUser->parent_id))?$currentUser->parent_id:$userId;

        $formdata = $request->formdata;

//        reference_name`,  `reference_slug`,  `reference_email`,  `reference_phone`,  LEFT(`reference_desc

//         echo '<pre>';
//         print_r($formdata);
//         echo '</pre>';
//         exit();

        $objReference = new \App\Reference();
        $objReference->reference_name = $formdata['reference_name'];
        $objReference->reference_slug = $formdata['reference_email'];
        $objReference->reference_email = $formdata['reference_email'];
        $objReference->reference_phone = $formdata['reference_phone'];
        $objReference->reference_desc = $formdata['reference_desc'];
        $objReference->status = 'Y';

        if($objReference->save()){
            $objUserReferenceMapping = new \App\UserReferenceMapping();
            $objUserReferenceMapping->user_id = $company_user_id;
            $objUserReferenceMapping->reference_id = $objReference->id;
            $objUserReferenceMapping->entered_by = $userId;
            $objUserReferenceMapping->status = 'Y';
            $objUserReferenceMapping->save();
            return redirect('user/dashboard/reference')->with('success', 'Reference added successfully!');
        }else{
            return redirect('user/dashboard/reference')->with('error', 'Reference cannot be added!');
        }
    }

    public function update($id){
        $objMenu = Reference::find($id);

        return view('frontend/add_reference')
            ->with('data', $objMenu)
            ->with('route', 'edit');
    }
    public function postUpdate(Request $request) {

        $formdata = $request->formdata;

        $objReference = Reference::find($formdata['id']);
        $objReference->reference_name = $formdata['reference_name'];
        $objReference->reference_slug = $formdata['reference_email'];
        $objReference->reference_email = $formdata['reference_email'];
        $objReference->reference_phone = $formdata['reference_phone'];
        $objReference->reference_desc = $formdata['reference_desc'];
        $objReference->status = 'Y';

        if($objReference->save()){
            return redirect('user/dashboard/reference')->with('success', 'Reference added successfully!');
        }else{
            return redirect('user/dashboard/reference')->with('error', 'Reference cannot be added!');
        }
    }

}
