<?php

namespace App\Http\Controllers\dashboard;

use App\CompanyAppliedFor;
use App\CountryAppliedFor;
use App\User;
use App\UserCompanyMapping;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CompanyAppliedForController extends Controller
{
    public function index(Request $request){
        $userId = $request->session()->get('user_id');

        $objUser = new User();
        $user_arr = $objUser->getUserArray($userId);

        // $result = CompanyAppliedFor::where('status', 'Y')->get();

        $result = CompanyAppliedFor::join('user_company_mapping', 'company_applied_for.id', '=', 'user_company_mapping.company_id')
            ->leftJoin('country_applied_for', 'country_applied_for.id', '=', 'company_applied_for.country_id')
            ->whereIn('user_company_mapping.user_id', $user_arr)
            ->select('company_applied_for.*', 'country_applied_for.country_applied_for_name')
            ->get();

        return view('company_list')->with('data',$result);
    }
    public function create(){

        $country_applied_for = CountryAppliedFor::all();

        $objMenu = new \stdClass();
        $objMenu->id = '';
//        ', 'company_applied_for_slug', '
        $objMenu->company_applied_for_name = '';
        $objMenu->company_applied_for_desc = '';
        $objMenu->country_id = '';
        $objMenu->status = '';

        return view('frontend/add_company')
            ->with('data', $objMenu)
            ->with('country_applied_for', $country_applied_for)
            ->with('route', 'add');
    }
    public function postcreate(Request $request){

        $userId = $request->session()->get('user_id');
        $currentUser = User::find($userId);
        $company_user_id = (!empty($currentUser->parent_id))?$currentUser->parent_id:$userId;

        $objCompanyAppliedFor = new CompanyAppliedFor();
        $objCompanyAppliedFor->company_applied_for_name = $request->company_applied_for_name;
        $objCompanyAppliedFor->company_applied_for_slug = str_replace(' ','-',strtolower($request->company_applied_for_name));
        $objCompanyAppliedFor->company_applied_for_desc = $request->company_applied_for_desc;
        $objCompanyAppliedFor->country_id = $request->country_id;
        $objCompanyAppliedFor->status = 'Y';

        if($objCompanyAppliedFor->save()):
            $objUserCompanyMapping = new UserCompanyMapping();
            $objUserCompanyMapping->user_id = $company_user_id;
            $objUserCompanyMapping->company_id = $objCompanyAppliedFor->id;
            $objUserCompanyMapping->entered_by = $userId;
            $objUserCompanyMapping->save();

            return redirect('user/dashboard/company')->with('success', 'Company added successfully!');
        else:
            return redirect('user/dashboard/company')->with('error', 'Company cannot be added!');
        endif;

    }
    public function update($id){

        $country_applied_for = CountryAppliedFor::all();

        $data = CompanyAppliedFor::find($id);

        return view('editcompany')->with('data', $data)
            ->with('country_applied_for', $country_applied_for)->with('id',$id);
    }
    public function postupdate(Request $request){
        $objPost = CompanyAppliedFor::find($request->id);
        $objPost->company_applied_for_name = $request->company_applied_for_name;
        //$objPost->company_applied_for_slug = $request->company_applied_for_slug;
        $objPost->company_applied_for_desc = $request->company_applied_for_desc;
        $objPost->country_id = $request->country_id;
        $objPost->status = $request->status;

        if($objPost->save())
            return redirect('user/dashboard/company')->with('success', 'Company updated successfully!');
        else
            return redirect('user/dashboard/company')->with('error', 'Company not updated!');

    }
    public function delete($id){
        $objPost = CompanyAppliedFor::find($id);
        $objPost->status = 'N';

        if($objPost->save())
            return redirect('user/dashboard/company')->with('success', 'Company deleted successfully!');
        else
            return redirect('user/dashboard/company')->with('error', 'Company not deleted!');
    }
}
