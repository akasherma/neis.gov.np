<?php

namespace App\Http\Controllers\dashboard;

use App\MenuType;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class MenuTypeController extends Controller
{
    public function index(){
        $result = MenuType::where('status','Y')->get();
        return view('dashboard/menu_type_list')->with('data',$result);
    }
    public function create(){
        $data = new \stdClass();
        $data->id = '';
        $data->menu_type_name = '';
        $data->menu_type_desc = '';
        return view('dashboard/add_menu_type')->with('data', $data)->with('route', 'add');
    }
    public function postcreate(Request $request){

        $objPost = new MenuType();
        $objPost->menu_type_name = $request->menu_type_name;
        $objPost->menu_type_slug = str_replace(' ','-',strtolower($request->menu_type_name));
        $objPost->menu_type_desc = (!empty($request->menu_type_desc))?$request->menu_type_desc:'';
        $objPost->status = 'Y';

        if($objPost->save())
            return redirect('dashboard/menu_type')->with('success', 'Menu Type Created Successfully!');
        else
            return redirect('dashboard/menu_type')->with('error', 'Menu Type Not Created!');
    }
    public  function  update($id){
        $data = MenuType::find($id);
        return view('dashboard/add_menu_type')->with('data', $data)->with('route', 'edit');
    }
    public function postupdate(Request $request){
        $objPost = MenuType::find($request->id);
        $objPost->menu_type_name = $request->menu_type_name;
        $objPost->menu_type_desc = (!empty($request->menu_type_desc))?$request->menu_type_desc:'';
        $objPost->status = 'Y';

        if($objPost->save())
            return redirect('dashboard/menu_type')->with('success', 'Menu Type updated successfully!');
        else
            return redirect('dashboard/menu_type')->with('error', 'Menu Type not updated!');

    }
    public function delete($id){
        $objPost = MenuType::find($id);
        $objPost->status = 'N';

        if($objPost->save())
            return redirect('dashboard/menu_type')->with('success', 'Menu Type deleted successfully!');
        else
            return redirect('dashboard/menu_type')->with('error', 'Menu Type not deleted!');
    }
}
