<?php

namespace App\Http\Controllers\dashboard;

use App\LogTable;
use App\Source;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

class SourceController extends Controller
{

    public function __construct(){
        $this->middleware('auth');
    }

    public function index(){
        $result =  source::where('status', 'Y')->get();
        return view('dashboard.source_list')
            ->with('data', $result);
    }

    public function create(){

        $objData=new \stdClass();
        $objData->id = '';
        $objData->source_name = '';
        $objData->source_slug = '';
        $objData->source_desc = 0;
        $objData->status = '';
        return view('dashboard/source_add')
            ->with('data', $objData)
            ->with('route', 'add');
    }
    public function postCreate(Request $request) {
        $formdata = $request->formdata;

        // echo '<pre>';
        // print_r($formdata);
        // echo '</pre>';
        // exit();

//        'source_name', 'source_slug', 'source_desc', 'status'

        $formdata['source_slug'] = (empty($formdata['source_name']))?$formdata['source_name']:str_replace(" ","-", strtolower($formdata['source_name']));
        $formdata['source_desc'] = (!empty($formdata['source_desc']))?$formdata['source_desc']:null;

        $objData = new Source();
        $objData->source_name = $formdata['source_name'];
        $objData->source_slug = $formdata['source_slug'];
        $objData->source_desc = $formdata['source_desc'];
        $objData->status = 'Y';


        if($objData->save()){

            $objLog = new LogTable();
            $log_details = array(
                'Source Name: '.$formdata['source_name'],
                'Description: '.$formdata['source_desc']
            );
            $data = array(
                'log_details'   => serialize($log_details),
                'menu_name'     => 'Added Source',
                'created_by'    => Auth::user()->id
            );
            $objLog->insertIntoLogTable($data);

            return redirect('dashboard/source')->with('success', 'Source added successfully!');

        }
        else{

            return redirect('dashboard/source')->with('error', 'Source cannot be added!');

        }

    }
    public function update($source_id = '') {

        $objData = Source::find($source_id);

        if($source_id == '' || is_null($objData)):

            return redirect('dashboard/source')->with('error', 'No source Selected!');

        else:

            return view('dashboard/source_add')
                ->with('route', 'update')
                ->with('data', $objData);

        endif;

    }

    public function postUpdate(Request $request) {

        $formdata = $request->formdata;

        $formdata['source_desc'] = (!empty($formdata['source_desc']))?$formdata['source_desc']:null;

        $objData = Source::find($formdata['id']);
        $objData->source_name = $formdata['source_name'];
        $objData->source_desc = $formdata['source_desc'];

        $objData->save();

        $objLog = new LogTable();
        $log_details = array(
            'Source Name: '.$formdata['source_name'],
            'Description: '.$formdata['source_desc']
        );
        $data = array(
            'log_details'   => serialize($log_details),
            'menu_name'     => 'Updated Source',
            'created_by'    => Auth::user()->id
        );
        $objLog->insertIntoLogTable($data);

        return redirect('dashboard/source')->with('success', 'Source updated successfully!');

    }

    public function delete($source_id) {

        $objData = Source::find($source_id);
        $objData->status = 'N';
        $objData->save();

        return redirect('dashboard/source')->with('error', 'Source deleted successfully!');

    }

}
