<?php

namespace App\Http\Controllers\dashboard;

use App\LocationType;
use App\LogTable;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use stdClass;

class LocationTypeController extends Controller
{
    //
    public function __construct(){
        $this->middleware('auth');
    }
    public function index(){
        $result = LocationType::where('status','Y')->get();
        return view('dashboard.locationtypelist')->with('data',$result);
    }
    public function create(){

        $child_location_type = LocationType::where('status', 'Y')->get();

        $objPost = new StdClass();
        $objPost->id = '';
        $objPost->location_type_name = '';
        $objPost->location_type_slug = '';
        $objPost->location_type_desc = '';
        $objPost->child_id = 0;
        $objPost->status = '';
        return view('dashboard/locationtypeadd')->with('data', $objPost)->with('child_location_type', $child_location_type)->with('route', 'add');
    }
    public function postCreate(Request $request) {
        $formdata = $request->formdata;

        // echo '<pre>';
        // print_r($formdata);
        // echo '</pre>';
        // exit();

        $formdata['location_type_slug'] = (empty($formdata['location_type_name']))?$formdata['location_type_name']:str_replace(" ","-", strtolower($formdata['location_type_name']));
//        $formdata['parent_id'] = (!empty($formdata['parent_id']))?$formdata['parent_id']:0;

        $objPost = new LocationType();
        $objPost->location_type_name = $formdata['location_type_name'];
        $objPost->location_type_slug = $formdata['location_type_slug'];
        $objPost->location_type_desc = $formdata['location_type_desc'];
        $objPost->child_id = (!empty($formdata['child_id']))?$formdata['child_id']:0;
//        $objPost->parent_id = $formdata['parent_id'];
        $objPost->status = 'Y';


        if($objPost->save()){

            $objLog = new LogTable();
            $log_details = array(
                'Location Type Name: '.$formdata['location_type_name'],
                'Description: '.$formdata['location_type_desc']
            );
            $data = array(
                'log_details'   => serialize($log_details),
                'menu_name'     => 'Added New Location Type',
                'created_by'    => Auth::user()->id
            );
            $objLog->insertIntoLogTable($data);

            return redirect('dashboard/location-type')->with('success', 'Location Type added successfully!');

        }
        else
            return redirect('dashboard/location-type')->with('error', 'Location Type cannot be added!');

    }
    public function update($id = '') {

        $child_location_type = LocationType::where('status', 'Y')->get();

        $objPost = LocationType::find($id);

        if($id == '' || is_null($objPost)):

            return redirect('dashboard/location-type')->with('error', 'No Location Type Selected!');

        else:

            return view('dashboard/locationtypeadd')
                ->with('child_location_type', $child_location_type)
                ->with('route', 'update')
                ->with('data', $objPost);

        endif;

    }

    public function postUpdate(Request $request) {

        $formdata = $request->formdata;

        $objPost = LocationType::find($formdata['id']);
        $objPost->location_type_name = $formdata['location_type_name'];
        $objPost->location_type_desc = $formdata['location_type_desc'];
        $objPost->child_id = (!empty($formdata['child_id']))?$formdata['child_id']:0;

        $objPost->save();

        $objLog = new LogTable();
        $log_details = array(
            'Location Type Name: '.$formdata['location_type_name'],
            'Description: '.$formdata['location_type_desc']
        );
        $data = array(
            'log_details'   => serialize($log_details),
            'menu_name'     => 'Updated Location Type',
            'created_by'    => Auth::user()->id
        );
        $objLog->insertIntoLogTable($data);

        return redirect('dashboard/location-type')->with('success', 'Location Type updated successfully!');

    }

    public function delete($id) {

        $objPost = LocationType::find($id);
        $objPost->status = 'N';
        $objPost->save();

        return redirect('dashboard/location-type')->with('error', 'Location Type deleted successfully!');

    }
}
