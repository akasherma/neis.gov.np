<?php

namespace App\Http\Controllers\dashboard;

use App\LogTable;
use App\Sector;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use stdClass;

class SectorController extends Controller
{

    public function __construct(){
        $this->middleware('auth');
    }

    public function index(){
        $result =  Sector::where('status', 'Y')->get();
        return view('dashboard.sectorlist')
            ->with('data', $result);
    }

    public function create(){

        $objSector=new StdClass();
        $objSector->id = '';
        $objSector->sector_name = '';
        $objSector->sector_slug = '';
        $objSector->sector_order = 0;
        $objSector->status = '';
        return view('dashboard/sectoradd')
            ->with('data', $objSector)
            ->with('route', 'add');
    }
    public function postCreate(Request $request) {
        $formdata = $request->formdata;

        // echo '<pre>';
        // print_r($formdata);
        // echo '</pre>';
        // exit();

        $formdata['sector_slug'] = (empty($formdata['sector_name']))?$formdata['sector_name']:str_replace(" ","-", strtolower($formdata['sector_name']));
        $formdata['sector_order'] = (!empty($formdata['sector_order']))?$formdata['sector_order']:0;

        $objSector = new Sector();
        $objSector->sector_name = $formdata['sector_name'];
        $objSector->sector_slug = $formdata['sector_slug'];
        $objSector->sector_order = $formdata['sector_order'];
        $objSector->status = 'Y';

        $objLog = new LogTable();
        $log_details = array('Sector: '.$formdata['sector_name']
        );
        $data = array(
            'log_details'   => serialize($log_details),
            'menu_name'     => 'New Sector',
            'created_by'    => Auth::user()->id
        );
        $objLog->insertIntoLogTable($data);

        if($objSector->save())
            return redirect('dashboard/sector')->with('success', 'Sector added successfully!');
        else
            return redirect('dashboard/sector')->with('error', 'Sector cannot be added!');

    }
    public function update($sector_id = '') {

        $objSector = Sector::find($sector_id);

        if($sector_id == '' || is_null($objSector)):

            return redirect('dashboard/sector')->with('error', 'No Sector Selected!');

        else:

            return view('dashboard/sectoradd')
                ->with('route', 'update')
                ->with('data', $objSector);

        endif;

    }

    public function postUpdate(Request $request) {

        $formdata = $request->formdata;

        $objSector = Sector::find($formdata['id']);
        $objSector->sector_name = $formdata['sector_name'];
        $objSector->sector_order = $formdata['sector_order'];

        $objSector->save();

        $objLog = new LogTable();
        $log_details = array('Sector: '.$formdata['sector_name']
        );
        $data = array(
            'log_details'   => serialize($log_details),
            'menu_name'     => 'Updated Sector',
            'created_by'    => Auth::user()->id
        );
        $objLog->insertIntoLogTable($data);

        return redirect('dashboard/sector')->with('success', 'Sector updated successfully!');

    }

    public function delete($sector_id) {

        $objSector = Sector::find($sector_id);
        $objSector->status = 'N';
        $objSector->save();

        return redirect('dashboard/sector')->with('error', 'Sector deleted successfully!');

    }
}
