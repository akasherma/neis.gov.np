<?php

namespace App\Http\Controllers\dashboard;

use App\Location;
use App\LogTable;
use App\User;
use App\UserGroup;
use App\Users;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index(Request $request){

        $result = User::join('user_group', 'user_group.id', '=', 'users.user_group_id')
            ->where('users.status', 'Y')
            ->select('users.*', 'user_group.user_group_name')
            ->get();

        return view('dashboard/userlist')->with('data',$result);

    }
    public function create(Request $request){

        $data = new \stdClass();
        $data->id = '';
        $data->name = '';
        $data->email = '';
        $data->password = '';
        $data->phone = '';
        $data->address = '';
        $data->designation = '';
        $data->organization_name = '';
        $data->user_group_id = '';
        $data->status = '';
        $data->province_id = '';
        $data->district_id = '';
        $data->local_govt_id = '';
        $data->is_central = '';

        $user_group = UserGroup::where('status','Y')->get();

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->get();

        $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'district')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->get();

        $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'local-government')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->get();

        return view('dashboard/adduser')
            ->with('data', $data)
            ->with('user_group', $user_group)
            ->with('provinces', $provinces)
            ->with('districts', $districts)
            ->with('local_governments', $local_governments)
            ->with('route', 'add');

    }
    public function postcreate(Request $request){

        $formdata = $request->formdata;

        if(empty(User::where('email', $request->email)->first())){

            $objUser = new User();
            $objUser->name = $formdata['name'];
            $objUser->email = $formdata['email'];
            $objUser->phone = $formdata['phone'];
            $objUser->password = Hash::make($formdata['password']);
            $objUser->address = $formdata['address'];
            $objUser->designation = $formdata['designation'];
            $objUser->organization_name = $formdata['organization_name'];
            $objUser->user_group_id = $formdata['user_group_id'];
            $objUser->status = 'Y';

            $objUser->is_central = (!empty($formdata['is_central']))?$formdata['is_central']:'';
            $objUser->province_id = (!empty($formdata['province_id']))?$formdata['province_id']:'';
            $objUser->district_id = (!empty($formdata['district_id']))?$formdata['district_id']:'';
            $objUser->local_govt_id = (!empty($formdata['local_govt_id']))?$formdata['local_govt_id']:'';

            if($objUser->save()){

                return redirect('dashboard/user')->with('success', 'User created successfully!');

//                 $subject = "Reset code for ".$objUser->email;
//
//                 $msg = '';
//
//                 $time_plus = strtotime(date('Y-m-d H:i:s')) + 60*60;
//
//                 $encode = base64_encode($objUser->email.'-'.$time_plus);
//
//                 $message = "<html>
//               <head>
//               <title>".$subject."</title>
//               </head>
//               <body>
//               <strong>Dear</strong>
//               <p>Reset your activation code using<a href='".url('/').'/resetcode/'.$encode."'>".url('/').'/resetcode/'.$encode."</a></p>
//               <p>Thank you,</p>
//               </body>
//               </html>
//               ";

                 // Always set content-type when sending HTML email
//                 $headers = "MIME-Version: 1.0" . "\r\n";
//                 $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
//
//                 // More headers
//                 $headers .= 'From: <info@wecs.gov.np>' . "\r\n";

//                 if(mail($objUser->email,$subject,$message,$headers)){
//
//                     $objLog = new LogTable();
//                     $log_details = array(
//                         'Login Name: '.$formdata['name'],
//                         'Email: '.$formdata['email']
//                     );
//                     $data = array(
//                         'log_details'   => serialize($log_details),
//                         'menu_name'     => 'Added User',
//                         'created_by'    => Auth::user()->id
//                     );
//                     $objLog->insertIntoLogTable($data);
//
//                     $status = 'success';
//                     $msg = 'Mail has been sent to your email. Please check it out!';
//
//                     return redirect('dashboard/user')->with('success', 'Mail sent to '.$objUser->email.', please let him/her to check inbox or spam folder !');
//
//                 }else {
//                     $status = 'warning';
//                     $msg = 'Mail has been sent to your email. Please check it out!';
//
//                     return redirect('dashboard/user')->with('success', 'Mail cannot be sent!');
//
//                 }

            }else {
                return redirect('dashboard/user')->with('error', 'User cannot be created.');
            }

        }else {
            return redirect('dashboard/user')->with('error', 'Email already registered! Try another one.');
        }
    }
    public function update($id){

        $user_group = UserGroup::where('status','Y')->get();

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->get();

        $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'district')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->get();

        $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'local-government')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->get();

        $data = User::find($id);

        return view('dashboard/adduser')
            ->with('data', $data)
            ->with('user_group', $user_group)
            ->with('provinces', $provinces)
            ->with('districts', $districts)
            ->with('local_governments', $local_governments)
            ->with('route', 'edit');
    }
    public function postupdate(Request $request){

        $formdata = $request->formdata;

        $objUser = User::find($formdata['id']);
        $objUser->name = $formdata['name'];
        $objUser->email = $formdata['email'];
        $objUser->phone = $formdata['phone'];
        if(!empty($formdata['password']))
        $objUser->password = Hash::make($formdata['password']);
        $objUser->address = $formdata['address'];
        $objUser->designation = $formdata['designation'];
        $objUser->organization_name = $formdata['organization_name'];
        $objUser->user_group_id = (!empty($formdata['user_group_id']))?$formdata['user_group_id']:0;
        $objUser->status = 'Y';

        $objUser->is_central = (!empty($formdata['is_central']))?$formdata['is_central']:'';
        $objUser->province_id = (!empty($formdata['province_id']))?$formdata['province_id']:'';
        $objUser->district_id = (!empty($formdata['district_id']))?$formdata['district_id']:'';
        $objUser->local_govt_id = (!empty($formdata['local_govt_id']))?$formdata['local_govt_id']:'';

        if($objUser->save()){

            $objLog = new LogTable();
            $log_details = array(
                'Login Name: '.$formdata['name'],
                'Email: '.$formdata['email']
            );
            $data = array(
                'log_details'   => serialize($log_details),
                'menu_name'     => 'Updated User',
                'created_by'    => Auth::user()->id
            );
            $objLog->insertIntoLogTable($data);

            return redirect('dashboard/user')->with('success', 'User Updated Successfully!');

        }
        else{

            return redirect('dashboard/user')->with('error', 'User Not Updated!');

        }

    }
    public function delete($id){
        $objUser = User::find($id);
        $objUser->status = 'N';

        if($objUser->save()){

            $objLog = new LogTable();
            $log_details = array(
                'Login Name: '.$objUser->name,
                'Email: '.$objUser->email
            );
            $data = array(
                'log_details'   => serialize($log_details),
                'menu_name'     => 'Deleted User',
                'created_by'    => Auth::user()->id
            );
            $objLog->insertIntoLogTable($data);

            return redirect('dashboard/user')->with('success', 'User deleted successfully!');

        }
        else {
            return redirect('dashboard/user')->with('error', 'User not deleted!');
        }
    }
    public function viewprofile(Request $request){
        $userId = Auth::user()->id;
        $currentUser = User::find($userId);
//        echo '<pre>';
//        print_r($userId);
//        print_r(json_decode($currentUser));
//        exit();
        return view('viewprofile')->with('data', $currentUser)->with('id', $userId);
    }
    public  function  profileupdate( Request $request){
        $userId = Auth::user()->id;

        $currentUser = \App\User::find($userId);
        return view('profileupdate')->with('data', $currentUser)->with('id',$userId);
    }
    public function postprofileupdate(Request $request){

        $userId = Auth::user()->id;

        $objPost = User::find($userId);
        $objPost->name = $request->name;
        $objPost->email = $request->email;
        $objPost->phone = $request->phone;
        $objPost->address = $request->address;
        $objPost->organization_name = $request->organization_name;
        $objPost->designation = $request->designation;

        //$objPost->status = $request->status;

        if($objPost->save()){

            $objLog = new LogTable();
            $log_details = array(
                'Login Name: '.$request->name,
                'Email: '.$request->email
            );
            $data = array(
                'log_details'   => serialize($log_details),
                'menu_name'     => 'Updated User Profile',
                'created_by'    => Auth::user()->id
            );
            $objLog->insertIntoLogTable($data);

            return redirect('dashboard/viewprofile')->with('success', 'User Profile updated successfully!');

        }
        else{

            return redirect('dashboard/viewprofile')->with('error', 'User Profile not updated!');

        }
    }
    public function passwordupdate(Request $request){
        $userId = Auth::user()->id;
        $currentUser = User::find($userId);
        return view('passwordupdate')->with('data', $currentUser)->with('id', $userId);
    }
    public function postpasswordupdate(Request $request){
        $userId = Auth::user()->id;
        $old_password = $request->oldpassword;
        $new_password = $request->newpassword;
        if($new_password != $old_password){

            $objUser = User::find($userId);

            if(Hash::check($new_password, $objUser->password)){

                $msg = 'Old Password mismatched!';
                return redirect('dashboard/passwordupdate')->with('error', 'You Cannot Use Old Password!');

            }else{

                $objUser->password = bcrypt($new_password);
                $objUser->save();

                $objLog = new LogTable();
                $log_details = array(
                    'Login Name: '.$request->name,
                    'Email: '.$request->email
                );
                $data = array(
                    'log_details'   => serialize($log_details),
                    'menu_name'     => 'Updated User Password',
                    'created_by'    => Auth::user()->id
                );
                $objLog->insertIntoLogTable($data);

                $msg = 'Password changed successfully!';

            }

            return redirect('dashboard/viewprofile')->with('success', $msg);

        }
        else{
            return redirect('dashboard/passwordupdate')->with('error', 'You Cannot Use Old Password!');
        }

    }
}

