<?php

namespace App\Http\Controllers\dashboard;

use App\Menu;
use App\MenuType;
use App\User;
use App\UserGroupMenuMapping;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

class MenuController extends Controller
{

    public function __construct(Request $request)
    {
        $this->middleware('auth');

//        echo Auth::user()->id;

////        $request->url()
//
////        echo Auth::user();
////
//        exit();
//
//        $objData = new UserGroupMenuMapping();
//
//        $data = $objData->userGroupMenuPolicy($request->url());
//
//        echo '<pre>';
//        print_r($data);
//        echo '</pre>';

//        echo $request->url();

//        return 1;
    }

    public function index(Request $request){

//        $user_id = Auth::user()->id;
//
////        $request->url()
//
////        echo Auth::user();
//
//
//        $objData = new UserGroupMenuMapping();
//
//        $data = $objData->userGroupMenuPolicy(Auth::user()->id, $request->url());
//
//        echo '<pre>';
//        print_r($data);
//        echo '</pre>';
//
//        exit();



        $result = Menu::leftJoin('menu_type', 'menu_type.id', '=', 'menu.menu_type_id')
            ->where('menu.status', 'Y')
            ->select('menu.*', 'menu_type.menu_type_name')
            ->get();

        return view('dashboard/menulist')->with('data',$result);

    }
    public function create(Request $request){

        $data = new \stdClass();
        $data->id = '';
        $data->menu_name = '';
        $data->menu_slug = '';
        $data->menu_desc = '';
        $data->menu_order = '';
        $data->menu_type_id = '';

        $menu_type = MenuType::where('status','Y')->get();

        return view('dashboard/addmenu')->with('data', $data)->with('menu_type', $menu_type)->with('route', 'add');

    }
    public function postcreate(Request $request){

        $formdata = $request->formdata;
        
        $objMenu = new Menu();
        $objMenu->menu_name = $formdata['menu_name'];
        $objMenu->menu_slug = $formdata['menu_slug'];
        $objMenu->menu_desc = $formdata['menu_desc'];
        $objMenu->menu_order = $formdata['menu_order'];
        $objMenu->menu_type_id = (!empty($formdata['menu_type_id']))?$formdata['menu_type_id']:0;
        $objMenu->status = 'Y';

        if($objMenu->save()){

            return redirect('dashboard/menu')->with('success', 'Menu created successfully!');

        }else {
            return redirect('dashboard/menu')->with('error', 'Menu cannot be created.');
        }
    }
    public function update($id){

        $menu_type = MenuType::where('status','Y')->get();

        $data = Menu::find($id);
        return view('dashboard/addmenu')->with('data', $data)->with('menu_type', $menu_type)->with('route', 'edit');
    }
    public function postupdate(Request $request){

        $formdata = $request->formdata;

        $objMenu = Menu::find($formdata['id']);
        $objMenu->menu_name = $formdata['menu_name'];
        $objMenu->menu_slug = $formdata['menu_slug'];
        $objMenu->menu_desc = $formdata['menu_desc'];
        $objMenu->menu_order = $formdata['menu_order'];
        $objMenu->menu_type_id = (!empty($formdata['menu_type_id']))?$formdata['menu_type_id']:0;
        $objMenu->status = 'Y';

        if($objMenu->save())
            return redirect('dashboard/menu')->with('success', 'Menu Updated Successfully!');
        else
            return redirect('dashboard/menu')->with('error', 'Menu Not Updated!');

    }
    public function delete($id){
        $objMenu = Menu::find($id);
        $objMenu->status = 'N';

        if($objMenu->save())
            return redirect('dashboard/menu')->with('success', 'Menu deleted successfully!');
        else
            return redirect('dashboard/menu')->with('error', 'Menu not deleted!');
    }
}
