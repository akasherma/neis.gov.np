<?php

namespace App\Http\Controllers\dashboard;

use App\LogTable;
use App\Menu;
use App\UserGroup;
use App\UserGroupMenuMapping;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

class UserGroupController extends Controller
{
    public function index(){
        $result = UserGroup::where('status','Y')->get();
        return view('dashboard/user_group_list')->with('data',$result);
    }
    public function create(){
        $data = new \stdClass();
        $data->id = '';
        $data->user_group_name = '';
        $data->user_group_slug = '';
        $data->user_group_desc = '';
        $data->user_level = '';
        $data->status = '';

        return view('dashboard/add_user_group')->with('data', $data)->with('route', 'add');
    }
    public function postcreate(Request $request){

        $objPost = new UserGroup();
        $objPost->user_group_name = $request->user_group_name;
        $objPost->user_group_slug = str_replace(' ','-',strtolower($request->user_group_name));
        $objPost->user_group_desc = (!empty($request->user_group_desc))?$request->user_group_desc:null;
        $objPost->user_level = (!empty($request->user_level))?$request->user_level:null;
        $objPost->status = 'Y';

//        'user_group_name', 'user_group_slug', 'user_group_desc', 'status'

        if($objPost->save()){

            $objLog = new LogTable();
            $log_details = array(
                'User Group Name: '.$request->user_group_name );
            $data = array(
                'log_details'   => serialize($log_details),
                'menu_name'     => 'Added User Group',
                'created_by'    => Auth::user()->id
            );
            $objLog->insertIntoLogTable($data);

            return redirect('dashboard/user_group')->with('success', 'User Group Created Successfully!');

        }
        else{

            return redirect('dashboard/user_group')->with('error', 'User Group Not Created!');

        }
    }
    public  function  update($id){
        $data = UserGroup::find($id);
        return view('dashboard/add_user_group')->with('data', $data)->with('route', 'edit');
    }
    public function postupdate(Request $request){
        $objPost = UserGroup::find($request->id);
        $objPost->user_group_name = $request->user_group_name;
        $objPost->user_group_desc = (!empty($request->user_group_desc))?$request->user_group_desc:null;
        $objPost->user_level = (!empty($request->user_level))?$request->user_level:null;

        if($objPost->save()){

            $objLog = new LogTable();
            $log_details = array(
                'User Group Name: '.$request->user_group_name );
            $data = array(
                'log_details'   => serialize($log_details),
                'menu_name'     => 'Updated User Group',
                'created_by'    => Auth::user()->id
            );
            $objLog->insertIntoLogTable($data);

            return redirect('dashboard/user_group')->with('success', 'User Group updated successfully!');

        }
        else{

            return redirect('dashboard/user_group')->with('error', 'User Group not updated!');

        }

    }
    public function delete($id){
        $objPost = UserGroup::find($id);
        $objPost->status = 'N';

        if($objPost->save())
            return redirect('dashboard/user_group')->with('success', 'User Group deleted successfully!');
        else
            return redirect('dashboard/user_group')->with('error', 'User Group not deleted!');
    }

    public function policy($user_group_id){

        $this_user_group = UserGroup::find($user_group_id);

        $objMenuUserType = UserGroupMenuMapping::where('user_group_id', $user_group_id)
            ->select('menu_id')
            ->get()
            ->toArray();

        $checked_menu_type_id = array();

        if(count($objMenuUserType) > 0)
            foreach($objMenuUserType as $the_menu_type_id)
                array_push($checked_menu_type_id, $the_menu_type_id['menu_id']);

        $objMenu = Menu::where('status', 'Y')->get();

//        echo '<pre>';
//        print_r(json_decode($objMenu));
//        echo '<hr />';
//        print_r($checked_menu_type_id);
//        echo '</pre>';
//
//        exit();

        /*echo '<pre>';
        print_r($objServicetypeServicefieldMapping);
        echo '</pre>';
        echo '<pre>';
        print_r($objServicefield);
        echo '</pre>';
        exit();*/

        return view('dashboard/menu_user_group')
            ->with('route', 'policy')
            ->with('this_user_group', $this_user_group)
            ->with('menus', $objMenu)
            ->with('plot', $checked_menu_type_id);
    }
    public function updatepolicy(Request $request){
        $user_group_id = $request->user_group_id;
        $menu_ids = $request->menu_id;

//        echo '<pre>';
//        print_r($serviceTypeId);
//        echo '</pre>';
//
//        echo '<pre>';
//        print_r($serviceFieldId);
//        echo '</pre>';
//        exit();

        UserGroupMenuMapping::where('user_group_id', $user_group_id)->delete();

//    echo json_decode($objUser);
//    exit();
//    $objUser->delete();

        for ($i = 0; $i < count($menu_ids); $i++) {
            $objUserGroupMenuMapping = new UserGroupMenuMapping();
            $objUserGroupMenuMapping->menu_id = $menu_ids[$i];
            $objUserGroupMenuMapping->user_group_id = $user_group_id;
            $objUserGroupMenuMapping->status = 'Y';
            $objUserGroupMenuMapping->save();
        }
        return redirect('dashboard/user_group')->with('success', 'User Group Policy saved changes.');

    }
}
