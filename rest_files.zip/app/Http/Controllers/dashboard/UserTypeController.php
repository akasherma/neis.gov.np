<?php

namespace App\Http\Controllers\dashboard;

use App\UserType;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class UserTypeController extends Controller
{
    public function index(){
        $result = UserType::where('status','Y')->get();
        return view('usertype-list')->with('data',$result);
    }
    public function create(){
        return view('addusertype');
    }
    public function postcreate(Request $request){

        $objPost = new UserType();
        $objPost->user_type_name = $request->user_type_name;
        $objPost->user_type_slug = str_replace(' ','-',strtolower($request->user_type_name));
        $objPost->user_type_desc = $request->user_type_desc;
        //$objUser->company_logo = $request->post_slug;
        //$objUser->other_logo = $request->post_slug;
        $objPost->status = $request->status;

        if($objPost->save())
            return redirect('user/dashboard/usertype')->with('success', 'User Type Created Successfully!');
        else
            return redirect('user/dashboard/usertype')->with('error', 'User Type Not Created!');
    }
    public  function  update($id){
        $data = UserType::find($id);
        return view('editusertype')->with('data', $data)->with('id',$id);
    }
    public function postupdate(Request $request){
        $objPost = UserType::find($request->id);
        $objPost->user_type_name = $request->user_type_name;
        //$objPost->company_applied_for_slug = $request->company_applied_for_slug;
        $objPost->user_type_desc = $request->user_type_desc;
        $objPost->status = $request->status;

        if($objPost->save())
            return redirect('user/dashboard/usertype')->with('success', 'User Type updated successfully!');
        else
            return redirect('user/dashboard/usertype')->with('error', 'User Type not updated!');

    }
    public function delete($id){
        $objPost = UserType::find($id);
        $objPost->status = 'N';

        if($objPost->save())
            return redirect('user/dashboard/usertype')->with('success', 'User Type deleted successfully!');
        else
            return redirect('user/dashboard/usertype')->with('error', 'User Type not deleted!');
    }
}
