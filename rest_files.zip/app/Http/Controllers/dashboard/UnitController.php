<?php

namespace App\Http\Controllers\dashboard;

use App\Unit;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use stdClass;

class UnitController extends Controller
{
    //
    public function __construct(){
        $this->middleware('auth');
    }
    public function index(){
        $result = Unit::where('status', 'Y')->get();
        return view('dashboard.unitlist')->with('data', $result);
    }
    public function create(){
        $objPost = new StdClass();
        $objPost->id = '';
        $objPost->unit_name = '';
        $objPost->unit_slug = '';
        $objPost->unit_desc = '';
        $objPost->unit_short_form = '';
        $objPost->status = '';
        return view('dashboard/unitadd')->with('data', $objPost)->with('route', 'add');
    }
    public function postCreate(Request $request){
        $formdata = $request->formdata;

        // echo '<pre>';
        // print_r($formdata);
        // echo '</pre>';
        // exit();

        $formdata['unit_slug'] = (empty($formdata['unit_name']))?$formdata['unit_name']:str_replace(" ","-", strtolower($formdata['unit_name']));
//        $formdata['sector_order'] = (!empty($formdata['sector_order']))?$formdata['sector_order']:0;

        $objPost = new Unit();
        $objPost->unit_name = $formdata['unit_name'];
        $objPost->unit_slug = $formdata['unit_slug'];
        $objPost->unit_desc = $formdata['unit_desc'];
        $objPost->unit_short_form = $formdata['unit_short_form'];
        $objPost->status = 'Y';


        if($objPost->save())
            return redirect('dashboard/unit/edit/'.$objPost->id)->with('success', 'Unit added successfully!');
        else
            return redirect('dashboard/unit')->with('error', 'Unit cannot be added!');
    }
    public function update($id = ''){
        $objPost = Unit::find($id);

        if($id == '' || is_null($objPost)):

            return redirect('dashboard/unit')->with('error', 'No Unit Selected!');

        else:

            return view('dashboard/unitadd')
                ->with('route', 'edit')
                ->with('data', $objPost);

        endif;
    }
    public function postUpdate(Request $request){
        $formdata = $request->formdata;

        $objPost = Unit::find($formdata['id']);
        $objPost->unit_name = $formdata['unit_name'];
        $objPost->unit_desc = $formdata['unit_desc'];
        $objPost->unit_short_form = $formdata['unit_short_form'];
        //$formdata['land_type_slug'] = (empty($formdata['land_type_name']))?$formdata['land_type_name']:str_replace(" ","-", strtolower($formdata['land_type_name']));
        //$objPost->land_type_slug = $formdata['land_type_slug'];
        $objPost->save();

        return redirect('dashboard/unit/edit/'.$objPost->id)->with('success', 'Unit updated successfully!');
    }
    public function delete($id){
        $objPost = Unit::find($id);
        $objPost->status = 'N';
        $objPost->save();

        return redirect('dashboard/unit')->with('error', 'Unit deleted successfully!');
    }
}
