<?php

namespace App\Http\Controllers\dashboard;
use App\CountryAppliedFor;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CountryAppliedForController extends Controller
{
    public function index(){
        $result = CountryAppliedFor::where('status','Y')->get();
        return view('country-list')->with('data',$result);
    }
    public function create(){
        return view('addcountry');
    }
    public function postcreate(Request $request){

        $objPost = new CountryAppliedFor();
        $objPost->country_applied_for_name = $request->country_applied_for_name;
        $objPost->country_applied_for_slug = str_replace(' ','-',strtolower($request->country_applied_for_name));
        $objPost->country_applied_for_desc = $request->country_applied_for_desc;
        //$objUser->company_logo = $request->post_slug;
        //$objUser->other_logo = $request->post_slug;
        $objPost->status = $request->status;

        if($objPost->save())
            return redirect('/user/dashboard/country')->with('success', 'Country Created Successfully!');
        else
            return redirect('/user/dashboard/country')->with('error', 'Country Not Created!');
    }
    public  function  update($id){
        $data = CountryAppliedFor::find($id);
        return view('editcountry')->with('data', $data)->with('id',$id);
    }
    public function postupdate(Request $request){

        $objPost = CountryAppliedFor::find($request->id);
        $objPost->country_applied_for_name = $request->country_applied_for_name;
        //$objPost->company_applied_for_slug = $request->company_applied_for_slug;
        $objPost->country_applied_for_desc = $request->country_applied_for_desc;
        $objPost->status = $request->status;

        if($objPost->save())
            return redirect('user/dashboard/country')->with('success', 'Country updated successfully!');
        else
            return redirect('user/dashboard/country')->with('error', 'Country not updated!');

    }
    public function delete($id){
        $objPost = CountryAppliedFor::find($id);
        $objPost->status = 'N';

        if($objPost->save())
            return redirect('user/dashboard/country')->with('success', 'Country deleted successfully!');
        else
            return redirect('user/dashboard/country')->with('error', 'Country not deleted!');
    }
}
