<?php

namespace App\Http\Controllers\dashboard;

use App\Menu;
use App\Records;
use App\River;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use stdClass;

class RecordController extends Controller
{

    public function __construct(){
        $this->middleware('auth');
    }
    public function index($record = ''){
//        echo $record;
        $menu = Menu::where('menu_slug', '=', $record)->where('status', '=', 'Y')->first();
//        echo '<pre>';
//        print_r(json_decode($menu));
//        echo '</pre>';
//        exit();
        if($record != '' && !empty($menu->menu_slug)){

            $result = Records::where('menu_id', '=', $menu->id)->where('status', 'Y')->get();
//            echo '<pre>';
//            print_r(json_decode($result));
//            echo '</pre>';
//            exit();
            return view('dashboard.recordlist')->with('data', $result)->with('menu', $menu);
        }else{
            return redirect('dashboard')->with('warning', 'First choose any Record!');
        }
    }
    public function create($record = ''){
        $menu = Menu::where('menu_slug', '=', $record)->where('status', '=', 'Y')->first();
//        echo '<pre>';
//        print_r(json_decode($menu));
//        echo '</pre>';
//        exit();
        if($record != '' && !empty($menu->menu_slug)){
            $objPost = new StdClass();
            $objPost->id = '';
            $objPost->record_name = '';
            $objPost->record_desc = '';
            $objPost->record_type = '';
            $objPost->address = '';
            $objPost->capacity = '';
            $objPost->unit = '';
            $objPost->lat = '';
            $objPost->lang = '';
            $objPost->status = '';
            return view('dashboard/recordadd')->with('data', $objPost)->with('menu', $menu)->with('route', 'add');
        }else{
            return redirect('dashboard')->with('warning', 'First choose any Record!');
        }
    }
    public function postCreate(Request $request){
        $formdata = $request->formdata;

//         echo '<pre>';
//         print_r($formdata);
//         echo '</pre>';
//         exit();


//        echo '<pre>';
//        print_r(json_decode($menu));
//        echo '</pre>';
//        exit();

        if($formdata['menu_id'] != '') {
            $menu = Menu::find($formdata['menu_id']);

            $formdata['record_slug'] = (empty($formdata['record_name'])) ? $formdata['record_name'] : str_replace(" ", "-", strtolower($formdata['record_name']));

            $objPost = new Records();
            $objPost->record_name = $formdata['record_name'];
            $objPost->record_desc = $formdata['record_desc'];
            $objPost->record_type = (!empty($formdata['record_type'])) ? $formdata['record_type'] : '';
            $objPost->address = $formdata['address'];
            $objPost->capacity = $formdata['capacity'];
            $objPost->unit = $formdata['unit'];
            $objPost->lat = $formdata['lat'];
            $objPost->lang = $formdata['lang'];
            $objPost->record_slug = $formdata['record_slug'];
            $objPost->menu_id = $formdata['menu_id'];
            $objPost->status = 'Y';

            if ($objPost->save() && (!empty($menu->menu_slug))) {
                $route = 'dashboard/records/' . $menu->menu_slug . '/edit/' . $objPost->id;
                return redirect($route)->with('success', 'Record added successfully!');
            }else if ((!empty($menu->menu_slug))) {
                $route = 'dashboard/records/' . $menu->menu_slug;
                return redirect($route)->with('success', 'Record cannot be added!');
            }else{
                return redirect('dashboard/')->with('error', 'Record cannot be added!');
            }
        }
        else{
            return redirect('dashboard')->with('error', 'Record cannot be added!');
        }
    }
    public function update($record = '', $id = ''){
        $menu = Menu::where('menu_slug', '=', $record)->where('status', '=', 'Y')->first();
//        echo '<pre>';
//        print_r(json_decode($menu));
//        echo '</pre>';
//        exit();
        if($record != '' && !empty($menu->menu_slug)){

            $objPost = Records::find($id);

            if($id == '' || is_null($objPost)):

                return redirect('dashboard/records/'.$menu->menu_slug)->with('error', 'No Record Selected!');

            else:

                return view('dashboard/recordadd')
                    ->with('route', 'edit')
                    ->with('menu', $menu)
                    ->with('data', $objPost);

            endif;
        }else{
            return redirect('dashboard')->with('warning', 'First choose any Record!');
        }

    }
    public function postUpdate(Request $request){
        $formdata = $request->formdata;

        if($formdata['menu_id'] != '') {
            $menu = Menu::find($formdata['menu_id']);

            $objPost = Records::find($formdata['id']);
            $objPost->record_name = $formdata['record_name'];
            $objPost->record_type = (!empty($formdata['record_type'])) ? $formdata['record_type'] : '';
            $objPost->record_desc = $formdata['record_desc'];

            $objPost->address = $formdata['address'];
            $objPost->capacity = $formdata['capacity'];
            $objPost->unit = $formdata['unit'];
            $objPost->lat = $formdata['lat'];
            $objPost->lang = $formdata['lang'];

            //$formdata['land_type_slug'] = (empty($formdata['land_type_name']))?$formdata['land_type_name']:str_replace(" ","-", strtolower($formdata['land_type_name']));
            //$objPost->land_type_slug = $formdata['land_type_slug'];
//            $objPost->save();
//
//            return redirect('dashboard/river/edit/'.$objPost->id)->with('success', 'River updated successfully!');

            if ($objPost->save() && (!empty($menu->menu_slug))) {
                $route = 'dashboard/records/' . $menu->menu_slug . '/edit/' . $objPost->id;
                return redirect($route)->with('success', 'Record updated successfully!');
            }else if ((!empty($menu->menu_slug))) {
                $route = 'dashboard/records/' . $menu->menu_slug;
                return redirect($route)->with('success', 'Record cannot be updated!');
            }else{
                return redirect('dashboard/records/'.$menu->menu_slug)->with('error', 'Record cannot be updated!');
            }

        }
        else{
            return redirect('dashboard')->with('error', 'Record cannot be added!');
        }
    }
    public function delete($record = '', $id){

        $menu = Menu::where('menu_slug', '=', $record)->where('status', '=', 'Y')->first();

//        echo '<pre>';
//        print_r(json_decode($menu));
//        echo '</pre>';
//        exit();

        if($record != '' && !empty($menu->menu_slug)){

            $objPost = Records::find($id);
            $objPost->status = 'N';
            $objPost->save();

            if ($objPost->save() && (!empty($menu->menu_slug))) {
                $route = 'dashboard/records/' . $menu->menu_slug;
                return redirect($route)->with('error', 'Record deleted successfully!');
            }else if ((!empty($menu->menu_slug))) {
                $route = 'dashboard/records/' . $menu->menu_slug;
                return redirect($route)->with('success', 'Record cannot be deleted!');
            }else{
                return redirect('dashboard')->with('error', 'Record cannot be deleted!');
            }

        }else{
            return redirect('dashboard')->with('warning', 'First choose any Record!');
        }

}
}
