<?php

namespace App\Http\Controllers\dashboard;

use App\Energy;
use App\EnergyTypes;
use App\FuelType;
use App\LogTable;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use \stdClass;

class EnergyController extends Controller
{

    public function __construct(){
        $this->middleware('auth');
    }

    public function index(){

        $result = Energy::leftJoin('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
            ->select('energy.*', 'fuel_type.fuel_type_name')
            ->get();

        return view('dashboard.energy_list')
            ->with('data', $result);
    }

    /**
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function create(){

        $objEnergy=new StdClass();
        $objEnergy->id = '';
        $objEnergy->energy_name = '';
        $objEnergy->energy_slug = '';
        $objEnergy->energy_desc = '';
        $objEnergy->fuel_type_id = '';
        $objEnergy->status = '';
        $objEnergy->is_deleted = '';
        $objEnergy->economic_survey_status = '';

//        energy_name`,  `energy_slug`,  LEFT(`energy_desc`, 256),  `fuel_type_id`,  `status

        $energy_type_list = EnergyTypes::where('status', 'Y')->get();

        $fuel_type_list = FuelType::where('status', 'Y')->where('is_last_child', 'Y')->get();

        return view('dashboard/energy_add')
            ->with('data', $objEnergy)
            ->with('energy_type', $energy_type_list)
            ->with('fuel_type', $fuel_type_list)
            ->with('route', 'add');
    }
    public function postCreate(Request $request) {
        $formdata = $request->formdata;

        // echo '<pre>';
        // print_r($formdata);
        // echo '</pre>';
        // exit();

        $formdata['energy_slug'] = 'energy-'.now();

        if(!empty($formdata['energy_name'])){
            $formdata['energy_slug'] = str_replace(" ","-", str_replace("/","", strtolower($formdata['energy_name'])));
        }

        $objEnergy = new Energy();

        $objEnergy->energy_name = $formdata['energy_name'];
        $objEnergy->energy_slug = $formdata['energy_slug'];
        $objEnergy->energy_desc = $formdata['energy_desc'];
        $objEnergy->fuel_type_id = $formdata['fuel_type_id'];
        $objEnergy->status = (!empty($formdata['status']))?$formdata['status']:'N';
        $objEnergy->economic_survey_status = (!empty($formdata['economic_survey_status']))?$formdata['economic_survey_status']:'N';
        $objEnergy->status = 'Y';

        if($objEnergy->save()){

            $objLog = new LogTable();
            $log_details = array('Energy ID: '.$objEnergy->id
            );
            $data = array(
                'log_details'   => serialize($log_details),
                'menu_name'     => 'New Energy Conversion Data',
                'created_by'    => Auth::user()->id
            );
            $objLog->insertIntoLogTable($data);

            return redirect('dashboard/energy')->with('success', 'Energy Conversion added successfully!');

        }else{
            return redirect('dashboard/energy')->with('error', 'Energy Conversion cannot be added!');
        }

    }
    public function update($id = '') {

        $objEnergy = Energy::find($id);

        $energy_type_list = EnergyTypes::where('status', 'Y')->get();

        $fuel_type_list = FuelType::where('status', 'Y')->where('is_last_child', 'Y')->get();

        if($id == '' || is_null($objEnergy)):

            return redirect('dashboard/energy')->with('error', 'No Energy Selected!');

        else:

            return view('dashboard/energy_add')
                ->with('route', 'update')
                ->with('energy_type', $energy_type_list)
                ->with('fuel_type', $fuel_type_list)
                ->with('data', $objEnergy);

        endif;

    }

    public function postUpdate(Request $request) {

        $formdata = $request->formdata;

        $objEnergy = Energy::find($formdata['id']);
        $objEnergy->energy_name = $formdata['energy_name'];
        $objEnergy->energy_desc = $formdata['energy_desc'];
        $objEnergy->fuel_type_id = $formdata['fuel_type_id'];
        $objEnergy->status = (!empty($formdata['status']))?$formdata['status']:'N';
        $objEnergy->economic_survey_status = (!empty($formdata['economic_survey_status']))?$formdata['economic_survey_status']:'N';

        $objEnergy->save();

        $objLog = new LogTable();
        $log_details = array('Energy ID: '.$formdata['id']
        );
        $data = array(
            'log_details'   => serialize($log_details),
            'menu_name'     => 'Update Energy Conversion Data',
            'created_by'    => Auth::user()->id
        );
        $objLog->insertIntoLogTable($data);

        return redirect('dashboard/energy')->with('success', 'Energy updated successfully!');

    }

    public function delete($id) {

        $objEnergy = Energy::find($id);
        $objEnergy->is_deleted = 'N';
        $objEnergy->save();

        return redirect('dashboard/energy')->with('error', 'Energy deleted successfully!');

    }

}
