<?php

namespace App\Http\Controllers\dashboard;


use App\Location;
use App\LocationType;
use App\LogTable;
use App\UserGroupMenuMapping;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use stdClass;

class LocationController extends Controller
{
    //
    public function __construct(){
        $this->middleware('auth');
    }
    public function index(Request $request){

        $objData = new UserGroupMenuMapping();
        $data = $objData->userGroupMenuPolicy(Auth::user()->id, 'location');
        if(((int)$data) < 1)
            return redirect('dashboard')->with('warning', 'You do not have permission to enter into the location section!');

//        echo '<pre>';
//        print_r($data);
//        echo '</pre>';
//        exit();

        //$result = Location::where('status','Y')->get();
        $result = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->leftJoin('location as location_parent', 'location_parent.id', '=', 'location.parent_id')
            ->where('location.status','Y')
            ->select('location.*', 'location_type.location_type_name', 'location_parent.location_name as location_parent_name')
            ->get();
        return view('dashboard/locationlist')->with('data', $result);
    }
    public function create(){
        $objPost = new StdClass();
        $objPost->id = '';
        $objPost->location_name = '';
        $objPost->location_slug = '';
        $objPost->location_type_id = '';
        $objPost->parent_id = '';
        $objPost->status = '';

        $objLocationType = LocationType::where('status','Y')->get();

        $objLocation = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location.status','Y')
            ->select('location.*', 'location_type.child_id as location_type_parent')
            ->get();

//        echo '<pre>';
//        print_r(json_decode($objLocation));
//        echo '</pre>';
//        exit();

        return view('dashboard.locationadd')
            ->with('location_type', $objLocationType)
            ->with('location', $objLocation)
            ->with('route', 'add')
            ->with('data', $objPost);
    }
    public  function postCreate(Request $request){
        $formdata = $request->formdata;

        // echo '<pre>';
        // print_r($formdata);
        // echo '</pre>';
        // exit();

        $formdata['location_slug'] = (empty($formdata['location_name']))?$formdata['location_name']:str_replace(" ","-", strtolower($formdata['location_name']));
//        $formdata['parent_id'] = (!empty($formdata['parent_id']))?$formdata['parent_id']:0;

        $objPost = new Location();
        $objPost->location_name = $formdata['location_name'];
        $objPost->location_slug = $formdata['location_slug'];
        $objPost->location_type_id = $formdata['location_type_id'];
        $objPost->parent_id = (!empty($formdata['parent_id']))? $formdata['parent_id']: 0;
        $objPost->status = 'Y';


        if($objPost->save()){

            $objLog = new LogTable();
            $log_details = array(
                'Location Name: '.$formdata['location_name']
            );
            $data = array(
                'log_details'   => serialize($log_details),
                'menu_name'     => 'Added New Location',
                'created_by'    => Auth::user()->id
            );
            $objLog->insertIntoLogTable($data);

            return redirect('dashboard/location')->with('success', 'Location added successfully!');

        }
        else{
            return redirect('dashboard/location')->with('error', 'Location cannot be added!');
        }
    }
    public function update($id){
        $data = Location::find($id);
        $locationType = LocationType::where('status', 'Y')->get();


//            if($id == '' || is_null($objPost)):
//
//                return redirect('dashboard/location')->with('error', 'No Location Selected!');
//
//            else:
//            $objLocationType = LocationType::where('status','Y')->get();

            $objLocation = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location.status','Y')
                ->select('location.*', 'location_type.child_id as location_type_parent')
                ->get();

//            echo '<pre>';
//            print_r(json_decode($objLocation));
//            echo '</pre>';
//            exit();

            return view('dashboard/locationadd')
                ->with('route', 'update')
                ->with('data', $data)
                ->with('location_type', $locationType)
                ->with('location', $objLocation);

//        endif;
    }
    public function postUpdate(Request $request){
        $formdata = $request->formdata;

        $objPost = Location::find($formdata['id']);
        $objPost->location_name = $formdata['location_name'];
        $objPost->location_type_id = $formdata['location_type_id'];
        $objPost->parent_id = (!empty($formdata['parent_id']))? $formdata['parent_id']: 0;

        $objPost->save();

        $objLog = new LogTable();
        $log_details = array(
            'Location Name: '.$formdata['location_name']
        );
        $data = array(
            'log_details'   => serialize($log_details),
            'menu_name'     => 'Updated Location',
            'created_by'    => Auth::user()->id
        );
        $objLog->insertIntoLogTable($data);

        return redirect('dashboard/location')->with('success', 'Location Updated successfully!');
    }
    public function delete($id){
        $objPost = Location::find($id);
        $objPost->status = 'N';
        $objPost->save();

        return redirect('dashboard/location')->with('error', 'Location Deleted successfully!');
    }
}
