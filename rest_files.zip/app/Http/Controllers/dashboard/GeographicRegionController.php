<?php

namespace App\Http\Controllers\dashboard;

use App\GeographicRegion;
use App\LogTable;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use stdClass;

class GeographicRegionController extends Controller
{
    //
    public function __construct(){
        $this->middleware('auth');
    }
    public function index(){
        $result = GeographicRegion::where('status','Y')->get();
        return view('dashboard.geographicregionlist')->with('data',$result);
    }
    public function create(){
        $objPost =new StdClass();
        $objPost->id = '';
        $objPost->geographic_region_name = '';
        $objPost->geographic_region_slug = '';
        $objPost->geographic_region_desc = '';
        $objPost->status = '';
        return view('dashboard/geographicregionadd')->with('data', $objPost)->with('route', 'add');
    }
    public function postCreate(Request $request) {
        $formdata = $request->formdata;

        // echo '<pre>';
        // print_r($formdata);
        // echo '</pre>';
        // exit();

        $formdata['geographic_region_slug'] = (!empty($formdata['geographic_region_name']))?$formdata['geographic_region_name']:str_replace(" ","-", strtolower($formdata['geographic_region_name']));
//        $formdata['sector_order'] = (!empty($formdata['sector_order']))?$formdata['sector_order']:0;

        $objPost = new GeographicRegion();
        $objPost->geographic_region_name = $formdata['geographic_region_name'];
        $objPost->geographic_region_slug = $formdata['geographic_region_slug'];
        $objPost->geographic_region_desc = $formdata['geographic_region_desc'];
        $objPost->status = 'Y';


        if($objPost->save()){

            $objLog = new LogTable();
            $log_details = array(
                'Geographic Region Name: '.$formdata['geographic_region_name'], 'Description'.$formdata['geographic_region_desc']
            );
            $data = array(
                'log_details'   => serialize($log_details),
                'menu_name'     => 'Added New Geographic Region',
                'created_by'    => Auth::user()->id
            );
            $objLog->insertIntoLogTable($data);

            return redirect('dashboard/geographic-region')->with('success', 'Geographic Region added successfully!');

        }
        else{

            return redirect('dashboard/geographic-region')->with('error', 'Geographic Region cannot be added!');

        }

    }
    public function update($id = '') {

        $objPost = GeographicRegion::find($id);

        if($id == '' || is_null($objPost)):

            return redirect('dashboard/geographic-region')->with('error', 'No Geographic Region Selected!');

        else:

            return view('dashboard/geographicregionadd')
                ->with('route', 'update')
                ->with('data', $objPost);

        endif;

    }

    public function postUpdate(Request $request) {

        $formdata = $request->formdata;

        $objPost = GeographicRegion::find($formdata['id']);
        $objPost->geographic_region_name = $formdata['geographic_region_name'];
        $objPost->geographic_region_desc = $formdata['geographic_region_desc'];

        $objPost->save();

        $objLog = new LogTable();
        $log_details = array(
            'Geographic Region Name: '.$formdata['geographic_region_name'], 'Description'.$formdata['geographic_region_desc']
        );
        $data = array(
            'log_details'   => serialize($log_details),
            'menu_name'     => 'Updated Geographic Region',
            'created_by'    => Auth::user()->id
        );
        $objLog->insertIntoLogTable($data);

        return redirect('dashboard/geographic-region')->with('success', 'Geographic Region updated successfully!');

    }

    public function delete($id) {

        $objPost = GeographicRegion::find($id);
        $objPost->status = 'N';
        $objPost->save();

        return redirect('dashboard/geographic-region')->with('error', 'Geographic Region deleted successfully!');

    }
}
