<?php

namespace App\Http\Controllers\dashboard;

use App\ResourcesEnergyForm;
use App\Energy;
use App\EnergyFormMeta;
use App\EnergyTypes;
use App\EnergyTypeTopicMapping;
use App\GeographicRegion;
use App\LandType;
use App\Location;
use App\LogTable;
use App\River;
use App\Sector;
use App\Unit;
use App\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use stdClass;

class ResourcesEnergyFormController extends Controller
{

    public function __construct(){
        $this->middleware('auth');
    }

    public function index(){

        $user_id = Auth::user()->id;
        $objUser = new User();
        $route = $objUser->getUserLevel($user_id);

        $result = ResourcesEnergyForm::join('energy', 'energy.id', '=', 'resources_energy_form.energy_id')
            ->leftJoin('location as lp', 'lp.id', '=', 'resources_energy_form.province_id')
            ->leftJoin('location as ld', 'ld.id', '=', 'resources_energy_form.district_id')
            ->leftJoin('location as ll', 'll.id', '=', 'resources_energy_form.local_gov_id')
            ->select('energy.id', 'energy.energy_name', 'resources_energy_form.*', 'lp.location_name as province', 'ld.location_name as district', 'll.location_name as local_gov')
            ->where('resources_energy_form.status', 'Y')
            ->get();

        return view('dashboard.resources_energy_form_list')
            ->with('route', $route)
            ->with('data', $result);
    }

    public function postCreate(Request $request) {
        $entered_by = Auth::user()->id;
        $formdata = $request->formdata;
        $land_type = $request->land_type;
        $sector = $request->sector;
        $river = $request->river;
        $geographic_region = $request->geographic_region;
        $overall = $request->overall;

        $energy_id = $formdata['energy_id'];
        $central_id = (!empty($formdata['central_id']))?$formdata['central_id']:null;
        $province_id = (!empty($formdata['province_id']))?$formdata['province_id']:null;
        $district_id = (!empty($formdata['district_id']))?$formdata['district_id']:null;
        $local_gov_id = (!empty($formdata['local_gov_id']))?$formdata['local_gov_id']:null;
        $from_date = (!empty($formdata['from_date']))?$formdata['from_date']:null;
        $to_date = (!empty($formdata['to_date']))?$formdata['to_date']:null;

        $checkResourcesEnergyForm = ResourcesEnergyForm::where("energy_id", $energy_id)
            ->where("central_id", $central_id)
            ->where("province_id", $province_id)
            ->where("district_id", $district_id)
            ->where("local_gov_id", $local_gov_id)
            ->where("from_date", $from_date)
            ->where("to_date", $to_date)
            ->count();

//        echo $checkResourcesEnergyForm;
//        exit();

        if($checkResourcesEnergyForm < 1){

            $objResourcesEnergyForm = new ResourcesEnergyForm();
            $objResourcesEnergyForm->energy_id = $formdata['energy_id'];
            $objResourcesEnergyForm->central_id = (!empty($formdata['central_id']))?$formdata['central_id']:null;
            $objResourcesEnergyForm->province_id = (!empty($formdata['province_id']))?$formdata['province_id']:null;
            $objResourcesEnergyForm->district_id = (!empty($formdata['district_id']))?$formdata['district_id']:null;
            $objResourcesEnergyForm->local_gov_id = (!empty($formdata['local_gov_id']))?$formdata['local_gov_id']:null;
            $objResourcesEnergyForm->from_date = (!empty($formdata['from_date']))?$formdata['from_date']:null;
            $objResourcesEnergyForm->to_date = (!empty($formdata['to_date']))?$formdata['to_date']:null;
            $objResourcesEnergyForm->entered_by = (!empty($entered_by))?$entered_by:null;
            $objResourcesEnergyForm->status = 'Y';

            if($objResourcesEnergyForm->save()){

                $energy_form_id = $objResourcesEnergyForm->id;
                $energy_id = $formdata['energy_id'];
                $energy_topic = 'overall';
                $energy_topic_ids = $overall['id'];
                $natural_qty = $overall['natural_qty'];
                $natural_unit = $overall['natural_unit'];
                $scientific_qty = $overall['scientific_qty'];
                $scientific_unit = $overall['scientific_unit'];

                if(is_array($overall)) {
                    $objEnergyFormMeta = new EnergyFormMeta();
                    $objEnergyFormMeta->energy_form_id = $energy_form_id;
                    $objEnergyFormMeta->energy_id = $energy_id;
                    $objEnergyFormMeta->energy_topic = $energy_topic;
                    $objEnergyFormMeta->energy_topic_id = $energy_topic_ids;
                    $objEnergyFormMeta->natural_qty = (!empty($natural_qty))?$natural_qty:null;
                    $objEnergyFormMeta->natural_unit = (!empty($natural_unit))?$natural_unit:null;
                    $objEnergyFormMeta->scientific_qty = (!empty($scientific_qty))?$scientific_qty:null;
                    $objEnergyFormMeta->scientific_unit = (!empty($scientific_unit))?$scientific_unit:null;
                    $objEnergyFormMeta->energy_form_topic = 'resources';
                    $objEnergyFormMeta->status = 'Y';

                    $objEnergyFormMeta->save();

                }

                if(is_array($land_type)){
                    $energy_form_id = $objResourcesEnergyForm->id;
                    $energy_id = $formdata['energy_id'];
                    $energy_topic = 'land_type';
                    $energy_topic_ids = $land_type['id'];
                    $natural_qty = $land_type['natural_qty'];
                    $natural_unit = $land_type['natural_unit'];
                    $scientific_qty = $land_type['scientific_qty'];
                    $scientific_unit = $land_type['scientific_unit'];

                    if(is_array($energy_topic_ids)){
                        for($i = 0; $i < count($energy_topic_ids); $i++){
                            $objEnergyFormMeta = new EnergyFormMeta();
                            $objEnergyFormMeta->energy_form_id = $energy_form_id;
                            $objEnergyFormMeta->energy_id = $energy_id;
                            $objEnergyFormMeta->energy_topic = $energy_topic;
                            $objEnergyFormMeta->energy_topic_id = $energy_topic_ids[$i];
                            $objEnergyFormMeta->natural_qty = (!empty($natural_qty[$i]))?$natural_qty[$i]:null;
                            $objEnergyFormMeta->natural_unit = (!empty($natural_unit[$i]))?$natural_unit[$i]:null;
                            $objEnergyFormMeta->scientific_qty = (!empty($scientific_qty[$i]))?$scientific_qty[$i]:null;
                            $objEnergyFormMeta->scientific_unit = (!empty($scientific_unit[$i]))?$scientific_unit[$i]:null;
                            $objEnergyFormMeta->energy_form_topic = 'resources';
                            $objEnergyFormMeta->status = 'Y';

                            $objEnergyFormMeta->save();
                        }
                    }

                }

                if(is_array($sector)){
                    $energy_form_id = $objResourcesEnergyForm->id;
                    $energy_id = $formdata['energy_id'];
                    $energy_topic = 'sector';
                    $energy_topic_ids = $sector['id'];
                    $natural_qty = $sector['natural_qty'];
                    $natural_unit = $sector['natural_unit'];
                    $scientific_qty = $sector['scientific_qty'];
                    $scientific_unit = $sector['scientific_unit'];

                    if(is_array($energy_topic_ids)){
                        for($i = 0; $i < count($energy_topic_ids); $i++){
                            $objEnergyFormMeta = new EnergyFormMeta();
                            $objEnergyFormMeta->energy_form_id = $energy_form_id;
                            $objEnergyFormMeta->energy_id = $energy_id;
                            $objEnergyFormMeta->energy_topic = $energy_topic;
                            $objEnergyFormMeta->energy_topic_id = $energy_topic_ids[$i];
                            $objEnergyFormMeta->natural_qty = (!empty($natural_qty[$i]))?$natural_qty[$i]:null;
                            $objEnergyFormMeta->natural_unit = (!empty($natural_unit[$i]))?$natural_unit[$i]:null;
                            $objEnergyFormMeta->scientific_qty = (!empty($scientific_qty[$i]))?$scientific_qty[$i]:null;
                            $objEnergyFormMeta->scientific_unit = (!empty($scientific_unit[$i]))?$scientific_unit[$i]:null;
                            $objEnergyFormMeta->energy_form_topic = 'resources';
                            $objEnergyFormMeta->status = 'Y';

                            $objEnergyFormMeta->save();
                        }
                    }

                }

                if(is_array($geographic_region)){
                    $energy_form_id = $objResourcesEnergyForm->id;
                    $energy_id = $formdata['energy_id'];
                    $energy_topic = 'geographic_region';
                    $energy_topic_ids = $geographic_region['id'];
                    $natural_qty = $geographic_region['natural_qty'];
                    $natural_unit = $geographic_region['natural_unit'];
                    $scientific_qty = $geographic_region['scientific_qty'];
                    $scientific_unit = $geographic_region['scientific_unit'];

                    if(is_array($energy_topic_ids)){
                        for($i = 0; $i < count($energy_topic_ids); $i++){
                            $objEnergyFormMeta = new EnergyFormMeta();
                            $objEnergyFormMeta->energy_form_id = $energy_form_id;
                            $objEnergyFormMeta->energy_id = $energy_id;
                            $objEnergyFormMeta->energy_topic = $energy_topic;
                            $objEnergyFormMeta->energy_topic_id = $energy_topic_ids[$i];
                            $objEnergyFormMeta->natural_qty = (!empty($natural_qty[$i]))?$natural_qty[$i]:null;
                            $objEnergyFormMeta->natural_unit = (!empty($natural_unit[$i]))?$natural_unit[$i]:null;
                            $objEnergyFormMeta->scientific_qty = (!empty($scientific_qty[$i]))?$scientific_qty[$i]:null;
                            $objEnergyFormMeta->scientific_unit = (!empty($scientific_unit[$i]))?$scientific_unit[$i]:null;
                            $objEnergyFormMeta->energy_form_topic = 'resources';
                            $objEnergyFormMeta->status = 'Y';
                            $objEnergyFormMeta->save();
                        }
                    }

                }

                if(is_array($river)){
                    $energy_form_id = $objResourcesEnergyForm->id;
                    $energy_id = $formdata['energy_id'];
                    $energy_topic = 'river';
                    $energy_topic_ids = $river['id'];
                    $natural_qty = $river['natural_qty'];
                    $natural_unit = $river['natural_unit'];
                    $scientific_qty = $river['scientific_qty'];
                    $scientific_unit = $river['scientific_unit'];

                    if(is_array($energy_topic_ids)){
                        for($i = 0; $i < count($energy_topic_ids); $i++){
                            $objEnergyFormMeta = new EnergyFormMeta();
                            $objEnergyFormMeta->energy_form_id = $energy_form_id;
                            $objEnergyFormMeta->energy_id = $energy_id;
                            $objEnergyFormMeta->energy_topic = $energy_topic;
                            $objEnergyFormMeta->energy_topic_id = $energy_topic_ids[$i];
                            $objEnergyFormMeta->natural_qty = (!empty($natural_qty[$i]))?$natural_qty[$i]:null;
                            $objEnergyFormMeta->natural_unit = (!empty($natural_unit[$i]))?$natural_unit[$i]:null;
                            $objEnergyFormMeta->scientific_qty = (!empty($scientific_qty[$i]))?$scientific_qty[$i]:null;
                            $objEnergyFormMeta->scientific_unit = (!empty($scientific_unit[$i]))?$scientific_unit[$i]:null;
                            $objEnergyFormMeta->energy_form_topic = 'resources';
                            $objEnergyFormMeta->status = 'Y';
                            $objEnergyFormMeta->save();
                        }
                    }

                }

                $objLog = new LogTable();
                $log_details = array('Resource Energy Form Entry for energy ID: '.$energy_id);
                $data = array(
                    'log_details'   => serialize($log_details),
                    'menu_name'     => 'New Resource Energy Form Entry',
                    'created_by'    => Auth::user()->id
                );
                $objLog->insertIntoLogTable($data);

                return redirect('dashboard/resources-energy-form/edit/'.$objResourcesEnergyForm->id)->with('success', 'Resource Energy Form Entry done successfully!');


            }else{
                return redirect('dashboard/resources-energy-form')->with('error', 'Duplicate Resource Energy Form Entry!');
            }
        }else{
            return redirect('dashboard/resources-energy-form')->with('error', 'Duplicate Resource Energy Form Entry!');
        }

    }
    public function update($route, $id) {

        $data = ResourcesEnergyForm::join('energy_form_meta', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
            ->join('energy', 'energy.id', '=', 'energy_form_meta.energy_id')
            ->select('resources_energy_form.*', 'energy.energy_name')
            ->where('resources_energy_form.id','=',$id)
            ->first();

        $energy_list = Energy::where('status', 'Y')->get();

        $central = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'central')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->first();

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')->get();

        $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'district')
            ->where('location.status', 'Y')
            ->select('location.*')->get();

        $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'local-government')
            ->where('location.status', 'Y')
            ->select('location.*')->get();

        $land_types = LandType::leftJoin('energy_form_meta', function ($join) use ($id) {
            $join->on('land_type.id', '=', 'energy_form_meta.energy_topic_id')
                ->where('energy_form_meta.energy_form_topic', '=', 'resources')
                ->where('energy_form_meta.energy_topic', '=', 'land_type')
                ->where('energy_form_meta.energy_form_id', '=',$id);
        })
            ->where('land_type.status', 'Y')
            ->select('land_type.*', 'energy_form_meta.natural_qty', 'energy_form_meta.natural_unit', 'energy_form_meta.scientific_qty', 'energy_form_meta.scientific_unit')
            ->groupBy('land_type.id')
            ->get();

        $sectors = Sector::leftJoin('energy_form_meta', function ($join0) use ($id) {
            $join0->on('sector.id', '=', 'energy_form_meta.energy_topic_id')
                ->where('energy_form_meta.energy_form_topic', '=', 'resources')
                ->where('energy_form_meta.energy_topic', '=', 'sector')
                ->where('energy_form_meta.energy_form_id', '=',$id);
        })
            ->where('sector.status', 'Y')
            ->select('sector.*', 'energy_form_meta.natural_qty', 'energy_form_meta.natural_unit', 'energy_form_meta.scientific_qty', 'energy_form_meta.scientific_unit')
            ->groupBy('sector.id')
            ->get();


//        $geographic_regions = GeographicRegion::where('status', 'Y')->get();
//        $rivers = River::where('status', 'Y')->get();

        $geographic_regions = GeographicRegion::leftJoin('energy_form_meta', function ($join1) use ($id) {
            $join1->on('geographic_region.id', '=', 'energy_form_meta.energy_topic_id')
                ->where('energy_form_meta.energy_form_topic', '=', 'resources')
                ->where('energy_form_meta.energy_topic', '=', 'geographic_region')
                ->where('energy_form_meta.energy_form_id', '=',$id);
        })
            ->where('geographic_region.status', 'Y')
            ->select('geographic_region.*', 'energy_form_meta.natural_qty', 'energy_form_meta.natural_unit', 'energy_form_meta.scientific_qty', 'energy_form_meta.scientific_unit')
            ->groupBy('geographic_region.id')
            ->get();

        $rivers = River::leftJoin('energy_form_meta', function ($join1) use ($id) {
            $join1->on('river.id', '=', 'energy_form_meta.energy_topic_id')
                ->where('energy_form_meta.energy_form_topic', '=', 'resources')
                ->where('energy_form_meta.energy_topic', '=', 'river')
                ->where('energy_form_meta.energy_form_id', '=',$id);
        })
            ->where('river.status', 'Y')
            ->select('river.*', 'energy_form_meta.natural_qty', 'energy_form_meta.natural_unit', 'energy_form_meta.scientific_qty', 'energy_form_meta.scientific_unit')
            ->groupBy('river.id')
            ->get();

        $overall = EnergyFormMeta::where('energy_form_topic', 'resources')->where('energy_form_id', $id)->where('energy_topic', 'overall')->first();

//        echo '<pre>';
//        print_r($overall);
//        echo '</pre>';
//
//        exit();

        $field_topics = EnergyTypeTopicMapping::where('energy_type_topic', 'resources')
            ->where('energy_id', $data->energy_id)
            ->pluck('energy_field_topic')->toArray();

        $units = Unit::join('energy_conversion', 'energy_conversion.natural_unit', '=', 'unit.id')
            ->where('unit.status', 'Y')
            ->where('energy_conversion.energy_id', $data->energy_id)
            ->select('unit.*', 'energy_conversion.scientific_qty')
            ->groupBy('unit.id')
            ->get();

        return view('dashboard/resources_energy_form_add')
            ->with('data', $data)
            ->with('energy_list', $energy_list)
            ->with('central', $central)
            ->with('provinces', $provinces)
            ->with('districts', $districts)
            ->with('local_governments', $local_governments)
            ->with('land_types', $land_types)
            ->with('sectors', $sectors)
            ->with('field_topics', $field_topics)
            ->with('rivers', $rivers)
            ->with('geographic_regions', $geographic_regions)
            ->with('units', $units)
            ->with('overall', $overall)
            ->with('route', 'edit');

    }

    public function postUpdate(Request $request) {
        $formdata = $request->formdata;
        $land_type = $request->land_type;
        $sector = $request->sector;
        $geographic_region = $request->geographic_region;
        $river = $request->river;
        $overall = $request->overall;

        $user_id = Auth::user()->id;
        $route = (!empty($request->route))?$request->route:'edit';

//        echo '<pre>';
//        print_r($formdata);
//        print_r($land_type);
//        print_r($sector);
//        print_r($geographic_region);
//        print_r($river);
//        print_r($overall);
//        echo '</pre>';
//        exit();

        $objResourcesEnergyForm = ResourcesEnergyForm::find($formdata['id']);

        if(!empty($objResourcesEnergyForm)){

            if($route == 'check'){
                $objResourcesEnergyForm->qa_by = $user_id;
                $objResourcesEnergyForm->save();
            }elseif($route == 'approve'){
                $objResourcesEnergyForm->published_by = $user_id;
                $objResourcesEnergyForm->save();
            }

            $energy_form_id = $objResourcesEnergyForm->id;

            $energy_id = $formdata['energy_id'];

            if(is_array($land_type)){

                $energy_topic = 'land_type';
                $energy_topic_ids = $land_type['id'];
                $natural_qty = $land_type['natural_qty'];
                $natural_unit = $land_type['natural_unit'];
                $scientific_qty = $land_type['scientific_qty'];
                $scientific_unit = $land_type['scientific_unit'];

                EnergyFormMeta::where('energy_form_topic', 'resources')
                    ->where('energy_topic', $energy_topic)
                    ->where('energy_form_id', $energy_form_id)
                    ->delete();

                if(is_array($energy_topic_ids)){
                    for($i = 0; $i < count($energy_topic_ids); $i++){
                        $objEnergyFormMeta = new EnergyFormMeta();
                        $objEnergyFormMeta->energy_form_id = $energy_form_id;
                        $objEnergyFormMeta->energy_id = $energy_id;
                        $objEnergyFormMeta->energy_topic = $energy_topic;
                        $objEnergyFormMeta->energy_topic_id = $energy_topic_ids[$i];
                        $objEnergyFormMeta->natural_qty = (!empty($natural_qty[$i]))?$natural_qty[$i]:null;
                        $objEnergyFormMeta->natural_unit = (!empty($natural_unit[$i]))?$natural_unit[$i]:null;
                        $objEnergyFormMeta->scientific_qty = (!empty($scientific_qty[$i]))?$scientific_qty[$i]:null;
                        $objEnergyFormMeta->scientific_unit = (!empty($scientific_unit[$i]))?$scientific_unit[$i]:null;
                        $objEnergyFormMeta->energy_form_topic = 'resources';
                        $objEnergyFormMeta->status = 'Y';

                        $objEnergyFormMeta->save();
                    }
                }

            }

            if(is_array($sector)){
                $energy_topic = 'sector';
                $energy_topic_ids = $sector['id'];
                $natural_qty = $sector['natural_qty'];
                $natural_unit = $sector['natural_unit'];
                $scientific_qty = $sector['scientific_qty'];
                $scientific_unit = $sector['scientific_unit'];

                EnergyFormMeta::where('energy_form_topic', 'resources')
                    ->where('energy_topic', '=', $energy_topic)
                    ->where('energy_form_id', '=', $energy_form_id)
                    ->delete();

                if(is_array($energy_topic_ids)){
                    for($i = 0; $i < count($energy_topic_ids); $i++){
                        $objEnergyFormMeta = new EnergyFormMeta();
                        $objEnergyFormMeta->energy_form_id = $energy_form_id;
                        $objEnergyFormMeta->energy_id = $energy_id;
                        $objEnergyFormMeta->energy_topic = $energy_topic;
                        $objEnergyFormMeta->energy_topic_id = $energy_topic_ids[$i];
                        $objEnergyFormMeta->natural_qty = (!empty($natural_qty[$i]))?$natural_qty[$i]:null;
                        $objEnergyFormMeta->natural_unit = (!empty($natural_unit[$i]))?$natural_unit[$i]:null;
                        $objEnergyFormMeta->scientific_qty = (!empty($scientific_qty[$i]))?$scientific_qty[$i]:null;
                        $objEnergyFormMeta->scientific_unit = (!empty($scientific_unit[$i]))?$scientific_unit[$i]:null;
                        $objEnergyFormMeta->energy_form_topic = 'resources';
                        $objEnergyFormMeta->status = 'Y';

                        $objEnergyFormMeta->save();
                    }
                }

            }

            if(is_array($geographic_region)){
                $energy_topic = 'geographic_region';
                $energy_topic_ids = $geographic_region['id'];
                $natural_qty = $geographic_region['natural_qty'];
                $natural_unit = $geographic_region['natural_unit'];
                $scientific_qty = $geographic_region['scientific_qty'];
                $scientific_unit = $geographic_region['scientific_unit'];

                EnergyFormMeta::where('energy_form_topic', 'resources')
                    ->where('energy_topic', '=', $energy_topic)
                    ->where('energy_form_id', '=', $energy_form_id)
                    ->delete();

                if(is_array($energy_topic_ids)){
                    for($i = 0; $i < count($energy_topic_ids); $i++){
                        $objEnergyFormMeta = new EnergyFormMeta();
                        $objEnergyFormMeta->energy_form_id = $energy_form_id;
                        $objEnergyFormMeta->energy_id = $energy_id;
                        $objEnergyFormMeta->energy_topic = $energy_topic;
                        $objEnergyFormMeta->energy_topic_id = $energy_topic_ids[$i];
                        $objEnergyFormMeta->natural_qty = (!empty($natural_qty[$i]))?$natural_qty[$i]:null;
                        $objEnergyFormMeta->natural_unit = (!empty($natural_unit[$i]))?$natural_unit[$i]:null;
                        $objEnergyFormMeta->scientific_qty = (!empty($scientific_qty[$i]))?$scientific_qty[$i]:null;
                        $objEnergyFormMeta->scientific_unit = (!empty($scientific_unit[$i]))?$scientific_unit[$i]:null;
                        $objEnergyFormMeta->energy_form_topic = 'resources';
                        $objEnergyFormMeta->status = 'Y';


                        $objEnergyFormMeta->save();
                    }
                }

            }

            if(is_array($river)){
                $energy_topic = 'river';
                $energy_topic_ids = $river['id'];
                $natural_qty = $river['natural_qty'];
                $natural_unit = $river['natural_unit'];
                $scientific_qty = $river['scientific_qty'];
                $scientific_unit = $river['scientific_unit'];

                EnergyFormMeta::where('energy_form_topic', 'resources')
                    ->where('energy_topic', '=', $energy_topic)
                    ->where('energy_form_id', '=', $energy_form_id)
                    ->delete();

                if(is_array($energy_topic_ids)){
                    for($i = 0; $i < count($energy_topic_ids); $i++){
                        $objEnergyFormMeta = new EnergyFormMeta();
                        $objEnergyFormMeta->energy_form_id = $energy_form_id;
                        $objEnergyFormMeta->energy_id = $energy_id;
                        $objEnergyFormMeta->energy_topic = $energy_topic;
                        $objEnergyFormMeta->energy_topic_id = $energy_topic_ids[$i];
                        $objEnergyFormMeta->natural_qty = (!empty($natural_qty[$i]))?$natural_qty[$i]:null;
                        $objEnergyFormMeta->natural_unit = (!empty($natural_unit[$i]))?$natural_unit[$i]:null;
                        $objEnergyFormMeta->scientific_qty = (!empty($scientific_qty[$i]))?$scientific_qty[$i]:null;
                        $objEnergyFormMeta->scientific_unit = (!empty($scientific_unit[$i]))?$scientific_unit[$i]:null;
                        $objEnergyFormMeta->energy_form_topic = 'resources';
                        $objEnergyFormMeta->status = 'Y';


                        $objEnergyFormMeta->save();
                    }
                }

            }

            if(is_array($overall)){

                $energy_topic = 'overall';
                $energy_topic_ids = $overall['id'];
                $natural_qty = $overall['natural_qty'];
                $natural_unit = $overall['natural_unit'];
                $scientific_qty = $overall['scientific_qty'];
                $scientific_unit = $overall['scientific_unit'];

                EnergyFormMeta::where('energy_form_topic', 'resource')
                    ->where('energy_topic', $energy_topic)
                    ->where('energy_form_id', $energy_form_id)
                    ->delete();

                $objEnergyFormMeta = new EnergyFormMeta();
                $objEnergyFormMeta->energy_form_id = $energy_form_id;
                $objEnergyFormMeta->energy_id = $energy_id;
                $objEnergyFormMeta->energy_topic = $energy_topic;
                $objEnergyFormMeta->energy_topic_id = $energy_topic_ids;
                $objEnergyFormMeta->natural_qty = (!empty($natural_qty))?$natural_qty:null;
                $objEnergyFormMeta->natural_unit = (!empty($natural_unit))?$natural_unit:null;
                $objEnergyFormMeta->scientific_qty = (!empty($scientific_qty))?$scientific_qty:null;
                $objEnergyFormMeta->scientific_unit = (!empty($scientific_unit))?$scientific_unit:null;
                $objEnergyFormMeta->energy_form_topic = 'resources';
                $objEnergyFormMeta->status = 'Y';

                $objEnergyFormMeta->save();

            }

            $objLog = new LogTable();
            $log_details = array('Resource Energy Form updated for energy ID: '.$formdata['energy_id']);
            $data = array(
                'log_details'   => serialize($log_details),
                'menu_name'     => 'New Resource Energy Form Entry',
                'created_by'    => Auth::user()->id
            );
            $objLog->insertIntoLogTable($data);

            return redirect('dashboard/resources-energy-form/'.$route.'/'.$objResourcesEnergyForm->id)->with('success', 'Resource Energy Form Entry updated successfully!');

        }else{
            return redirect('dashboard/resources-energy-form')->with('error', 'Resource Energy Form Entry cannot be updated!');
        }

    }

    public function delete($id) {

        $objEnergy = ResourcesEnergyForm::find($id);
        $objEnergy->status = 'N';
        $objEnergy->save();

        return redirect('dashboard/resources-energy-form')->with('success', 'Resources deleted successfully!');

    }

}
