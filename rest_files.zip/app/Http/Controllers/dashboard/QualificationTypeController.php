<?php

namespace App\Http\Controllers\dashboard;

use App\QualificationType;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class QualificationTypeController extends Controller
{
    public function index(){
        $result = QualificationType::where('status','Y')->get();
        return view('qualificationtype-list')->with('data',$result);
    }
    public function create(){
        return view('addqualificationtype');
    }
    public function postcreate(Request $request){

        $objPost = new QualificationType();
        $objPost->qualification_type_name = $request->qualification_type_name;
        $objPost->qualification_type_slug = str_replace(' ','-',strtolower($request->qualification_type_name));
        //$objUser->company_logo = $request->post_slug;
        //$objUser->other_logo = $request->post_slug;
        $objPost->status = $request->status;

        if($objPost->save())
            return redirect('user/dashboard/qualificationtype')->with('success', 'Qualification Type Created Successfully!');
        else
            return redirect('user/dashboard/qualificationtype')->with('error', 'Qualification Type Not Created!');
    }
    public  function  update($id){
        $data = QualificationType::find($id);
        return view('editqualificationtype')->with('data', $data)->with('id',$id);
    }
    public function postupdate(Request $request){
        $objPost = QualificationType::find($request->id);
        $objPost->qualification_type_name = $request->qualification_type_name;
        //$objPost->company_applied_for_slug = $request->company_applied_for_slug;
        $objPost->status = $request->status;

        if($objPost->save())
            return redirect('user/dashboard/qualificationtype')->with('success', 'Qualification Type updated successfully!');
        else
            return redirect('user/dashboard/qualificationtype')->with('error', 'Qualification Type not updated!');

    }
    public function delete($id){
        $objPost = QualificationType::find($id);
        $objPost->status = 'N';

        if($objPost->save())
            return redirect('user/dashboard/qualificationtype')->with('success', 'Qualification Type deleted successfully!');
        else
            return redirect('user/dashboard/qualificationtype')->with('error', 'Qualification Type not deleted!');
    }
}
