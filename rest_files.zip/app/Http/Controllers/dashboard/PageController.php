<?php

namespace App\Http\Controllers\dashboard;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use stdClass;
use App\LogTable;
use App\Page;
use Illuminate\Support\Facades\Auth;

class PageController extends Controller
{

    public function __construct(){
        $this->middleware('auth');
    }

    public function index(){
        $result =  Page::where('status', 'Y')->get();
        return view('dashboard.page_list')
            ->with('data', $result);
    }

    public function create(){

        $objData=new StdClass;
        $objData->id = '';
        $objData->page_name = '';
        $objData->page_slug = '';
        $objData->page_desc = 0;
        $objData->status = '';
        return view('dashboard/page_add')
            ->with('data', $objData)
            ->with('route', 'add');
    }
    public function postCreate(Request $request) {
        $formdata = $request->formdata;

        // echo '<pre>';
        // print_r($formdata);
        // echo '</pre>';
        // exit();

//        'page_name', 'page_slug', 'page_desc', 'status'

        $formdata['page_slug'] = (empty($formdata['page_slug']))?str_replace(" ","-", strtolower($formdata['page_name'])):str_replace(" ","-", strtolower($formdata['page_slug']));
        $formdata['page_desc'] = (!empty($formdata['page_desc']))?$formdata['page_desc']:null;

        $objData = new Page();
        $objData->page_name = $formdata['page_name'];
        $objData->page_slug = $formdata['page_slug'];
        $objData->page_desc = $formdata['page_desc'];
        $objData->status = 'Y';


        if($objData->save()){

            $objLog = new LogTable();
            $log_details = array(
                'Page Name: '.$formdata['page_name'],
                'Description: '.$formdata['page_desc']
            );
            $data = array(
                'log_details'   => serialize($log_details),
                'menu_name'     => 'Added Page',
                'created_by'    => Auth::user()->id
            );
            $objLog->insertIntoLogTable($data);

            return redirect('dashboard/page')->with('success', 'Page added successfully!');

        }
        else{

            return redirect('dashboard/page')->with('error', 'Page cannot be added!');

        }

    }
    public function update($page_id = '') {

        $objData = Page::find($page_id);

        if($page_id == '' || is_null($objData)):

            return redirect('dashboard/page')->with('error', 'No Page Selected!');

        else:

            return view('dashboard/page_add')
                ->with('route', 'update')
                ->with('data', $objData);

        endif;

    }

    public function postUpdate(Request $request) {

        $formdata = $request->formdata;

        $formdata['page_desc'] = (!empty($formdata['page_desc']))?$formdata['page_desc']:null;

        $objData = Page::find($formdata['id']);
        $objData->page_name = $formdata['page_name'];
        $objData->page_slug = $formdata['page_slug'];
        $objData->page_desc = $formdata['page_desc'];

        $objData->save();

        $objLog = new LogTable();
        $log_details = array(
            'Page Name: '.$formdata['page_name'],
            'Description: '.$formdata['page_desc']
        );
        $data = array(
            'log_details'   => serialize($log_details),
            'menu_name'     => 'Updated Page',
            'created_by'    => Auth::user()->id
        );
        $objLog->insertIntoLogTable($data);

        return redirect('dashboard/page')->with('success', 'Page updated successfully!');

    }

    public function delete($page_id) {

        $objData = Page::find($page_id);
        $objData->status = 'N';
        $objData->save();

        return redirect('dashboard/page')->with('error', 'Page deleted successfully!');

    }

}
