<?php

namespace App\Http\Controllers\dashboard;

use App\LogTable;
use App\Nature;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use stdClass;

class NatureController extends Controller
{

    public function __construct(){
        $this->middleware('auth');
    }

    public function index(){
        $result =  Nature::where('status', 'Y')->get();
        return view('dashboard.nature_list')
            ->with('data', $result);
    }

    public function create(){

        $objData=new StdClass;
        $objData->id = '';
        $objData->nature_name = '';
        $objData->nature_slug = '';
        $objData->nature_desc = 0;
        $objData->status = '';
        return view('dashboard/nature_add')
            ->with('data', $objData)
            ->with('route', 'add');
    }
    public function postCreate(Request $request) {
        $formdata = $request->formdata;

        // echo '<pre>';
        // print_r($formdata);
        // echo '</pre>';
        // exit();

//        'nature_name', 'nature_slug', 'nature_desc', 'status'

        $formdata['nature_slug'] = (empty($formdata['nature_name']))?$formdata['nature_name']:str_replace(" ","-", strtolower($formdata['nature_name']));
        $formdata['nature_desc'] = (!empty($formdata['nature_desc']))?$formdata['nature_desc']:null;

        $objData = new Nature();
        $objData->nature_name = $formdata['nature_name'];
        $objData->nature_slug = $formdata['nature_slug'];
        $objData->nature_desc = $formdata['nature_desc'];
        $objData->status = 'Y';


        if($objData->save()){

            $objLog = new LogTable();
            $log_details = array(
                'Nature Name: '.$formdata['nature_name'],
                'Description: '.$formdata['nature_desc']
            );
            $data = array(
                'log_details'   => serialize($log_details),
                'menu_name'     => 'Added Nature',
                'created_by'    => Auth::user()->id
            );
            $objLog->insertIntoLogTable($data);

            return redirect('dashboard/nature')->with('success', 'Nature added successfully!');

        }
        else{

            return redirect('dashboard/nature')->with('error', 'Nature cannot be added!');

        }

    }
    public function update($nature_id = '') {

        $objData = Nature::find($nature_id);

        if($nature_id == '' || is_null($objData)):

            return redirect('dashboard/nature')->with('error', 'No Nature Selected!');

        else:

            return view('dashboard/nature_add')
                ->with('route', 'update')
                ->with('data', $objData);

        endif;

    }

    public function postUpdate(Request $request) {

        $formdata = $request->formdata;

        $formdata['nature_desc'] = (!empty($formdata['nature_desc']))?$formdata['nature_desc']:null;

        $objData = Nature::find($formdata['id']);
        $objData->nature_name = $formdata['nature_name'];
        $objData->nature_desc = $formdata['nature_desc'];

        $objData->save();

        $objLog = new LogTable();
        $log_details = array(
            'Nature Name: '.$formdata['nature_name'],
            'Description: '.$formdata['nature_desc']
        );
        $data = array(
            'log_details'   => serialize($log_details),
            'menu_name'     => 'Updated Nature',
            'created_by'    => Auth::user()->id
        );
        $objLog->insertIntoLogTable($data);

        return redirect('dashboard/nature')->with('success', 'Nature updated successfully!');

    }

    public function delete($nature_id) {

        $objData = Nature::find($nature_id);
        $objData->status = 'N';
        $objData->save();

        return redirect('dashboard/nature')->with('error', 'Nature deleted successfully!');

    }
    
}
