<?php

namespace App\Http\Controllers\dashboard;

use App\EnergyYear;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use stdClass;

class EnergyYearController extends Controller
{

    public function __construct(){
        $this->middleware('auth');
    }
    public function index(){
        $result = EnergyYear::where('status', 'Y')->get();
        return view('dashboard.energy_year_list')->with('data', $result);
    }
    public function create(){
        $objPost = new StdClass();
        $objPost->id = '';
        $objPost->energy_year_start = '';
        $objPost->energy_year_end = '';
        $objPost->is_completed = '';
        $objPost->status = '';
        return view('dashboard/energy_year_add')->with('data', $objPost)->with('route', 'add');
    }
    public function postCreate(Request $request){
        $formdata = $request->formdata;

        $objPost = new EnergyYear();
        $objPost->energy_year_start = $formdata['energy_year_start'];
        $objPost->energy_year_end = $formdata['energy_year_end'];
        $objPost->is_completed = $formdata['is_completed'];
        $objPost->status = 'Y';


        if($objPost->save())
            return redirect('dashboard/energy-year/edit/'.$objPost->id)->with('success', 'Energy Year added successfully!');
        else
            return redirect('dashboard/energy-year')->with('error', 'Energy Year cannot be added!');
    }
    public function update($id = ''){
        $objPost = EnergyYear::find($id);

        if($id == '' || is_null($objPost)):

            return redirect('dashboard/energy-year')->with('error', 'No Energy Year Selected!');

        else:

            return view('dashboard/energy_year_add')
                ->with('route', 'edit')
                ->with('data', $objPost);

        endif;
    }
    public function postUpdate(Request $request){
        $formdata = $request->formdata;

        $objPost = EnergyYear::find($formdata['id']);
        $objPost->energy_year_start = $formdata['energy_year_start'];
        $objPost->energy_year_end = $formdata['energy_year_end'];
        $objPost->is_completed = $formdata['is_completed'];

        $objPost->save();

        return redirect('dashboard/energy-year/edit/'.$objPost->id)->with('success', 'Energy Year updated successfully!');
    }
    public function delete($id){

        $objPost = EnergyYear::find($id);
        $objPost->status = 'N';
        $objPost->save();

        return redirect('dashboard/energy-year')->with('error', 'Energy Year deleted successfully!');
    }
}
