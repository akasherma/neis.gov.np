<?php

namespace App\Http\Controllers\dashboard;

use App\FuelType;
use App\LogTable;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use stdClass;

class FuelTypeController extends Controller
{
    //
    public function __construct(){
        $this->middleware('auth');
    }
    public function index(){
        $result = FuelType::leftJoin('fuel_type as ft', 'ft.id', '=', 'fuel_type.parent_id')
            ->where('fuel_type.status','Y')
            ->select('ft.fuel_type_name as fuel_type_parent', 'fuel_type.*')
            ->get();
        return view('dashboard.fueltypelist')->with('data',$result);
    }
    public function create(){
        $objPost =new StdClass();
        $objPost->id = '';
        $objPost->fuel_type_name = '';
        $objPost->fuel_type_slug = '';
        $objPost->fuel_type_desc = '';
        $objPost->parent_id = 0;
        $objPost->is_last_child = '';
        $objPost->status = '';

        $parent_fuel_type = FuelType::where('status', 'Y')->where('is_last_child', '=', 'N')->get();

        return view('dashboard/fueltypeadd')->with('data', $objPost)->with('parent_fuel_type', $parent_fuel_type)->with('route', 'add');
    }
    public function postCreate(Request $request) {
        $formdata = $request->formdata;

        // echo '<pre>';
        // print_r($formdata);
        // echo '</pre>';
        // exit();

        $formdata['fuel_type_slug'] = (empty($formdata['fuel_type_name']))?$formdata['fuel_type_name']:str_replace(" ","-", strtolower($formdata['fuel_type_name']));
        $formdata['fuel_type_desc'] = (!empty($formdata['fuel_type_desc']))?$formdata['fuel_type_desc']:null;
        $formdata['parent_id'] = (!empty($formdata['parent_id']))?$formdata['parent_id']:0;

        $objPost = new FuelType();
        $objPost->fuel_type_name = $formdata['fuel_type_name'];
        $objPost->fuel_type_slug = $formdata['fuel_type_slug'];
        $objPost->fuel_type_desc = $formdata['fuel_type_desc'];
        $objPost->parent_id = $formdata['parent_id'];
        $objPost->is_last_child = $formdata['is_last_child'];
        $objPost->status = 'Y';

        if($objPost->save()){

            $objLog = new LogTable();
            $log_details = array(
                'Fuel Type Name: '.$formdata['fuel_type_name'], 'Description'.$formdata['fuel_type_desc']
            );
            $data = array(
                'log_details'   => serialize($log_details),
                'menu_name'     => 'Added Fuel Type',
                'created_by'    => Auth::user()->id
            );
            $objLog->insertIntoLogTable($data);

            return redirect('dashboard/fuel-type')->with('success', 'Fuel Type added successfully!');

        }
        else{

            return redirect('dashboard/fuel-type')->with('error', 'Fuel Type cannot be added!');

        }

    }
    public function update($id = '') {

        $objPost = FuelType::find($id);

        $parent_fuel_type = FuelType::where('status', 'Y')->where('is_last_child', '=', 'N')->get();

        if($id == '' || is_null($objPost)):

            return redirect('dashboard/fuel-type')->with('error', 'No Fuel Type Selected!');

        else:

            return view('dashboard/fueltypeadd')
                ->with('route', 'update')
                ->with('parent_fuel_type', $parent_fuel_type)
                ->with('data', $objPost);

        endif;

    }

    public function postUpdate(Request $request) {

        $formdata = $request->formdata;

        $formdata['fuel_type_desc'] = (!empty($formdata['fuel_type_desc']))?$formdata['fuel_type_desc']:null;

        $objPost = FuelType::find($formdata['id']);
        $objPost->fuel_type_name = $formdata['fuel_type_name'];
        $objPost->fuel_type_desc = $formdata['fuel_type_desc'];
        $objPost->is_last_child = $formdata['is_last_child'];

        $objPost->save();

        $objLog = new LogTable();
        $log_details = array(
            'Fuel Type Name: '.$formdata['fuel_type_name'], 'Description'.$formdata['fuel_type_desc']
        );
        $data = array(
            'log_details'   => serialize($log_details),
            'menu_name'     => 'Updated Fuel Type',
            'created_by'    => Auth::user()->id
        );
        $objLog->insertIntoLogTable($data);

        return redirect('dashboard/fuel-type')->with('success', 'Fuel Type updated successfully!');

    }

    public function delete($id) {

        $objPost = FuelType::find($id);
        $objPost->status = 'N';
        $objPost->save();

        return redirect('dashboard/fuel-type')->with('error', 'Fuel Type deleted successfully!');

    }
}
