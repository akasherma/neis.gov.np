<?php

namespace App\Http\Controllers\dashboard;

use App\Energy;
use App\EnergyTypes;
use App\EnergyTypeTopicMapping;
use App\EnergyTypeVersesEnergyMapping;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use stdClass;

class EnergyTypesController extends Controller
{

    public function __construct(){
        $this->middleware('auth');
    }

    public function index(){
        $result =  EnergyTypes::where('status', 'Y')->get();
        return view('dashboard.energy_type_list')
            ->with('data', $result);
    }

    public function create(){

        $objData=new StdClass;
        $objData->id = '';
        $objData->energy_type_name = '';
        $objData->energy_type_slug = '';
        $objData->energy_type_desc = 0;
        $objData->status = '';
        return view('dashboard/energy_type_add')
            ->with('data', $objData)
            ->with('route', 'add');
    }
    public function postCreate(Request $request) {
        $formdata = $request->formdata;

        // echo '<pre>';
        // print_r($formdata);
        // echo '</pre>';
        // exit();

//        'energy_type_name', 'energy_type_slug', 'energy_type_desc', 'status'

        $formdata['energy_type_slug'] = (empty($formdata['energy_type_name']))?$formdata['energy_type_name']:str_replace(" ","-", strtolower($formdata['energy_type_name']));
        $formdata['energy_type_desc'] = (!empty($formdata['energy_type_desc']))?$formdata['energy_type_desc']:0;

        $objData = new EnergyTypes();
        $objData->energy_type_name = $formdata['energy_type_name'];
        $objData->energy_type_slug = $formdata['energy_type_slug'];
        $objData->energy_type_desc = $formdata['energy_type_desc'];
        $objData->status = (!empty($formdata['status']))?$formdata['status']:'N';
        $objData->economic_survey_status = (!empty($formdata['economic_survey_status']))?$formdata['economic_survey_status']:'N';


        if($objData->save())
            return redirect('dashboard/energy_type')->with('success', 'Energy Types added successfully!');
        else
            return redirect('dashboard/energy_type')->with('error', 'Energy Types cannot be added!');

    }
    public function update($energy_type_id = '') {

        $objData = EnergyTypes::find($energy_type_id);

        if($energy_type_id == '' || is_null($objData)):

            return redirect('dashboard/energy_type')->with('error', 'No Energy Types Selected!');

        else:

            return view('dashboard/energy_type_add')
                ->with('route', 'update')
                ->with('data', $objData);

        endif;

    }

    public function postUpdate(Request $request) {

        $formdata = $request->formdata;

        $objData = EnergyTypes::find($formdata['id']);
        $objData->energy_type_name = $formdata['energy_type_name'];
        $objData->energy_type_desc = $formdata['energy_type_desc'];
        $objData->status = (!empty($formdata['status']))?$formdata['status']:'N';
        $objData->economic_survey_status = (!empty($formdata['economic_survey_status']))?$formdata['economic_survey_status']:'N';

        $objData->save();

        return redirect('dashboard/energy_type')->with('success', 'Energy Types updated successfully!');

    }

    public function delete($energy_type_id) {

        $objData = EnergyTypes::find($energy_type_id);
        $objData->is_deleted = 'N';
        $objData->save();

        return redirect('dashboard/energy_type')->with('error', 'Energy Types deleted successfully!');

    }

    public function EnergyTypeEnergyListing($energy_type_slug) {

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $energy_lists = Energy::leftJoin('energy_type_topic_mapping', function ($join) use ($energy_type_slug) {
                $join->on('energy_type_topic_mapping.energy_id', '=', 'energy.id');
                $join->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug);
            })
            ->select('energy.*', DB::raw('group_concat(energy_type_topic_mapping.energy_field_topic) as field_topics'))
            ->where('energy.status', 'Y')
            ->groupBy('energy.id')
            ->get();

//        echo '<pre>';
////        print_r($this_energy_type);
//        print_r(json_decode($energy_lists));
//        echo '</pre>';
//        exit();

        return view('dashboard/energy_type_energy_listing')
            ->with('this_energy_type', $this_energy_type)
            ->with('energy_lists', $energy_lists);

    }

    public function EnergyTypeTopicMappingPolicy($energy_type_slug, $energy_id){

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $this_energy = Energy::find($energy_id);

        $energy_lists = Energy::where('status', 'Y')->get();

        $energy_field_topic_list = array('sector', 'land_type', 'geographic_region', 'river');

        $plot = EnergyTypeTopicMapping::where('energy_type_topic', $energy_type_slug)
            ->where('energy_id', $energy_id)
            ->select('energy_field_topic')
            ->groupBy('energy_field_topic')->get();

        $plot_this = array();

        if(!empty($plot)){
            foreach($plot as $the_plot){
                array_push($plot_this, $the_plot->energy_field_topic);
            }
        }

//        echo '<pre>';
//        print_r(json_decode($plot));
//        echo '<hr />';
//        print_r($plot_this);
//        echo '</pre>';
//        exit();

        // energy_type_topic_mapping energy_type_topic`, `energy_id`, `energy_field_topic

        return view('dashboard/energy_type_topic_mapping')
            ->with('this_energy_type', $this_energy_type)
            ->with('this_energy', $this_energy)
            ->with('energy_field_topic_list', $energy_field_topic_list)
            ->with('plot', $plot_this);

    }

    public function EnergyTypeTopicMappingPolicyEnergyListing($energy_type_slug){

//        return $energy_type_slug;


        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $energy_lists = Energy::where('status', 'Y')->get();

        $plot = EnergyTypeVersesEnergyMapping::where('energy_type_id', $this_energy_type->id)
                ->groupBy('energy_id')
                ->get();

//        echo '<pre>';
//        print_r($energy_lists);
//        print_r($plot);
//        exit();

        $plot_this = array();

        if(!empty($plot)){
            foreach($plot as $the_plot){
                array_push($plot_this, $the_plot->energy_id);
            }
        }

//        echo '<pre>';
//        print_r(json_decode($plot));
//        echo '<hr />';
//        print_r($plot_this);
//        echo '</pre>';
//        exit();

        // energy_type_topic_mapping energy_type_topic`, `energy_id`, `energy_field_topic

        return view('dashboard/energy_type_topic_mapping_energylisting')
            ->with('this_energy_type', $this_energy_type)
            ->with('energy_lists', $energy_lists)
            ->with('plot', $plot_this);

    }


    public function EnergyTypeTopicMappingPolicyPost(Request $request){
        $energy_type_slug = $request->energy_type_topic;
        $energy_id = $request->energy_id;
        $energy_field_topic = (!empty($request->energy_field_topic))?$request->energy_field_topic:array();

//        echo '<pre>';
//        print_r($serviceTypeId);
//        echo '</pre>';
//
//        echo '<pre>';
//        print_r($serviceFieldId);
//        echo '</pre>';
//        exit();

        EnergyTypeTopicMapping::where('energy_type_topic', $energy_type_slug)
            ->where('energy_id', $energy_id)->delete();

//    echo json_decode($objUser);
//    exit();
//    $objUser->delete();

        for ($i = 0; $i < count($energy_field_topic); $i++) {
            $objEnergyTypeTopicMapping = new EnergyTypeTopicMapping();
            $objEnergyTypeTopicMapping->energy_field_topic = $energy_field_topic[$i];
            $objEnergyTypeTopicMapping->energy_type_topic = $energy_type_slug;
            $objEnergyTypeTopicMapping->energy_id = $energy_id;
            $objEnergyTypeTopicMapping->status = 'Y';
            $objEnergyTypeTopicMapping->save();
        }

        return redirect('/dashboard/energy_type/'.$energy_type_slug.'/energy/'.$energy_id)->with('success', 'Energy Field Group Policy saved changes.');

    }

    public function EnergyTypeTopicMappingPolicyEnergyListingPost(Request $request){

//        echo $energy_type_slug;


        $energy_ids = $request->energy_ids;
        $energy_type_slug = $request->energy_type_slug;

//        echo '<pre>';
//        print_r($energy_ids);
//        echo '</pre>';
//        exit();
//
//        echo '<pre>';
//        print_r($serviceFieldId);
//        echo '</pre>';
//        exit();


        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

//
//        $energy_lists = Energy::where('status', 'Y')->get();
//
//        $plot = EnergyTypeVersesEnergyMapping::where('energy_type_id', $this_energy_type->id)
//            ->groupBy('energy_id')
//            ->get();
//
        EnergyTypeVersesEnergyMapping::where('energy_type_id', $this_energy_type->id)->delete();

//    echo json_decode($objUser);
//    exit();
//    $objUser->delete();

        if(!empty($energy_ids) && is_array($energy_ids) && count($energy_ids) > 0){
            foreach($energy_ids as $energy_id){

                $objEnergyTypeVersesEnergyMapping = new EnergyTypeVersesEnergyMapping();
                $objEnergyTypeVersesEnergyMapping->energy_id = $energy_id;
                $objEnergyTypeVersesEnergyMapping->energy_type_id = $this_energy_type->id;
                $objEnergyTypeVersesEnergyMapping->status = 'Y';
                $objEnergyTypeVersesEnergyMapping->save();

            }
        }

        return redirect('/dashboard/energy_type/'.$energy_type_slug.'/energylisting/')->with('success', 'Energy Field Group Policy saved changes.');

    }

}
