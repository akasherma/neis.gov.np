<?php

namespace App\Http\Controllers\dashboard;

use App\Position;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class PositionController extends Controller
{
    public function index(){
        $result = Position::where('status','Y')->get();
        return view('position-list')->with('data',$result);
    }
    public function create(){
        return view('addposition');
    }
    public function postcreate(Request $request){

        $objPost = new Position();
        $objPost->position_name = $request->position_name;
        $objPost->position_slug = str_replace(' ','-',strtolower($request->position_name));
        $objPost->position_desc = $request->position_desc;
        //$objUser->company_logo = $request->post_slug;
        //$objUser->other_logo = $request->post_slug;
        $objPost->status = $request->status;

        if($objPost->save())
            return redirect('/user/dashboard/position')->with('success', 'Position Created Successfully!');
        else
            return redirect('/user/dashboard/position')->with('error', 'Position Not Created!');
    }
    public  function  update($id){
        $data = Position::find($id);
        return view('editposition')->with('data', $data)->with('id',$id);
    }
    public function postupdate(Request $request){
        $objPost = Position::find($request->id);
        $objPost->position_name = $request->position_name;
        //$objPost->company_applied_for_slug = $request->company_applied_for_slug;
        $objPost->position_desc = $request->position_desc;
        $objPost->status = $request->status;



        if($objPost->save())
            return redirect('/user/dashboard/position')->with('success', 'Position updated successfully!');
        else
            return redirect('/user/dashboard/position')->with('error', 'Position not updated!');

    }
    public function delete($id){
        $objPost = Position::find($id);
        $objPost->status = 'N';

        if($objPost->save())
            return redirect('/user/dashboard/position')->with('success', 'Position deleted successfully!');
        else
            return redirect('/user/dashboard/position')->with('error', 'Position not deleted!');
    }
}
