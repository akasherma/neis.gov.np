<?php

namespace App\Http\Controllers\dashboard;

use App\LandType;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use stdClass;

class LandTypeController extends Controller
{
    //
    public function __construct(){
        $this->middleware('auth');
    }
    public function index(){
        $result = LandType::where('status', 'Y')->get();
        return view('dashboard.landtypelist')->with('data', $result);
    }
    public function create(){
        $objPost = new StdClass();
        $objPost->id = '';
        $objPost->land_type_name = '';
        $objPost->land_type_slug = '';
        $objPost->land_type_desc = '';
        $objPost->status = '';
        return view('dashboard/landtypeadd')->with('data', $objPost)->with('route', 'add');
    }
    public function postCreate(Request $request){
        $formdata = $request->formdata;

        // echo '<pre>';
        // print_r($formdata);
        // echo '</pre>';
        // exit();

        $formdata['land_type_slug'] = (empty($formdata['land_type_name']))?$formdata['land_type_name']:str_replace(" ","-", strtolower($formdata['land_type_name']));
//        $formdata['sector_order'] = (!empty($formdata['sector_order']))?$formdata['sector_order']:0;

        $objPost = new LandType();
        $objPost->land_type_name = $formdata['land_type_name'];
        $objPost->land_type_slug = $formdata['land_type_slug'];
        $objPost->land_type_desc = $formdata['land_type_desc'];
        $objPost->status = 'Y';


        if($objPost->save())
            return redirect('dashboard/land-type')->with('success', 'Land Type added successfully!');
        else
            return redirect('dashboard/land-type')->with('error', 'Land Type cannot be added!');
    }
    public function update($id = ''){
        $objPost = LandType::find($id);

        if($id == '' || is_null($objPost)):

            return redirect('dashboard/land-type')->with('error', 'No Land Type Selected!');

        else:

            return view('dashboard/landtypeadd')
                ->with('route', 'update')
                ->with('data', $objPost);

        endif;
    }
    public function postUpdate(Request $request){
        $formdata = $request->formdata;

        $objPost = LandType::find($formdata['id']);
        $objPost->land_type_name = $formdata['land_type_name'];
        $objPost->land_type_desc = $formdata['land_type_desc'];
        //$formdata['land_type_slug'] = (empty($formdata['land_type_name']))?$formdata['land_type_name']:str_replace(" ","-", strtolower($formdata['land_type_name']));
        //$objPost->land_type_slug = $formdata['land_type_slug'];
        $objPost->save();

        return redirect('dashboard/land-type')->with('success', 'Land Type updated successfully!');
    }
    public function delete($id){
        $objPost = LandType::find($id);
        $objPost->status = 'N';
        $objPost->save();

        return redirect('dashboard/land-type')->with('error', 'Land Type deleted successfully!');
    }
}
