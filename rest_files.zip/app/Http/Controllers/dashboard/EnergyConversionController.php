<?php

namespace App\Http\Controllers\dashboard;

use App\Energy;
use App\EnergyConversion;
use App\LogTable;
use App\Unit;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use stdClass;

class EnergyConversionController extends Controller
{

    public function __construct(){
        $this->middleware('auth');
    }

    public function index(){

        $result = EnergyConversion::join('energy', 'energy.id', '=', 'energy_conversion.energy_id')
            ->join('unit', 'unit.id', '=', 'energy_conversion.natural_unit')
            ->where('energy_conversion.status', 'Y')
            ->select('energy_conversion.*', 'energy.energy_name', 'unit.unit_name as natural_unit_name')
            ->get();

        return view('dashboard.energy_conversion_list')
            ->with('data', $result);
    }

    public function create(){

        $objEnergyConversion=new StdClass();
        $objEnergyConversion->id = '';
        $objEnergyConversion->energy_id = '';
        $objEnergyConversion->natural_unit = '';
        $objEnergyConversion->natural_qty = '';
        $objEnergyConversion->scientific_unit = '';
        $objEnergyConversion->scientific_qty = '';
        $objEnergyConversion->status = '';

        $energy_list = Energy::where('status', 'Y')->get();

        $units = Unit::where('status', 'Y')->get();
        
        return view('dashboard/energy_conversion_add')
            ->with('data', $objEnergyConversion)
            ->with('energy_list', $energy_list)
            ->with('units', $units)
            ->with('route', 'add');
    }
    public function postCreate(Request $request) {
        $formdata = $request->formdata;

        // echo '<pre>';
        // print_r($formdata);
        // echo '</pre>';
        // exit();

        $checkEnergyConversion = EnergyConversion::where('energy_id', $formdata['energy_id'])
            ->where('natural_unit', $formdata['natural_unit'])
            ->where('status', 'Y')
            ->first();

        // echo '<pre>';
        // print_r($formdata);
        // echo '</pre>';
        // exit();

        if(is_null($checkEnergyConversion)){

            $objEnergyConversion = new EnergyConversion();
            $objEnergyConversion->energy_id = $formdata['energy_id'];
            $objEnergyConversion->natural_unit = $formdata['natural_unit'];
            $objEnergyConversion->natural_qty = $formdata['natural_qty'];
            $objEnergyConversion->scientific_unit = $formdata['scientific_unit'];
            $objEnergyConversion->scientific_qty = $formdata['scientific_qty'];
            $objEnergyConversion->status = 'Y';

            if($objEnergyConversion->save()){


                $objLog = new LogTable();
                $log_details = array('Energy ID: '.$formdata['energy_id']
                );
                $data = array(
                    'log_details'   => serialize($log_details),
                    'menu_name'     => 'New Energy Conversion Data',
                    'created_by'    => Auth::user()->id
                );
                $objLog->insertIntoLogTable($data);

                return redirect('dashboard/energy-conversion')->with('success', 'Energy Conversion added successfully!');

            }else{
                return redirect('dashboard/energy-conversion')->with('error', 'Energy Conversion cannot be added!');
            }

        }else{
            return redirect('dashboard/energy-conversion')->with('error', 'Duplicate Energy With Unit Conversion!');
        }

    }
    public function update($id = '') {

        $objEnergyConversion = EnergyConversion::find($id);

        $energy_list = Energy::where('status', 'Y')->get();

        $units = Unit::where('status', 'Y')->get();

        if($id == '' || is_null($objEnergyConversion)):

            return redirect('dashboard/energy-conversion')->with('error', 'No Energy Conversion Selected!');

        else:

            return view('dashboard/energy_conversion_add')
                ->with('route', 'update')
                ->with('units', $units)
                ->with('energy_list', $energy_list)
                ->with('data', $objEnergyConversion);

        endif;

    }

    public function postUpdate(Request $request) {

        $formdata = $request->formdata;

        $objEnergyConversion = EnergyConversion::find($formdata['id']);
        $objEnergyConversion->natural_unit = $formdata['natural_unit'];
        $objEnergyConversion->natural_qty = $formdata['natural_qty'];
        $objEnergyConversion->scientific_unit = $formdata['scientific_unit'];
        $objEnergyConversion->scientific_qty = $formdata['scientific_qty'];

        $objEnergyConversion->save();

        return redirect('dashboard/energy-conversion')->with('success', 'Energy Conversion updated successfully!');

    }

    public function delete($id) {

        $objEnergyConversion = EnergyConversion::find($id);
        $objEnergyConversion->status = 'N';
        $objEnergyConversion->save();

        return redirect('dashboard/energy-conversion')->with('error', 'Energy Conversion deleted successfully!');

    }

}
