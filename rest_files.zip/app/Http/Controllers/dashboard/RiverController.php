<?php

namespace App\Http\Controllers\dashboard;

use App\River;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use stdClass;

class RiverController extends Controller
{
    //
    public function __construct(){
        $this->middleware('auth');
    }
    public function index(){
        $result = River::where('status', 'Y')->get();
        return view('dashboard.riverlist')->with('data', $result);
    }
    public function create(){
        $objPost = new StdClass();
        $objPost->id = '';
        $objPost->river_name = '';
        $objPost->river_slug = '';
        $objPost->river_desc = '';
        $objPost->status = '';
        return view('dashboard/riveradd')->with('data', $objPost)->with('route', 'add');
    }
    public function postCreate(Request $request){
        $formdata = $request->formdata;

        // echo '<pre>';
        // print_r($formdata);
        // echo '</pre>';
        // exit();

        $formdata['river_slug'] = (empty($formdata['river_name']))?$formdata['river_name']:str_replace(" ","-", strtolower($formdata['river_name']));
//        $formdata['sector_order'] = (!empty($formdata['sector_order']))?$formdata['sector_order']:0;

        $objPost = new River();
        $objPost->river_name = $formdata['river_name'];
        $objPost->river_slug = $formdata['river_slug'];
        $objPost->river_desc = $formdata['river_desc'];
        $objPost->status = 'Y';


        if($objPost->save())
            return redirect('dashboard/river/edit/'.$objPost->id)->with('success', 'River added successfully!');
        else
            return redirect('dashboard/river')->with('error', 'River cannot be added!');
    }
    public function update($id = ''){
        $objPost = River::find($id);

        if($id == '' || is_null($objPost)):

            return redirect('dashboard/river')->with('error', 'No River Selected!');

        else:

            return view('dashboard/riveradd')
                ->with('route', 'update')
                ->with('data', $objPost);

        endif;
    }
    public function postUpdate(Request $request){
        $formdata = $request->formdata;

        $objPost = River::find($formdata['id']);
        $objPost->river_name = $formdata['river_name'];
        $objPost->river_desc = $formdata['river_desc'];
        //$formdata['land_type_slug'] = (empty($formdata['land_type_name']))?$formdata['land_type_name']:str_replace(" ","-", strtolower($formdata['land_type_name']));
        //$objPost->land_type_slug = $formdata['land_type_slug'];
        $objPost->save();

        return redirect('dashboard/river/edit/'.$objPost->id)->with('success', 'River updated successfully!');
    }
    public function delete($id){
        $objPost = River::find($id);
        $objPost->status = 'N';
        $objPost->save();

        return redirect('dashboard/river')->with('error', 'River deleted successfully!');
    }
}
