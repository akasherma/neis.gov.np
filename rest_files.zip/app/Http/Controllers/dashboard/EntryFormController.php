<?php

namespace App\Http\Controllers\dashboard;

use App\ConsumptionEnergyForm;
use App\Energy;
use App\EnergyFormMeta;
use App\EnergyTypes;
use App\EnergyTypeTopicMapping;
use App\EnergyYear;
use App\ExportEnergyForm;
use App\GeographicRegion;
use App\ImportEnergyForm;
use App\LandType;
use App\Location;
use App\LogTable;
use App\ProductionEnergyForm;
use App\ResourcesEnergyForm;
use App\River;
use App\Sector;
use App\Unit;
use App\UserGroup;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use stdClass;

class EntryFormController extends Controller
{

    public function entryFormProvinceListing(Request $request){

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->get();

        $central = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'central')
            ->first();

        return view('dashboard/entry_form_province_listing')
            ->with('url', $request->url())
            ->with('provinces', $provinces)
            ->with('central', $central);

    }
    public function reportProvinceListing(Request $request){

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->get();

        $central = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'central')
            ->first();

        return view('dashboard/report_province_listing')
            ->with('url', $request->url())
            ->with('provinces', $provinces)
            ->with('central', $central);


    }

    public function entryFormDistrictListing($province_slug, Request $request){

        $this_province = Location::where('location_slug', $province_slug)->where('status', 'Y')->first();

        $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'district')
            ->where('location.status', 'Y')
            ->where('location.parent_id', $this_province->id)
            ->select('location.*')
            ->get();

        return view('dashboard/entry_form_district_listing')
            ->with('url', $request->url())
            ->with('districts', $districts)
            ->with('this_province', $this_province);

    }

    public function entryFormLocalListing($province_slug, $district_slug, Request $request){

        $this_province = Location::where('location_slug', $province_slug)->where('status', 'Y')->first();

        $this_district = Location::where('location_slug', $district_slug)->where('status', 'Y')->first();

        $locals = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'local-government')
            ->where('location.status', 'Y')
            ->where('location.parent_id', $this_district->id)
            ->select('location.*')
            ->get();

        return view('dashboard/entry_form_local_listing')
            ->with('url', $request->url())
            ->with('locals', $locals)
            ->with('this_province', $this_province)
            ->with('this_district', $this_district);

    }

    public function entryFormEnergyYearListing(Request $request) {

//        echo $request->url();
//        exit();

        $energy_years = EnergyYear::where('status', 'Y')->orderBy('energy_year_start', 'ASC')->get();

        return view('dashboard/entry_form_energy_year_listing')
            ->with('url', $request->url())
            ->with('energy_years', $energy_years);

    }

    public function entryFormEnergyYearListingNew(Request $request) {

//        echo $request->url();
//        exit();

        $energy_years = EnergyYear::where('status', 'Y')->orderBy('energy_year_start', 'ASC')->get();

        return view('dashboard/entry_form_energy_year_listing_new')
            ->with('url', $request->url())
            ->with('energy_years', $energy_years);

    }

    public function entryFormProvinceEnergyYearListing($province_slug, Request $request) {

        $this_province = Location::where('location_slug', $province_slug)->where('status', 'Y')->first();

        $energy_years = EnergyYear::where('status', 'Y')->orderBy('energy_year_start', 'ASC')->get();

        return view('dashboard/entry_form_energy_year_listing')
            ->with('url', $request->url())
            ->with('energy_years', $energy_years)
            ->with('this_province', $this_province);

    }

    public function entryFormDistrictEnergyYearListing($province_slug, $district_slug, Request $request) {

        $this_province = Location::where('location_slug', $province_slug)->where('status', 'Y')->first();

        $this_district = Location::where('location_slug', $district_slug)->where('status', 'Y')->first();

        $energy_years = EnergyYear::where('status', 'Y')->orderBy('energy_year_start', 'ASC')->get();

        return view('dashboard/entry_form_energy_year_listing')
            ->with('url', $request->url())
            ->with('energy_years', $energy_years)
            ->with('this_province', $this_province)
            ->with('this_district', $this_district);

    }

    public function entryFormLocalEnergyYearListing($province_slug, $district_slug, $local_slug, Request $request) {

        $this_province = Location::where('location_slug', $province_slug)->where('status', 'Y')->first();

        $this_district = Location::where('location_slug', $district_slug)->where('status', 'Y')->first();

        $this_local = Location::where('location_slug', $local_slug)->where('status', 'Y')->first();

        $energy_years = EnergyYear::where('status', 'Y')->orderBy('energy_year_start', 'ASC')->get();

        return view('dashboard/entry_form_energy_year_listing')
            ->with('url', $request->url())
            ->with('energy_years', $energy_years)
            ->with('this_province', $this_province)
            ->with('this_district', $this_district)
            ->with('this_local', $this_local);

    }

    public function entryFormEnergyTypeEnergyListing($start, $end, $energy_type_slug, Request $request) {

//        return $start.'-'.$end;

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        if(!empty($this_energy_type)){

//            $final_energy = Energy::where('status', 'Y')->orderBy('energy.energy_order', 'asc')->get();

            $final_energy = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
                ->select('energy.*')
                ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
                ->where('energy.status', '=', 'Y')
                ->groupBy('energy.id')
                ->orderBy('energy.energy_order', 'asc')
                ->get();

            $energy_lists  = array();

            $result_energy = array();

            if($energy_type_slug == 'production'){
                $energy_list_with = Energy::join('energy_form_meta', function ($join) use ($energy_type_slug) {
                    $join->on('energy_form_meta.energy_id', '=', 'energy.id');
                    $join->where('energy_form_meta.energy_form_topic', '=', $energy_type_slug);
                })
                    ->join('production_energy_form', function ($join) use($start, $end) {
                        $join->on('energy_form_meta.energy_form_id', '=', 'production_energy_form.id');
                        $join->where('production_energy_form.from_date', $start);
                        $join->where('production_energy_form.to_date', $end);
                        $join->whereNull('production_energy_form.province_id');
                    })
                    ->select('energy_form_meta.energy_id', 'production_energy_form.id as form_id')
                    ->where('energy.status', '=', 'Y')
                    ->groupBy('energy.id')
                    ->orderBy('energy.energy_order', 'asc')
                    ->get()
                    ->toArray();

                if(is_array($energy_list_with) && count($energy_list_with)){
                    foreach($energy_list_with as $the_energy){
                        $result_energy[$the_energy['energy_id']] = $the_energy['form_id'];
                    }
                }

            }else if($energy_type_slug == 'resources'){
                $energy_list_with = Energy::join('energy_form_meta', function ($join) use ($energy_type_slug) {
                    $join->on('energy_form_meta.energy_id', '=', 'energy.id');
                    $join->where('energy_form_meta.energy_form_topic', '=', $energy_type_slug);
                })
                    ->join('resources_energy_form', function ($join) use($start, $end) {
                        $join->on('energy_form_meta.energy_form_id', '=', 'resources_energy_form.id');
                        $join->where('resources_energy_form.from_date', $start);
                        $join->where('resources_energy_form.to_date', $end);
                        $join->whereNull('resources_energy_form.province_id');
                    })
                    ->select('energy_form_meta.energy_id', 'resources_energy_form.id as form_id')
                    ->where('energy.status', '=', 'Y')
                    ->groupBy('energy.id')
                    ->orderBy('energy.energy_order', 'asc')
                    ->get()
                    ->toArray();

                if(is_array($energy_list_with) && count($energy_list_with)){
                    foreach($energy_list_with as $the_energy){
                        $result_energy[$the_energy['energy_id']] = $the_energy['form_id'];
                    }
                }

            }else if($energy_type_slug == 'import'){
                $energy_list_with = Energy::join('energy_form_meta', function ($join) use ($energy_type_slug) {
                    $join->on('energy_form_meta.energy_id', '=', 'energy.id');
                    $join->where('energy_form_meta.energy_form_topic', '=', $energy_type_slug);
                })
                    ->join('import_energy_form', function ($join) use($start, $end) {
                        $join->on('energy_form_meta.energy_form_id', '=', 'import_energy_form.id');
                        $join->where('import_energy_form.from_date', $start);
                        $join->where('import_energy_form.to_date', $end);
                        $join->whereNull('import_energy_form.province_id');
                    })
                    ->select('energy_form_meta.energy_id', 'import_energy_form.id as form_id')
                    ->where('energy.status', '=', 'Y')
                    ->groupBy('energy.id')
                    ->orderBy('energy.energy_order', 'asc')
                    ->get()
                    ->toArray();

                if(is_array($energy_list_with) && count($energy_list_with)){
                    foreach($energy_list_with as $the_energy){
                        $result_energy[$the_energy['energy_id']] = $the_energy['form_id'];
                    }
                }

            }else if($energy_type_slug == 'export'){
                $energy_list_with = Energy::join('energy_form_meta', function ($join) use ($energy_type_slug) {
                    $join->on('energy_form_meta.energy_id', '=', 'energy.id');
                    $join->where('energy_form_meta.energy_form_topic', '=', $energy_type_slug);
                })
                    ->join('export_energy_form', function ($join) use($start, $end) {
                        $join->on('energy_form_meta.energy_form_id', '=', 'export_energy_form.id');
                        $join->where('export_energy_form.from_date', $start);
                        $join->where('export_energy_form.to_date', $end);
                        $join->whereNull('export_energy_form.province_id');
                    })
                    ->select('energy_form_meta.energy_id', 'export_energy_form.id as form_id')
                    ->where('energy.status', '=', 'Y')
                    ->groupBy('energy.id')
                    ->orderBy('energy.energy_order', 'asc')
                    ->get()
                    ->toArray();

                if(is_array($energy_list_with) && count($energy_list_with)){
                    foreach($energy_list_with as $the_energy){
                        $result_energy[$the_energy['energy_id']] = $the_energy['form_id'];
                    }
                }

            }else{
                $energy_list_with = Energy::join('energy_form_meta', function ($join) use ($energy_type_slug) {
                    $join->on('energy_form_meta.energy_id', '=', 'energy.id');
                    $join->where('energy_form_meta.energy_form_topic', '=', $energy_type_slug);
                })
                    ->join('consumption_energy_form', function ($join) use($start, $end) {
                        $join->on('energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id');
                        $join->where('consumption_energy_form.from_date', $start);
                        $join->where('consumption_energy_form.to_date', $end);
                        $join->whereNull('consumption_energy_form.province_id');
                    })
                    ->select('energy_form_meta.energy_id', 'consumption_energy_form.id as form_id')
                    ->where('energy.status', '=', 'Y')
                    ->groupBy('energy.id')
                    ->orderBy('energy.energy_order', 'asc')
                    ->get()
                    ->toArray();

                if(is_array($energy_list_with) && count($energy_list_with)){
                    foreach($energy_list_with as $the_energy){
                        $result_energy[$the_energy['energy_id']] = $the_energy['form_id'];
                    }
                }

            }

            if(!empty($final_energy)){
                foreach($final_energy as $the_energy){
                    if(!empty($result_energy[$the_energy->id]) && $result_energy[$the_energy->id] != ''){
                        $the_energy->form_id = $result_energy[$the_energy->id];
                    }
                    array_push($energy_lists, json_decode($the_energy));
                }
            }

//            echo '<pre>';
//            print_r($energy_lists);
//            exit();

//            echo '<pre>';
//            print_r($final_energy);
//            exit();

            return view('dashboard/entry_form_energy_type_energy_listing')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_lists', $energy_lists);

//            return view('dashboard/entry_form_energy_type_energy_listing')
//                ->with('url', $request->url())
//                ->with('this_province', $this_province)
//                ->with('this_energy_type', $this_energy_type)
//                ->with('start', $start)
//                ->with('end', $end)
//                ->with('energy_lists', $energy_lists);

        }else{

            return redirect('dashboard/entry-form')->with('warning', 'No such Energy Type!');

        }

//
//        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();
//
//        if(!empty($this_energy_type)){
//
////            $energy_lists = Energy::leftJoin('energy_type_topic_mapping', function ($join) use ($energy_type_slug) {
////                $join->on('energy_type_topic_mapping.energy_id', '=', 'energy.id');
////                $join->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug);
////            })
////                ->select('energy.*')
////                ->where('energy.status', 'Y')
////                ->groupBy('energy.id')
////                ->get();
//
//
//
////            $energy_lists = Energy::where('status', 'Y')->get();
//
////            $energy_lists = Energy::where('status', 'Y')->get();
//
//            $energy_lists = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
//                ->select('energy.*')
//                ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
//                ->where('energy.status', 'Y')
//                ->groupBy('energy.id')
//                ->orderBy('energy.energy_order', 'asc')
//                ->get();
//
//            return view('dashboard/entry_form_energy_type_energy_listing')
//                ->with('url', $request->url())
//                ->with('this_energy_type', $this_energy_type)
//                ->with('start', $start)
//                ->with('end', $end)
//                ->with('energy_lists', $energy_lists);
//
//        }else{
//
//            return redirect('dashboard/entry-form')->with('warning', 'No such Energy Type!');
//
//        }

    }

    public function entryFormProvinceEnergyTypeEnergyListing($province_slug, $start, $end, $energy_type_slug, Request $request) {

        $this_province = Location::where('location_slug', $province_slug)->where('status', 'Y')->first();

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        if(!empty($this_energy_type)){

//            $final_energy = Energy::where('status', 'Y')->orderBy('energy.energy_order', 'asc')->get();

            $final_energy = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
                ->select('energy.*')
                ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
                ->where('energy.status', '=', 'Y')
                ->groupBy('energy.id')
                ->orderBy('energy.energy_order', 'asc')
                ->get();

            $energy_lists  = array();

            $result_energy = array();

            if($energy_type_slug == 'production'){
                $energy_list_with = Energy::join('energy_form_meta', function ($join) use ($energy_type_slug) {
                    $join->on('energy_form_meta.energy_id', '=', 'energy.id');
                    $join->where('energy_form_meta.energy_form_topic', '=', $energy_type_slug);
                })
                    ->join('export_energy_form', function ($join) use ($this_province) {
                        $join->on('energy_form_meta.energy_form_id', '=', 'production_energy_form.id');
                        $join->where('production_energy_form.province_id', '=', $this_province->id);
                    })
                    ->select('energy_form_meta.energy_id', 'production_energy_form.id as form_id')
                    ->where('energy.status', '=', 'Y')
                    ->groupBy('energy.id')
                    ->orderBy('energy.energy_order', 'asc')
                    ->get()
                    ->toArray();

                if(is_array($energy_list_with) && count($energy_list_with)){
                    foreach($energy_list_with as $the_energy){
                        $result_energy[$the_energy['energy_id']] = $the_energy['form_id'];
                    }
                }

            }else if($energy_type_slug == 'resources'){
                $energy_list_with = Energy::join('energy_form_meta', function ($join) use ($energy_type_slug) {
                    $join->on('energy_form_meta.energy_id', '=', 'energy.id');
                    $join->where('energy_form_meta.energy_form_topic', '=', $energy_type_slug);
                })
                    ->join('export_energy_form', function ($join) use ($this_province) {
                        $join->on('energy_form_meta.energy_form_id', '=', 'resources_energy_form.id');
                        $join->where('resources_energy_form.province_id', '=', $this_province->id);
                    })
                    ->select('energy_form_meta.energy_id', 'resources_energy_form.id as form_id')
                    ->where('energy.status', '=', 'Y')
                    ->groupBy('energy.id')
                    ->orderBy('energy.energy_order', 'asc')
                    ->get()
                    ->toArray();

                if(is_array($energy_list_with) && count($energy_list_with)){
                    foreach($energy_list_with as $the_energy){
                        $result_energy[$the_energy['energy_id']] = $the_energy['form_id'];
                    }
                }

            }else if($energy_type_slug == 'import'){
                $energy_list_with = Energy::join('energy_form_meta', function ($join) use ($energy_type_slug) {
                    $join->on('energy_form_meta.energy_id', '=', 'energy.id');
                    $join->where('energy_form_meta.energy_form_topic', '=', $energy_type_slug);
                })
                    ->join('export_energy_form', function ($join) use ($this_province) {
                        $join->on('energy_form_meta.energy_form_id', '=', 'import_energy_form.id');
                        $join->where('import_energy_form.province_id', '=', $this_province->id);
                    })
                    ->select('energy_form_meta.energy_id', 'import_energy_form.id as form_id')
                    ->where('energy.status', '=', 'Y')
                    ->groupBy('energy.id')
                    ->orderBy('energy.energy_order', 'asc')
                    ->get()
                    ->toArray();

                if(is_array($energy_list_with) && count($energy_list_with)){
                    foreach($energy_list_with as $the_energy){
                        $result_energy[$the_energy['energy_id']] = $the_energy['form_id'];
                    }
                }

            }else if($energy_type_slug == 'export'){
                $energy_list_with = Energy::join('energy_form_meta', function ($join) use ($energy_type_slug) {
                    $join->on('energy_form_meta.energy_id', '=', 'energy.id');
                    $join->where('energy_form_meta.energy_form_topic', '=', $energy_type_slug);
                })
                    ->join('export_energy_form', function ($join) use ($this_province) {
                        $join->on('energy_form_meta.energy_form_id', '=', 'export_energy_form.id');
                        $join->where('export_energy_form.province_id', '=', $this_province->id);
                    })
                    ->select('energy_form_meta.energy_id', 'export_energy_form.id as form_id')
                    ->where('energy.status', '=', 'Y')
                    ->groupBy('energy.id')
                    ->orderBy('energy.energy_order', 'asc')
                    ->get()
                    ->toArray();

                if(is_array($energy_list_with) && count($energy_list_with)){
                    foreach($energy_list_with as $the_energy){
                        $result_energy[$the_energy['energy_id']] = $the_energy['form_id'];
                    }
                }

            }else{
                $energy_list_with = Energy::join('energy_form_meta', function ($join) use ($energy_type_slug) {
                        $join->on('energy_form_meta.energy_id', '=', 'energy.id');
                        $join->where('energy_form_meta.energy_form_topic', '=', $energy_type_slug);
                    })
                    ->join('consumption_energy_form', function ($join) use ($this_province) {
                        $join->on('energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id');
                        $join->where('consumption_energy_form.province_id', '=', $this_province->id);
                    })
                    ->select('energy_form_meta.energy_id', 'consumption_energy_form.id as form_id')
                    ->where('energy.status', '=', 'Y')
                    ->groupBy('energy.id')
                    ->orderBy('energy.energy_order', 'asc')
                    ->get()
                    ->toArray();

                if(is_array($energy_list_with) && count($energy_list_with)){
                    foreach($energy_list_with as $the_energy){
                        $result_energy[$the_energy['energy_id']] = $the_energy['form_id'];
                    }
                }

            }

            if(!empty($final_energy)){
                foreach($final_energy as $the_energy){
                    if(!empty($result_energy[$the_energy->id]) && $result_energy[$the_energy->id] != ''){
                        $the_energy->form_id = $result_energy[$the_energy->id];
                    }
                    array_push($energy_lists, json_decode($the_energy));
                }
            }

//            echo '<pre>';
//            print_r($energy_lists);
//            exit();

//            echo '<pre>';
//            print_r($final_energy);
//            exit();

            return view('dashboard/entry_form_energy_type_energy_listing')
                ->with('url', $request->url())
                ->with('this_province', $this_province)
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_lists', $energy_lists);

        }else{

            return redirect('dashboard/entry-form')->with('warning', 'No such Energy Type!');

        }

    }

    public function entryFormDistrictEnergyTypeEnergyListing($province_slug, $district_slug, $start, $end, $energy_type_slug, Request $request) {

        $this_province = Location::where('location_slug', $province_slug)->where('status', 'Y')->first();

        $this_district = Location::where('location_slug', $district_slug)->where('status', 'Y')->first();

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        if(!empty($this_energy_type)){

            $final_energy = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
                ->select('energy.*')
                ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
                ->where('energy.status', '=', 'Y')
                ->groupBy('energy.id')
                ->orderBy('energy.energy_order', 'asc')
                ->get();

            $energy_lists  = array();

            $result_energy = array();

            if($energy_type_slug == 'production'){
                $energy_list_with = Energy::join('energy_form_meta', function ($join) use ($energy_type_slug) {
                    $join->on('energy_form_meta.energy_id', '=', 'energy.id');
                    $join->where('energy_form_meta.energy_form_topic', '=', $energy_type_slug);
                })
                    ->join('export_energy_form', function ($join) use ($this_province) {
                        $join->on('energy_form_meta.energy_form_id', '=', 'production_energy_form.id');
                        $join->where('production_energy_form.province_id', '=', $this_province->id);
                    })
                    ->select('energy_form_meta.energy_id', 'production_energy_form.id as form_id')
                    ->where('energy.status', '=', 'Y')
                    ->groupBy('energy.id')
                    ->orderBy('energy.energy_order', 'asc')
                    ->get()
                    ->toArray();

                if(is_array($energy_list_with) && count($energy_list_with)){
                    foreach($energy_list_with as $the_energy){
                        $result_energy[$the_energy['energy_id']] = $the_energy['form_id'];
                    }
                }

            }else if($energy_type_slug == 'resources'){
                $energy_list_with = Energy::join('energy_form_meta', function ($join) use ($energy_type_slug) {
                    $join->on('energy_form_meta.energy_id', '=', 'energy.id');
                    $join->where('energy_form_meta.energy_form_topic', '=', $energy_type_slug);
                })
                    ->join('export_energy_form', function ($join) use ($this_province, $this_district) {
                        $join->on('energy_form_meta.energy_form_id', '=', 'resources_energy_form.id');
                        $join->where('resources_energy_form.province_id', '=', $this_province->id);
                        $join->where('resources_energy_form.district_id', '=', $this_district->id);
                    })
                    ->select('energy_form_meta.energy_id', 'resources_energy_form.id as form_id')
                    ->where('energy.status', '=', 'Y')
                    ->groupBy('energy.id')
                    ->orderBy('energy.energy_order', 'asc')
                    ->get()
                    ->toArray();

                if(is_array($energy_list_with) && count($energy_list_with)){
                    foreach($energy_list_with as $the_energy){
                        $result_energy[$the_energy['energy_id']] = $the_energy['form_id'];
                    }
                }

            }else if($energy_type_slug == 'import'){
                $energy_list_with = Energy::join('energy_form_meta', function ($join) use ($energy_type_slug) {
                    $join->on('energy_form_meta.energy_id', '=', 'energy.id');
                    $join->where('energy_form_meta.energy_form_topic', '=', $energy_type_slug);
                })
                    ->join('export_energy_form', function ($join) use ($this_province, $this_district) {
                        $join->on('energy_form_meta.energy_form_id', '=', 'import_energy_form.id');
                        $join->where('import_energy_form.province_id', '=', $this_province->id);
                        $join->where('import_energy_form.district_id', '=', $this_district->id);
                    })
                    ->select('energy_form_meta.energy_id', 'import_energy_form.id as form_id')
                    ->where('energy.status', '=', 'Y')
                    ->groupBy('energy.id')
                    ->orderBy('energy.energy_order', 'asc')
                    ->get()
                    ->toArray();

                if(is_array($energy_list_with) && count($energy_list_with)){
                    foreach($energy_list_with as $the_energy){
                        $result_energy[$the_energy['energy_id']] = $the_energy['form_id'];
                    }
                }

            }else if($energy_type_slug == 'export'){
                $energy_list_with = Energy::join('energy_form_meta', function ($join) use ($energy_type_slug) {
                    $join->on('energy_form_meta.energy_id', '=', 'energy.id');
                    $join->where('energy_form_meta.energy_form_topic', '=', $energy_type_slug);
                })
                    ->join('export_energy_form', function ($join) use ($this_province, $this_district) {
                        $join->on('energy_form_meta.energy_form_id', '=', 'export_energy_form.id');
                        $join->where('export_energy_form.province_id', '=', $this_province->id);
                        $join->where('export_energy_form.district_id', '=', $this_district->id);
                    })
                    ->select('energy_form_meta.energy_id', 'export_energy_form.id as form_id')
                    ->where('energy.status', '=', 'Y')
                    ->groupBy('energy.id')
                    ->orderBy('energy.energy_order', 'asc')
                    ->get()
                    ->toArray();

                if(is_array($energy_list_with) && count($energy_list_with)){
                    foreach($energy_list_with as $the_energy){
                        $result_energy[$the_energy['energy_id']] = $the_energy['form_id'];
                    }
                }

            }else{
                $energy_list_with = Energy::join('energy_form_meta', function ($join) use ($energy_type_slug) {
                    $join->on('energy_form_meta.energy_id', '=', 'energy.id');
                    $join->where('energy_form_meta.energy_form_topic', '=', $energy_type_slug);
                })
                    ->join('consumption_energy_form', function ($join) use ($this_province, $this_district) {
                        $join->on('energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id');
                        $join->where('consumption_energy_form.province_id', '=', $this_province->id);
                        $join->where('consumption_energy_form.district_id', '=', $this_district->id);
                    })
                    ->select('energy_form_meta.energy_id', 'consumption_energy_form.id as form_id')
                    ->where('energy.status', '=', 'Y')
                    ->groupBy('energy.id')
                    ->orderBy('energy.energy_order', 'asc')
                    ->get()
                    ->toArray();

                if(is_array($energy_list_with) && count($energy_list_with)){
                    foreach($energy_list_with as $the_energy){
                        $result_energy[$the_energy['energy_id']] = $the_energy['form_id'];
                    }
                }

            }

            if(!empty($final_energy)){
                foreach($final_energy as $the_energy){
                    if(!empty($result_energy[$the_energy->id]) && $result_energy[$the_energy->id] != ''){
                        $the_energy->form_id = $result_energy[$the_energy->id];
                    }
                    array_push($energy_lists, json_decode($the_energy));
                }
            }

//            echo '<pre>';
//            print_r($energy_lists);
//            exit();

//            echo '<pre>';
//            print_r($final_energy);
//            exit();

            return view('dashboard/entry_form_energy_type_energy_listing')
                ->with('url', $request->url())
                ->with('this_province', $this_province)
                ->with('this_district', $this_district)
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_lists', $energy_lists);

//            $energy_lists = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
//                ->select('energy.*')
//                ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
//                ->where('energy.status', 'Y')
//                ->groupBy('energy.id')
//                ->orderBy('energy.energy_order', 'asc')
//                ->get();
//
//            return view('dashboard/entry_form_energy_type_energy_listing')
//                ->with('url', $request->url())
//                ->with('this_province', $this_province)
//                ->with('this_district', $this_district)
//                ->with('this_energy_type', $this_energy_type)
//                ->with('start', $start)
//                ->with('end', $end)
//                ->with('energy_lists', $energy_lists);

        }else{

            return redirect('dashboard/entry-form')->with('warning', 'No such Energy Type!');

        }

    }

    public function entryFormLocalEnergyTypeEnergyListing($province_slug, $district_slug, $local_slug, $start, $end, $energy_type_slug, Request $request) {

        $this_province = Location::where('location_slug', $province_slug)->where('status', 'Y')->first();

        $this_district = Location::where('location_slug', $district_slug)->where('status', 'Y')->first();

        $this_local = Location::where('location_slug', $local_slug)->where('status', 'Y')->first();

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        if(!empty($this_energy_type)){

//            $energy_lists = Energy::join('energy_type_topic_mapping', function ($join) use ($energy_type_slug) {
//                $join->on('energy_type_topic_mapping.energy_id', '=', 'energy.id');
//                $join->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug);
//            })
//                ->select('energy.*')
//                ->where('energy.status', 'Y')
//                ->groupBy('energy.id')
//                ->get();

            $energy_lists = Energy::where('status', 'Y')->get();

            return view('dashboard/entry_form_energy_type_energy_listing')
                ->with('url', $request->url())
                ->with('this_province', $this_province)
                ->with('this_district', $this_district)
                ->with('this_local', $this_local)
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_lists', $energy_lists);

        }else{

            return redirect('dashboard/entry-form')->with('warning', 'No such Energy Type!');

        }

    }

    public function EntryFormController($province_slug, $district_slug, $local_slug, $start, $end, $energy_type_slug) {

        $this_province = Location::where('location_slug', $province_slug)->where('status', 'Y')->first();

        $this_district = Location::where('location_slug', $district_slug)->where('status', 'Y')->first();

        $this_local = Location::where('location_slug', $local_slug)->where('status', 'Y')->first();

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        if(!empty($this_energy_type)){

            $energy_lists = Energy::join('energy_type_topic_mapping', function ($join) use ($energy_type_slug) {
                $join->on('energy_type_topic_mapping.energy_id', '=', 'energy.id');
                $join->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug);
            })
                ->select('energy.*')
                ->where('energy.status', '=', 'Y')
                ->groupBy('energy.id')
                ->get();

            return view('dashboard/entry_form_energy_type_energy_listing')
                ->with('this_province', $this_province)
                ->with('this_district', $this_district)
                ->with('this_local', $this_local)
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_lists', $energy_lists);

        }else{

            return redirect('dashboard/entry-form')->with('warning', 'No such Energy Type!');

        }

    }

    public function entryFormEnergyTypeListing($start, $end, Request $request) {

        $energy_types = EnergyTypes::where('status', 'Y')->get();

        return view('dashboard/entry_form_energy_type_listing')
            ->with('url', $request->url())
            ->with('start', $start)
            ->with('end', $end)
            ->with('energy_types', $energy_types);

    }

    public function entryFormEnergyTypeListingNew(Request $request) {

        $energy_types = EnergyTypes::where('status', 'Y')->get();

        return view('dashboard/entry_form_energy_type_listing_new')
            ->with('url', $request->url())
            ->with('year', '')
            ->with('energy_types', $energy_types);

    }

    public function entryFormEnergyTypeListingNewProvincial(Request $request) {

        $energy_types = EnergyTypes::where('status', 'Y')->get();

        return view('dashboard/entry_form_energy_type_listing_new_provincial')
            ->with('url', $request->url())
            ->with('year', '')
            ->with('energy_types', $energy_types);

    }

    public function entryFormEnergyTypeListingNewDistrictwise(Request $request) {

        $energy_types = EnergyTypes::where('status', 'Y')->get();

        return view('dashboard/entry_form_energy_type_listing_new_districtwise')
            ->with('url', $request->url())
            ->with('year', '')
            ->with('energy_types', $energy_types);

    }

    public function entryFormEnergyTypeListingNewReport(Request $request) {

        $energy_types = EnergyTypes::where('status', 'Y')->get();

        return view('dashboard/entry_form_energy_type_listing_new_report')
            ->with('url', $request->url())
            ->with('year', '')
            ->with('energy_types', $energy_types);

    }

    public function entryFormProvinceEnergyTypeListing($province_slug, $start, $end, Request $request) {

        $this_province = Location::where('location_slug', $province_slug)->where('status', 'Y')->first();

        $energy_types = EnergyTypes::where('status', 'Y')->get();

        return view('dashboard/entry_form_energy_type_listing')
            ->with('url', $request->url())
            ->with('this_province', $this_province)
            ->with('start', $start)
            ->with('end', $end)
            ->with('energy_types', $energy_types);

    }

    public function entryFormDistrictEnergyTypeListing($province_slug, $district_slug, $start, $end, Request $request) {

        $this_province = Location::where('location_slug', $province_slug)->where('status', 'Y')->first();

        $this_district = Location::where('location_slug', $district_slug)->where('status', 'Y')->first();

        $energy_types = EnergyTypes::where('status', 'Y')->get();

        return view('dashboard/entry_form_energy_type_listing')
            ->with('url', $request->url())
            ->with('this_province', $this_province)
            ->with('this_district', $this_district)
            ->with('start', $start)
            ->with('end', $end)
            ->with('energy_types', $energy_types);

    }

    public function entryFormLocalEnergyTypeListing($province_slug, $district_slug, $local_slug, $start, $end, Request $request) {
//return 1;

        $this_province = Location::where('location_slug', $province_slug)->where('status', 'Y')->first();

        $this_district = Location::where('location_slug', $district_slug)->where('status', 'Y')->first();

        $this_local = Location::where('location_slug', $local_slug)->where('status', 'Y')->first();

        $energy_types = EnergyTypes::where('status', 'Y')->get();

        return view('dashboard/entry_form_energy_type_listing')
            ->with('url', $request->url())
            ->with('this_province', $this_province)
            ->with('this_district', $this_district)
            ->with('this_local', $this_local)
            ->with('start', $start)
            ->with('end', $end)
            ->with('energy_types', $energy_types);

    }

    public function entryFormEnergyForm($start, $end, $energy_type_slug, $energy_slug) {

        $data = new StdClass();
        $data->id = '';
        $data->energy_id = '';
        $data->central_id = '';
        $data->province_id = '';
        $data->district_id = '';
        $data->local_gov_id = '';
        $data->from_date = '';
        $data->to_date = '';

        $central = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'central')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'asc')
            ->first();

        $this_energy = Energy::where('energy_slug', $energy_slug)->first();

        $field_topics = EnergyTypeTopicMapping::where('energy_type_topic', $energy_type_slug)
            ->where('energy_id', $this_energy->id)
            ->orderBy('energy_field_topic', 'asc')
            ->pluck('energy_field_topic')->toArray();

//        $field_topics = array('production', 'resources', 'consumption', 'import', 'export');

        $land_types = LandType::where('status', 'Y')->get();
        $sectors = Sector::where('status', 'Y')->orderBy('entry_order', 'ASC')->orderBy('sector_name', 'ASC')->get();
        $geographic_regions = GeographicRegion::where('status', 'Y')->get();
        $rivers = River::where('status', 'Y')->get();
        $overall = new stdClass();
        $overall->natural_unit = '';

        $units = Unit::join('energy_conversion', 'energy_conversion.natural_unit', '=', 'unit.id')
            ->where('unit.status', 'Y')
            ->where('energy_conversion.energy_id', $this_energy->id)
            ->select('unit.*', 'energy_conversion.scientific_qty')
            ->groupBy('unit.id')
            ->get();

        return view('dashboard/energy_form_add')
            ->with('data', $data)
            ->with('this_energy', $this_energy)
            ->with('central', $central)
            ->with('land_types', $land_types)
            ->with('sectors', $sectors)
            ->with('geographic_regions', $geographic_regions)
            ->with('rivers', $rivers)
            ->with('overall', $overall)
            ->with('units', $units)
            ->with('field_topics', $field_topics)
            ->with('start', $start)
            ->with('end', $end)
            ->with('energy_type', $energy_type_slug)
            ->with('route', 'add');
    }

    public function entryFormEnergyFormNew($energy_type_slug, Request $request) {

        $user_level_id = Auth::user()->user_group_id;

        $user_level = UserGroup::find($user_level_id);

//        echo 'hi';
//        exit();

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $start = '';
        $end = '';
        $energy_slug = '';

        $start = (!empty($request->get('year')))?$request->get('year'):date('Y');
        $end = $start + 1;

        $central_id = 1;
        $province_id = (!empty($request->get('province_id')))?$request->get('province_id'):null;
        $district_id = (!empty($request->get('district_id')))?$request->get('district_id'):null;
        $local_gov_id = (!empty($request->get('local_gov_id')))?$request->get('local_gov_id'):null;


        $is_central = (!empty($request->get('is_central')))?$request->get('is_central'):0;

        if($is_central > 0){
            $province_id = null;
            $district_id = null;
            $local_gov_id = null;
        }

//        $data = new StdClass();
//        $data->id = '';
//        $data->energy_id = '';
//        $data->central_id = '';
//        $data->province_id = '';
//        $data->district_id = '';
//        $data->local_gov_id = '';
//        $data->from_date = '';
//        $data->to_date = '';


        $central = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'central')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'asc')
            ->first();

        if(Auth::user()->is_admin == 'Y' || Auth::user()->is_central == '1'){
            $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'province')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'district')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'local-government')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();
        }else{

            // Auth::user()->id;

            $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->join('users', 'users.province_id', '=', 'location.id')
                ->where('users.id', Auth::user()->id)
                ->where('location_type.location_type_slug', 'province')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->join('users', 'users.district_id', '=', 'location.id')
                ->where('users.id', Auth::user()->id)
                ->where('location_type.location_type_slug', 'district')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->join('users', 'users.local_govt_id', '=', 'location.id')
                ->where('users.id', Auth::user()->id)
                ->where('location_type.location_type_slug', 'local-government')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

        }

        $energy_year = EnergyYear::where('status', 'Y')->where('is_completed', 'N')->orderBy('energy_year_start','desc')->get();

        $this_energy = '';
        $units = '';

//        echo $energy_type_slug;

        $energy_listing = Energy::join('energy_type_verses_energy_mapping AS etvem', 'etvem.energy_id', '=', 'energy.id')
                            ->join('fuel_type AS ft', 'ft.id', '=', 'energy.fuel_type_id')
                            ->select('energy.*', 'ft.fuel_type_name')
                            ->where('etvem.energy_type_id', $this_energy_type->id)
                            ->where('energy.status', '=', 'Y')
                            ->orderBy('ft.fuel_order', 'asc')
                            ->get();

        $data = array();

        if(!empty($energy_listing[0])){
            foreach($energy_listing as $the_energy){
                $arr = ImportEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'import_energy_form.id')
                    ->select('efm.*')
                    ->where('import_energy_form.energy_id', '=', $the_energy->id)
                    ->where('import_energy_form.province_id', '=', $province_id)
                    ->where('import_energy_form.district_id', '=', $district_id)
                    ->where('import_energy_form.local_gov_id', '=', $local_gov_id)
                    ->where('efm.energy_form_topic', '=', 'import')
                    ->where('efm.energy_topic', '=', 'overall')
                    ->first();

//                echo '<pre>';
//                print_r(json_decode($arr));
//                echo '</pre>';

                $data[$the_energy->id] = $arr;

            }
        }

//        echo '<pre>';
//        print_r($energy_listing);
//        echo '</pre>';
//        exit();

//        $this_energy = Energy::where('energy_slug', $energy_slug)->first();
//
        $field_topics = EnergyTypeTopicMapping::where('energy_type_topic', $energy_type_slug)
            ->orderBy('energy_field_topic', 'asc')
            ->pluck('energy_field_topic')->toArray();

//        $field_topics = array('production', 'resources', 'consumption', 'import', 'export');

//        $land_types = LandType::where('status', 'Y')->get();
        $sectors = Sector::where('status', 'Y')->orderBy('entry_order', 'ASC')->orderBy('sector_name', 'ASC')->get();
//        $geographic_regions = GeographicRegion::where('status', 'Y')->get();
//        $rivers = River::where('status', 'Y')->get();

        $overall = new stdClass();
        $overall->natural_unit = '';

        $units = Unit::join('energy_conversion', 'energy_conversion.natural_unit', '=', 'unit.id')
            ->where('unit.status', 'Y')
            ->select('unit.*', 'energy_conversion.scientific_qty')
            ->groupBy('unit.id')
            ->get();

        return view('dashboard/energy_form_add_new')
            ->with('data', $data)
            ->with('this_energy_type', $this_energy_type)
            ->with('central', $central)
            ->with('sectors', $sectors)
            ->with('overall', $overall)
            ->with('units', $units)
            ->with('field_topics', $field_topics)
            ->with('start', $start)
            ->with('end', $end)
            ->with('province_id', $province_id)
            ->with('district_id', $district_id)
            ->with('local_gov_id', $local_gov_id)
            ->with('provinces', $provinces)
            ->with('districts', $districts)
            ->with('local_governments', $local_governments)
            ->with('energy_type', $energy_type_slug)
            ->with('energy_listing', $energy_listing)
            ->with('energy_year', $energy_year)
            ->with('is_central', $is_central)
            ->with('route', 'add');
    }

    public function entryFormEnergyFormNewImport(Request $request) {

        $user_level_id = Auth::user()->user_group_id;

        $user_level = UserGroup::find($user_level_id);

        $energy_type_slug = 'import';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $start = (!empty($request->get('year')))?$request->get('year'):date('Y');
        $end = $start + 1;

        $central_id = 1;
        $province_id = (!empty($request->get('province_id')))?$request->get('province_id'):null;
        $district_id = (!empty($request->get('district_id')))?$request->get('district_id'):null;
        $local_gov_id = (!empty($request->get('local_gov_id')))?$request->get('local_gov_id'):null;


        $is_central = (!empty($request->get('is_central')))?$request->get('is_central'):0;

        if($is_central > 0){
            $province_id = null;
            $district_id = null;
            $local_gov_id = null;
        }

        $central = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'central')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'asc')
            ->first();

        if(Auth::user()->is_admin == 'Y' || Auth::user()->is_central == '1'){
            $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'province')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'district')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'local-government')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();
        }else{

            $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->join('users', 'users.province_id', '=', 'location.id')
                ->where('users.id', Auth::user()->id)
                ->where('location_type.location_type_slug', 'province')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->join('users', 'users.district_id', '=', 'location.id')
                ->where('users.id', Auth::user()->id)
                ->where('location_type.location_type_slug', 'district')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->join('users', 'users.local_govt_id', '=', 'location.id')
                ->where('users.id', Auth::user()->id)
                ->where('location_type.location_type_slug', 'local-government')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

        }

        $energy_year = EnergyYear::where('status', 'Y')->where('is_completed', 'N')->orderBy('energy_year_start','desc')->get();

        $energy_listing = Energy::join('energy_type_verses_energy_mapping AS etvem', 'etvem.energy_id', '=', 'energy.id')
                            ->join('fuel_type AS ft', 'ft.id', '=', 'energy.fuel_type_id')
                            ->select('energy.*', 'ft.fuel_type_name')
                            ->where('etvem.energy_type_id', $this_energy_type->id)
                            ->where('energy.status', '=', 'Y')
                            ->orderBy('ft.fuel_order', 'asc')
                            ->get();

        $data = array();

        if($province_id > 0) {

            if (!empty($energy_listing[0])) {
                foreach ($energy_listing as $the_energy) {
                    $arr = ImportEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'import_energy_form.id')
                        ->select('efm.*')
                        ->where('import_energy_form.energy_id', '=', $the_energy->id)
                        ->where('import_energy_form.province_id', '=', $province_id)
                        ->where('import_energy_form.district_id', '=', $district_id)
                        ->where('import_energy_form.local_gov_id', '=', $local_gov_id)
                        ->where('import_energy_form.from_date', '=', $start)
                        ->where('efm.energy_form_topic', '=', 'import')
                        ->where('efm.energy_topic', '=', 'overall')
                        ->first();

                    $data[$the_energy->id] = $arr;

                }
            }

        }else{

            if (!empty($energy_listing[0])) {
                foreach ($energy_listing as $the_energy) {
                    $arr = ImportEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'import_energy_form.id')
                        ->select('efm.*')
                        ->where('import_energy_form.energy_id', '=', $the_energy->id)
                        ->where('import_energy_form.central_id', '=', $central_id)
                        ->where('import_energy_form.from_date', '=', $start)
                        ->where('efm.energy_form_topic', '=', 'import')
                        ->where('efm.energy_topic', '=', 'overall')
                        ->first();

                    $data[$the_energy->id] = $arr;

                }
            }

        }

        $field_topics = EnergyTypeTopicMapping::where('energy_type_topic', $energy_type_slug)
            ->orderBy('energy_field_topic', 'asc')
            ->pluck('energy_field_topic')->toArray();

        $overall = new stdClass();
        $overall->natural_unit = '';

        $units = Unit::join('energy_conversion', 'energy_conversion.natural_unit', '=', 'unit.id')
            ->where('unit.status', 'Y')
            ->select('unit.*', 'energy_conversion.scientific_qty')
            ->groupBy('unit.id')
            ->get();

        return view('dashboard/energy_form_add_new')
            ->with('data', $data)
            ->with('this_energy_type', $this_energy_type)
            ->with('central', $central)
            ->with('overall', $overall)
            ->with('units', $units)
            ->with('field_topics', $field_topics)
            ->with('start', $start)
            ->with('end', $end)
            ->with('province_id', $province_id)
            ->with('district_id', $district_id)
            ->with('local_gov_id', $local_gov_id)
            ->with('provinces', $provinces)
            ->with('districts', $districts)
            ->with('local_governments', $local_governments)
            ->with('energy_type', $energy_type_slug)
            ->with('energy_listing', $energy_listing)
            ->with('energy_year', $energy_year)
            ->with('is_central', $is_central)
            ->with('route', 'add');
    }


    public function entryFormEnergyFormNewImportProvincial(Request $request) {

        $user_level_id = Auth::user()->user_group_id;

        $user_level = UserGroup::find($user_level_id);

        $province_id = Auth::user()->province_id;

        $energy_type_slug = 'import';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $start = (!empty($request->get('year')))?$request->get('year'):0;
        $end = $start + 1;

        $central_id = 1;
//        $province_id = (!empty($request->get('province_id')))?$request->get('province_id'):null;
        $district_id = (!empty($request->get('district_id')))?$request->get('district_id'):null;
        $local_gov_id = (!empty($request->get('local_gov_id')))?$request->get('local_gov_id'):null;


        $is_central = (!empty($request->get('is_central')))?$request->get('is_central'):0;

//        if($is_central > 0){
//            $province_id = null;
//            $district_id = null;
//            $local_gov_id = null;
//        }

        $central = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'central')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'asc')
            ->first();

        if(Auth::user()->is_admin == 'Y'){
            $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'province')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'district')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'local-government')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();
        }else{

            $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location.id', $province_id)
                ->where('location_type.location_type_slug', 'province')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'district')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'local-government')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

        }

        $energy_year = EnergyYear::where('status', 'Y')->where('is_completed', 'N')->orderBy('energy_year_start','desc')->get();

        $energy_listing = Energy::join('energy_type_verses_energy_mapping AS etvem', 'etvem.energy_id', '=', 'energy.id')
                            ->join('fuel_type AS ft', 'ft.id', '=', 'energy.fuel_type_id')
                            ->select('energy.*', 'ft.fuel_type_name')
                            ->where('etvem.energy_type_id', $this_energy_type->id)
                            ->where('energy.status', '=', 'Y')
                            ->orderBy('ft.fuel_order', 'asc')
                            ->get();

        $data = array();

        if($province_id > 0) {

            if (!empty($energy_listing[0])) {
                foreach ($energy_listing as $the_energy) {
                    $arr = ImportEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'import_energy_form.id')
                        ->select('efm.*')
                        ->where('import_energy_form.energy_id', '=', $the_energy->id)
                        ->where('import_energy_form.province_id', '=', $province_id)
                        ->where('import_energy_form.district_id', '=', $district_id)
                        ->where('import_energy_form.local_gov_id', '=', $local_gov_id)
                        ->where('import_energy_form.from_date', '=', $start)
                        ->where('efm.energy_form_topic', '=', 'import')
                        ->where('efm.energy_topic', '=', 'overall')
                        ->first();

                    $data[$the_energy->id] = $arr;

                }
            }

        }else{

            if (!empty($energy_listing[0])) {
                foreach ($energy_listing as $the_energy) {
                    $arr = ImportEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'import_energy_form.id')
                        ->select('efm.*')
                        ->where('import_energy_form.energy_id', '=', $the_energy->id)
                        ->where('import_energy_form.central_id', '=', $central_id)
                        ->where('import_energy_form.from_date', '=', $start)
                        ->where('efm.energy_form_topic', '=', 'import')
                        ->where('efm.energy_topic', '=', 'overall')
                        ->first();

                    $data[$the_energy->id] = $arr;

                }
            }

        }

        $field_topics = EnergyTypeTopicMapping::where('energy_type_topic', $energy_type_slug)
            ->orderBy('energy_field_topic', 'asc')
            ->pluck('energy_field_topic')->toArray();

        $overall = new stdClass();
        $overall->natural_unit = '';

        $units = Unit::join('energy_conversion', 'energy_conversion.natural_unit', '=', 'unit.id')
            ->where('unit.status', 'Y')
            ->select('unit.*', 'energy_conversion.scientific_qty')
            ->groupBy('unit.id')
            ->get();

        return view('dashboard/energy_form_add_new_provincial')
            ->with('data', $data)
            ->with('this_energy_type', $this_energy_type)
            ->with('central', $central)
            ->with('overall', $overall)
            ->with('units', $units)
            ->with('field_topics', $field_topics)
            ->with('start', $start)
            ->with('end', $end)
            ->with('province_id', $province_id)
            ->with('district_id', $district_id)
            ->with('local_gov_id', $local_gov_id)
            ->with('provinces', $provinces)
            ->with('districts', $districts)
            ->with('local_governments', $local_governments)
            ->with('energy_type', $energy_type_slug)
            ->with('energy_listing', $energy_listing)
            ->with('energy_year', $energy_year)
            ->with('is_central', $is_central)
            ->with('route', 'add');
    }

    public function entryFormEnergyFormNewProduction(Request $request) {

        $user_level_id = Auth::user()->user_group_id;

        $user_level = UserGroup::find($user_level_id);

        $energy_type_slug = 'production';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $start = (!empty($request->get('year')))?$request->get('year'):date('Y');
        $end = $start + 1;

        $central_id = 1;
        $province_id = (!empty($request->get('province_id')))?$request->get('province_id'):null;
        $district_id = (!empty($request->get('district_id')))?$request->get('district_id'):null;
        $local_gov_id = (!empty($request->get('local_gov_id')))?$request->get('local_gov_id'):null;


        $is_central = (!empty($request->get('is_central')))?$request->get('is_central'):0;

        if($is_central > 0){
            $province_id = null;
            $district_id = null;
            $local_gov_id = null;
        }

        $central = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'central')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'asc')
            ->first();

        if(Auth::user()->is_admin == 'Y' || Auth::user()->is_central == '1'){
            $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'province')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'district')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'local-government')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();
        }else{

            $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->join('users', 'users.province_id', '=', 'location.id')
                ->where('users.id', Auth::user()->id)
                ->where('location_type.location_type_slug', 'province')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->join('users', 'users.district_id', '=', 'location.id')
                ->where('users.id', Auth::user()->id)
                ->where('location_type.location_type_slug', 'district')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->join('users', 'users.local_govt_id', '=', 'location.id')
                ->where('users.id', Auth::user()->id)
                ->where('location_type.location_type_slug', 'local-government')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

        }

        $energy_year = EnergyYear::where('status', 'Y')->where('is_completed', 'N')->orderBy('energy_year_start','desc')->get();

        $energy_listing = Energy::join('energy_type_verses_energy_mapping AS etvem', 'etvem.energy_id', '=', 'energy.id')
            ->join('fuel_type AS ft', 'ft.id', '=', 'energy.fuel_type_id')
            ->select('energy.*', 'ft.fuel_type_name')
            ->where('etvem.energy_type_id', $this_energy_type->id)
            ->where('energy.status', '=', 'Y')
            ->orderBy('ft.fuel_order', 'asc')
            ->get();

        $data = array();

        if($province_id > 0) {
            if (!empty($energy_listing[0])) {
                foreach ($energy_listing as $the_energy) {
                    $arr = ProductionEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'production_energy_form.id')
                        ->select('efm.*')
                        ->where('production_energy_form.energy_id', '=', $the_energy->id)
                        ->where('production_energy_form.province_id', '=', $province_id)
                        ->where('production_energy_form.district_id', '=', $district_id)
                        ->where('production_energy_form.local_gov_id', '=', $local_gov_id)
                        ->where('production_energy_form.from_date', '=', $start)
                        ->where('efm.energy_form_topic', '=', 'production')
                        ->where('efm.energy_topic', '=', 'overall')
                        ->first();

                    $data[$the_energy->id] = $arr;

                }
            }
        }else{

            if (!empty($energy_listing[0])) {
                foreach ($energy_listing as $the_energy) {
                    $arr = ProductionEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'production_energy_form.id')
                        ->select('efm.*')
                        ->where('production_energy_form.energy_id', '=', $the_energy->id)
                        ->where('production_energy_form.central_id', '=', $central_id)
                        ->where('production_energy_form.from_date', '=', $start)
                        ->where('efm.energy_form_topic', '=', 'production')
                        ->where('efm.energy_topic', '=', 'overall')
                        ->first();

                    $data[$the_energy->id] = $arr;

                }
            }

        }

        $field_topics = EnergyTypeTopicMapping::where('energy_type_topic', $energy_type_slug)
            ->orderBy('energy_field_topic', 'asc')
            ->pluck('energy_field_topic')->toArray();

        $overall = new stdClass();
        $overall->natural_unit = '';

        $units = Unit::join('energy_conversion', 'energy_conversion.natural_unit', '=', 'unit.id')
            ->where('unit.status', 'Y')
            ->select('unit.*', 'energy_conversion.scientific_qty')
            ->groupBy('unit.id')
            ->get();

        return view('dashboard/energy_form_add_new_production')
            ->with('data', $data)
            ->with('this_energy_type', $this_energy_type)
            ->with('central', $central)
            ->with('overall', $overall)
            ->with('units', $units)
            ->with('field_topics', $field_topics)
            ->with('start', $start)
            ->with('end', $end)
            ->with('province_id', $province_id)
            ->with('district_id', $district_id)
            ->with('local_gov_id', $local_gov_id)
            ->with('provinces', $provinces)
            ->with('districts', $districts)
            ->with('local_governments', $local_governments)
            ->with('energy_type', $energy_type_slug)
            ->with('energy_listing', $energy_listing)
            ->with('energy_year', $energy_year)
            ->with('user_level', $user_level)
            ->with('is_central', $is_central)
            ->with('route', 'add');
    }

    public function entryFormEnergyFormNewProductionProvincial(Request $request) {

        $user_level_id = Auth::user()->user_group_id;

        $province_id = Auth::user()->province_id;

        $user_level = UserGroup::find($user_level_id);

        $energy_type_slug = 'production';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $start = (!empty($request->get('year')))?$request->get('year'):0;
        $end = $start + 1;

        $central_id = 1;
//        $province_id = (!empty($request->get('province_id')))?$request->get('province_id'):null;
        $district_id = (!empty($request->get('district_id')))?$request->get('district_id'):null;
        $local_gov_id = (!empty($request->get('local_gov_id')))?$request->get('local_gov_id'):null;


        $is_central = (!empty($request->get('is_central')))?$request->get('is_central'):0;



        $central = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'central')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'asc')
            ->first();

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location.id', $province_id)
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug')
            ->get();

//        echo '<pre>';
//        echo $province_id;
//        print_r($provinces);
//        echo '</pre>';
//
//        exit();

        $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'district')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug')
            ->get();

        $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'local-government')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug')
            ->get();



        $energy_year = EnergyYear::where('status', 'Y')->where('is_completed', 'N')->orderBy('energy_year_start','desc')->get();

        $energy_listing = Energy::join('energy_type_verses_energy_mapping AS etvem', 'etvem.energy_id', '=', 'energy.id')
            ->join('fuel_type AS ft', 'ft.id', '=', 'energy.fuel_type_id')
            ->select('energy.*', 'ft.fuel_type_name')
            ->where('etvem.energy_type_id', $this_energy_type->id)
            ->where('energy.status', '=', 'Y')
            ->orderBy('ft.fuel_order', 'asc')
            ->get();

        $data = array();

        if($province_id > 0) {
            if (!empty($energy_listing[0])) {
                foreach ($energy_listing as $the_energy) {
                    $arr = ProductionEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'production_energy_form.id')
                        ->select('efm.*')
                        ->where('production_energy_form.energy_id', '=', $the_energy->id)
                        ->where('production_energy_form.province_id', '=', $province_id)
                        ->where('production_energy_form.district_id', '=', $district_id)
                        ->where('production_energy_form.local_gov_id', '=', $local_gov_id)
                        ->where('production_energy_form.from_date', '=', $start)
                        ->where('efm.energy_form_topic', '=', 'production')
                        ->where('efm.energy_topic', '=', 'overall')
                        ->first();

                    $data[$the_energy->id] = $arr;

                }
            }
        }

        $field_topics = EnergyTypeTopicMapping::where('energy_type_topic', $energy_type_slug)
            ->orderBy('energy_field_topic', 'asc')
            ->pluck('energy_field_topic')->toArray();

        $overall = new stdClass();
        $overall->natural_unit = '';

        $units = Unit::join('energy_conversion', 'energy_conversion.natural_unit', '=', 'unit.id')
            ->where('unit.status', 'Y')
            ->select('unit.*', 'energy_conversion.scientific_qty')
            ->groupBy('unit.id')
            ->get();

        return view('dashboard/energy_form_add_new_production_provincial')
            ->with('data', $data)
            ->with('this_energy_type', $this_energy_type)
            ->with('central', $central)
            ->with('overall', $overall)
            ->with('units', $units)
            ->with('field_topics', $field_topics)
            ->with('start', $start)
            ->with('end', $end)
            ->with('province_id', $province_id)
            ->with('district_id', $district_id)
            ->with('local_gov_id', $local_gov_id)
            ->with('provinces', $provinces)
            ->with('districts', $districts)
            ->with('local_governments', $local_governments)
            ->with('energy_type', $energy_type_slug)
            ->with('energy_listing', $energy_listing)
            ->with('energy_year', $energy_year)
            ->with('user_level', $user_level)
            ->with('is_central', $is_central)
            ->with('route', 'add');
    }


    public function entryFormEnergyFormNewDistrictwise(Request $request) {

        $user_level_id = Auth::user()->user_group_id;

        $province_id = Auth::user()->province_id;

        $user_level = UserGroup::find($user_level_id);

        $energy_type_slug = 'production';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $start = (!empty($request->get('year')))?$request->get('year'):0;
        $end = $start + 1;

        $central_id = 1;
//        $province_id = (!empty($request->get('province_id')))?$request->get('province_id'):null;
        $district_id = (!empty($request->get('district_id')))?$request->get('district_id'):null;
        $local_gov_id = (!empty($request->get('local_gov_id')))?$request->get('local_gov_id'):null;


        $is_central = (!empty($request->get('is_central')))?$request->get('is_central'):0;



        $central = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'central')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'asc')
            ->first();

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location.id', $province_id)
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug')
            ->get();

//        echo '<pre>';
//        echo $province_id;
//        print_r($provinces);
//        echo '</pre>';
//
//        exit();

        $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'district')
            ->where('location.status', 'Y')
            ->where('location.parent_id', $province_id)
            ->select('location.*')
            ->orderBy('location.location_slug')
            ->get();

        $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'local-government')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug')
            ->get();

        $energy_year = EnergyYear::where('status', 'Y')->where('is_completed', 'N')->orderBy('energy_year_start','desc')->get();

        $energy_listing = Energy::join('energy_type_verses_energy_mapping AS etvem', 'etvem.energy_id', '=', 'energy.id')
            ->join('fuel_type AS ft', 'ft.id', '=', 'energy.fuel_type_id')
            ->select('energy.*', 'ft.fuel_type_name')
            ->where('etvem.energy_type_id', $this_energy_type->id)
            ->where('energy.status', '=', 'Y')
            ->orderBy('ft.fuel_order', 'asc')
            ->get();

        $data = array();

        if($province_id > 0) {

            if (!empty($districts[0])) {
                foreach ($districts as $the_district) {
                    if (!empty($energy_listing[0])) {
                        foreach ($energy_listing as $the_energy) {

                            $arr = ProductionEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'production_energy_form.id')
                                ->select('efm.*')
                                ->where('production_energy_form.energy_id', '=', $the_energy->id)
                                ->where('production_energy_form.province_id', '=', $province_id)
                                ->where('production_energy_form.district_id', '=', $the_district->id)
                                ->where('production_energy_form.from_date', '=', $start)
                                ->where('efm.energy_form_topic', '=', 'production')
                                ->where('efm.energy_topic', '=', 'overall')
                                ->first();

//                            echo '<pre>';
////                            echo $province_id;
//                            print_r(json_decode($arr));
//                            echo '</pre>';

                            $data[$the_district->id][$the_energy->id]['natural_qty'] = (!empty($arr->natural_qty))?$arr->natural_qty:'';
                            $data[$the_district->id][$the_energy->id]['natural_unit'] = (!empty($arr->natural_unit))?$arr->natural_unit:'';

                        }
                    }

                }
            }
        }

//        echo '<hr />';
//
//        echo '<pre>';
////        echo $province_id;
//        print_r($data);
//        echo '</pre>';
//
//        exit();

        $field_topics = EnergyTypeTopicMapping::where('energy_type_topic', $energy_type_slug)
            ->orderBy('energy_field_topic', 'asc')
            ->pluck('energy_field_topic')->toArray();

        $overall = new stdClass();
        $overall->natural_unit = '';

        $units = Unit::join('energy_conversion', 'energy_conversion.natural_unit', '=', 'unit.id')
            ->where('unit.status', 'Y')
            ->select('unit.*', 'energy_conversion.scientific_qty')
            ->groupBy('unit.id')
            ->get();

        return view('dashboard/energy_form_add_new_format_districtwise')
            ->with('data', $data)
            ->with('this_energy_type', $this_energy_type)
            ->with('central', $central)
            ->with('overall', $overall)
            ->with('units', $units)
            ->with('field_topics', $field_topics)
            ->with('start', $start)
            ->with('end', $end)
            ->with('province_id', $province_id)
            ->with('district_id', $district_id)
            ->with('local_gov_id', $local_gov_id)
            ->with('provinces', $provinces)
            ->with('districts', $districts)
            ->with('local_governments', $local_governments)
            ->with('energy_type', $energy_type_slug)
            ->with('energy_listing', $energy_listing)
            ->with('energy_year', $energy_year)
            ->with('user_level', $user_level)
            ->with('is_central', $is_central)
            ->with('route', 'add');
    }


    public function entryFormEnergyFormNewDistrictwiseProduction(Request $request) {

        $user_level_id = Auth::user()->user_group_id;

        $province_id = Auth::user()->province_id;

        $user_level = UserGroup::find($user_level_id);

        $energy_type_slug = 'production';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $start = (!empty($request->get('year')))?$request->get('year'):0;
        $end = $start + 1;

        $central_id = 1;
//        $province_id = (!empty($request->get('province_id')))?$request->get('province_id'):null;
        $district_id = (!empty($request->get('district_id')))?$request->get('district_id'):null;
//        $local_gov_id = (!empty($request->get('local_gov_id')))?$request->get('local_gov_id'):null;


        $is_central = (!empty($request->get('is_central')))?$request->get('is_central'):0;



        $central = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'central')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'asc')
            ->first();

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location.id', $province_id)
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug')
            ->get();

//        echo '<pre>';
//        echo $province_id;
//        print_r($provinces);
//        echo '</pre>';
//
//        exit();

        $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'district')
            ->where('location.status', 'Y')
            ->where('location.parent_id', $province_id)
            ->select('location.*')
            ->orderBy('location.location_slug')
            ->get();

//        $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
//            ->where('location_type.location_type_slug', 'local-government')
//            ->where('location.status', 'Y')
//            ->select('location.*')
//            ->orderBy('location.location_slug')
//            ->get();

        $energy_year = EnergyYear::where('status', 'Y')->where('is_completed', 'N')->orderBy('energy_year_start','desc')->get();

        $energy_listing = Energy::join('energy_type_verses_energy_mapping AS etvem', 'etvem.energy_id', '=', 'energy.id')
            ->join('fuel_type AS ft', 'ft.id', '=', 'energy.fuel_type_id')
            ->select('energy.*', 'ft.fuel_type_name')
            ->where('etvem.energy_type_id', $this_energy_type->id)
            ->where('energy.status', '=', 'Y')
            ->orderBy('ft.fuel_order', 'asc')
            ->get();

        $data = array();

        $data_overall = array();

        if($province_id > 0) {

            if (!empty($districts[0])) {
                foreach ($districts as $the_district) {
                    if (!empty($energy_listing[0])) {
                        foreach ($energy_listing as $the_energy) {

                            $arr = ProductionEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'production_energy_form.id')
                                ->select('efm.*')
                                ->where('production_energy_form.energy_id', '=', $the_energy->id)
                                ->where('production_energy_form.province_id', '=', $province_id)
                                ->where('production_energy_form.district_id', '=', $the_district->id)
                                ->where('production_energy_form.from_date', '=', $start)
                                ->where('efm.energy_form_topic', '=', 'production')
                                ->where('efm.energy_topic', '=', 'overall')
                                ->first();

//                            echo '<pre>';
////                            echo $province_id;
//                            print_r(json_decode($arr));
//                            echo '</pre>';

                            $data[$the_district->id][$the_energy->id]['natural_qty'] = (!empty($arr->natural_qty))?$arr->natural_qty:'';
                            $data[$the_district->id][$the_energy->id]['natural_unit'] = (!empty($arr->natural_unit))?$arr->natural_unit:'';

                        }
                    }

                }
            }
            if (!empty($energy_listing[0])) {
                foreach ($energy_listing as $the_energy) {

                    $arr = ProductionEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'production_energy_form.id')
                        ->select('efm.*')
                        ->where('production_energy_form.energy_id', '=', $the_energy->id)
                        ->where('production_energy_form.province_id', '=', $province_id)
                        ->where('production_energy_form.district_id', '=', null)
                        ->where('production_energy_form.from_date', '=', $start)
                        ->where('efm.energy_form_topic', '=', 'production')
                        ->where('efm.energy_topic', '=', 'overall')
                        ->first();

//                            echo '<pre>';
////                            echo $province_id;
//                            print_r(json_decode($arr));
//                            echo '</pre>';

                    $data_overall[$the_energy->id]['natural_qty'] = (!empty($arr->natural_qty))?$arr->natural_qty:'';
                    $data_overall[$the_energy->id]['natural_unit'] = (!empty($arr->natural_unit))?$arr->natural_unit:'';

                }
            }
        }

//        echo '<hr />';
//
//        echo '<pre>';
////        echo $province_id;
//        print_r($data);
//        echo '</pre>';
//
//        exit();

        $field_topics = EnergyTypeTopicMapping::where('energy_type_topic', $energy_type_slug)
            ->orderBy('energy_field_topic', 'asc')
            ->pluck('energy_field_topic')->toArray();

        $units = Unit::join('energy_conversion', 'energy_conversion.natural_unit', '=', 'unit.id')
            ->where('unit.status', 'Y')
            ->select('unit.*', 'energy_conversion.scientific_qty')
            ->groupBy('unit.id')
            ->get();

        return view('dashboard/energy_form_add_new_format_districtwise')
            ->with('data', $data)
            ->with('this_energy_type', $this_energy_type)
            ->with('central', $central)
            ->with('data_overall', $data_overall)
            ->with('units', $units)
            ->with('field_topics', $field_topics)
            ->with('start', $start)
            ->with('end', $end)
            ->with('province_id', $province_id)
            ->with('district_id', $district_id)
            ->with('provinces', $provinces)
            ->with('districts', $districts)
            ->with('energy_type', $energy_type_slug)
            ->with('energy_listing', $energy_listing)
            ->with('energy_year', $energy_year)
            ->with('user_level', $user_level)
            ->with('is_central', $is_central)
            ->with('route', 'add');
    }

    public function entryFormEnergyFormNewDistrictwiseResources(Request $request) {

        $user_level_id = Auth::user()->user_group_id;

        $province_id = Auth::user()->province_id;

        $user_level = UserGroup::find($user_level_id);

        $energy_type_slug = 'resources';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $start = (!empty($request->get('year')))?$request->get('year'):0;
        $end = $start + 1;

        $central_id = 1;
//        $province_id = (!empty($request->get('province_id')))?$request->get('province_id'):null;
        $district_id = (!empty($request->get('district_id')))?$request->get('district_id'):null;
//        $local_gov_id = (!empty($request->get('local_gov_id')))?$request->get('local_gov_id'):null;


        $is_central = (!empty($request->get('is_central')))?$request->get('is_central'):0;



        $central = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'central')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'asc')
            ->first();

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location.id', $province_id)
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug')
            ->get();

//        echo '<pre>';
//        echo $province_id;
//        print_r($provinces);
//        echo '</pre>';
//
//        exit();

        $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'district')
            ->where('location.status', 'Y')
            ->where('location.parent_id', $province_id)
            ->select('location.*')
            ->orderBy('location.location_slug')
            ->get();

//        $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
//            ->where('location_type.location_type_slug', 'local-government')
//            ->where('location.status', 'Y')
//            ->select('location.*')
//            ->orderBy('location.location_slug')
//            ->get();

        $energy_year = EnergyYear::where('status', 'Y')->where('is_completed', 'N')->orderBy('energy_year_start','desc')->get();

        $energy_listing = Energy::join('energy_type_verses_energy_mapping AS etvem', 'etvem.energy_id', '=', 'energy.id')
            ->join('fuel_type AS ft', 'ft.id', '=', 'energy.fuel_type_id')
            ->select('energy.*', 'ft.fuel_type_name')
            ->where('etvem.energy_type_id', $this_energy_type->id)
            ->where('energy.status', '=', 'Y')
            ->orderBy('ft.fuel_order', 'asc')
            ->get();

        $data = array();

        $data_overall = array();

        if($province_id > 0) {

            if (!empty($districts[0])) {
                foreach ($districts as $the_district) {
                    if (!empty($energy_listing[0])) {
                        foreach ($energy_listing as $the_energy) {

                            $arr = ResourcesEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'resources_energy_form.id')
                                ->select('efm.*')
                                ->where('resources_energy_form.energy_id', '=', $the_energy->id)
                                ->where('resources_energy_form.province_id', '=', $province_id)
                                ->where('resources_energy_form.district_id', '=', $the_district->id)
                                ->where('resources_energy_form.from_date', '=', $start)
                                ->where('efm.energy_form_topic', '=', 'resources')
                                ->where('efm.energy_topic', '=', 'overall')
                                ->first();

                            $data[$the_district->id][$the_energy->id]['natural_qty'] = (!empty($arr->natural_qty))?$arr->natural_qty:'';
                            $data[$the_district->id][$the_energy->id]['natural_unit'] = (!empty($arr->natural_unit))?$arr->natural_unit:'';

                        }
                    }

                }
            }
        }

        if (!empty($energy_listing[0])) {
            foreach ($energy_listing as $the_energy) {

                $arr = ResourcesEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'resources_energy_form.id')
                    ->select('efm.*')
                    ->where('resources_energy_form.energy_id', '=', $the_energy->id)
                    ->where('resources_energy_form.province_id', '=', $province_id)
                    ->where('resources_energy_form.district_id', '=', null)
                    ->where('resources_energy_form.from_date', '=', $start)
                    ->where('efm.energy_form_topic', '=', 'resources')
                    ->where('efm.energy_topic', '=', 'overall')
                    ->first();

                $data_overall[$the_energy->id]['natural_qty'] = (!empty($arr->natural_qty))?$arr->natural_qty:'';
                $data_overall[$the_energy->id]['natural_unit'] = (!empty($arr->natural_unit))?$arr->natural_unit:'';

            }
        }

        $field_topics = EnergyTypeTopicMapping::where('energy_type_topic', $energy_type_slug)
            ->orderBy('energy_field_topic', 'asc')
            ->pluck('energy_field_topic')->toArray();

        $units = Unit::join('energy_conversion', 'energy_conversion.natural_unit', '=', 'unit.id')
            ->where('unit.status', 'Y')
            ->select('unit.*', 'energy_conversion.scientific_qty')
            ->groupBy('unit.id')
            ->get();

        return view('dashboard/energy_form_add_new_format_districtwise')
            ->with('data', $data)
            ->with('this_energy_type', $this_energy_type)
            ->with('central', $central)
            ->with('data_overall', $data_overall)
            ->with('units', $units)
            ->with('field_topics', $field_topics)
            ->with('start', $start)
            ->with('end', $end)
            ->with('province_id', $province_id)
            ->with('district_id', $district_id)
            ->with('provinces', $provinces)
            ->with('districts', $districts)
            ->with('energy_type', $energy_type_slug)
            ->with('energy_listing', $energy_listing)
            ->with('energy_year', $energy_year)
            ->with('user_level', $user_level)
            ->with('is_central', $is_central)
            ->with('route', 'add');
    }


    public function entryFormEnergyFormNewDistrictwiseImport(Request $request) {

        $user_level_id = Auth::user()->user_group_id;

        $province_id = Auth::user()->province_id;

        $user_level = UserGroup::find($user_level_id);

        $energy_type_slug = 'import';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $start = (!empty($request->get('year')))?$request->get('year'):0;
        $end = $start + 1;

        $central_id = 1;
//        $province_id = (!empty($request->get('province_id')))?$request->get('province_id'):null;
        $district_id = (!empty($request->get('district_id')))?$request->get('district_id'):null;
//        $local_gov_id = (!empty($request->get('local_gov_id')))?$request->get('local_gov_id'):null;


        $is_central = (!empty($request->get('is_central')))?$request->get('is_central'):0;



        $central = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'central')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'asc')
            ->first();

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location.id', $province_id)
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug')
            ->get();

//        echo '<pre>';
//        echo $province_id;
//        print_r($provinces);
//        echo '</pre>';
//
//        exit();

        $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'district')
            ->where('location.status', 'Y')
            ->where('location.parent_id', $province_id)
            ->select('location.*')
            ->orderBy('location.location_slug')
            ->get();

//        $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
//            ->where('location_type.location_type_slug', 'local-government')
//            ->where('location.status', 'Y')
//            ->select('location.*')
//            ->orderBy('location.location_slug')
//            ->get();

        $energy_year = EnergyYear::where('status', 'Y')->where('is_completed', 'N')->orderBy('energy_year_start','desc')->get();

        $energy_listing = Energy::join('energy_type_verses_energy_mapping AS etvem', 'etvem.energy_id', '=', 'energy.id')
            ->join('fuel_type AS ft', 'ft.id', '=', 'energy.fuel_type_id')
            ->select('energy.*', 'ft.fuel_type_name')
            ->where('etvem.energy_type_id', $this_energy_type->id)
            ->where('energy.status', '=', 'Y')
            ->orderBy('ft.fuel_order', 'asc')
            ->get();

        $data = array();

        $data_overall = array();

        if($province_id > 0) {

            if (!empty($districts[0])) {
                foreach ($districts as $the_district) {
                    if (!empty($energy_listing[0])) {
                        foreach ($energy_listing as $the_energy) {

                            $arr = ImportEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'import_energy_form.id')
                                ->select('efm.*')
                                ->where('import_energy_form.energy_id', '=', $the_energy->id)
                                ->where('import_energy_form.province_id', '=', $province_id)
                                ->where('import_energy_form.district_id', '=', $the_district->id)
                                ->where('import_energy_form.from_date', '=', $start)
                                ->where('efm.energy_form_topic', '=', 'import')
                                ->where('efm.energy_topic', '=', 'overall')
                                ->first();

//                            echo '<pre>';
////                            echo $province_id;
//                            print_r(json_decode($arr));
//                            echo '</pre>';

                            $data[$the_district->id][$the_energy->id]['natural_qty'] = (!empty($arr->natural_qty))?$arr->natural_qty:'';
                            $data[$the_district->id][$the_energy->id]['natural_unit'] = (!empty($arr->natural_unit))?$arr->natural_unit:'';

                        }
                    }

                }
            }
            if (!empty($energy_listing[0])) {
                foreach ($energy_listing as $the_energy) {

                    $arr = ImportEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'import_energy_form.id')
                        ->select('efm.*')
                        ->where('import_energy_form.energy_id', '=', $the_energy->id)
                        ->where('import_energy_form.province_id', '=', $province_id)
                        ->where('import_energy_form.district_id', '=', null)
                        ->where('import_energy_form.from_date', '=', $start)
                        ->where('efm.energy_form_topic', '=', 'import')
                        ->where('efm.energy_topic', '=', 'overall')
                        ->first();

//                            echo '<pre>';
////                            echo $province_id;
//                            print_r(json_decode($arr));
//                            echo '</pre>';

                    $data_overall[$the_energy->id]['natural_qty'] = (!empty($arr->natural_qty))?$arr->natural_qty:'';
                    $data_overall[$the_energy->id]['natural_unit'] = (!empty($arr->natural_unit))?$arr->natural_unit:'';

                }
            }
        }

        $field_topics = EnergyTypeTopicMapping::where('energy_type_topic', $energy_type_slug)
            ->orderBy('energy_field_topic', 'asc')
            ->pluck('energy_field_topic')->toArray();

        $overall = new stdClass();
        $overall->natural_unit = '';

        $units = Unit::join('energy_conversion', 'energy_conversion.natural_unit', '=', 'unit.id')
            ->where('unit.status', 'Y')
            ->select('unit.*', 'energy_conversion.scientific_qty')
            ->groupBy('unit.id')
            ->get();

        return view('dashboard/energy_form_add_new_format_districtwise')
            ->with('data', $data)
            ->with('this_energy_type', $this_energy_type)
            ->with('central', $central)
            ->with('data_overall', $data_overall)
            ->with('units', $units)
            ->with('field_topics', $field_topics)
            ->with('start', $start)
            ->with('end', $end)
            ->with('province_id', $province_id)
            ->with('district_id', $district_id)
            ->with('provinces', $provinces)
            ->with('districts', $districts)
            ->with('energy_type', $energy_type_slug)
            ->with('energy_listing', $energy_listing)
            ->with('energy_year', $energy_year)
            ->with('user_level', $user_level)
            ->with('is_central', $is_central)
            ->with('route', 'add');
    }


    public function entryFormEnergyFormNewDistrictwiseExport(Request $request) {

        $user_level_id = Auth::user()->user_group_id;

        $province_id = Auth::user()->province_id;

        $user_level = UserGroup::find($user_level_id);

        $energy_type_slug = 'export';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $start = (!empty($request->get('year')))?$request->get('year'):0;
        $end = $start + 1;

        $central_id = 1;
//        $province_id = (!empty($request->get('province_id')))?$request->get('province_id'):null;
        $district_id = (!empty($request->get('district_id')))?$request->get('district_id'):null;
//        $local_gov_id = (!empty($request->get('local_gov_id')))?$request->get('local_gov_id'):null;


        $is_central = (!empty($request->get('is_central')))?$request->get('is_central'):0;



        $central = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'central')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'asc')
            ->first();

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location.id', $province_id)
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug')
            ->get();

//        echo '<pre>';
//        echo $province_id;
//        print_r($provinces);
//        echo '</pre>';
//
//        exit();

        $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'district')
            ->where('location.status', 'Y')
            ->where('location.parent_id', $province_id)
            ->select('location.*')
            ->orderBy('location.location_slug')
            ->get();

//        $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
//            ->where('location_type.location_type_slug', 'local-government')
//            ->where('location.status', 'Y')
//            ->select('location.*')
//            ->orderBy('location.location_slug')
//            ->get();

        $energy_year = EnergyYear::where('status', 'Y')->where('is_completed', 'N')->orderBy('energy_year_start','desc')->get();

        $energy_listing = Energy::join('energy_type_verses_energy_mapping AS etvem', 'etvem.energy_id', '=', 'energy.id')
            ->join('fuel_type AS ft', 'ft.id', '=', 'energy.fuel_type_id')
            ->select('energy.*', 'ft.fuel_type_name')
            ->where('etvem.energy_type_id', $this_energy_type->id)
            ->where('energy.status', '=', 'Y')
            ->orderBy('ft.fuel_order', 'asc')
            ->get();

        $data = array();

        $data_overall = array();

        if($province_id > 0) {

            if (!empty($districts[0])) {
                foreach ($districts as $the_district) {
                    if (!empty($energy_listing[0])) {
                        foreach ($energy_listing as $the_energy) {

                            $arr = ExportEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'export_energy_form.id')
                                ->select('efm.*')
                                ->where('export_energy_form.energy_id', '=', $the_energy->id)
                                ->where('export_energy_form.province_id', '=', $province_id)
                                ->where('export_energy_form.district_id', '=', $the_district->id)
                                ->where('export_energy_form.from_date', '=', $start)
                                ->where('efm.energy_form_topic', '=', 'export')
                                ->where('efm.energy_topic', '=', 'overall')
                                ->first();

//                            echo '<pre>';
////                            echo $province_id;
//                            print_r(json_decode($arr));
//                            echo '</pre>';

                            $data[$the_district->id][$the_energy->id]['natural_qty'] = (!empty($arr->natural_qty))?$arr->natural_qty:'';
                            $data[$the_district->id][$the_energy->id]['natural_unit'] = (!empty($arr->natural_unit))?$arr->natural_unit:'';

                        }
                    }

                }
            }
            if (!empty($energy_listing[0])) {
                foreach ($energy_listing as $the_energy) {

                    $arr = ExportEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'export_energy_form.id')
                        ->select('efm.*')
                        ->where('export_energy_form.energy_id', '=', $the_energy->id)
                        ->where('export_energy_form.province_id', '=', $province_id)
                        ->where('export_energy_form.district_id', '=', null)
                        ->where('export_energy_form.from_date', '=', $start)
                        ->where('efm.energy_form_topic', '=', 'export')
                        ->where('efm.energy_topic', '=', 'overall')
                        ->first();

//                            echo '<pre>';
////                            echo $province_id;
//                            print_r(json_decode($arr));
//                            echo '</pre>';

                    $data_overall[$the_energy->id]['natural_qty'] = (!empty($arr->natural_qty))?$arr->natural_qty:'';
                    $data_overall[$the_energy->id]['natural_unit'] = (!empty($arr->natural_unit))?$arr->natural_unit:'';

                }
            }
        }

//        echo '<hr />';
//
//        echo '<pre>';
////        echo $province_id;
//        print_r($data);
//        echo '</pre>';
//
//        exit();

        $field_topics = EnergyTypeTopicMapping::where('energy_type_topic', $energy_type_slug)
            ->orderBy('energy_field_topic', 'asc')
            ->pluck('energy_field_topic')->toArray();

        $overall = new stdClass();
        $overall->natural_unit = '';

        $units = Unit::join('energy_conversion', 'energy_conversion.natural_unit', '=', 'unit.id')
            ->where('unit.status', 'Y')
            ->select('unit.*', 'energy_conversion.scientific_qty')
            ->groupBy('unit.id')
            ->get();

        return view('dashboard/energy_form_add_new_format_districtwise')
            ->with('data', $data)
            ->with('this_energy_type', $this_energy_type)
            ->with('central', $central)
            ->with('data_overall', $data_overall)
            ->with('units', $units)
            ->with('field_topics', $field_topics)
            ->with('start', $start)
            ->with('end', $end)
            ->with('province_id', $province_id)
            ->with('district_id', $district_id)
            ->with('provinces', $provinces)
            ->with('districts', $districts)
            ->with('energy_type', $energy_type_slug)
            ->with('energy_listing', $energy_listing)
            ->with('energy_year', $energy_year)
            ->with('user_level', $user_level)
            ->with('is_central', $is_central)
            ->with('route', 'add');
    }


    public function entryFormEnergyFormNewDistrictwiseConsumption(Request $request) {

//        return 1;

        $user_level_id = Auth::user()->user_group_id;

        $province_id = Auth::user()->province_id;

        $user_level = UserGroup::find($user_level_id);

        $energy_type_slug = 'consumption';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $sectors = Sector::where('status', 'Y')->orderBy('entry_order', 'ASC')->get();

        $this_sector = (!empty($request->get('sector')))?$request->get('sector'):'agricultural';

        $this_sector_obj = Sector::where('sector_slug', $this_sector)->first();

        $this_sector_id = 0;

        if(!empty($this_sector_obj->id)){
            $this_sector_id = $this_sector_obj->id;
        }else{
            $this_sector_id = Sector::where('sector_slug', 'agricultural')->pluck('id')->first();
        }

//        echo $this_sector_id;
//
//        exit();

        $start = (!empty($request->get('year')))?$request->get('year'):0;
        $end = $start + 1;

        $central_id = 1;
//        $province_id = (!empty($request->get('province_id')))?$request->get('province_id'):null;
        $district_id = (!empty($request->get('district_id')))?$request->get('district_id'):null;
//        $local_gov_id = (!empty($request->get('local_gov_id')))?$request->get('local_gov_id'):null;


        $is_central = (!empty($request->get('is_central')))?$request->get('is_central'):0;

        $central = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'central')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'asc')
            ->first();

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location.id', $province_id)
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug')
            ->get();

//        echo '<pre>';
//        echo $province_id;
//        print_r($provinces);
//        echo '</pre>';
//
//        exit();

        $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'district')
            ->where('location.status', 'Y')
            ->where('location.parent_id', $province_id)
            ->select('location.*')
            ->orderBy('location.location_slug')
            ->get();

//        $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
//            ->where('location_type.location_type_slug', 'local-government')
//            ->where('location.status', 'Y')
//            ->select('location.*')
//            ->orderBy('location.location_slug')
//            ->get();

        $energy_year = EnergyYear::where('status', 'Y')->where('is_completed', 'N')->orderBy('energy_year_start','desc')->get();

        $energy_listing = Energy::join('energy_type_verses_energy_mapping AS etvem', 'etvem.energy_id', '=', 'energy.id')
            ->join('fuel_type AS ft', 'ft.id', '=', 'energy.fuel_type_id')
            ->select('energy.*', 'ft.fuel_type_name')
            ->where('etvem.energy_type_id', $this_energy_type->id)
            ->where('energy.status', '=', 'Y')
            ->orderBy('ft.fuel_order', 'asc')
            ->get();

        $data = array();

        $data_overall = array();

        if($province_id > 0) {

            if (!empty($districts[0])) {
                foreach ($districts as $the_district) {
                    if (!empty($energy_listing[0])) {
                        foreach ($energy_listing as $the_energy) {

                            $arr = ConsumptionEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'consumption_energy_form.id')
                                ->select('efm.*')
                                ->where('consumption_energy_form.energy_id', '=', $the_energy->id)
                                ->where('consumption_energy_form.province_id', '=', $province_id)
                                ->where('consumption_energy_form.district_id', '=', $the_district->id)
                                ->where('consumption_energy_form.from_date', '=', $start)
                                ->where('consumption_energy_form.sector_id', '=', $this_sector_id)
                                ->where('efm.energy_form_topic', '=', 'consumption')
                                ->where('efm.energy_topic', '=', 'sector')
                                ->where('efm.energy_topic_id', '=', $this_sector_id)
                                ->first();

//                            echo '<pre>';
////                            echo $province_id;
//                            print_r(json_decode($arr));
//                            echo '</pre>';

                            $data[$the_district->id][$the_energy->id]['natural_qty'] = (!empty($arr->natural_qty))?$arr->natural_qty:'';
                            $data[$the_district->id][$the_energy->id]['natural_unit'] = (!empty($arr->natural_unit))?$arr->natural_unit:'';

                        }
                    }

                }
            }
        }

        if (!empty($energy_listing[0])) {
            foreach ($energy_listing as $the_energy) {

                $arr = ConsumptionEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'consumption_energy_form.id')
                    ->select('efm.*')
                    ->where('consumption_energy_form.energy_id', '=', $the_energy->id)
                    ->where('consumption_energy_form.province_id', '=', $province_id)
                    ->where('consumption_energy_form.district_id', '=', null)
                    ->where('consumption_energy_form.from_date', '=', $start)
                    ->where('consumption_energy_form.sector_id', '=', $this_sector_id)
                    ->where('efm.energy_form_topic', '=', 'consumption')
                    ->where('efm.energy_topic', '=', 'sector')
                    ->where('efm.energy_topic_id', '=', $this_sector_id)
                    ->first();

//                            echo '<pre>';
////                            echo $province_id;
//                            print_r(json_decode($arr));
//                            echo '</pre>';

                $data_overall[$the_energy->id]['natural_qty'] = (!empty($arr->natural_qty))?$arr->natural_qty:'';
                $data_overall[$the_energy->id]['natural_unit'] = (!empty($arr->natural_unit))?$arr->natural_unit:'';

            }
        }

//        echo '<hr />';
//
//        echo '<pre>';
////        echo $province_id;
//        print_r($data);
//        echo '</pre>';
//
//        exit();

        $field_topics = EnergyTypeTopicMapping::where('energy_type_topic', $energy_type_slug)
            ->orderBy('energy_field_topic', 'asc')
            ->pluck('energy_field_topic')->toArray();

        $units = Unit::join('energy_conversion', 'energy_conversion.natural_unit', '=', 'unit.id')
            ->where('unit.status', 'Y')
            ->select('unit.*', 'energy_conversion.scientific_qty')
            ->groupBy('unit.id')
            ->get();

        return view('dashboard/energy_form_add_new_format_districtwise_consumption')
            ->with('data', $data)
            ->with('this_energy_type', $this_energy_type)
            ->with('central', $central)
            ->with('data_overall', $data_overall)
            ->with('units', $units)
            ->with('field_topics', $field_topics)
            ->with('start', $start)
            ->with('end', $end)
            ->with('province_id', $province_id)
            ->with('district_id', $district_id)
            ->with('this_sector_id', $this_sector_id)
            ->with('sectors', $sectors)
            ->with('provinces', $provinces)
            ->with('districts', $districts)
            ->with('energy_type', $energy_type_slug)
            ->with('energy_listing', $energy_listing)
            ->with('energy_year', $energy_year)
            ->with('user_level', $user_level)
            ->with('is_central', $is_central)
            ->with('route', 'add');
    }

    public function entryFormEnergyReportNewProduction(Request $request) {

        $energy_type_slug = 'production';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $start = (!empty($request->get('year')))?$request->get('year'):date('Y');
        $end = $start + 1;

        $central_id = 1;
        $province_id = (!empty($request->get('province_id')))?$request->get('province_id'):null;
        $district_id = (!empty($request->get('district_id')))?$request->get('district_id'):null;
        $local_gov_id = (!empty($request->get('local_gov_id')))?$request->get('local_gov_id'):null;

        $output = (!empty($request->get('output')))?$request->get('output'):null;

        $central = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'central')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'asc')
            ->first();

        if(Auth::user()->is_admin == 'Y' || Auth::user()->is_central == '1'){
            $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'province')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'district')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'local-government')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();
        }else{

            $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->join('users', 'users.province_id', '=', 'location.id')
                ->where('users.id', Auth::user()->id)
                ->where('location_type.location_type_slug', 'province')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->join('users', 'users.district_id', '=', 'location.id')
                ->where('users.id', Auth::user()->id)
                ->where('location_type.location_type_slug', 'district')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->join('users', 'users.local_govt_id', '=', 'location.id')
                ->where('users.id', Auth::user()->id)
                ->where('location_type.location_type_slug', 'local-government')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

        }

        $energy_year = EnergyYear::where('status', 'Y')->where('is_completed', 'N')->orderBy('energy_year_start','desc')->get();

        $energy_listing = Energy::join('energy_type_verses_energy_mapping AS etvem', 'etvem.energy_id', '=', 'energy.id')
            ->join('fuel_type AS ft', 'ft.id', '=', 'energy.fuel_type_id')
            ->select('energy.*', 'ft.fuel_type_name')
            ->where('etvem.energy_type_id', $this_energy_type->id)
            ->where('energy.status', '=', 'Y')
            ->orderBy('ft.fuel_order', 'asc')
            ->get();

        $data = array();

        if (!empty($energy_listing[0])) {
            foreach ($energy_listing as $the_energy) {
                $arr = ProductionEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'production_energy_form.id')
                    ->select('efm.*')
                    ->where('production_energy_form.energy_id', '=', $the_energy->id)
                    ->where('production_energy_form.province_id', '=', $province_id)
                    ->where('production_energy_form.district_id', '=', $district_id)
                    ->where('production_energy_form.local_gov_id', '=', $local_gov_id)
                    ->where('efm.energy_form_topic', '=', 'production')
                    ->where('efm.energy_topic', '=', 'overall')
                    ->first();

                $data[$the_energy->id] = $arr;

            }
        }

        $final_result = array();

        if($output == 'fueltype'){

            $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
                ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
                ->where('et.energy_type_slug', '=', 'production')
                ->where('energy.status', '=', 'Y')
                ->select('energy.*')
                ->groupBy('energy.id')
                ->orderBy('energy.energy_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', 'overall')
                        ->where('energy_form_meta.energy_form_topic', '=', 'production')
                        ->where('energy_form_meta.energy_id', '=', $the_row->id)
                        ->where('production_energy_form.from_date', '=', $start)
                        ->where('production_energy_form.to_date', '=', $end)
                        ->where('production_energy_form.province_id', '=', $province_id)
                        ->where('production_energy_form.district_id', '=', null)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    if(!empty($objEnergyMetaForm->qty)){
                        $final_result[$the_row->energy_name] = $objEnergyMetaForm->qty;
                    }else{
                        $final_result[$the_row->energy_name] = 0;
                    }
                }
            }

//            exit();

            $province_name = '';
            $district_name = '';

            if($province_id > 0)
                $province_name = Location::find($province_id);

            if($district_id > 0)
                $district_name = Location::find($district_id);

            return view('dashboard/energy_report_new_production_bar')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('province_id', $province_id)
                ->with('district_id', $district_id)
                ->with('local_gov_id', $local_gov_id)
                ->with('provinces', $provinces)
                ->with('districts', $districts)
                ->with('local_governments', $local_governments)
                ->with('energy_topic', $rows)
                ->with('energy_type', $energy_type_slug)
                ->with('energy_year', $energy_year)
                ->with('col_send', $rows)
                ->with('province_name', $province_name)
                ->with('district_name', $district_name)
                ->with('final_result', $final_result);

        }elseif($output == 'districtwise'){


            $final_result = array();

            $col_keys = '';

//        $rows = Energy::join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
//            ->select('energy.*', 'fuel_type.fuel_type_name')
//            ->groupBy('energy.id')
//            ->orderBy('energy.energy_order', 'asc')
//            ->get();



            $col_keys = Location::join('location_type as lt', 'lt.id', '=', 'location.location_type_id')
                ->where('lt.location_type_slug', 'district')
                ->where('location.parent_id', $province_id)
                ->select('location.*')
                ->groupBy('location.id')
                ->orderBy('location.location_name', 'asc')
                ->get();

            $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
                ->select('energy.*', 'fuel_type.fuel_type_name')
                ->where('et.energy_type_slug', '=', 'production')
                ->where('energy.status', '=', 'Y')
                ->groupBy('energy.id')
                ->orderBy('energy.energy_order', 'asc')
                ->get();

            $col_send = array();

            if(!empty($col_keys)){
                foreach($col_keys as $this_col_key){
                    array_push($col_send, $this_col_key->location_name);
                }
            }

//            echo '<pre>';
//            print_r($col_send);
//            exit();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', 'overall')
                            ->where('energy_form_meta.energy_form_topic', '=', 'production')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('production_energy_form.from_date', '=', $start)
                            ->where('production_energy_form.to_date', '=', $end)
                            ->where('production_energy_form.district_id', '=', $the_col->id)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();

                        $inner_col[$counter] += (!empty($objEnergyMetaForm->qty))?(float)$objEnergyMetaForm->qty:0;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }

//            exit();

            $province_name = '';
            $district_name = '';

            if($province_id > 0)
                $province_name = Location::find($province_id);

            if($district_id > 0)
                $district_name = Location::find($district_id);

            return view('dashboard/energy_report_new_production_bar_districtwise2')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('province_id', $province_id)
                ->with('district_id', '')
                ->with('local_gov_id', $local_gov_id)
                ->with('provinces', $provinces)
                ->with('districts', $districts)
                ->with('local_governments', $local_governments)
                ->with('energy_topic', $rows)
                ->with('energy_type', $energy_type_slug)
                ->with('energy_year', $energy_year)
                ->with('col_send', $rows)
                ->with('col_send', $col_send)
                ->with('energy_type_slug', $energy_type_slug)
                ->with('energy_topic', 'Overall')
                ->with('province_name', $province_name)
                ->with('district_name', $district_name)
                ->with('final_result', $final_result);

        }else{
            $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
                ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
                ->where('et.energy_type_slug', '=', 'production')
                ->where('energy.status', '=', 'Y')
                ->select('energy.*')
                ->groupBy('energy.id')
                ->orderBy('energy.energy_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', 'overall')
                        ->where('energy_form_meta.energy_form_topic', '=', 'production')
                        ->where('energy_form_meta.energy_id', '=', $the_row->id)
                        ->where('production_energy_form.from_date', '=', $start)
                        ->where('production_energy_form.to_date', '=', $end)
                        ->where('production_energy_form.province_id', '=', $province_id)
                        ->where('production_energy_form.district_id', '=', null)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    if(!empty($objEnergyMetaForm->qty)){
                        $final_result[$the_row->energy_name] = $objEnergyMetaForm->qty;
                    }else{
                        $final_result[$the_row->energy_name] = 0;
                    }

//                    echo '<pre>';
//                    print_r(json_decode($objEnergyMetaForm));
                }
            }

//            exit();

            $province_name = '';
            $district_name = '';

            if($province_id > 0)
                $province_name = Location::find($province_id);

            if($district_id > 0)
                $district_name = Location::find($district_id);

            return view('dashboard/energy_report_new_production_pie')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('province_id', $province_id)
                ->with('district_id', $district_id)
                ->with('local_gov_id', $local_gov_id)
                ->with('provinces', $provinces)
                ->with('districts', $districts)
                ->with('local_governments', $local_governments)
                ->with('energy_topic', $rows)
                ->with('energy_type', $energy_type_slug)
                ->with('energy_year', $energy_year)
                ->with('province_name', $province_name)
                ->with('district_name', $district_name)
                ->with('final_result', $final_result);

        }

    }

    public function entryFormEnergyReportNewResources(Request $request) {

        $energy_type_slug = 'resources';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $start = (!empty($request->get('year')))?$request->get('year'):date('Y');
        $end = $start + 1;

        $province_id = (!empty($request->get('province_id')))?$request->get('province_id'):null;
        $district_id = (!empty($request->get('district_id')))?$request->get('district_id'):null;
        $local_gov_id = (!empty($request->get('local_gov_id')))?$request->get('local_gov_id'):null;

        $output = (!empty($request->get('output')))?$request->get('output'):null;

        $central = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'central')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'asc')
            ->first();

        if(Auth::user()->is_admin == 'Y' || Auth::user()->is_central == '1'){
            $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'province')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'district')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'local-government')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();
        }else{

            $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->join('users', 'users.province_id', '=', 'location.id')
                ->where('users.id', Auth::user()->id)
                ->where('location_type.location_type_slug', 'province')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->join('users', 'users.district_id', '=', 'location.id')
                ->where('users.id', Auth::user()->id)
                ->where('location_type.location_type_slug', 'district')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->join('users', 'users.local_govt_id', '=', 'location.id')
                ->where('users.id', Auth::user()->id)
                ->where('location_type.location_type_slug', 'local-government')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

        }

        $energy_year = EnergyYear::where('status', 'Y')->where('is_completed', 'N')->orderBy('energy_year_start','desc')->get();

        $energy_listing = Energy::join('energy_type_verses_energy_mapping AS etvem', 'etvem.energy_id', '=', 'energy.id')
            ->join('fuel_type AS ft', 'ft.id', '=', 'energy.fuel_type_id')
            ->select('energy.*', 'ft.fuel_type_name')
            ->where('etvem.energy_type_id', $this_energy_type->id)
            ->where('energy.status', '=', 'Y')
            ->orderBy('ft.fuel_order', 'asc')
            ->get();

        $data = array();

        if(!empty($energy_listing[0])){
            foreach($energy_listing as $the_energy){
                $arr = ResourcesEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'resources_energy_form.id')
                    ->select('efm.*')
                    ->where('resources_energy_form.energy_id', '=', $the_energy->id)
                    ->where('resources_energy_form.province_id', '=', $province_id)
                    ->where('resources_energy_form.district_id', '=', $district_id)
                    ->where('resources_energy_form.local_gov_id', '=', $local_gov_id)
                    ->where('efm.energy_form_topic', '=', 'resources')
                    ->where('efm.energy_topic', '=', 'overall')
                    ->first();

                $data[$the_energy->id] = $arr;

            }
        }

        $final_result = array();

        if($output == 'fueltype'){

            $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
                ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
                ->where('et.energy_type_slug', '=', 'resources')
                ->where('energy.status', '=', 'Y')
                ->select('energy.*')
                ->groupBy('energy.id')
                ->orderBy('energy.energy_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', 'overall')
                        ->where('energy_form_meta.energy_form_topic', '=', 'resources')
                        ->where('energy_form_meta.energy_id', '=', $the_row->id)
                        ->where('resources_energy_form.from_date', '=', $start)
                        ->where('resources_energy_form.to_date', '=', $end)
                        ->where('resources_energy_form.province_id', '=', $province_id)
                        ->where('resources_energy_form.district_id', '=', $district_id)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    if(!empty($objEnergyMetaForm->qty)){
                        $final_result[$the_row->energy_name] = $objEnergyMetaForm->qty;
                    }else{
                        $final_result[$the_row->energy_name] = 0;
                    }
                }
            }

            $province_name = '';
            $district_name = '';

            if($province_id > 0)
                $province_name = Location::find($province_id);

            if($district_id > 0)
                $district_name = Location::find($district_id);

//            exit();

            return view('dashboard/energy_report_new_production_bar')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('province_id', $province_id)
                ->with('district_id', $district_id)
                ->with('local_gov_id', $local_gov_id)
                ->with('provinces', $provinces)
                ->with('districts', $districts)
                ->with('local_governments', $local_governments)
                ->with('energy_topic', $rows)
                ->with('energy_type', $energy_type_slug)
                ->with('energy_year', $energy_year)
                ->with('col_send', $rows)
                ->with('province_name', $province_name)
                ->with('district_name', $district_name)
                ->with('final_result', $final_result);

        }elseif($output == 'districtwise'){


            $final_result = array();

            $col_keys = Location::join('location_type as lt', 'lt.id', '=', 'location.location_type_id')
                ->where('lt.location_type_slug', 'district')
                ->where('location.parent_id', $province_id)
                ->select('location.*')
                ->groupBy('location.id')
                ->orderBy('location.location_name', 'asc')
                ->get();

            $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
                ->select('energy.*', 'fuel_type.fuel_type_name')
                ->where('et.energy_type_slug', '=', 'resources')
                ->where('energy.status', '=', 'Y')
                ->groupBy('energy.id')
                ->orderBy('energy.energy_order', 'asc')
                ->get();

            $col_send = array();

            if(!empty($col_keys)){
                foreach($col_keys as $this_col_key){
                    array_push($col_send, $this_col_key->location_name);
                }
            }

//            echo '<pre>';
//            print_r($col_send);
//            exit();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', 'overall')
                            ->where('energy_form_meta.energy_form_topic', '=', 'resources')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('resources_energy_form.from_date', '=', $start)
                            ->where('resources_energy_form.to_date', '=', $end)
                            ->where('resources_energy_form.district_id', '=', $the_col->id)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();

                        $inner_col[$counter] += (!empty($objEnergyMetaForm->qty))?(float)$objEnergyMetaForm->qty:0;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }

            $province_name = '';
            $district_name = '';

            if($province_id > 0)
                $province_name = Location::find($province_id);

            if($district_id > 0)
                $district_name = Location::find($district_id);

//            exit();

            $province_name = '';
            $district_name = '';

            if($province_id > 0)
                $province_name = Location::find($province_id);

            if($district_id > 0)
                $district_name = Location::find($district_id);

            return view('dashboard/energy_report_new_production_bar_districtwise2')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('province_id', $province_id)
                ->with('district_id', '')
                ->with('local_gov_id', $local_gov_id)
                ->with('provinces', $provinces)
                ->with('districts', $districts)
                ->with('local_governments', $local_governments)
                ->with('energy_topic', $rows)
                ->with('energy_type', $energy_type_slug)
                ->with('energy_year', $energy_year)
                ->with('col_send', $rows)
                ->with('col_send', $col_send)
                ->with('energy_type_slug', $energy_type_slug)
                ->with('energy_topic', 'Overall')
                ->with('province_name', $province_name)
                ->with('district_name', $district_name)
                ->with('final_result', $final_result);

        }else{
            $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
                ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
                ->where('et.energy_type_slug', '=', 'resources')
                ->where('energy.status', '=', 'Y')
                ->select('energy.*')
                ->groupBy('energy.id')
                ->orderBy('energy.energy_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', 'overall')
                        ->where('energy_form_meta.energy_form_topic', '=', 'resources')
                        ->where('energy_form_meta.energy_id', '=', $the_row->id)
                        ->where('resources_energy_form.from_date', '=', $start)
                        ->where('resources_energy_form.to_date', '=', $end)
                        ->where('resources_energy_form.province_id', '=', $province_id)
                        ->where('resources_energy_form.district_id', '=', $district_id)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    if(!empty($objEnergyMetaForm->qty)){
                        $final_result[$the_row->energy_name] = $objEnergyMetaForm->qty;
                    }else{
                        $final_result[$the_row->energy_name] = 0;
                    }

//                    echo '<pre>';
//                    print_r(json_decode($objEnergyMetaForm));
                }
            }

//            exit();

            $province_name = '';
            $district_name = '';

            if($province_id > 0)
                $province_name = Location::find($province_id);

            if($district_id > 0)
                $district_name = Location::find($district_id);

            return view('dashboard/energy_report_new_production_pie')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('province_id', $province_id)
                ->with('district_id', $district_id)
                ->with('local_gov_id', $local_gov_id)
                ->with('provinces', $provinces)
                ->with('districts', $districts)
                ->with('local_governments', $local_governments)
                ->with('energy_topic', $rows)
                ->with('energy_type', $energy_type_slug)
                ->with('energy_year', $energy_year)
                ->with('province_name', $province_name)
                ->with('district_name', $district_name)
                ->with('final_result', $final_result);

        }

    }

    public function entryFormEnergyReportNewImport(Request $request) {

        $energy_type_slug = 'import';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $start = (!empty($request->get('year')))?$request->get('year'):date('Y');
        $end = $start + 1;

        $province_id = (!empty($request->get('province_id')))?$request->get('province_id'):null;
        $district_id = (!empty($request->get('district_id')))?$request->get('district_id'):null;
        $local_gov_id = (!empty($request->get('local_gov_id')))?$request->get('local_gov_id'):null;

        $output = (!empty($request->get('output')))?$request->get('output'):null;

        $central = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'central')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'asc')
            ->first();

        if(Auth::user()->is_admin == 'Y' || Auth::user()->is_central == '1'){
            $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'province')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'district')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'local-government')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();
        }else{

            $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->join('users', 'users.province_id', '=', 'location.id')
                ->where('users.id', Auth::user()->id)
                ->where('location_type.location_type_slug', 'province')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->join('users', 'users.district_id', '=', 'location.id')
                ->where('users.id', Auth::user()->id)
                ->where('location_type.location_type_slug', 'district')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->join('users', 'users.local_govt_id', '=', 'location.id')
                ->where('users.id', Auth::user()->id)
                ->where('location_type.location_type_slug', 'local-government')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

        }

        $energy_year = EnergyYear::where('status', 'Y')->where('is_completed', 'N')->orderBy('energy_year_start','desc')->get();

        $energy_listing = Energy::join('energy_type_verses_energy_mapping AS etvem', 'etvem.energy_id', '=', 'energy.id')
            ->join('fuel_type AS ft', 'ft.id', '=', 'energy.fuel_type_id')
            ->select('energy.*', 'ft.fuel_type_name')
            ->where('etvem.energy_type_id', $this_energy_type->id)
            ->where('energy.status', '=', 'Y')
            ->orderBy('ft.fuel_order', 'asc')
            ->get();

        $data = array();

        if(!empty($energy_listing[0])){
            foreach($energy_listing as $the_energy){
                $arr = ImportEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'import_energy_form.id')
                    ->select('efm.*')
                    ->where('import_energy_form.energy_id', '=', $the_energy->id)
                    ->where('import_energy_form.province_id', '=', $province_id)
                    ->where('import_energy_form.district_id', '=', $district_id)
                    ->where('import_energy_form.local_gov_id', '=', $local_gov_id)
                    ->where('efm.energy_form_topic', '=', 'import')
                    ->where('efm.energy_topic', '=', 'overall')
                    ->first();

                $data[$the_energy->id] = $arr;

            }
        }

        $final_result = array();

        if($output == 'fueltype'){

            $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
                ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
                ->where('et.energy_type_slug', '=', 'import')
                ->where('energy.status', '=', 'Y')
                ->select('energy.*')
                ->groupBy('energy.id')
                ->orderBy('energy.energy_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', 'overall')
                        ->where('energy_form_meta.energy_form_topic', '=', 'import')
                        ->where('energy_form_meta.energy_id', '=', $the_row->id)
                        ->where('import_energy_form.from_date', '=', $start)
                        ->where('import_energy_form.to_date', '=', $end)
                        ->where('import_energy_form.province_id', '=', $province_id)
                        ->where('import_energy_form.district_id', '=', $district_id)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    if(!empty($objEnergyMetaForm->qty)){
                        $final_result[$the_row->energy_name] = $objEnergyMetaForm->qty;
                    }else{
                        $final_result[$the_row->energy_name] = 0;
                    }
                }
            }

//            exit();

            $province_name = '';
            $district_name = '';

            if($province_id > 0)
                $province_name = Location::find($province_id);

            if($district_id > 0)
                $district_name = Location::find($district_id);

            return view('dashboard/energy_report_new_production_bar')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('province_id', $province_id)
                ->with('district_id', $district_id)
                ->with('local_gov_id', $local_gov_id)
                ->with('provinces', $provinces)
                ->with('districts', $districts)
                ->with('local_governments', $local_governments)
                ->with('energy_topic', $rows)
                ->with('energy_type', $energy_type_slug)
                ->with('energy_year', $energy_year)
                ->with('col_send', $rows)
                ->with('province_name', $province_name)
                ->with('district_name', $district_name)
                ->with('final_result', $final_result);

        }elseif($output == 'districtwise'){


            $final_result = array();

            $col_keys = Location::join('location_type as lt', 'lt.id', '=', 'location.location_type_id')
                ->where('lt.location_type_slug', 'district')
                ->where('location.parent_id', $province_id)
                ->select('location.*')
                ->groupBy('location.id')
                ->orderBy('location.location_name', 'asc')
                ->get();

            $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
                ->select('energy.*', 'fuel_type.fuel_type_name')
                ->where('et.energy_type_slug', '=', 'import')
                ->where('energy.status', '=', 'Y')
                ->groupBy('energy.id')
                ->orderBy('energy.energy_order', 'asc')
                ->get();

            $col_send = array();

            if(!empty($col_keys)){
                foreach($col_keys as $this_col_key){
                    array_push($col_send, $this_col_key->location_name);
                }
            }

//            echo '<pre>';
//            print_r($col_send);
//            exit();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', 'overall')
                            ->where('energy_form_meta.energy_form_topic', '=', 'import')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('import_energy_form.from_date', '=', $start)
                            ->where('import_energy_form.to_date', '=', $end)
                            ->where('import_energy_form.district_id', '=', $the_col->id)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();

                        $inner_col[$counter] += (!empty($objEnergyMetaForm->qty))?(float)$objEnergyMetaForm->qty:0;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }

//            exit();

            $province_name = '';
            $district_name = '';

            if($province_id > 0)
                $province_name = Location::find($province_id);

            if($district_id > 0)
                $district_name = Location::find($district_id);

            return view('dashboard/energy_report_new_production_bar_districtwise2')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('province_id', $province_id)
                ->with('district_id', '')
                ->with('local_gov_id', $local_gov_id)
                ->with('provinces', $provinces)
                ->with('districts', $districts)
                ->with('local_governments', $local_governments)
                ->with('energy_topic', $rows)
                ->with('energy_type', $energy_type_slug)
                ->with('energy_year', $energy_year)
                ->with('col_send', $rows)
                ->with('col_send', $col_send)
                ->with('energy_type_slug', $energy_type_slug)
                ->with('energy_topic', 'Overall')
                ->with('province_name', $province_name)
                ->with('district_name', $district_name)
                ->with('final_result', $final_result);

        }else{
            $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
                ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
                ->where('et.energy_type_slug', '=', 'import')
                ->where('energy.status', '=', 'Y')
                ->select('energy.*')
                ->groupBy('energy.id')
                ->orderBy('energy.energy_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', 'overall')
                        ->where('energy_form_meta.energy_form_topic', '=', 'import')
                        ->where('energy_form_meta.energy_id', '=', $the_row->id)
                        ->where('import_energy_form.from_date', '=', $start)
                        ->where('import_energy_form.to_date', '=', $end)
                        ->where('import_energy_form.province_id', '=', $province_id)
                        ->where('import_energy_form.district_id', '=', $district_id)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    if(!empty($objEnergyMetaForm->qty)){
                        $final_result[$the_row->energy_name] = $objEnergyMetaForm->qty;
                    }else{
                        $final_result[$the_row->energy_name] = 0;
                    }

//                    echo '<pre>';
//                    print_r(json_decode($objEnergyMetaForm));
                }
            }

//            exit();

            $province_name = '';
            $district_name = '';

            if($province_id > 0)
                $province_name = Location::find($province_id);

            if($district_id > 0)
                $district_name = Location::find($district_id);

            return view('dashboard/energy_report_new_production_pie')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('province_id', $province_id)
                ->with('district_id', $district_id)
                ->with('local_gov_id', $local_gov_id)
                ->with('provinces', $provinces)
                ->with('districts', $districts)
                ->with('local_governments', $local_governments)
                ->with('energy_topic', $rows)
                ->with('energy_type', $energy_type_slug)
                ->with('energy_year', $energy_year)
                ->with('province_name', $province_name)
                ->with('district_name', $district_name)
                ->with('final_result', $final_result);

        }

    }


    public function entryFormEnergyReportNewExport(Request $request) {

        $energy_type_slug = 'export';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $start = (!empty($request->get('year')))?$request->get('year'):date('Y');
        $end = $start + 1;

        $province_id = (!empty($request->get('province_id')))?$request->get('province_id'):null;
        $district_id = (!empty($request->get('district_id')))?$request->get('district_id'):null;
        $local_gov_id = (!empty($request->get('local_gov_id')))?$request->get('local_gov_id'):null;

        $output = (!empty($request->get('output')))?$request->get('output'):null;

        $central = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'central')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'asc')
            ->first();

        if(Auth::user()->is_admin == 'Y' || Auth::user()->is_central == '1'){
            $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'province')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'district')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'local-government')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();
        }else{

            $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->join('users', 'users.province_id', '=', 'location.id')
                ->where('users.id', Auth::user()->id)
                ->where('location_type.location_type_slug', 'province')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->join('users', 'users.district_id', '=', 'location.id')
                ->where('users.id', Auth::user()->id)
                ->where('location_type.location_type_slug', 'district')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->join('users', 'users.local_govt_id', '=', 'location.id')
                ->where('users.id', Auth::user()->id)
                ->where('location_type.location_type_slug', 'local-government')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

        }

        $energy_year = EnergyYear::where('status', 'Y')->where('is_completed', 'N')->orderBy('energy_year_start','desc')->get();

        $energy_listing = Energy::join('energy_type_verses_energy_mapping AS etvem', 'etvem.energy_id', '=', 'energy.id')
            ->join('fuel_type AS ft', 'ft.id', '=', 'energy.fuel_type_id')
            ->select('energy.*', 'ft.fuel_type_name')
            ->where('etvem.energy_type_id', $this_energy_type->id)
            ->where('energy.status', '=', 'Y')
            ->orderBy('ft.fuel_order', 'asc')
            ->get();

        $data = array();

        if(!empty($energy_listing[0])){
            foreach($energy_listing as $the_energy){
                $arr = ExportEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'export_energy_form.id')
                    ->select('efm.*')
                    ->where('export_energy_form.energy_id', '=', $the_energy->id)
                    ->where('export_energy_form.province_id', '=', $province_id)
                    ->where('export_energy_form.district_id', '=', $district_id)
                    ->where('export_energy_form.local_gov_id', '=', $local_gov_id)
                    ->where('efm.energy_form_topic', '=', 'export')
                    ->where('efm.energy_topic', '=', 'overall')
                    ->first();

                $data[$the_energy->id] = $arr;

            }
        }

        $final_result = array();

        if($output == 'fueltype'){

            $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
                ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
                ->where('et.energy_type_slug', '=', 'export')
                ->where('energy.status', '=', 'Y')
                ->select('energy.*')
                ->groupBy('energy.id')
                ->orderBy('energy.energy_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', 'overall')
                        ->where('energy_form_meta.energy_form_topic', '=', 'export')
                        ->where('energy_form_meta.energy_id', '=', $the_row->id)
                        ->where('export_energy_form.from_date', '=', $start)
                        ->where('export_energy_form.to_date', '=', $end)
                        ->where('export_energy_form.province_id', '=', $province_id)
                        ->where('export_energy_form.district_id', '=', $district_id)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    if(!empty($objEnergyMetaForm->qty)){
                        $final_result[$the_row->energy_name] = $objEnergyMetaForm->qty;
                    }else{
                        $final_result[$the_row->energy_name] = 0;
                    }
                }
            }

//            exit();

            $province_name = '';
            $district_name = '';

            if($province_id > 0)
                $province_name = Location::find($province_id);

            if($district_id > 0)
                $district_name = Location::find($district_id);

            return view('dashboard/energy_report_new_production_bar')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('province_id', $province_id)
                ->with('district_id', $district_id)
                ->with('local_gov_id', $local_gov_id)
                ->with('provinces', $provinces)
                ->with('districts', $districts)
                ->with('local_governments', $local_governments)
                ->with('energy_topic', $rows)
                ->with('energy_type', $energy_type_slug)
                ->with('energy_year', $energy_year)
                ->with('col_send', $rows)
                ->with('province_name', $province_name)
                ->with('district_name', $district_name)
                ->with('final_result', $final_result);

        }elseif($output == 'districtwise'){


            $final_result = array();

            $col_keys = Location::join('location_type as lt', 'lt.id', '=', 'location.location_type_id')
                ->where('lt.location_type_slug', 'district')
                ->where('location.parent_id', $province_id)
                ->select('location.*')
                ->groupBy('location.id')
                ->orderBy('location.location_name', 'asc')
                ->get();

            $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
                ->select('energy.*', 'fuel_type.fuel_type_name')
                ->where('et.energy_type_slug', '=', 'export')
                ->where('energy.status', '=', 'Y')
                ->groupBy('energy.id')
                ->orderBy('energy.energy_order', 'asc')
                ->get();

            $col_send = array();

            if(!empty($col_keys)){
                foreach($col_keys as $this_col_key){
                    array_push($col_send, $this_col_key->location_name);
                }
            }

//            echo '<pre>';
//            print_r($col_send);
//            exit();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', 'overall')
                            ->where('energy_form_meta.energy_form_topic', '=', 'export')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('export_energy_form.from_date', '=', $start)
                            ->where('export_energy_form.to_date', '=', $end)
                            ->where('export_energy_form.district_id', '=', $the_col->id)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();

                        $inner_col[$counter] += (!empty($objEnergyMetaForm->qty))?(float)$objEnergyMetaForm->qty:0;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }

//            exit();

            $province_name = '';
            $district_name = '';

            if($province_id > 0)
                $province_name = Location::find($province_id);

            if($district_id > 0)
                $district_name = Location::find($district_id);

            return view('dashboard/energy_report_new_production_bar_districtwise2')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('province_id', $province_id)
                ->with('district_id', '')
                ->with('local_gov_id', $local_gov_id)
                ->with('provinces', $provinces)
                ->with('districts', $districts)
                ->with('local_governments', $local_governments)
                ->with('energy_topic', $rows)
                ->with('energy_type', $energy_type_slug)
                ->with('energy_year', $energy_year)
                ->with('col_send', $rows)
                ->with('col_send', $col_send)
                ->with('energy_type_slug', $energy_type_slug)
                ->with('energy_topic', 'Overall')
                ->with('province_name', $province_name)
                ->with('district_name', $district_name)
                ->with('final_result', $final_result);

        }else{
            $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
                ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
                ->where('et.energy_type_slug', '=', 'export')
                ->where('energy.status', '=', 'Y')
                ->select('energy.*')
                ->groupBy('energy.id')
                ->orderBy('energy.energy_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', 'overall')
                        ->where('energy_form_meta.energy_form_topic', '=', 'export')
                        ->where('energy_form_meta.energy_id', '=', $the_row->id)
                        ->where('export_energy_form.from_date', '=', $start)
                        ->where('export_energy_form.to_date', '=', $end)
                        ->where('export_energy_form.province_id', '=', $province_id)
                        ->where('export_energy_form.district_id', '=', $district_id)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    if(!empty($objEnergyMetaForm->qty)){
                        $final_result[$the_row->energy_name] = $objEnergyMetaForm->qty;
                    }else{
                        $final_result[$the_row->energy_name] = 0;
                    }

//                    echo '<pre>';
//                    print_r(json_decode($objEnergyMetaForm));
                }
            }

//            exit();

            $province_name = '';
            $district_name = '';

            if($province_id > 0)
                $province_name = Location::find($province_id);

            if($district_id > 0)
                $district_name = Location::find($district_id);

            return view('dashboard/energy_report_new_production_pie')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('province_id', $province_id)
                ->with('district_id', $district_id)
                ->with('local_gov_id', $local_gov_id)
                ->with('provinces', $provinces)
                ->with('districts', $districts)
                ->with('local_governments', $local_governments)
                ->with('energy_topic', $rows)
                ->with('energy_type', $energy_type_slug)
                ->with('energy_year', $energy_year)
                ->with('province_name', $province_name)
                ->with('district_name', $district_name)
                ->with('final_result', $final_result);

        }

    }

    public function entryFormEnergyReportNewConsumption(Request $request) {

        $energy_type_slug = 'consumption';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $start = (!empty($request->get('year')))?$request->get('year'):date('Y');
        $end = $start + 1;

        $province_id = (!empty($request->get('province_id')))?$request->get('province_id'):null;
        $district_id = (!empty($request->get('district_id')))?$request->get('district_id'):null;
        $local_gov_id = (!empty($request->get('local_gov_id')))?$request->get('local_gov_id'):null;

        $district_id = ($district_id != '')?$district_id:null;

        $output = (!empty($request->get('output')))?$request->get('output'):null;

        $central = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'central')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'asc')
            ->first();

        if(Auth::user()->is_admin == 'Y' || Auth::user()->is_central == '1'){
            $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'province')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'district')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'local-government')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();
        }else{

            $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->join('users', 'users.province_id', '=', 'location.id')
                ->where('users.id', Auth::user()->id)
                ->where('location_type.location_type_slug', 'province')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->join('users', 'users.district_id', '=', 'location.id')
                ->where('users.id', Auth::user()->id)
                ->where('location_type.location_type_slug', 'district')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->join('users', 'users.local_govt_id', '=', 'location.id')
                ->where('users.id', Auth::user()->id)
                ->where('location_type.location_type_slug', 'local-government')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

        }

        $energy_year = EnergyYear::where('status', 'Y')->where('is_completed', 'N')->orderBy('energy_year_start','desc')->get();

        $energy_listing = Energy::join('energy_type_verses_energy_mapping AS etvem', 'etvem.energy_id', '=', 'energy.id')
            ->join('fuel_type AS ft', 'ft.id', '=', 'energy.fuel_type_id')
            ->select('energy.*', 'ft.fuel_type_name')
            ->where('etvem.energy_type_id', $this_energy_type->id)
            ->where('energy.status', '=', 'Y')
            ->orderBy('ft.fuel_order', 'asc')
            ->get();

        $data = array();

        if(!empty($energy_listing[0])){
            foreach($energy_listing as $the_energy){
                $arr = ConsumptionEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'consumption_energy_form.id')
                    ->select('efm.*')
                    ->where('consumption_energy_form.energy_id', '=', $the_energy->id)
                    ->where('consumption_energy_form.province_id', '=', $province_id)
                    ->where('consumption_energy_form.district_id', '=', $district_id)
                    ->where('consumption_energy_form.local_gov_id', '=', $local_gov_id)
                    ->where('efm.energy_form_topic', '=', 'consumption')
                    ->where('efm.energy_topic', '=', 'overall')
                    ->first();

                $data[$the_energy->id] = $arr;

            }
        }

        $final_result = array();

        if($output == 'fueltype'){

            $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
                ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
                ->where('et.energy_type_slug', '=', 'consumption')
                ->where('energy.status', '=', 'Y')
                ->select('energy.*')
                ->groupBy('energy.id')
                ->orderBy('energy.energy_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_form_topic', '=', 'consumption')
                        ->where('energy_form_meta.energy_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->where('consumption_energy_form.province_id', '=', $province_id)
                        ->where('consumption_energy_form.district_id', '=', null)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    if(!empty($objEnergyMetaForm->qty)){
                        $final_result[$the_row->energy_name] = $objEnergyMetaForm->qty;
                    }else{
                        $final_result[$the_row->energy_name] = 0;
                    }
                }
            }

//            exit();

            $province_name = '';
            $district_name = '';

            if($province_id > 0)
                $province_name = Location::find($province_id);

            if($district_id > 0)
                $district_name = Location::find($district_id);

            return view('dashboard/energy_report_new_consumption_bar')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('province_id', $province_id)
                ->with('district_id', $district_id)
                ->with('local_gov_id', $local_gov_id)
                ->with('provinces', $provinces)
                ->with('districts', $districts)
                ->with('local_governments', $local_governments)
                ->with('energy_topic', $rows)
                ->with('energy_type', $energy_type_slug)
                ->with('energy_year', $energy_year)
                ->with('col_send', $rows)
                ->with('province_name', $province_name)
                ->with('district_name', $district_name)
                ->with('final_result', $final_result);

        }elseif($output == 'districtwise'){

            $final_result = array();

            $col_keys = Location::join('location_type as lt', 'lt.id', '=', 'location.location_type_id')
                ->where('lt.location_type_slug', 'district')
                ->where('location.parent_id', $province_id)
                ->select('location.*')
                ->groupBy('location.id')
                ->orderBy('location.location_name', 'asc')
                ->get();

            $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
                ->select('energy.*', 'fuel_type.fuel_type_name')
                ->where('et.energy_type_slug', '=', 'consumption')
                ->where('energy.status', '=', 'Y')
                ->groupBy('energy.id')
                ->orderBy('energy.energy_order', 'asc')
                ->get();

            $col_send = array();

            if(!empty($col_keys)){
                foreach($col_keys as $this_col_key){
                    array_push($col_send, $this_col_key->location_name);
                }
            }

//            echo '<pre>';
//            print_r($col_send);
//            exit();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_form_topic', '=', 'consumption')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->where('consumption_energy_form.province_id', '=', $province_id)
                            ->where('consumption_energy_form.district_id', '=', $the_col->id)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();

                        $inner_col[$counter] += (!empty($objEnergyMetaForm->qty))?(float)$objEnergyMetaForm->qty:0;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }

//            exit();

            $province_name = '';
            $district_name = '';

            if($province_id > 0)
                $province_name = Location::find($province_id);

            if($district_id > 0)
                $district_name = Location::find($district_id);

            return view('dashboard/energy_report_new_consumption_bar_districtwise2')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('province_id', $province_id)
                ->with('district_id', '')
                ->with('local_gov_id', $local_gov_id)
                ->with('provinces', $provinces)
                ->with('districts', $districts)
                ->with('local_governments', $local_governments)
                ->with('energy_topic', $rows)
                ->with('energy_type', $energy_type_slug)
                ->with('energy_year', $energy_year)
                ->with('col_send', $rows)
                ->with('col_send', $col_send)
                ->with('energy_type_slug', $energy_type_slug)
                ->with('energy_topic', 'Overall')
                ->with('province_name', $province_name)
                ->with('district_name', $district_name)
                ->with('final_result', $final_result);

        }elseif($output == 'sectorwise'){

            $final_result = array();

            $col_keys = Sector::where('status', 'Y')->orderBy('entry_order', 'ASC')->get();

//            $col_keys = Location::join('location_type as lt', 'lt.id', '=', 'location.location_type_id')
//                ->where('lt.location_type_slug', 'district')
//                ->where('location.parent_id', $province_id)
//                ->select('location.*')
//                ->groupBy('location.id')
//                ->orderBy('location.location_name', 'asc')
//                ->get();

            $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
                ->select('energy.*', 'fuel_type.fuel_type_name')
                ->where('et.energy_type_slug', '=', 'consumption')
                ->where('energy.status', '=', 'Y')
                ->groupBy('energy.id')
                ->orderBy('energy.energy_order', 'asc')
                ->get();

            $col_send = array();

            if(!empty($col_keys)){
                foreach($col_keys as $this_col_key){
                    array_push($col_send, $this_col_key->sector_name);
                }
            }

//            echo '<pre>';
//            print_r($col_send);
//            exit();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_form_topic', '=', 'consumption')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->where('consumption_energy_form.province_id', '=', $province_id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();

                        $inner_col[$counter] += (!empty($objEnergyMetaForm->qty))?(float)$objEnergyMetaForm->qty:0;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }

//            exit();

            $province_name = '';
            $district_name = '';

            if($province_id > 0)
                $province_name = Location::find($province_id);

            if($district_id > 0)
                $district_name = Location::find($district_id);

            return view('dashboard/energy_report_new_consumption_bar_sectorwise2')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('province_id', $province_id)
                ->with('district_id', '')
                ->with('local_gov_id', $local_gov_id)
                ->with('provinces', $provinces)
                ->with('districts', $districts)
                ->with('local_governments', $local_governments)
                ->with('energy_topic', $rows)
                ->with('energy_type', $energy_type_slug)
                ->with('energy_year', $energy_year)
                ->with('col_send', $rows)
                ->with('col_send', $col_send)
                ->with('energy_type_slug', $energy_type_slug)
                ->with('energy_topic', 'Overall')
                ->with('province_name', $province_name)
                ->with('district_name', $district_name)
                ->with('final_result', $final_result);

//            $final_result = array();
//
//            $col_keys = Sector::orderBy('entry_order', 'asc')->get();
//
//            $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
//                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
//                ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
//                ->select('energy.*', 'fuel_type.fuel_type_name')
//                ->where('et.energy_type_slug', '=', 'consumption')
//                ->where('energy.status', 'Y')
//                ->groupBy('energy.id')
//                ->orderBy('energy.energy_order', 'asc')
//                ->get();
//
//            $col_send = array();
//
//            if(!empty($col_keys)){
//                foreach($col_keys as $this_col_key){
//                    array_push($col_send, $this_col_key->sector_name);
//                }
//            }
//
////            echo '<pre>';
////            print_r($col_send);
////            exit();
//
//            if(!empty($rows)){
//                foreach($rows as $the_row){
//                    $inner_col = array();
//                    $counter = 0;
//                    foreach($col_keys as $the_col){
//                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
//                        $objEnergyMetaForm = EnergyFormMeta::join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
//                            ->where('energy_form_meta.energy_form_topic', '=', 'consumption_energy_form')
//                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
//                            ->where('export_energy_form.from_date', '=', $start)
//                            ->where('export_energy_form.to_date', '=', $end)
//                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
//                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
//                            ->first();
//
//                        $inner_col[$counter] += (!empty($objEnergyMetaForm->qty))?(float)$objEnergyMetaForm->qty:0;
//                        $counter++;
//                    }
//                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
//                }
//            }
//
////            exit();


        }elseif($output == 'overall_sectorwise'){

            $rows = Sector::where('status', 'Y')->orderBy('entry_order', 'ASC')->get();

//            $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
//                ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
//                ->where('et.energy_type_slug', '=', 'consumption')
//                ->select('energy.*')
//                ->groupBy('energy.id')
//                ->orderBy('energy.energy_order', 'asc')
//                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_form_topic', '=', 'consumption')
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->where('consumption_energy_form.province_id', '=', $province_id)
                        ->where('consumption_energy_form.district_id', '=', null)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    if(!empty($objEnergyMetaForm->qty)){
                        $final_result[$the_row->sector_name] = $objEnergyMetaForm->qty;
                    }else{
                        $final_result[$the_row->sector_name] = 0;
                    }

//                    echo '<pre>';
//                    print_r(json_decode($objEnergyMetaForm));
                }
            }

//            exit();

            $province_name = '';
            $district_name = '';

            if($province_id > 0)
                $province_name = Location::find($province_id);

            if($district_id > 0)
                $district_name = Location::find($district_id);

            return view('dashboard/energy_report_new_consumption_pie_sectorwise')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('province_id', $province_id)
                ->with('district_id', $district_id)
                ->with('local_gov_id', $local_gov_id)
                ->with('provinces', $provinces)
                ->with('districts', $districts)
                ->with('local_governments', $local_governments)
                ->with('energy_topic', $rows)
                ->with('energy_type', $energy_type_slug)
                ->with('energy_year', $energy_year)
                ->with('province_name', $province_name)
                ->with('district_name', $district_name)
                ->with('final_result', $final_result);

        }else{
            $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
                ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
                ->where('et.energy_type_slug', '=', 'consumption')
                ->where('energy.status', '=', 'Y')
                ->select('energy.*')
                ->groupBy('energy.id')
                ->orderBy('energy.energy_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
//                        ->where('energy_form_meta.energy_topic', '=', 'overall')
                        ->where('energy_form_meta.energy_form_topic', '=', 'consumption')
                        ->where('energy_form_meta.energy_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->where('consumption_energy_form.province_id', '=', $province_id)
                        ->where('consumption_energy_form.district_id', '=', $district_id)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    if(!empty($objEnergyMetaForm->qty)){
                        $final_result[$the_row->energy_name] = $objEnergyMetaForm->qty;
                    }else{
                        $final_result[$the_row->energy_name] = 0;
                    }

//                    echo '<pre>';
//                    print_r(json_decode($objEnergyMetaForm));
                }
            }

//            exit();

            $province_name = '';
            $district_name = '';

            if($province_id > 0)
                $province_name = Location::find($province_id);

            if($district_id > 0)
                $district_name = Location::find($district_id);

            return view('dashboard/energy_report_new_consumption_pie')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('province_id', $province_id)
                ->with('district_id', $district_id)
                ->with('local_gov_id', $local_gov_id)
                ->with('provinces', $provinces)
                ->with('districts', $districts)
                ->with('local_governments', $local_governments)
                ->with('energy_topic', $rows)
                ->with('energy_type', $energy_type_slug)
                ->with('energy_year', $energy_year)
                ->with('province_name', $province_name)
                ->with('district_name', $district_name)
                ->with('final_result', $final_result);

        }

    }

    public function entryFormEnergyFormNewResources(Request $request) {

        $user_level_id = Auth::user()->user_group_id;

        $user_level = UserGroup::find($user_level_id);

        $energy_type_slug = 'resources';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $start = (!empty($request->get('year')))?$request->get('year'):date('Y');
        $end = $start + 1;

        $central_id = 1;
        $province_id = (!empty($request->get('province_id')))?$request->get('province_id'):null;
        $district_id = (!empty($request->get('district_id')))?$request->get('district_id'):null;
        $local_gov_id = (!empty($request->get('local_gov_id')))?$request->get('local_gov_id'):null;


        $is_central = (!empty($request->get('is_central')))?$request->get('is_central'):0;

        if($is_central > 0){
            $province_id = null;
            $district_id = null;
            $local_gov_id = null;
        }

        $central = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'central')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'asc')
            ->first();

        if(Auth::user()->is_admin == 'Y' || Auth::user()->is_central == '1'){
            $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'province')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'district')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'local-government')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();
        }else{

            $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->join('users', 'users.province_id', '=', 'location.id')
                ->where('users.id', Auth::user()->id)
                ->where('location_type.location_type_slug', 'province')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->join('users', 'users.district_id', '=', 'location.id')
                ->where('users.id', Auth::user()->id)
                ->where('location_type.location_type_slug', 'district')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->join('users', 'users.local_govt_id', '=', 'location.id')
                ->where('users.id', Auth::user()->id)
                ->where('location_type.location_type_slug', 'local-government')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

        }

        $energy_year = EnergyYear::where('status', 'Y')->where('is_completed', 'N')->orderBy('energy_year_start','desc')->get();

        $energy_listing = Energy::join('energy_type_verses_energy_mapping AS etvem', 'etvem.energy_id', '=', 'energy.id')
            ->join('fuel_type AS ft', 'ft.id', '=', 'energy.fuel_type_id')
            ->select('energy.*', 'ft.fuel_type_name')
            ->where('etvem.energy_type_id', $this_energy_type->id)
            ->where('energy.status', '=', 'Y')
            ->orderBy('ft.fuel_order', 'asc')
            ->get();

        $data = array();

        if($province_id > 0) {
            if (!empty($energy_listing[0])) {
                foreach ($energy_listing as $the_energy) {
                    $arr = ResourcesEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'resources_energy_form.id')
                        ->select('efm.*')
                        ->where('resources_energy_form.energy_id', '=', $the_energy->id)
                        ->where('resources_energy_form.province_id', '=', $province_id)
                        ->where('resources_energy_form.district_id', '=', $district_id)
                        ->where('resources_energy_form.local_gov_id', '=', $local_gov_id)
                        ->where('resources_energy_form.from_date', '=', $start)
                        ->where('efm.energy_form_topic', '=', 'resources')
                        ->where('efm.energy_topic', '=', 'overall')
                        ->first();

                    $data[$the_energy->id] = $arr;

                }
            }
        }else{
            if (!empty($energy_listing[0])) {
                foreach ($energy_listing as $the_energy) {
                    $arr = ResourcesEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'resources_energy_form.id')
                        ->select('efm.*')
                        ->where('resources_energy_form.energy_id', '=', $the_energy->id)
                        ->where('resources_energy_form.central_id', '=', $central_id)
                        ->where('resources_energy_form.from_date', '=', $start)
                        ->where('efm.energy_form_topic', '=', 'resources')
                        ->where('efm.energy_topic', '=', 'overall')
                        ->first();

                    $data[$the_energy->id] = $arr;

                }
            }

        }

        $field_topics = EnergyTypeTopicMapping::where('energy_type_topic', $energy_type_slug)
            ->orderBy('energy_field_topic', 'asc')
            ->pluck('energy_field_topic')->toArray();

        $overall = new stdClass();
        $overall->natural_unit = '';

        $units = Unit::join('energy_conversion', 'energy_conversion.natural_unit', '=', 'unit.id')
            ->where('unit.status', 'Y')
            ->select('unit.*', 'energy_conversion.scientific_qty')
            ->groupBy('unit.id')
            ->get();

        return view('dashboard/energy_form_add_new_resources')
            ->with('data', $data)
            ->with('this_energy_type', $this_energy_type)
            ->with('central', $central)
            ->with('overall', $overall)
            ->with('units', $units)
            ->with('field_topics', $field_topics)
            ->with('start', $start)
            ->with('end', $end)
            ->with('province_id', $province_id)
            ->with('district_id', $district_id)
            ->with('local_gov_id', $local_gov_id)
            ->with('provinces', $provinces)
            ->with('districts', $districts)
            ->with('local_governments', $local_governments)
            ->with('energy_type', $energy_type_slug)
            ->with('energy_listing', $energy_listing)
            ->with('energy_year', $energy_year)
            ->with('user_level', $user_level)
            ->with('is_central', $is_central)
            ->with('route', 'add');
    }


    public function entryFormEnergyFormNewResourcesProvincial(Request $request) {

        $user_level_id = Auth::user()->user_group_id;

        $province_id = Auth::user()->province_id;

        $user_level = UserGroup::find($user_level_id);

        $energy_type_slug = 'resources';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $start = (!empty($request->get('year')))?$request->get('year'):0;
        $end = $start + 1;

        $central_id = 1;
//        $province_id = (!empty($request->get('province_id')))?$request->get('province_id'):null;
        $district_id = (!empty($request->get('district_id')))?$request->get('district_id'):null;
        $local_gov_id = (!empty($request->get('local_gov_id')))?$request->get('local_gov_id'):null;


        $is_central = (!empty($request->get('is_central')))?$request->get('is_central'):0;

//        if($is_central > 0){
//            $province_id = null;
//            $district_id = null;
//            $local_gov_id = null;
//        }

        $central = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'central')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'asc')
            ->first();

        if(Auth::user()->is_admin == 'Y'){
            $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'province')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'district')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'local-government')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();
        }else{

            $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location.id', $province_id)
                ->where('location_type.location_type_slug', 'province')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'district')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'local-government')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

        }

        $energy_year = EnergyYear::where('status', 'Y')->where('is_completed', 'N')->orderBy('energy_year_start','desc')->get();

        $energy_listing = Energy::join('energy_type_verses_energy_mapping AS etvem', 'etvem.energy_id', '=', 'energy.id')
            ->join('fuel_type AS ft', 'ft.id', '=', 'energy.fuel_type_id')
            ->select('energy.*', 'ft.fuel_type_name')
            ->where('etvem.energy_type_id', $this_energy_type->id)
            ->where('energy.status', '=', 'Y')
            ->orderBy('ft.fuel_order', 'asc')
            ->get();

        $data = array();

        if($province_id > 0) {
            if (!empty($energy_listing[0])) {
                foreach ($energy_listing as $the_energy) {
                    $arr = ResourcesEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'resources_energy_form.id')
                        ->select('efm.*')
                        ->where('resources_energy_form.energy_id', '=', $the_energy->id)
                        ->where('resources_energy_form.province_id', '=', $province_id)
                        ->where('resources_energy_form.district_id', '=', $district_id)
                        ->where('resources_energy_form.local_gov_id', '=', $local_gov_id)
                        ->where('resources_energy_form.from_date', '=', $start)
                        ->where('efm.energy_form_topic', '=', 'resources')
                        ->where('efm.energy_topic', '=', 'overall')
                        ->first();

                    $data[$the_energy->id] = $arr;

                }
            }
        }

        $field_topics = EnergyTypeTopicMapping::where('energy_type_topic', $energy_type_slug)
            ->orderBy('energy_field_topic', 'asc')
            ->pluck('energy_field_topic')->toArray();

        $overall = new stdClass();
        $overall->natural_unit = '';

        $units = Unit::join('energy_conversion', 'energy_conversion.natural_unit', '=', 'unit.id')
            ->where('unit.status', 'Y')
            ->select('unit.*', 'energy_conversion.scientific_qty')
            ->groupBy('unit.id')
            ->get();

        return view('dashboard/energy_form_add_new_resources_provincial')
            ->with('data', $data)
            ->with('this_energy_type', $this_energy_type)
            ->with('central', $central)
            ->with('overall', $overall)
            ->with('units', $units)
            ->with('field_topics', $field_topics)
            ->with('start', $start)
            ->with('end', $end)
            ->with('province_id', $province_id)
            ->with('district_id', $district_id)
            ->with('local_gov_id', $local_gov_id)
            ->with('provinces', $provinces)
            ->with('districts', $districts)
            ->with('local_governments', $local_governments)
            ->with('energy_type', $energy_type_slug)
            ->with('energy_listing', $energy_listing)
            ->with('energy_year', $energy_year)
            ->with('user_level', $user_level)
            ->with('is_central', $is_central)
            ->with('route', 'add');
    }

    public function entryFormEnergyFormNewConsumption(Request $request) {

        $user_level_id = Auth::user()->user_group_id;

        $user_level = UserGroup::find($user_level_id);

        $energy_type_slug = 'consumption';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $start = (!empty($request->get('year')))?$request->get('year'):date('Y');
        $end = $start + 1;

        $central_id = 1;
        $province_id = (!empty($request->get('province_id')))?$request->get('province_id'):null;
        $district_id = (!empty($request->get('district_id')))?$request->get('district_id'):null;
        $local_gov_id = (!empty($request->get('local_gov_id')))?$request->get('local_gov_id'):null;


        $is_central = (!empty($request->get('is_central')))?$request->get('is_central'):0;

        if($is_central > 0){
            $province_id = null;
            $district_id = null;
            $local_gov_id = null;
        }

        $central = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'central')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'asc')
            ->first();

        $sectors = Sector::where('status', 'Y')->orderBy('entry_order', 'ASC')->get();

        if(Auth::user()->is_admin == 'Y' || Auth::user()->is_central == '1'){

            $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'province')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'district')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'local-government')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

        }else{

            $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->join('users', 'users.province_id', '=', 'location.id')
                ->where('users.id', Auth::user()->id)
                ->where('location_type.location_type_slug', 'province')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->join('users', 'users.district_id', '=', 'location.id')
                ->where('users.id', Auth::user()->id)
                ->where('location_type.location_type_slug', 'district')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->join('users', 'users.local_govt_id', '=', 'location.id')
                ->where('users.id', Auth::user()->id)
                ->where('location_type.location_type_slug', 'local-government')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

        }

        $energy_year = EnergyYear::where('status', 'Y')->where('is_completed', 'N')->orderBy('energy_year_start','desc')->get();
        
        if($central_id > 0){
         
            $energy_listing = Energy::join('energy_type_verses_energy_mapping AS etvem', 'etvem.energy_id', '=', 'energy.id')
                ->join('fuel_type AS ft', 'ft.id', '=', 'energy.fuel_type_id')
                ->select('energy.*', 'ft.fuel_type_name')
                ->where('etvem.energy_type_id', $this_energy_type->id)
                ->where('energy.economic_survey_status', '=', 'Y')
                ->orderBy('ft.fuel_order', 'asc')
                ->get();
   
        }else{
            
            $energy_listing = Energy::join('energy_type_verses_energy_mapping AS etvem', 'etvem.energy_id', '=', 'energy.id')
                ->join('fuel_type AS ft', 'ft.id', '=', 'energy.fuel_type_id')
                ->select('energy.*', 'ft.fuel_type_name')
                ->where('etvem.energy_type_id', $this_energy_type->id)
                ->where('energy.status', '=', 'Y')
                ->orderBy('ft.fuel_order', 'asc')
                ->get();

        }
            
        $data = array();

        if($province_id > 0) {
            if (!empty($sectors[0])) {
                foreach ($sectors as $the_sector) {

                    $sub_data = array();

                    if (!empty($energy_listing[0])) {
                        foreach ($energy_listing as $the_energy) {
                            $arr = ConsumptionEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'consumption_energy_form.id')
                                ->select('efm.*')
                                ->where('consumption_energy_form.energy_id', '=', $the_energy->id)
                                ->where('consumption_energy_form.province_id', '=', $province_id)
                                ->where('consumption_energy_form.district_id', '=', $district_id)
                                ->where('consumption_energy_form.local_gov_id', '=', $local_gov_id)
                                ->where('efm.energy_form_topic', '=', 'consumption')
                                ->where('efm.energy_topic', '=', 'sector')
                                ->where('efm.energy_topic_id', '=', $the_sector->id)
                                ->where('consumption_energy_form.from_date', '=', $start)
                                ->first();

                            $sub_data[$the_energy->id] = $arr;

                        }
                    }

                    $data[$the_sector->sector_slug] = $sub_data;


                }
            }
        }else{

            if (!empty($sectors[0])) {
                foreach ($sectors as $the_sector) {

                    $sub_data = array();

                    if (!empty($energy_listing[0])) {
                        foreach ($energy_listing as $the_energy) {
                            $arr = ConsumptionEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'consumption_energy_form.id')
                                ->select('efm.*')
                                ->where('consumption_energy_form.energy_id', '=', $the_energy->id)
                                ->where('consumption_energy_form.central_id', '=', $central_id)
                                ->where('consumption_energy_form.province_id', '=', null)
                                ->where('consumption_energy_form.district_id', '=', null)
                                ->where('consumption_energy_form.local_gov_id', '=', null)
                                ->where('efm.energy_form_topic', '=', 'consumption')
                                ->where('efm.energy_topic', '=', 'sector')
                                ->where('efm.energy_topic_id', '=', $the_sector->id)
                                ->where('consumption_energy_form.from_date', '=', $start)
                                ->first();

                            $sub_data[$the_energy->id] = $arr;

                        }
                    }

                    $data[$the_sector->sector_slug] = $sub_data;


                }
            }

        }

//        echo '<pre>';
////        print_r($formdata);
//        echo '<hr />';
//        print_r($data);
//        echo '</pre>';
//        echo '<hr />';
//        exit();

        $field_topics = EnergyTypeTopicMapping::where('energy_type_topic', $energy_type_slug)
            ->orderBy('energy_field_topic', 'asc')
            ->pluck('energy_field_topic')->toArray();

        $overall = new stdClass();
        $overall->natural_unit = '';

        $units = Unit::join('energy_conversion', 'energy_conversion.natural_unit', '=', 'unit.id')
            ->where('unit.status', 'Y')
            ->select('unit.*', 'energy_conversion.scientific_qty')
            ->groupBy('unit.id')
            ->get();

        return view('dashboard/energy_form_add_new_consumption2')
            ->with('data', $data)
            ->with('this_energy_type', $this_energy_type)
            ->with('central', $central)
            ->with('overall', $overall)
            ->with('units', $units)
            ->with('field_topics', $field_topics)
            ->with('start', $start)
            ->with('end', $end)
            ->with('province_id', $province_id)
            ->with('district_id', $district_id)
            ->with('local_gov_id', $local_gov_id)
            ->with('provinces', $provinces)
            ->with('districts', $districts)
            ->with('local_governments', $local_governments)
            ->with('energy_type', $energy_type_slug)
            ->with('energy_listing', $energy_listing)
            ->with('energy_year', $energy_year)
            ->with('sectors', $sectors)
            ->with('user_level', $user_level)
            ->with('is_central', $is_central)
            ->with('route', 'add');
    }


    public function entryFormEnergyFormNewConsumptionProvincial(Request $request) {

        $user_level_id = Auth::user()->user_group_id;

        $province_id = Auth::user()->province_id;

        $user_level = UserGroup::find($user_level_id);

        $energy_type_slug = 'consumption';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $start = (!empty($request->get('year')))?$request->get('year'):0;
        $end = $start + 1;

        $central_id = 1;
//        $province_id = (!empty($request->get('province_id')))?$request->get('province_id'):null;
        $district_id = (!empty($request->get('district_id')))?$request->get('district_id'):null;
        $local_gov_id = (!empty($request->get('local_gov_id')))?$request->get('local_gov_id'):null;


        $is_central = (!empty($request->get('is_central')))?$request->get('is_central'):0;

        if($is_central > 0){
            $province_id = null;
            $district_id = null;
            $local_gov_id = null;
        }

        $central = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'central')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'asc')
            ->first();

        $sectors = Sector::where('status', 'Y')->orderBy('entry_order', 'ASC')->get();

        if(Auth::user()->is_admin == 'Y'){
            $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'province')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'district')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'local-government')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();
        }else{

            $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->join('users', 'users.province_id', '=', 'location.id')
                ->where('users.id', Auth::user()->id)
                ->where('location_type.location_type_slug', 'province')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'district')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'local-government')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

        }

        $energy_year = EnergyYear::where('status', 'Y')->where('is_completed', 'N')->orderBy('energy_year_start','desc')->get();

        $energy_listing = Energy::join('energy_type_verses_energy_mapping AS etvem', 'etvem.energy_id', '=', 'energy.id')
            ->join('fuel_type AS ft', 'ft.id', '=', 'energy.fuel_type_id')
            ->select('energy.*', 'ft.fuel_type_name')
            ->where('etvem.energy_type_id', $this_energy_type->id)
            ->where('energy.status', '=', 'Y')
            ->orderBy('ft.fuel_order', 'asc')
            ->get();

        $data = array();

        if($province_id > 0) {
            if (!empty($sectors[0])) {
                foreach ($sectors as $the_sector) {

                    $sub_data = array();

                    if (!empty($energy_listing[0])) {
                        foreach ($energy_listing as $the_energy) {
                            $arr = ConsumptionEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'consumption_energy_form.id')
                                ->select('efm.*')
                                ->where('consumption_energy_form.energy_id', '=', $the_energy->id)
                                ->where('consumption_energy_form.province_id', '=', $province_id)
                                ->where('consumption_energy_form.district_id', '=', $district_id)
                                ->where('consumption_energy_form.local_gov_id', '=', $local_gov_id)
                                ->where('efm.energy_form_topic', '=', 'consumption')
                                ->where('efm.energy_topic', '=', 'sector')
                                ->where('efm.energy_topic_id', '=', $the_sector->id)
                                ->where('consumption_energy_form.from_date', '=', $start)
                                ->first();

                            $sub_data[$the_energy->id] = $arr;

                        }
                    }

                    $data[$the_sector->sector_slug] = $sub_data;


                }
            }
        }else{

            if (!empty($sectors[0])) {
                foreach ($sectors as $the_sector) {

                    $sub_data = array();

                    if (!empty($energy_listing[0])) {
                        foreach ($energy_listing as $the_energy) {
                            $arr = ConsumptionEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'consumption_energy_form.id')
                                ->select('efm.*')
                                ->where('consumption_energy_form.energy_id', '=', $the_energy->id)
                                ->where('consumption_energy_form.central_id', '=', $central_id)
                                ->where('consumption_energy_form.province_id', '=', null)
                                ->where('consumption_energy_form.district_id', '=', null)
                                ->where('consumption_energy_form.local_gov_id', '=', null)
                                ->where('efm.energy_form_topic', '=', 'consumption')
                                ->where('efm.energy_topic', '=', 'sector')
                                ->where('efm.energy_topic_id', '=', $the_sector->id)
                                ->where('consumption_energy_form.from_date', '=', $start)
                                ->first();

                            $sub_data[$the_energy->id] = $arr;

                        }
                    }

                    $data[$the_sector->sector_slug] = $sub_data;


                }
            }

        }

//        echo '<pre>';
////        print_r($formdata);
//        echo '<hr />';
//        print_r($data);
//        echo '</pre>';
//        echo '<hr />';
//        exit();

        $field_topics = EnergyTypeTopicMapping::where('energy_type_topic', $energy_type_slug)
            ->orderBy('energy_field_topic', 'asc')
            ->pluck('energy_field_topic')->toArray();

        $overall = new stdClass();
        $overall->natural_unit = '';

        $units = Unit::join('energy_conversion', 'energy_conversion.natural_unit', '=', 'unit.id')
            ->where('unit.status', 'Y')
            ->select('unit.*', 'energy_conversion.scientific_qty')
            ->groupBy('unit.id')
            ->get();

        return view('dashboard/energy_form_add_new_consumption2_provincial')
            ->with('data', $data)
            ->with('this_energy_type', $this_energy_type)
            ->with('central', $central)
            ->with('overall', $overall)
            ->with('units', $units)
            ->with('field_topics', $field_topics)
            ->with('start', $start)
            ->with('end', $end)
            ->with('province_id', $province_id)
            ->with('district_id', $district_id)
            ->with('local_gov_id', $local_gov_id)
            ->with('provinces', $provinces)
            ->with('districts', $districts)
            ->with('local_governments', $local_governments)
            ->with('energy_type', $energy_type_slug)
            ->with('energy_listing', $energy_listing)
            ->with('energy_year', $energy_year)
            ->with('sectors', $sectors)
            ->with('user_level', $user_level)
            ->with('is_central', $is_central)
            ->with('route', 'add');
    }

    public function entryFormEnergyFormNewExport(Request $request) {

        $user_level_id = Auth::user()->user_group_id;

        $user_level = UserGroup::find($user_level_id);

        $energy_type_slug = 'export';

//        return 1;

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $start = (!empty($request->get('year')))?$request->get('year'):date('Y');
        $end = $start + 1;

        $central_id = 1;
        $province_id = (!empty($request->get('province_id')))?$request->get('province_id'):null;
        $district_id = (!empty($request->get('district_id')))?$request->get('district_id'):null;
        $local_gov_id = (!empty($request->get('local_gov_id')))?$request->get('local_gov_id'):null;


        $is_central = (!empty($request->get('is_central')))?$request->get('is_central'):0;

        if($is_central > 0){
            $province_id = null;
            $district_id = null;
            $local_gov_id = null;
        }

        $central = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'central')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'asc')
            ->first();

        if(Auth::user()->is_admin == 'Y' || Auth::user()->is_central == '1'){
            $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'province')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'district')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'local-government')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();
        }else{

            $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->join('users', 'users.province_id', '=', 'location.id')
                ->where('users.id', Auth::user()->id)
                ->where('location_type.location_type_slug', 'province')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->join('users', 'users.district_id', '=', 'location.id')
                ->where('users.id', Auth::user()->id)
                ->where('location_type.location_type_slug', 'district')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->join('users', 'users.local_govt_id', '=', 'location.id')
                ->where('users.id', Auth::user()->id)
                ->where('location_type.location_type_slug', 'local-government')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

        }

        $energy_year = EnergyYear::where('status', 'Y')->where('is_completed', 'N')->orderBy('energy_year_start','desc')->get();

        $energy_listing = Energy::join('energy_type_verses_energy_mapping AS etvem', 'etvem.energy_id', '=', 'energy.id')
            ->join('fuel_type AS ft', 'ft.id', '=', 'energy.fuel_type_id')
            ->select('energy.*', 'ft.fuel_type_name')
            ->where('etvem.energy_type_id', $this_energy_type->id)
            ->where('energy.status', '=', 'Y')
            ->orderBy('ft.fuel_order', 'asc')
            ->get();

        $data = array();

        if($province_id > 0) {
            if (!empty($energy_listing[0])) {
                foreach ($energy_listing as $the_energy) {
                    $arr = ExportEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'export_energy_form.id')
                        ->select('efm.*')
                        ->where('export_energy_form.energy_id', '=', $the_energy->id)
                        ->where('export_energy_form.province_id', '=', $province_id)
                        ->where('export_energy_form.district_id', '=', $district_id)
                        ->where('export_energy_form.local_gov_id', '=', $local_gov_id)
                        ->where('export_energy_form.from_date', '=', $start)
                        ->where('efm.energy_form_topic', '=', 'export')
                        ->where('efm.energy_topic', '=', 'overall')
                        ->first();

                    $data[$the_energy->id] = $arr;

                }
            }
        }else{
            if (!empty($energy_listing[0])) {
                foreach ($energy_listing as $the_energy) {
                    $arr = ExportEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'export_energy_form.id')
                        ->select('efm.*')
                        ->where('export_energy_form.energy_id', '=', $the_energy->id)
                        ->where('export_energy_form.central_id', '=', $central_id)
                        ->where('export_energy_form.from_date', '=', $start)
                        ->where('efm.energy_form_topic', '=', 'export')
                        ->where('efm.energy_topic', '=', 'overall')
                        ->first();

                    $data[$the_energy->id] = $arr;

                }
            }
        }

        $field_topics = EnergyTypeTopicMapping::where('energy_type_topic', $energy_type_slug)
            ->orderBy('energy_field_topic', 'asc')
            ->pluck('energy_field_topic')->toArray();

        $overall = new stdClass();
        $overall->natural_unit = '';

        $units = Unit::join('energy_conversion', 'energy_conversion.natural_unit', '=', 'unit.id')
            ->where('unit.status', 'Y')
            ->select('unit.*', 'energy_conversion.scientific_qty')
            ->groupBy('unit.id')
            ->get();

        return view('dashboard/energy_form_add_new')
            ->with('data', $data)
            ->with('this_energy_type', $this_energy_type)
            ->with('central', $central)
            ->with('overall', $overall)
            ->with('units', $units)
            ->with('field_topics', $field_topics)
            ->with('start', $start)
            ->with('end', $end)
            ->with('province_id', $province_id)
            ->with('district_id', $district_id)
            ->with('local_gov_id', $local_gov_id)
            ->with('provinces', $provinces)
            ->with('districts', $districts)
            ->with('local_governments', $local_governments)
            ->with('energy_type', $energy_type_slug)
            ->with('energy_listing', $energy_listing)
            ->with('energy_year', $energy_year)
            ->with('is_central', $is_central)
            ->with('route', 'add');
    }


    public function entryFormEnergyFormNewExportProvincial(Request $request) {

        $user_level_id = Auth::user()->user_group_id;

        $user_level = UserGroup::find($user_level_id);

        $province_id = Auth::user()->province_id;

        $energy_type_slug = 'export';

//        return 1;

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $start = (!empty($request->get('year')))?$request->get('year'):0;
        $end = $start + 1;

        $central_id = 1;
//        $province_id = (!empty($request->get('province_id')))?$request->get('province_id'):null;
        $district_id = (!empty($request->get('district_id')))?$request->get('district_id'):null;
        $local_gov_id = (!empty($request->get('local_gov_id')))?$request->get('local_gov_id'):null;


        $is_central = (!empty($request->get('is_central')))?$request->get('is_central'):0;

//        if($is_central > 0){
//            $province_id = null;
//            $district_id = null;
//            $local_gov_id = null;
//        }

        $central = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'central')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'asc')
            ->first();

        if(Auth::user()->is_admin == 'Y'){
            $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'province')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'district')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'local-government')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();
        }else{

            $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->join('users', 'users.province_id', '=', 'location.id')
                ->where('users.id', Auth::user()->id)
                ->where('location_type.location_type_slug', 'province')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'district')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

            $local_governments = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
                ->where('location_type.location_type_slug', 'local-government')
                ->where('location.status', 'Y')
                ->select('location.*')
                ->orderBy('location.location_slug')
                ->get();

        }

        $energy_year = EnergyYear::where('status', 'Y')->where('is_completed', 'N')->orderBy('energy_year_start','desc')->get();

        $energy_listing = Energy::join('energy_type_verses_energy_mapping AS etvem', 'etvem.energy_id', '=', 'energy.id')
            ->join('fuel_type AS ft', 'ft.id', '=', 'energy.fuel_type_id')
            ->select('energy.*', 'ft.fuel_type_name')
            ->where('etvem.energy_type_id', $this_energy_type->id)
            ->where('energy.status', '=', 'Y')
            ->orderBy('ft.fuel_order', 'asc')
            ->get();

        $data = array();

        if($province_id > 0) {
            if (!empty($energy_listing[0])) {
                foreach ($energy_listing as $the_energy) {
                    $arr = ExportEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'export_energy_form.id')
                        ->select('efm.*')
                        ->where('export_energy_form.energy_id', '=', $the_energy->id)
                        ->where('export_energy_form.province_id', '=', $province_id)
                        ->where('export_energy_form.district_id', '=', $district_id)
                        ->where('export_energy_form.local_gov_id', '=', $local_gov_id)
                        ->where('export_energy_form.from_date', '=', $start)
                        ->where('efm.energy_form_topic', '=', 'export')
                        ->where('efm.energy_topic', '=', 'overall')
                        ->first();

                    $data[$the_energy->id] = $arr;

                }
            }
        }else{
            if (!empty($energy_listing[0])) {
                foreach ($energy_listing as $the_energy) {
                    $arr = ExportEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'export_energy_form.id')
                        ->select('efm.*')
                        ->where('export_energy_form.energy_id', '=', $the_energy->id)
                        ->where('export_energy_form.central_id', '=', $central_id)
                        ->where('export_energy_form.from_date', '=', $start)
                        ->where('efm.energy_form_topic', '=', 'export')
                        ->where('efm.energy_topic', '=', 'overall')
                        ->first();

                    $data[$the_energy->id] = $arr;

                }
            }
        }

        $field_topics = EnergyTypeTopicMapping::where('energy_type_topic', $energy_type_slug)
            ->orderBy('energy_field_topic', 'asc')
            ->pluck('energy_field_topic')->toArray();

        $overall = new stdClass();
        $overall->natural_unit = '';

        $units = Unit::join('energy_conversion', 'energy_conversion.natural_unit', '=', 'unit.id')
            ->where('unit.status', 'Y')
            ->select('unit.*', 'energy_conversion.scientific_qty')
            ->groupBy('unit.id')
            ->get();

        return view('dashboard/energy_form_add_new_provincial')
            ->with('data', $data)
            ->with('this_energy_type', $this_energy_type)
            ->with('central', $central)
            ->with('overall', $overall)
            ->with('units', $units)
            ->with('field_topics', $field_topics)
            ->with('start', $start)
            ->with('end', $end)
            ->with('province_id', $province_id)
            ->with('district_id', $district_id)
            ->with('local_gov_id', $local_gov_id)
            ->with('provinces', $provinces)
            ->with('districts', $districts)
            ->with('local_governments', $local_governments)
            ->with('energy_type', $energy_type_slug)
            ->with('energy_listing', $energy_listing)
            ->with('energy_year', $energy_year)
            ->with('is_central', $is_central)
            ->with('route', 'add');
    }

    public function entryFormEnergyFormNewPost(Request $request){

        // return 1;

        $formdata = (!empty($request->formdata))?$request->formdata:array();
        $overall = (!empty($request->overall))?$request->overall:array();

        $from_date = (!empty($formdata['year']))?$formdata['from_date']:null;
        $to_date = (!empty($formdata['to_date']))?$formdata['to_date']:null;

        $province_id = (!empty($formdata['province_id']))?$formdata['province_id']:null;
        $district_id = (!empty($formdata['district_id']))?$formdata['district_id']:null;
        $local_gov_id = (!empty($formdata['local_gov_id']))?$formdata['local_gov_id']:null;

//        echo '<pre>';
//        print_r($formdata);
//        echo '<hr />';
//        print_r($overall);
//        exit();

        if(is_array($overall) && count($overall) > 0){
            foreach($overall as $the_overall) {
                if (!empty($the_overall['energy_id']) && $the_overall['energy_id'] != '') {

                    $objEntryForm = new ImportEnergyForm();
                    $objEntryForm->energy_id = $the_overall['energy_id'];
                    $objEntryForm->central_id = 1;

                    $objEntryForm->province_id = $province_id;
                    $objEntryForm->district_id = $district_id;
                    $objEntryForm->local_gov_id = $local_gov_id;
                    $objEntryForm->from_date = $from_date;
                    $objEntryForm->to_date = $to_date;
                    $objEntryForm->status = 'Y';

                    $user_level_id = Auth::user()->user_group_id;
                    $user_level = UserGroup::find($user_level_id);
                    $user_id = Auth::user()->id;

                    if(!empty($user_level->user_group_slug)){
                        if($user_level->user_group_slug == 'data-entry'){
                            $objEntryForm->entered_by = $user_id;
                        }elseif($user_level->user_group_slug == 'qa' || $user_level->user_group_slug == 'supervisor'){
                            $objEntryForm->qa_by = $user_id;
                            $objEntryForm->published_by = $user_id;
                        }

                    }else{
                        $objEntryForm->entered_by = $user_id;
                        $objEntryForm->qa_by = $user_id;
                        $objEntryForm->published_by = $user_id;
                    }

                    if ($objEntryForm->save()) {
                        $objEnergyFormMeta = new EnergyFormMeta();
                        $objEnergyFormMeta->energy_form_id = $objEntryForm->id;
                        $objEnergyFormMeta->energy_form_topic = 'import';
                        $objEnergyFormMeta->energy_id = $the_overall['energy_id'];
                        $objEnergyFormMeta->energy_topic = 'overall';
                        $objEnergyFormMeta->energy_topic_id = 0;
                        $objEnergyFormMeta->natural_qty = (!empty($the_overall['natural_qty'])) ? $the_overall['natural_qty'] : null;
                        $objEnergyFormMeta->natural_unit = (!empty($the_overall['natural_unit'])) ? $the_overall['natural_unit'] : null;
                        $objEnergyFormMeta->scientific_qty = (!empty($the_overall['scientific_qty'])) ? $the_overall['scientific_qty'] : null;
                        $objEnergyFormMeta->scientific_unit = (!empty($the_overall['scientific_unit'])) ? $the_overall['scientific_unit'] : null;
                        $objEnergyFormMeta->status = 'Y';
                        $objEnergyFormMeta->save();
                    }
                }
            }
        }

        $objLog = new LogTable();
        $log_details = array('Import Energy Form Entry');
        $data = array(
            'log_details'   => serialize($log_details),
            'menu_name'     => 'New Import Energy Form Entry',
            'created_by'    => Auth::user()->id
        );
        $objLog->insertIntoLogTable($data);

        return redirect('dashboard/entryform/import?year='.$from_date.'&province_id='.$province_id.'&district_id='.$district_id.'&local_gov_id='.$local_gov_id)->with('success', 'Production Energy Form Entry done successfully!');

    }

    public function entryFormEnergyFormNewImportPost(Request $request){

//         return 1;

        $formdata = (!empty($request->formdata))?$request->formdata:array();
        $overall = (!empty($request->overall))?$request->overall:array();

        $from_date = (!empty($formdata['from_date']))?$formdata['from_date']:null;
        $to_date = (!empty($formdata['to_date']))?$formdata['to_date']:null;
        $central_id = 1;
        $province_id = (!empty($formdata['province_id']))?$formdata['province_id']:null;
        $district_id = (!empty($formdata['district_id']))?$formdata['district_id']:null;
        $local_gov_id = (!empty($formdata['local_gov_id']))?$formdata['local_gov_id']:null;

//        echo '<pre>';
//        print_r($formdata);
//        echo '<hr />';
//        print_r($overall);
//        exit();

        if(is_array($overall) && count($overall) > 0){
            foreach($overall as $the_overall) {
                if (!empty($the_overall['energy_id']) && $the_overall['energy_id'] != '') {

                    $objCheckImportEnergyForm = ImportEnergyForm::where('energy_id', '=', $the_overall['energy_id'])
                        ->where('province_id', '=', $province_id)
                        ->where('district_id', '=', $district_id)
                        ->where('local_gov_id', '=', $local_gov_id)
                        ->where('from_date', '=', $from_date)
                        ->get();

                    if(!empty($objCheckImportEnergyForm[0])){
                        foreach($objCheckImportEnergyForm as $this_energyform){

                            ImportEnergyForm::find($this_energyform->id)->delete();
                            EnergyFormMeta::where('energy_form_id', $this_energyform->id)->where('energy_form_topic', 'import')->delete();

                        }
                    }

                    $objEntryForm = new ImportEnergyForm();
                    $objEntryForm->energy_id = $the_overall['energy_id'];
                    $objEntryForm->central_id = 1;
                    $objEntryForm->province_id = $province_id;
                    $objEntryForm->district_id = $district_id;
                    $objEntryForm->local_gov_id = $local_gov_id;
                    $objEntryForm->from_date = $from_date;
                    $objEntryForm->to_date = $to_date;
                    $objEntryForm->status = 'Y';

                    $user_level_id = Auth::user()->user_group_id;
                    $user_level = UserGroup::find($user_level_id);
                    $user_id = Auth::user()->id;

                    if(!empty($user_level->user_group_slug)){
                        if($user_level->user_group_slug == 'data-entry'){
                            $objEntryForm->entered_by = $user_id;
                        }elseif($user_level->user_group_slug == 'qa' || $user_level->user_group_slug == 'supervisor'){
                            $objEntryForm->qa_by = $user_id;
                            $objEntryForm->published_by = $user_id;
                        }

                    }else{
                        $objEntryForm->entered_by = $user_id;
                        $objEntryForm->qa_by = $user_id;
                        $objEntryForm->published_by = $user_id;
                    }

                    if ($objEntryForm->save()) {
                        $objEnergyFormMeta = new EnergyFormMeta();
                        $objEnergyFormMeta->energy_form_id = $objEntryForm->id;
                        $objEnergyFormMeta->energy_form_topic = 'import';
                        $objEnergyFormMeta->energy_id = $the_overall['energy_id'];
                        $objEnergyFormMeta->energy_topic = 'overall';
                        $objEnergyFormMeta->energy_topic_id = 0;
                        $objEnergyFormMeta->natural_qty = (!empty($the_overall['natural_qty'])) ? $the_overall['natural_qty'] : null;
                        $objEnergyFormMeta->natural_unit = (!empty($the_overall['natural_unit'])) ? $the_overall['natural_unit'] : null;
                        $objEnergyFormMeta->scientific_qty = (!empty($the_overall['scientific_qty'])) ? $the_overall['scientific_qty'] : null;
                        $objEnergyFormMeta->scientific_unit = (!empty($the_overall['scientific_unit'])) ? $the_overall['scientific_unit'] : null;
                        $objEnergyFormMeta->status = 'Y';
                        $objEnergyFormMeta->save();
                    }
                }
            }
        }

        $objLog = new LogTable();
        $log_details = array('Import Energy Form Entry');
        $data = array(
            'log_details'   => serialize($log_details),
            'menu_name'     => 'New Import Energy Form Entry',
            'created_by'    => Auth::user()->id
        );
        $objLog->insertIntoLogTable($data);

        $current_url_this = $request->url();

        return redirect($current_url_this.'?year='.$from_date.'&province_id='.$province_id.'&district_id='.$district_id.'&local_gov_id='.$local_gov_id)
            ->with('success', 'Import Energy Form Entry done successfully!');

    }


    public function entryFormEnergyFormNewExportPost(Request $request){

        // return 1;

        $formdata = (!empty($request->formdata))?$request->formdata:array();
        $overall = (!empty($request->overall))?$request->overall:array();

        $from_date = (!empty($formdata['from_date']))?$formdata['from_date']:null;
        $to_date = (!empty($formdata['to_date']))?$formdata['to_date']:null;
        $central_id = 1;
        $province_id = (!empty($formdata['province_id']))?$formdata['province_id']:null;
        $district_id = (!empty($formdata['district_id']))?$formdata['district_id']:null;
        $local_gov_id = (!empty($formdata['local_gov_id']))?$formdata['local_gov_id']:null;

//        echo '<pre>';
//        print_r($formdata);
//        echo '<hr />';
//        print_r($overall);
//        exit();

        if(is_array($overall) && count($overall) > 0){
            foreach($overall as $the_overall) {
                if (!empty($the_overall['energy_id']) && $the_overall['energy_id'] != '') {

                    $objCheckExportEnergyForm = ExportEnergyForm::where('energy_id', '=', $the_overall['energy_id'])
                        ->where('province_id', '=', $province_id)
                        ->where('district_id', '=', $district_id)
                        ->where('local_gov_id', '=', $local_gov_id)
                        ->where('from_date', '=', $from_date)
                        ->get();

                    if(!empty($objCheckExportEnergyForm[0])){
                        foreach($objCheckExportEnergyForm as $this_energyform){

                            ExportEnergyForm::find($this_energyform->id)->delete();
                            EnergyFormMeta::where('energy_form_id', $this_energyform->id)->where('energy_form_topic', 'export')->delete();

                        }
                    }

                    $objEntryForm = new ExportEnergyForm();
                    $objEntryForm->energy_id = $the_overall['energy_id'];
                    $objEntryForm->central_id = 1;
                    $objEntryForm->province_id = $province_id;
                    $objEntryForm->district_id = $district_id;
                    $objEntryForm->local_gov_id = $local_gov_id;
                    $objEntryForm->from_date = $from_date;
                    $objEntryForm->to_date = $to_date;
                    $objEntryForm->status = 'Y';

                    $user_level_id = Auth::user()->user_group_id;
                    $user_level = UserGroup::find($user_level_id);
                    $user_id = Auth::user()->id;

                    if(!empty($user_level->user_group_slug)){
                        if($user_level->user_group_slug == 'data-entry'){
                            $objEntryForm->entered_by = $user_id;
                        }elseif($user_level->user_group_slug == 'qa' || $user_level->user_group_slug == 'supervisor'){
                            $objEntryForm->qa_by = $user_id;
                            $objEntryForm->published_by = $user_id;
                        }

                    }else{
                        $objEntryForm->entered_by = $user_id;
                        $objEntryForm->qa_by = $user_id;
                        $objEntryForm->published_by = $user_id;
                    }

                    if ($objEntryForm->save()) {
                        $objEnergyFormMeta = new EnergyFormMeta();
                        $objEnergyFormMeta->energy_form_id = $objEntryForm->id;
                        $objEnergyFormMeta->energy_form_topic = 'export';
                        $objEnergyFormMeta->energy_id = $the_overall['energy_id'];
                        $objEnergyFormMeta->energy_topic = 'overall';
                        $objEnergyFormMeta->energy_topic_id = 0;
                        $objEnergyFormMeta->natural_qty = (!empty($the_overall['natural_qty'])) ? $the_overall['natural_qty'] : null;
                        $objEnergyFormMeta->natural_unit = (!empty($the_overall['natural_unit'])) ? $the_overall['natural_unit'] : null;
                        $objEnergyFormMeta->scientific_qty = (!empty($the_overall['scientific_qty'])) ? $the_overall['scientific_qty'] : null;
                        $objEnergyFormMeta->scientific_unit = (!empty($the_overall['scientific_unit'])) ? $the_overall['scientific_unit'] : null;
                        $objEnergyFormMeta->status = 'Y';
                        $objEnergyFormMeta->save();
                    }
                }
            }
        }

        $objLog = new LogTable();
        $log_details = array('Export Energy Form Entry');
        $data = array(
            'log_details'   => serialize($log_details),
            'menu_name'     => 'New Export Energy Form Entry',
            'created_by'    => Auth::user()->id
        );
        $objLog->insertIntoLogTable($data);

        $current_url_this = $request->url();

        return redirect($current_url_this.'?year='.$from_date.'&province_id='.$province_id.'&district_id='.$district_id.'&local_gov_id='.$local_gov_id)
            ->with('success', 'Export Energy Form Entry done successfully!');

    }

    public function entryFormEnergyFormNewProductionPost(Request $request){

        // return 1;

        $formdata = (!empty($request->formdata))?$request->formdata:array();
        $overall = (!empty($request->overall))?$request->overall:array();

        $from_date = (!empty($formdata['from_date']))?$formdata['from_date']:null;
        $to_date = (!empty($formdata['to_date']))?$formdata['to_date']:null;
        $central_id = 1;
        $province_id = (!empty($formdata['province_id']))?$formdata['province_id']:null;
        $district_id = (!empty($formdata['district_id']))?$formdata['district_id']:null;
        $local_gov_id = (!empty($formdata['local_gov_id']))?$formdata['local_gov_id']:null;

//        echo '<pre>';
//        print_r($formdata);
//        echo '<hr />';
//        print_r($overall);
//        exit();

        if(is_array($overall) && count($overall) > 0){
            foreach($overall as $the_overall) {
                if (!empty($the_overall['energy_id']) && $the_overall['energy_id'] != '') {

                    $objCheckProductionEnergyForm = ProductionEnergyForm::where('energy_id', '=', $the_overall['energy_id'])
                        ->where('province_id', '=', $province_id)
                        ->where('district_id', '=', $district_id)
                        ->where('local_gov_id', '=', $local_gov_id)
                        ->where('from_date', '=', $from_date)
                        ->get();

                    if(!empty($objCheckProductionEnergyForm[0])){
                        foreach($objCheckProductionEnergyForm as $this_energyform){

                            ProductionEnergyForm::find($this_energyform->id)->delete();
                            EnergyFormMeta::where('energy_form_id', $this_energyform->id)->where('energy_form_topic', 'production')->delete();

                        }
                    }

                    $objEntryForm = new ProductionEnergyForm();
                    $objEntryForm->energy_id = $the_overall['energy_id'];
                    $objEntryForm->central_id = 1;
                    $objEntryForm->province_id = $province_id;
                    $objEntryForm->district_id = $district_id;
                    $objEntryForm->local_gov_id = $local_gov_id;
                    $objEntryForm->from_date = $from_date;
                    $objEntryForm->to_date = $to_date;
                    $objEntryForm->status = 'Y';

                    $user_level_id = Auth::user()->user_group_id;
                    $user_level = UserGroup::find($user_level_id);
                    $user_id = Auth::user()->id;

                    if(!empty($user_level->user_group_slug)){
                        if($user_level->user_group_slug == 'data-entry'){
                            $objEntryForm->entered_by = $user_id;
                        }elseif($user_level->user_group_slug == 'qa' || $user_level->user_group_slug == 'supervisor'){
                            $objEntryForm->qa_by = $user_id;
                            $objEntryForm->published_by = $user_id;
                        }

                    }else{
                        $objEntryForm->entered_by = $user_id;
                        $objEntryForm->qa_by = $user_id;
                        $objEntryForm->published_by = $user_id;
                    }

                    if ($objEntryForm->save()) {
                        $objEnergyFormMeta = new EnergyFormMeta();
                        $objEnergyFormMeta->energy_form_id = $objEntryForm->id;
                        $objEnergyFormMeta->energy_form_topic = 'production';
                        $objEnergyFormMeta->energy_id = $the_overall['energy_id'];
                        $objEnergyFormMeta->energy_topic = 'overall';
                        $objEnergyFormMeta->energy_topic_id = 0;
                        $objEnergyFormMeta->natural_qty = (!empty($the_overall['natural_qty'])) ? $the_overall['natural_qty'] : null;
                        $objEnergyFormMeta->natural_unit = (!empty($the_overall['natural_unit'])) ? $the_overall['natural_unit'] : null;
                        $objEnergyFormMeta->scientific_qty = (!empty($the_overall['scientific_qty'])) ? $the_overall['scientific_qty'] : null;

                        $objEnergyFormMeta->forest_area_in_ha = (!empty($the_overall['forest_area_in_ha'])) ? $the_overall['forest_area_in_ha'] : null;
                        $objEnergyFormMeta->total_residue_in_no = (!empty($the_overall['total_residue_in_no'])) ? $the_overall['total_residue_in_no'] : null;
                        $objEnergyFormMeta->livestock_in_no = (!empty($the_overall['livestock_in_no'])) ? $the_overall['livestock_in_no'] : null;
                        $objEnergyFormMeta->size_of_plant_in_cubic_meter = (!empty($the_overall['size_of_plant_in_cubic_meter'])) ? $the_overall['size_of_plant_in_cubic_meter'] : null;
                        $objEnergyFormMeta->total_plant_size_in_mega_watt = (!empty($the_overall['total_plant_size_in_mega_watt'])) ? $the_overall['total_plant_size_in_mega_watt'] : null;
                        $objEnergyFormMeta->particular_no = (!empty($the_overall['particular_no'])) ? $the_overall['particular_no'] : null;


                        $objEnergyFormMeta->status = 'Y';
                        $objEnergyFormMeta->save();
                    }
                }
            }
        }

        $objLog = new LogTable();
        $log_details = array('Production Energy Form Entry');
        $data = array(
            'log_details'   => serialize($log_details),
            'menu_name'     => 'New Production Energy Form Entry',
            'created_by'    => Auth::user()->id
        );
        $objLog->insertIntoLogTable($data);

        $current_url_this = $request->url();

        return redirect($current_url_this.'?year='.$from_date.'&province_id='.$province_id.'&district_id='.$district_id.'&local_gov_id='.$local_gov_id)
            ->with('success', 'Production Energy Form Entry done successfully!');

//        return redirect('dashboard/entryform/production?year='.$from_date.'&province_id='.$province_id.'&district_id='.$district_id.'&local_gov_id='.$local_gov_id)
//            ->with('success', 'Production Energy Form Entry done successfully!');

    }


    public function entryFormEnergyFormNewDistrictwisePost(Request $request){

        // return 1;

        $formdata = (!empty($request->formdata))?$request->formdata:array();
        $districtwise = (!empty($request->districtwise))?$request->districtwise:array();
        $scientific_unit_conversion_standard = (!empty($request->scientific_unit_conversion_standard))?$request->scientific_unit_conversion_standard:array();

        $from_date = (!empty($formdata['from_date']))?$formdata['from_date']:null;
        $to_date = (!empty($formdata['to_date']))?$formdata['to_date']:null;
        $central_id = 1;
        $province_id = (!empty($formdata['province_id']))?$formdata['province_id']:null;


//        echo '<pre>';
//        print_r($formdata);
//        echo '<hr />';
//        print_r($districtwise);
//        echo '<hr />';
//        print_r($overall);
//        echo $province_id;
//        exit();

        if(is_array($districtwise) && count($districtwise) > 0){
            foreach($districtwise as $district_id=>$energy_arr) {

//                echo '<pre>';
//                echo $district_id;

                if (!empty($district_id) && $district_id != '') {
                    foreach($energy_arr as $energy_id=>$the_overall) {

//        print_r($the_overall);
//        echo '<hr />';
//        print_r($scientific_unit_conversion_standard);
//                        echo '<hr />';
//        print_r($v);
//                        echo $energy_id;
//                        echo '<hr />';
//        print_r($v);
//                        echo $district_id;
//                        echo '<hr />';

                        $objCheckProductionEnergyForm = ProductionEnergyForm::where('energy_id', '=', $energy_id)
                            ->where('province_id', '=', $province_id)
                            ->where('district_id', '=', $district_id)
                            ->where('from_date', '=', $from_date)
                            ->get();

                        if(!empty($objCheckProductionEnergyForm[0])){
                            foreach($objCheckProductionEnergyForm as $this_energyform){
                                ProductionEnergyForm::find($this_energyform->id)->delete();
                                EnergyFormMeta::where('energy_form_id', $this_energyform->id)->where('energy_form_topic', 'production')->delete();

                            }
                        }

                        if((!empty($the_overall['natural_qty']))){

                            $objEntryForm = new ProductionEnergyForm();
                            $objEntryForm->energy_id = $energy_id;
                            $objEntryForm->central_id = 1;
                            $objEntryForm->province_id = $province_id;
                            $objEntryForm->district_id = $district_id;
                            $objEntryForm->from_date = $from_date;
                            $objEntryForm->to_date = $to_date;
                            $objEntryForm->status = 'Y';

                            $user_level_id = Auth::user()->user_group_id;
                            $user_level = UserGroup::find($user_level_id);
                            $user_id = Auth::user()->id;

                            if(!empty($user_level->user_group_slug)){
                                if($user_level->user_group_slug == 'data-entry'){
                                    $objEntryForm->entered_by = $user_id;
                                }elseif($user_level->user_group_slug == 'qa' || $user_level->user_group_slug == 'supervisor'){
                                    $objEntryForm->qa_by = $user_id;
                                    $objEntryForm->published_by = $user_id;
                                }

                            }else{
                                $objEntryForm->entered_by = $user_id;
                                $objEntryForm->qa_by = $user_id;
                                $objEntryForm->published_by = $user_id;
                            }

                            if ($objEntryForm->save()) {
                                $objEnergyFormMeta = new EnergyFormMeta();
                                $objEnergyFormMeta->energy_form_id = $objEntryForm->id;
                                $objEnergyFormMeta->energy_form_topic = 'production';
                                $objEnergyFormMeta->energy_id = $energy_id;
                                $objEnergyFormMeta->energy_topic = 'overall';
                                $objEnergyFormMeta->energy_topic_id = 0;
                                $objEnergyFormMeta->natural_qty = (!empty($the_overall['natural_qty'])) ? $the_overall['natural_qty'] : null;
                                $objEnergyFormMeta->natural_unit = (!empty($the_overall['natural_unit'])) ? $the_overall['natural_unit'] : null;

//                                echo '<hr />';
                                $this_st_qty = (!empty($scientific_unit_conversion_standard[$objEnergyFormMeta->natural_unit]))?($scientific_unit_conversion_standard[$objEnergyFormMeta->natural_unit]*$objEnergyFormMeta->natural_qty):'';

//                                echo '<hr />';
//                                echo '<hr />';

                                $objEnergyFormMeta->scientific_qty = $this_st_qty;

                                $objEnergyFormMeta->status = 'Y';
                                $objEnergyFormMeta->save();
                            }

                        }

                    }
                }
            }
        }
//        exit();

        $objLog = new LogTable();
        $log_details = array('Production Energy Form Entry');
        $data = array(
            'log_details'   => serialize($log_details),
            'menu_name'     => 'New Production Energy Form Entry',
            'created_by'    => Auth::user()->id
        );
        $objLog->insertIntoLogTable($data);

        $current_url_this = $request->url();

        return redirect($current_url_this.'?year='.$from_date.'&province_id='.$province_id)
            ->with('success', 'Production Energy Form Entry done successfully!');

//        return redirect('dashboard/entryform/production?year='.$from_date.'&province_id='.$province_id.'&district_id='.$district_id.'&local_gov_id='.$local_gov_id)
//            ->with('success', 'Production Energy Form Entry done successfully!');

    }

    public function entryFormEnergyFormNewDistrictwiseProductionPost(Request $request){

        // return 1;

        $formdata = (!empty($request->formdata))?$request->formdata:array();
        $districtwise = (!empty($request->districtwise))?$request->districtwise:array();
        $overall = (!empty($request->overall))?$request->overall:array();
        $scientific_unit_conversion_standard = (!empty($request->scientific_unit_conversion_standard))?$request->scientific_unit_conversion_standard:array();

        $from_date = (!empty($formdata['from_date']))?$formdata['from_date']:null;
        $to_date = (!empty($formdata['to_date']))?$formdata['to_date']:null;
        $central_id = 1;
        $province_id = (!empty($formdata['province_id']))?$formdata['province_id']:null;

        if(is_array($districtwise) && count($districtwise) > 0){
            foreach($districtwise as $district_id=>$energy_arr) {

                if (!empty($district_id) && $district_id != '') {
                    foreach($energy_arr as $energy_id=>$the_overall) {

                        $objCheckProductionEnergyForm = ProductionEnergyForm::where('energy_id', '=', $energy_id)
                            ->where('province_id', '=', $province_id)
                            ->where('district_id', '=', $district_id)
                            ->where('from_date', '=', $from_date)
                            ->get();

                        if(!empty($objCheckProductionEnergyForm[0])){
                            foreach($objCheckProductionEnergyForm as $this_energyform){
                                ProductionEnergyForm::find($this_energyform->id)->delete();
                                EnergyFormMeta::where('energy_form_id', $this_energyform->id)->where('energy_form_topic', 'production')->delete();

                            }
                        }

                        if((!empty($the_overall['natural_qty']))){

                            $objEntryForm = new ProductionEnergyForm();
                            $objEntryForm->energy_id = $energy_id;
                            $objEntryForm->central_id = 1;
                            $objEntryForm->province_id = $province_id;
                            $objEntryForm->district_id = $district_id;
                            $objEntryForm->from_date = $from_date;
                            $objEntryForm->to_date = $to_date;
                            $objEntryForm->status = 'Y';

                            $user_level_id = Auth::user()->user_group_id;
                            $user_level = UserGroup::find($user_level_id);
                            $user_id = Auth::user()->id;

                            if(!empty($user_level->user_group_slug)){
                                if($user_level->user_group_slug == 'data-entry'){
                                    $objEntryForm->entered_by = $user_id;
                                }elseif($user_level->user_group_slug == 'qa' || $user_level->user_group_slug == 'supervisor'){
                                    $objEntryForm->qa_by = $user_id;
                                    $objEntryForm->published_by = $user_id;
                                }

                            }else{
                                $objEntryForm->entered_by = $user_id;
                                $objEntryForm->qa_by = $user_id;
                                $objEntryForm->published_by = $user_id;
                            }

                            if ($objEntryForm->save()) {
                                $objEnergyFormMeta = new EnergyFormMeta();
                                $objEnergyFormMeta->energy_form_id = $objEntryForm->id;
                                $objEnergyFormMeta->energy_form_topic = 'production';
                                $objEnergyFormMeta->energy_id = $energy_id;
                                $objEnergyFormMeta->energy_topic = 'overall';
                                $objEnergyFormMeta->energy_topic_id = 0;
                                $objEnergyFormMeta->natural_qty = (!empty($the_overall['natural_qty'])) ? $the_overall['natural_qty'] : null;
                                $objEnergyFormMeta->natural_unit = (!empty($the_overall['natural_unit'])) ? $the_overall['natural_unit'] : null;

//                                echo '<hr />';
                                $this_st_qty = (!empty($scientific_unit_conversion_standard[$objEnergyFormMeta->natural_unit]))?($scientific_unit_conversion_standard[$objEnergyFormMeta->natural_unit]*$objEnergyFormMeta->natural_qty):'';

//                                echo '<hr />';
//                                echo '<hr />';

                                $objEnergyFormMeta->scientific_qty = $this_st_qty;

                                $objEnergyFormMeta->status = 'Y';
                                $objEnergyFormMeta->save();
                            }

                        }

                    }
                }
            }
        }

        if(is_array($overall) && count($overall) > 0){
            foreach($overall as $energy_id=>$the_overall) {

                $objCheckProductionEnergyForm = ProductionEnergyForm::where('energy_id', '=', $energy_id)
                    ->where('province_id', '=', $province_id)
                    ->where('district_id', '=', null)
                    ->where('from_date', '=', $from_date)
                    ->get();

                if(!empty($objCheckProductionEnergyForm[0])){
                    foreach($objCheckProductionEnergyForm as $this_energyform){
                        ProductionEnergyForm::find($this_energyform->id)->delete();
                        EnergyFormMeta::where('energy_form_id', $this_energyform->id)->where('energy_form_topic', 'production')->delete();

                    }
                }

                if((!empty($the_overall['natural_qty']))){

                    $objEntryForm = new ProductionEnergyForm();
                    $objEntryForm->energy_id = $energy_id;
                    $objEntryForm->province_id = $province_id;
                    $objEntryForm->district_id = null;
                    $objEntryForm->from_date = $from_date;
                    $objEntryForm->to_date = $to_date;
                    $objEntryForm->status = 'Y';

                    $user_level_id = Auth::user()->user_group_id;
                    $user_level = UserGroup::find($user_level_id);
                    $user_id = Auth::user()->id;

                    if(!empty($user_level->user_group_slug)){
                        if($user_level->user_group_slug == 'data-entry'){
                            $objEntryForm->entered_by = $user_id;
                        }elseif($user_level->user_group_slug == 'qa' || $user_level->user_group_slug == 'supervisor'){
                            $objEntryForm->qa_by = $user_id;
                            $objEntryForm->published_by = $user_id;
                        }

                    }else{
                        $objEntryForm->entered_by = $user_id;
                        $objEntryForm->qa_by = $user_id;
                        $objEntryForm->published_by = $user_id;
                    }

                    if ($objEntryForm->save()) {
                        $objEnergyFormMeta = new EnergyFormMeta();
                        $objEnergyFormMeta->energy_form_id = $objEntryForm->id;
                        $objEnergyFormMeta->energy_form_topic = 'production';
                        $objEnergyFormMeta->energy_id = $energy_id;
                        $objEnergyFormMeta->energy_topic = 'overall';
                        $objEnergyFormMeta->energy_topic_id = 0;
                        $objEnergyFormMeta->natural_qty = (!empty($the_overall['natural_qty'])) ? $the_overall['natural_qty'] : null;
                        $objEnergyFormMeta->natural_unit = (!empty($the_overall['natural_unit'])) ? $the_overall['natural_unit'] : null;

//                                echo '<hr />';
                        $this_st_qty = (!empty($scientific_unit_conversion_standard[$objEnergyFormMeta->natural_unit]))?($scientific_unit_conversion_standard[$objEnergyFormMeta->natural_unit]*$objEnergyFormMeta->natural_qty):'';

//                                echo '<hr />';
//                                echo '<hr />';

                        $objEnergyFormMeta->scientific_qty = $this_st_qty;

                        $objEnergyFormMeta->status = 'Y';
                        $objEnergyFormMeta->save();
                    }
                }
            }
        }

//        exit();

        $objLog = new LogTable();
        $log_details = array('Production Energy Form Entry');
        $data = array(
            'log_details'   => serialize($log_details),
            'menu_name'     => 'New Production Energy Form Entry',
            'created_by'    => Auth::user()->id
        );
        $objLog->insertIntoLogTable($data);

        $current_url_this = $request->url();

        return redirect($current_url_this.'?year='.$from_date.'&province_id='.$province_id)
            ->with('success', 'Production Energy Form Entry done successfully!');

//        return redirect('dashboard/entryform/production?year='.$from_date.'&province_id='.$province_id.'&district_id='.$district_id.'&local_gov_id='.$local_gov_id)
//            ->with('success', 'Production Energy Form Entry done successfully!');

    }


    public function entryFormEnergyFormNewDistrictwiseResourcesPost(Request $request){

        // return 1;

        $formdata = (!empty($request->formdata))?$request->formdata:array();
        $districtwise = (!empty($request->districtwise))?$request->districtwise:array();
        $overall = (!empty($request->overall))?$request->overall:array();
        $scientific_unit_conversion_standard = (!empty($request->scientific_unit_conversion_standard))?$request->scientific_unit_conversion_standard:array();

        $from_date = (!empty($formdata['from_date']))?$formdata['from_date']:null;
        $to_date = (!empty($formdata['to_date']))?$formdata['to_date']:null;
        $central_id = 1;
        $province_id = (!empty($formdata['province_id']))?$formdata['province_id']:null;


//        echo '<pre>';
//        print_r($formdata);
//        echo '<hr />';
//        print_r($districtwise);
//        echo '<hr />';
//        print_r($overall);
//        echo $province_id;
//        exit();

        if(is_array($districtwise) && count($districtwise) > 0){
            foreach($districtwise as $district_id=>$energy_arr) {

//                echo '<pre>';
//                echo $district_id;

                if (!empty($district_id) && $district_id != '') {
                    foreach($energy_arr as $energy_id=>$the_overall) {

                        $objCheckProductionEnergyForm = ResourcesEnergyForm::where('energy_id', '=', $energy_id)
                            ->where('province_id', '=', $province_id)
                            ->where('district_id', '=', $district_id)
                            ->where('from_date', '=', $from_date)
                            ->get();

                        if(!empty($objCheckProductionEnergyForm[0])){
                            foreach($objCheckProductionEnergyForm as $this_energyform){
                                ResourcesEnergyForm::find($this_energyform->id)->delete();
                                EnergyFormMeta::where('energy_form_id', $this_energyform->id)->where('energy_form_topic', 'resources')->delete();
                            }
                        }

                        if((!empty($the_overall['natural_qty']))){

                            $objEntryForm = new ResourcesEnergyForm();
                            $objEntryForm->energy_id = $energy_id;
                            $objEntryForm->central_id = 1;
                            $objEntryForm->province_id = $province_id;
                            $objEntryForm->district_id = $district_id;
                            $objEntryForm->from_date = $from_date;
                            $objEntryForm->to_date = $to_date;
                            $objEntryForm->status = 'Y';

                            $user_level_id = Auth::user()->user_group_id;
                            $user_level = UserGroup::find($user_level_id);
                            $user_id = Auth::user()->id;

                            if(!empty($user_level->user_group_slug)){
                                if($user_level->user_group_slug == 'data-entry'){
                                    $objEntryForm->entered_by = $user_id;
                                }elseif($user_level->user_group_slug == 'qa' || $user_level->user_group_slug == 'supervisor'){
                                    $objEntryForm->qa_by = $user_id;
                                    $objEntryForm->published_by = $user_id;
                                }

                            }else{
                                $objEntryForm->entered_by = $user_id;
                                $objEntryForm->qa_by = $user_id;
                                $objEntryForm->published_by = $user_id;
                            }

                            if ($objEntryForm->save()) {
                                $objEnergyFormMeta = new EnergyFormMeta();
                                $objEnergyFormMeta->energy_form_id = $objEntryForm->id;
                                $objEnergyFormMeta->energy_form_topic = 'resources';
                                $objEnergyFormMeta->energy_id = $energy_id;
                                $objEnergyFormMeta->energy_topic = 'overall';
                                $objEnergyFormMeta->energy_topic_id = 0;
                                $objEnergyFormMeta->natural_qty = (!empty($the_overall['natural_qty'])) ? $the_overall['natural_qty'] : null;
                                $objEnergyFormMeta->natural_unit = (!empty($the_overall['natural_unit'])) ? $the_overall['natural_unit'] : null;

//                                echo '<hr />';
                                $this_st_qty = (!empty($scientific_unit_conversion_standard[$objEnergyFormMeta->natural_unit]))?($scientific_unit_conversion_standard[$objEnergyFormMeta->natural_unit]*$objEnergyFormMeta->natural_qty):'';

//                                echo '<hr />';
//                                echo '<hr />';

                                $objEnergyFormMeta->scientific_qty = $this_st_qty;

                                $objEnergyFormMeta->status = 'Y';
                                $objEnergyFormMeta->save();
                            }

                        }

                    }
                }
            }
        }

        if(is_array($overall) && count($overall) > 0){
            foreach($overall as $energy_id=>$the_overall) {

                $objCheckResourcesEnergyForm = ResourcesEnergyForm::where('energy_id', '=', $energy_id)
                    ->where('province_id', '=', $province_id)
                    ->where('district_id', '=', null)
                    ->where('from_date', '=', $from_date)
                    ->get();

                if(!empty($objCheckResourcesEnergyForm[0])){
                    foreach($objCheckResourcesEnergyForm as $this_energyform){
                        ResourcesEnergyForm::find($this_energyform->id)->delete();
                        EnergyFormMeta::where('energy_form_id', $this_energyform->id)->where('energy_form_topic', 'resources')->delete();

                    }
                }

                if((!empty($the_overall['natural_qty']))){

                    $objEntryForm = new ResourcesEnergyForm();
                    $objEntryForm->energy_id = $energy_id;
                    $objEntryForm->province_id = $province_id;
                    $objEntryForm->district_id = null;
                    $objEntryForm->from_date = $from_date;
                    $objEntryForm->to_date = $to_date;
                    $objEntryForm->status = 'Y';

                    $user_level_id = Auth::user()->user_group_id;
                    $user_level = UserGroup::find($user_level_id);
                    $user_id = Auth::user()->id;

                    if(!empty($user_level->user_group_slug)){
                        if($user_level->user_group_slug == 'data-entry'){
                            $objEntryForm->entered_by = $user_id;
                        }elseif($user_level->user_group_slug == 'qa' || $user_level->user_group_slug == 'supervisor'){
                            $objEntryForm->qa_by = $user_id;
                            $objEntryForm->published_by = $user_id;
                        }

                    }else{
                        $objEntryForm->entered_by = $user_id;
                        $objEntryForm->qa_by = $user_id;
                        $objEntryForm->published_by = $user_id;
                    }

                    if ($objEntryForm->save()) {
                        $objEnergyFormMeta = new EnergyFormMeta();
                        $objEnergyFormMeta->energy_form_id = $objEntryForm->id;
                        $objEnergyFormMeta->energy_form_topic = 'resources';
                        $objEnergyFormMeta->energy_id = $energy_id;
                        $objEnergyFormMeta->energy_topic = 'overall';
                        $objEnergyFormMeta->energy_topic_id = 0;
                        $objEnergyFormMeta->natural_qty = (!empty($the_overall['natural_qty'])) ? $the_overall['natural_qty'] : null;
                        $objEnergyFormMeta->natural_unit = (!empty($the_overall['natural_unit'])) ? $the_overall['natural_unit'] : null;

//                                echo '<hr />';
                        $this_st_qty = (!empty($scientific_unit_conversion_standard[$objEnergyFormMeta->natural_unit]))?($scientific_unit_conversion_standard[$objEnergyFormMeta->natural_unit]*$objEnergyFormMeta->natural_qty):'';

//                                echo '<hr />';
//                                echo '<hr />';

                        $objEnergyFormMeta->scientific_qty = $this_st_qty;

                        $objEnergyFormMeta->status = 'Y';
                        $objEnergyFormMeta->save();
                    }
                }
            }
        }


        $objLog = new LogTable();
        $log_details = array('Resources Energy Form Entry');
        $data = array(
            'log_details'   => serialize($log_details),
            'menu_name'     => 'New Resources Energy Form Entry',
            'created_by'    => Auth::user()->id
        );
        $objLog->insertIntoLogTable($data);

        $current_url_this = $request->url();

        return redirect($current_url_this.'?year='.$from_date.'&province_id='.$province_id)
            ->with('success', 'Resources Energy Form Entry done successfully!');

//        return redirect('dashboard/entryform/production?year='.$from_date.'&province_id='.$province_id.'&district_id='.$district_id.'&local_gov_id='.$local_gov_id)
//            ->with('success', 'Production Energy Form Entry done successfully!');

    }


    public function entryFormEnergyFormNewDistrictwiseImportPost(Request $request){

        // return 1;

        $formdata = (!empty($request->formdata))?$request->formdata:array();
        $districtwise = (!empty($request->districtwise))?$request->districtwise:array();
        $overall = (!empty($request->overall))?$request->overall:array();
        $scientific_unit_conversion_standard = (!empty($request->scientific_unit_conversion_standard))?$request->scientific_unit_conversion_standard:array();

        $from_date = (!empty($formdata['from_date']))?$formdata['from_date']:null;
        $to_date = (!empty($formdata['to_date']))?$formdata['to_date']:null;
        $central_id = 1;
        $province_id = (!empty($formdata['province_id']))?$formdata['province_id']:null;


//        echo '<pre>';
//        print_r($formdata);
//        echo '<hr />';
//        print_r($districtwise);
//        echo '<hr />';
//        print_r($overall);
//        echo $province_id;
//        exit();

        if(is_array($districtwise) && count($districtwise) > 0){
            foreach($districtwise as $district_id=>$energy_arr) {

//                echo '<pre>';
//                echo $district_id;

                if (!empty($district_id) && $district_id != '') {
                    foreach($energy_arr as $energy_id=>$the_overall) {

//        print_r($the_overall);
//        echo '<hr />';
//        print_r($scientific_unit_conversion_standard);
//                        echo '<hr />';
//        print_r($v);
//                        echo $energy_id;
//                        echo '<hr />';
//        print_r($v);
//                        echo $district_id;
//                        echo '<hr />';

                        $objCheckProductionEnergyForm = ImportEnergyForm::where('energy_id', '=', $energy_id)
                            ->where('province_id', '=', $province_id)
                            ->where('district_id', '=', $district_id)
                            ->where('from_date', '=', $from_date)
                            ->get();

                        if(!empty($objCheckProductionEnergyForm[0])){
                            foreach($objCheckProductionEnergyForm as $this_energyform){
                                ImportEnergyForm::find($this_energyform->id)->delete();
                                EnergyFormMeta::where('energy_form_id', $this_energyform->id)->where('energy_form_topic', 'import')->delete();

                            }
                        }

                        if((!empty($the_overall['natural_qty']))){

                            $objEntryForm = new ImportEnergyForm();
                            $objEntryForm->energy_id = $energy_id;
                            $objEntryForm->central_id = 1;
                            $objEntryForm->province_id = $province_id;
                            $objEntryForm->district_id = $district_id;
                            $objEntryForm->from_date = $from_date;
                            $objEntryForm->to_date = $to_date;
                            $objEntryForm->status = 'Y';

                            $user_level_id = Auth::user()->user_group_id;
                            $user_level = UserGroup::find($user_level_id);
                            $user_id = Auth::user()->id;

                            if(!empty($user_level->user_group_slug)){
                                if($user_level->user_group_slug == 'data-entry'){
                                    $objEntryForm->entered_by = $user_id;
                                }elseif($user_level->user_group_slug == 'qa' || $user_level->user_group_slug == 'supervisor'){
                                    $objEntryForm->qa_by = $user_id;
                                    $objEntryForm->published_by = $user_id;
                                }

                            }else{
                                $objEntryForm->entered_by = $user_id;
                                $objEntryForm->qa_by = $user_id;
                                $objEntryForm->published_by = $user_id;
                            }

                            if ($objEntryForm->save()) {
                                $objEnergyFormMeta = new EnergyFormMeta();
                                $objEnergyFormMeta->energy_form_id = $objEntryForm->id;
                                $objEnergyFormMeta->energy_form_topic = 'import';
                                $objEnergyFormMeta->energy_id = $energy_id;
                                $objEnergyFormMeta->energy_topic = 'overall';
                                $objEnergyFormMeta->energy_topic_id = 0;
                                $objEnergyFormMeta->natural_qty = (!empty($the_overall['natural_qty'])) ? $the_overall['natural_qty'] : null;
                                $objEnergyFormMeta->natural_unit = (!empty($the_overall['natural_unit'])) ? $the_overall['natural_unit'] : null;

//                                echo '<hr />';
                                $this_st_qty = (!empty($scientific_unit_conversion_standard[$objEnergyFormMeta->natural_unit]))?($scientific_unit_conversion_standard[$objEnergyFormMeta->natural_unit]*$objEnergyFormMeta->natural_qty):'';

//                                echo '<hr />';
//                                echo '<hr />';

                                $objEnergyFormMeta->scientific_qty = $this_st_qty;

                                $objEnergyFormMeta->status = 'Y';
                                $objEnergyFormMeta->save();
                            }

                        }

                    }
                }
            }
        }

        if(is_array($overall) && count($overall) > 0){
            foreach($overall as $energy_id=>$the_overall) {

                $objCheckImportEnergyForm = ImportEnergyForm::where('energy_id', '=', $energy_id)
                    ->where('province_id', '=', $province_id)
                    ->where('district_id', '=', null)
                    ->where('from_date', '=', $from_date)
                    ->get();

                if(!empty($objCheckImportEnergyForm[0])){
                    foreach($objCheckImportEnergyForm as $this_energyform){
                        ImportEnergyForm::find($this_energyform->id)->delete();
                        EnergyFormMeta::where('energy_form_id', $this_energyform->id)->where('energy_form_topic', 'production')->delete();

                    }
                }

                if((!empty($the_overall['natural_qty']))){

                    $objEntryForm = new ImportEnergyForm();
                    $objEntryForm->energy_id = $energy_id;
                    $objEntryForm->province_id = $province_id;
                    $objEntryForm->district_id = null;
                    $objEntryForm->from_date = $from_date;
                    $objEntryForm->to_date = $to_date;
                    $objEntryForm->status = 'Y';

                    $user_level_id = Auth::user()->user_group_id;
                    $user_level = UserGroup::find($user_level_id);
                    $user_id = Auth::user()->id;

                    if(!empty($user_level->user_group_slug)){
                        if($user_level->user_group_slug == 'data-entry'){
                            $objEntryForm->entered_by = $user_id;
                        }elseif($user_level->user_group_slug == 'qa' || $user_level->user_group_slug == 'supervisor'){
                            $objEntryForm->qa_by = $user_id;
                            $objEntryForm->published_by = $user_id;
                        }

                    }else{
                        $objEntryForm->entered_by = $user_id;
                        $objEntryForm->qa_by = $user_id;
                        $objEntryForm->published_by = $user_id;
                    }

                    if ($objEntryForm->save()) {
                        $objEnergyFormMeta = new EnergyFormMeta();
                        $objEnergyFormMeta->energy_form_id = $objEntryForm->id;
                        $objEnergyFormMeta->energy_form_topic = 'import';
                        $objEnergyFormMeta->energy_id = $energy_id;
                        $objEnergyFormMeta->energy_topic = 'overall';
                        $objEnergyFormMeta->energy_topic_id = 0;
                        $objEnergyFormMeta->natural_qty = (!empty($the_overall['natural_qty'])) ? $the_overall['natural_qty'] : null;
                        $objEnergyFormMeta->natural_unit = (!empty($the_overall['natural_unit'])) ? $the_overall['natural_unit'] : null;

//                                echo '<hr />';
                        $this_st_qty = (!empty($scientific_unit_conversion_standard[$objEnergyFormMeta->natural_unit]))?($scientific_unit_conversion_standard[$objEnergyFormMeta->natural_unit]*$objEnergyFormMeta->natural_qty):'';

//                                echo '<hr />';
//                                echo '<hr />';

                        $objEnergyFormMeta->scientific_qty = $this_st_qty;

                        $objEnergyFormMeta->status = 'Y';
                        $objEnergyFormMeta->save();
                    }
                }
            }
        }

//        exit();

        $objLog = new LogTable();
        $log_details = array('Import Energy Form Entry');
        $data = array(
            'log_details'   => serialize($log_details),
            'menu_name'     => 'New Import Energy Form Entry',
            'created_by'    => Auth::user()->id
        );
        $objLog->insertIntoLogTable($data);

        $current_url_this = $request->url();

        return redirect($current_url_this.'?year='.$from_date.'&province_id='.$province_id)
            ->with('success', 'Import Energy Form Entry done successfully!');

//        return redirect('dashboard/entryform/production?year='.$from_date.'&province_id='.$province_id.'&district_id='.$district_id.'&local_gov_id='.$local_gov_id)
//            ->with('success', 'Production Energy Form Entry done successfully!');

    }


    public function entryFormEnergyFormNewDistrictwiseExportPost(Request $request){

        // return 1;

        $formdata = (!empty($request->formdata))?$request->formdata:array();
        $districtwise = (!empty($request->districtwise))?$request->districtwise:array();
        $overall = (!empty($request->overall))?$request->overall:array();
        $scientific_unit_conversion_standard = (!empty($request->scientific_unit_conversion_standard))?$request->scientific_unit_conversion_standard:array();

        $from_date = (!empty($formdata['from_date']))?$formdata['from_date']:null;
        $to_date = (!empty($formdata['to_date']))?$formdata['to_date']:null;
        $central_id = 1;
        $province_id = (!empty($formdata['province_id']))?$formdata['province_id']:null;


//        echo '<pre>';
//        print_r($formdata);
//        echo '<hr />';
//        print_r($districtwise);
//        echo '<hr />';
//        print_r($overall);
//        echo $province_id;
//        exit();

        if(is_array($districtwise) && count($districtwise) > 0){
            foreach($districtwise as $district_id=>$energy_arr) {

//                echo '<pre>';
//                echo $district_id;

                if (!empty($district_id) && $district_id != '') {
                    foreach($energy_arr as $energy_id=>$the_overall) {

//        print_r($the_overall);
//        echo '<hr />';
//        print_r($scientific_unit_conversion_standard);
//                        echo '<hr />';
//        print_r($v);
//                        echo $energy_id;
//                        echo '<hr />';
//        print_r($v);
//                        echo $district_id;
//                        echo '<hr />';

                        $objCheckProductionEnergyForm = ExportEnergyForm::where('energy_id', '=', $energy_id)
                            ->where('province_id', '=', $province_id)
                            ->where('district_id', '=', $district_id)
                            ->where('from_date', '=', $from_date)
                            ->get();

                        if(!empty($objCheckProductionEnergyForm[0])){
                            foreach($objCheckProductionEnergyForm as $this_energyform){
                                ExportEnergyForm::find($this_energyform->id)->delete();
                                EnergyFormMeta::where('energy_form_id', $this_energyform->id)->where('energy_form_topic', 'export')->delete();

                            }
                        }

                        if((!empty($the_overall['natural_qty']))){

                            $objEntryForm = new ExportEnergyForm();
                            $objEntryForm->energy_id = $energy_id;
                            $objEntryForm->central_id = 1;
                            $objEntryForm->province_id = $province_id;
                            $objEntryForm->district_id = $district_id;
                            $objEntryForm->from_date = $from_date;
                            $objEntryForm->to_date = $to_date;
                            $objEntryForm->status = 'Y';

                            $user_level_id = Auth::user()->user_group_id;
                            $user_level = UserGroup::find($user_level_id);
                            $user_id = Auth::user()->id;

                            if(!empty($user_level->user_group_slug)){
                                if($user_level->user_group_slug == 'data-entry'){
                                    $objEntryForm->entered_by = $user_id;
                                }elseif($user_level->user_group_slug == 'qa' || $user_level->user_group_slug == 'supervisor'){
                                    $objEntryForm->qa_by = $user_id;
                                    $objEntryForm->published_by = $user_id;
                                }

                            }else{
                                $objEntryForm->entered_by = $user_id;
                                $objEntryForm->qa_by = $user_id;
                                $objEntryForm->published_by = $user_id;
                            }

                            if ($objEntryForm->save()) {
                                $objEnergyFormMeta = new EnergyFormMeta();
                                $objEnergyFormMeta->energy_form_id = $objEntryForm->id;
                                $objEnergyFormMeta->energy_form_topic = 'export';
                                $objEnergyFormMeta->energy_id = $energy_id;
                                $objEnergyFormMeta->energy_topic = 'overall';
                                $objEnergyFormMeta->energy_topic_id = 0;
                                $objEnergyFormMeta->natural_qty = (!empty($the_overall['natural_qty'])) ? $the_overall['natural_qty'] : null;
                                $objEnergyFormMeta->natural_unit = (!empty($the_overall['natural_unit'])) ? $the_overall['natural_unit'] : null;

//                                echo '<hr />';
                                $this_st_qty = (!empty($scientific_unit_conversion_standard[$objEnergyFormMeta->natural_unit]))?($scientific_unit_conversion_standard[$objEnergyFormMeta->natural_unit]*$objEnergyFormMeta->natural_qty):'';

//                                echo '<hr />';
//                                echo '<hr />';

                                $objEnergyFormMeta->scientific_qty = $this_st_qty;

                                $objEnergyFormMeta->status = 'Y';
                                $objEnergyFormMeta->save();
                            }

                        }

                    }
                }
            }
        }


        if(is_array($overall) && count($overall) > 0){
            foreach($overall as $energy_id=>$the_overall) {

                $objCheckExportEnergyForm = ExportEnergyForm::where('energy_id', '=', $energy_id)
                    ->where('province_id', '=', $province_id)
                    ->where('district_id', '=', null)
                    ->where('from_date', '=', $from_date)
                    ->get();

                if(!empty($objCheckExportEnergyForm[0])){
                    foreach($objCheckExportEnergyForm as $this_energyform){
                        ExportEnergyForm::find($this_energyform->id)->delete();
                        EnergyFormMeta::where('energy_form_id', $this_energyform->id)->where('energy_form_topic', 'export')->delete();

                    }
                }

                if((!empty($the_overall['natural_qty']))){

                    $objEntryForm = new ExportEnergyForm();
                    $objEntryForm->energy_id = $energy_id;
                    $objEntryForm->province_id = $province_id;
                    $objEntryForm->district_id = null;
                    $objEntryForm->from_date = $from_date;
                    $objEntryForm->to_date = $to_date;
                    $objEntryForm->status = 'Y';

                    $user_level_id = Auth::user()->user_group_id;
                    $user_level = UserGroup::find($user_level_id);
                    $user_id = Auth::user()->id;

                    if(!empty($user_level->user_group_slug)){
                        if($user_level->user_group_slug == 'data-entry'){
                            $objEntryForm->entered_by = $user_id;
                        }elseif($user_level->user_group_slug == 'qa' || $user_level->user_group_slug == 'supervisor'){
                            $objEntryForm->qa_by = $user_id;
                            $objEntryForm->published_by = $user_id;
                        }

                    }else{
                        $objEntryForm->entered_by = $user_id;
                        $objEntryForm->qa_by = $user_id;
                        $objEntryForm->published_by = $user_id;
                    }

                    if ($objEntryForm->save()) {
                        $objEnergyFormMeta = new EnergyFormMeta();
                        $objEnergyFormMeta->energy_form_id = $objEntryForm->id;
                        $objEnergyFormMeta->energy_form_topic = 'export';
                        $objEnergyFormMeta->energy_id = $energy_id;
                        $objEnergyFormMeta->energy_topic = 'overall';
                        $objEnergyFormMeta->energy_topic_id = 0;
                        $objEnergyFormMeta->natural_qty = (!empty($the_overall['natural_qty'])) ? $the_overall['natural_qty'] : null;
                        $objEnergyFormMeta->natural_unit = (!empty($the_overall['natural_unit'])) ? $the_overall['natural_unit'] : null;

//                                echo '<hr />';
                        $this_st_qty = (!empty($scientific_unit_conversion_standard[$objEnergyFormMeta->natural_unit]))?($scientific_unit_conversion_standard[$objEnergyFormMeta->natural_unit]*$objEnergyFormMeta->natural_qty):'';

//                                echo '<hr />';
//                                echo '<hr />';

                        $objEnergyFormMeta->scientific_qty = $this_st_qty;

                        $objEnergyFormMeta->status = 'Y';
                        $objEnergyFormMeta->save();
                    }
                }
            }
        }

        $objLog = new LogTable();
        $log_details = array('Export Energy Form Entry');
        $data = array(
            'log_details'   => serialize($log_details),
            'menu_name'     => 'New Export Energy Form Entry',
            'created_by'    => Auth::user()->id
        );
        $objLog->insertIntoLogTable($data);

        $current_url_this = $request->url();

        return redirect($current_url_this.'?year='.$from_date.'&province_id='.$province_id)
            ->with('success', 'Export Energy Form Entry done successfully!');
//        return redirect('dashboard/entryform/production?year='.$from_date.'&province_id='.$province_id.'&district_id='.$district_id.'&local_gov_id='.$local_gov_id)
//            ->with('success', 'Production Energy Form Entry done successfully!');

    }


    public function entryFormEnergyFormNewDistrictwiseConsumptionPost(Request $request){

        // return 1;

        $formdata = (!empty($request->formdata))?$request->formdata:array();
        $districtwise = (!empty($request->districtwise))?$request->districtwise:array();

        $overall = (!empty($request->overall))?$request->overall:array();

        $scientific_unit_conversion_standard = (!empty($request->scientific_unit_conversion_standard))?$request->scientific_unit_conversion_standard:array();

        $from_date = (!empty($formdata['from_date']))?$formdata['from_date']:null;
        $to_date = (!empty($formdata['to_date']))?$formdata['to_date']:null;
        $central_id = 1;
        $province_id = (!empty($formdata['province_id']))?$formdata['province_id']:null;
        $sector_id = (!empty($formdata['sector_id']))?$formdata['sector_id']:0;

        $this_sector_id = 0;

        if($sector_id > 0){
            $this_sector_obj = Sector::find($sector_id);

            if(!empty($this_sector_obj->id)){
                $this_sector_id = $this_sector_obj->id;
            }else{
                $this_sector_id = Sector::where('sector_slug', 'agricultural')->pluck('id')->first();
            }

        }


//        echo '<pre>';
//        print_r($overall);
//        echo '<hr />';
////        print_r($districtwise);
//        echo '<hr />';
////        print_r($overall);
//        echo $province_id;
//        exit();

        if(is_array($districtwise) && count($districtwise) > 0){
            foreach($districtwise as $district_id=>$energy_arr) {

//                echo '<pre>';
//                echo $district_id;

                if (!empty($district_id) && $district_id != '') {
                    foreach($energy_arr as $energy_id=>$the_overall) {

                        $objCheckProductionEnergyForm = ConsumptionEnergyForm::where('energy_id', '=', $energy_id)
                            ->where('sector_id', $this_sector_id)
                            ->where('province_id', '=', $province_id)
                            ->where('district_id', '=', $district_id)
                            ->where('from_date', '=', $from_date)
                            ->get();

                        if(!empty($objCheckProductionEnergyForm[0])){
                            foreach($objCheckProductionEnergyForm as $this_energyform){
                                ConsumptionEnergyForm::find($this_energyform->id)->delete();
                                EnergyFormMeta::where('energy_form_id', $this_energyform->id)
                                    ->where('energy_form_topic', 'consumption')
                                    ->delete();

                            }
                        }

                        if((!empty($the_overall['natural_qty']))){

                            $objEntryForm = new ConsumptionEnergyForm();
                            $objEntryForm->energy_id = $energy_id;
                            $objEntryForm->central_id = 1;
                            $objEntryForm->province_id = $province_id;
                            $objEntryForm->district_id = $district_id;
                            $objEntryForm->from_date = $from_date;
                            $objEntryForm->to_date = $to_date;
                            $objEntryForm->sector_id = $this_sector_id;
                            $objEntryForm->status = 'Y';

                            $user_level_id = Auth::user()->user_group_id;
                            $user_level = UserGroup::find($user_level_id);
                            $user_id = Auth::user()->id;

                            if(!empty($user_level->user_group_slug)){
                                if($user_level->user_group_slug == 'data-entry'){
                                    $objEntryForm->entered_by = $user_id;
                                }elseif($user_level->user_group_slug == 'qa' || $user_level->user_group_slug == 'supervisor'){
                                    $objEntryForm->qa_by = $user_id;
                                    $objEntryForm->published_by = $user_id;
                                }

                            }else{
                                $objEntryForm->entered_by = $user_id;
                                $objEntryForm->qa_by = $user_id;
                                $objEntryForm->published_by = $user_id;
                            }

                            if ($objEntryForm->save()) {
                                $objEnergyFormMeta = new EnergyFormMeta();
                                $objEnergyFormMeta->energy_form_id = $objEntryForm->id;
                                $objEnergyFormMeta->energy_form_topic = 'consumption';
                                $objEnergyFormMeta->energy_id = $energy_id;
                                $objEnergyFormMeta->energy_topic = 'sector';
                                $objEnergyFormMeta->energy_topic_id = $sector_id;
                                $objEnergyFormMeta->natural_qty = (!empty($the_overall['natural_qty'])) ? $the_overall['natural_qty'] : null;
                                $objEnergyFormMeta->natural_unit = (!empty($the_overall['natural_unit'])) ? $the_overall['natural_unit'] : null;

//                                echo '<hr />';
                                $this_st_qty = (!empty($scientific_unit_conversion_standard[$objEnergyFormMeta->natural_unit]))?($scientific_unit_conversion_standard[$objEnergyFormMeta->natural_unit]*$objEnergyFormMeta->natural_qty):'';

//                                echo '<hr />';
//                                echo '<hr />';

                                $objEnergyFormMeta->scientific_qty = $this_st_qty;

                                $objEnergyFormMeta->status = 'Y';
                                $objEnergyFormMeta->save();
                            }

                        }

                    }
                }
            }
        }


        if(is_array($overall) && count($overall) > 0){
            foreach($overall as $energy_id=>$the_overall) {

                $objCheckProductionEnergyForm = ConsumptionEnergyForm::where('energy_id', '=', $energy_id)
                    ->where('province_id', '=', $province_id)
                    ->where('district_id', '=', null)
                    ->where('from_date', '=', $from_date)
                    ->where('sector_id', $this_sector_id)
                    ->get();

                if(!empty($objCheckProductionEnergyForm[0])){
                    foreach($objCheckProductionEnergyForm as $this_energyform){
                        ConsumptionEnergyForm::find($this_energyform->id)->delete();
                        EnergyFormMeta::where('energy_form_id', $this_energyform->id)->where('energy_form_topic', 'consumption')->delete();

                    }
                }

                if((!empty($the_overall['natural_qty']))){

                    $objEntryForm = new ConsumptionEnergyForm();
                    $objEntryForm->energy_id = $energy_id;
                    $objEntryForm->central_id = 1;
                    $objEntryForm->province_id = $province_id;
                    $objEntryForm->district_id = null;
                    $objEntryForm->from_date = $from_date;
                    $objEntryForm->to_date = $to_date;
                    $objEntryForm->status = 'Y';
                    $objEntryForm->sector_id = $this_sector_id;

                    $user_level_id = Auth::user()->user_group_id;
                    $user_level = UserGroup::find($user_level_id);
                    $user_id = Auth::user()->id;

                    if(!empty($user_level->user_group_slug)){
                        if($user_level->user_group_slug == 'data-entry'){
                            $objEntryForm->entered_by = $user_id;
                        }elseif($user_level->user_group_slug == 'qa' || $user_level->user_group_slug == 'supervisor'){
                            $objEntryForm->qa_by = $user_id;
                            $objEntryForm->published_by = $user_id;
                        }

                    }else{
                        $objEntryForm->entered_by = $user_id;
                        $objEntryForm->qa_by = $user_id;
                        $objEntryForm->published_by = $user_id;
                    }

                    if ($objEntryForm->save()) {
                        $objEnergyFormMeta = new EnergyFormMeta();
                        $objEnergyFormMeta->energy_form_id = $objEntryForm->id;
                        $objEnergyFormMeta->energy_form_topic = 'consumption';
                        $objEnergyFormMeta->energy_id = $energy_id;
                        $objEnergyFormMeta->energy_topic = 'sector';
                        $objEnergyFormMeta->energy_topic_id = $sector_id;
                        $objEnergyFormMeta->natural_qty = (!empty($the_overall['natural_qty'])) ? $the_overall['natural_qty'] : null;
                        $objEnergyFormMeta->natural_unit = (!empty($the_overall['natural_unit'])) ? $the_overall['natural_unit'] : null;

//                                echo '<hr />';
                        $this_st_qty = (!empty($scientific_unit_conversion_standard[$objEnergyFormMeta->natural_unit]))?($scientific_unit_conversion_standard[$objEnergyFormMeta->natural_unit]*$objEnergyFormMeta->natural_qty):'';

//                                echo '<hr />';
//                                echo '<hr />';

                        $objEnergyFormMeta->scientific_qty = $this_st_qty;

                        $objEnergyFormMeta->status = 'Y';
                        $objEnergyFormMeta->save();
                    }

                }

            }
        }

        $this_sector_obj = Sector::find($sector_id);

        $this_sector_slug = '';

        if(!empty($this_sector_obj->id)){
            $this_sector_slug = $this_sector_obj->sector_slug;
        }else{
            $this_sector_slug = Sector::where('sector_slug', 'agricultural')->pluck('sector_slug')->first();
        }

        $objLog = new LogTable();
        $log_details = array('Consumption Energy Form Entry');
        $data = array(
            'log_details'   => serialize($log_details),
            'menu_name'     => 'New Consumption Energy Form Entry',
            'created_by'    => Auth::user()->id
        );
        $objLog->insertIntoLogTable($data);

        $current_url_this = $request->url();

        return redirect($current_url_this.'?year='.$from_date.'&province_id='.$province_id.'&sector='.$this_sector_slug)
            ->with('success', 'Consumption Energy Form Entry done successfully!');

//        return redirect('dashboard/entryform/production?year='.$from_date.'&province_id='.$province_id.'&district_id='.$district_id.'&local_gov_id='.$local_gov_id)
//            ->with('success', 'Production Energy Form Entry done successfully!');

    }


    public function entryFormEnergyFormNewResourcesPost(Request $request){

//         return 11;

        $formdata = (!empty($request->formdata))?$request->formdata:array();
        $overall = (!empty($request->overall))?$request->overall:array();

        $from_date = (!empty($formdata['from_date']))?$formdata['from_date']:null;
        $to_date = (!empty($formdata['to_date']))?$formdata['to_date']:null;
        $central_id = 1;
        $province_id = (!empty($formdata['province_id']))?$formdata['province_id']:null;
        $district_id = (!empty($formdata['district_id']))?$formdata['district_id']:null;
        $local_gov_id = (!empty($formdata['local_gov_id']))?$formdata['local_gov_id']:null;

//        echo '<pre>';
//        print_r($formdata);
//        echo '<hr />';
//        print_r($overall);
//        exit();

        if(is_array($overall) && count($overall) > 0){
            foreach($overall as $the_overall) {
                if (!empty($the_overall['energy_id']) && $the_overall['energy_id'] != '') {

                    $objCheckResourcesEnergyForm = ResourcesEnergyForm::where('energy_id', '=', $the_overall['energy_id'])
                        ->where('province_id', '=', $province_id)
                        ->where('district_id', '=', $district_id)
                        ->where('local_gov_id', '=', $local_gov_id)
                        ->where('from_date', '=', $from_date)
                        ->get();

                    if(!empty($objCheckResourcesEnergyForm[0])){
                        foreach($objCheckResourcesEnergyForm as $this_energyform){

                            ResourcesEnergyForm::find($this_energyform->id)->delete();
                            EnergyFormMeta::where('energy_form_id', $this_energyform->id)
                                ->where('energy_form_topic', 'resources')
                                ->delete();

                        }
                    }

                    $objEntryForm = new ResourcesEnergyForm();
                    $objEntryForm->energy_id = $the_overall['energy_id'];
                    $objEntryForm->central_id = 1;

                    $objEntryForm->province_id = $province_id;
                    $objEntryForm->district_id = $district_id;
                    $objEntryForm->local_gov_id = $local_gov_id;
                    $objEntryForm->entered_by = Auth::user()->id;
                    $objEntryForm->from_date = $from_date;
                    $objEntryForm->to_date = $to_date;
                    $objEntryForm->status = 'Y';

                    $user_level_id = Auth::user()->user_group_id;
                    $user_level = UserGroup::find($user_level_id);
                    $user_id = Auth::user()->id;

                    if(!empty($user_level->user_group_slug)){
                        if($user_level->user_group_slug == 'data-entry'){
                            $objEntryForm->entered_by = $user_id;
                        }elseif($user_level->user_group_slug == 'qa' || $user_level->user_group_slug == 'supervisor'){
                            $objEntryForm->qa_by = $user_id;
                            $objEntryForm->published_by = $user_id;
                        }

                    }else{
                        $objEntryForm->entered_by = $user_id;
                        $objEntryForm->qa_by = $user_id;
                        $objEntryForm->published_by = $user_id;
                    }

                    if ($objEntryForm->save()) {
                        $objEnergyFormMeta = new EnergyFormMeta();
                        $objEnergyFormMeta->energy_form_id = $objEntryForm->id;
                        $objEnergyFormMeta->energy_form_topic = 'resources';
                        $objEnergyFormMeta->energy_id = $the_overall['energy_id'];
                        $objEnergyFormMeta->energy_topic = 'overall';
                        $objEnergyFormMeta->energy_topic_id = 0;
                        $objEnergyFormMeta->natural_qty = (!empty($the_overall['natural_qty'])) ? $the_overall['natural_qty'] : null;
                        $objEnergyFormMeta->natural_unit = (!empty($the_overall['natural_unit'])) ? $the_overall['natural_unit'] : null;
                        $objEnergyFormMeta->scientific_qty = (!empty($the_overall['scientific_qty'])) ? $the_overall['scientific_qty'] : null;

                        $objEnergyFormMeta->forest_area_in_ha = (!empty($the_overall['forest_area_in_ha'])) ? $the_overall['forest_area_in_ha'] : null;
                        $objEnergyFormMeta->total_residue_in_no = (!empty($the_overall['total_residue_in_no'])) ? $the_overall['total_residue_in_no'] : null;
                        $objEnergyFormMeta->livestock_in_no = (!empty($the_overall['livestock_in_no'])) ? $the_overall['livestock_in_no'] : null;
                        $objEnergyFormMeta->size_of_plant_in_cubic_meter = (!empty($the_overall['size_of_plant_in_cubic_meter'])) ? $the_overall['size_of_plant_in_cubic_meter'] : null;
                        $objEnergyFormMeta->total_plant_size_in_mega_watt = (!empty($the_overall['total_plant_size_in_mega_watt'])) ? $the_overall['total_plant_size_in_mega_watt'] : null;

                        $objEnergyFormMeta->particular_no = (!empty($the_overall['particular_no'])) ? $the_overall['particular_no'] : null;

                        $objEnergyFormMeta->status = 'Y';
                        $objEnergyFormMeta->save();
                    }
                }
            }
        }

        $objLog = new LogTable();
        $log_details = array('Resources Energy Form Entry');
        $data = array(
            'log_details'   => serialize($log_details),
            'menu_name'     => 'New Resources Energy Form Entry',
            'created_by'    => Auth::user()->id
        );
        $objLog->insertIntoLogTable($data);

        $current_url_this = $request->url();

        return redirect($current_url_this.'?year='.$from_date.'&province_id='.$province_id.'&district_id='.$district_id.'&local_gov_id='.$local_gov_id)
            ->with('success', 'Resources Energy Form Entry done successfully!');

    }


    public function entryFormEnergyFormNewConsumptionPost(Request $request){

//        return 1;

        $formdata = (!empty($request->formdata))?$request->formdata:array();

        $agricultural = (!empty($request->agricultural))?$request->agricultural:array();
        $commercial = (!empty($request->commercial))?$request->commercial:array();
        $industrial = (!empty($request->industrial))?$request->industrial:array();
        $residential = (!empty($request->residential))?$request->residential:array();
        $transportation = (!empty($request->transportation))?$request->transportation:array();
        $other = (!empty($request->other))?$request->other:array();

        $all_arr = array();
        $all_arr[] = $agricultural;
        $all_arr[] = $commercial;
        $all_arr[] = $industrial;
        $all_arr[] = $residential;
        $all_arr[] = $transportation;
        $all_arr[] = $other;

        $from_date = (!empty($formdata['from_date']))?$formdata['from_date']:null;
        $to_date = (!empty($formdata['to_date']))?$formdata['to_date']:null;
        $central_id = 1;
        $province_id = (!empty($formdata['province_id']))?$formdata['province_id']:null;
        $district_id = (!empty($formdata['district_id']))?$formdata['district_id']:null;
        $local_gov_id = (!empty($formdata['local_gov_id']))?$formdata['local_gov_id']:null;

//        echo '<pre>';
////        print_r($formdata);
//        echo '<hr />';
//        print_r($all_arr);
//        echo '</pre>';
//        echo '<hr />';

        if($province_id > 0) {
            foreach ($all_arr as $overall) {
                if (is_array($overall) && count($overall) > 0) {
                    foreach ($overall as $the_overall) {

//                    echo '<pre>';
//                    print_r($the_overall);
//                    echo '<hr />';
//                    echo '</pre>';

                        if (!empty($the_overall['energy_id']) && $the_overall['energy_id'] != '') {

                            $objCheckConsumptionEnergyForm = ConsumptionEnergyForm::where('energy_id', '=', $the_overall['energy_id'])
                                ->where('province_id', '=', $province_id)
                                ->where('district_id', '=', $district_id)
                                ->where('local_gov_id', '=', $local_gov_id)
                                ->where('from_date', '=', $from_date)
                                ->first();

                            if (!empty($objCheckConsumptionEnergyForm->id) && $objCheckConsumptionEnergyForm->id > 0) {
                                $objEntryForm = ConsumptionEnergyForm::find($objCheckConsumptionEnergyForm->id);
                            } else {
                                $objEntryForm = new ConsumptionEnergyForm();
                            }

                            $objEntryForm->energy_id = $the_overall['energy_id'];
                            $objEntryForm->central_id = 1;

                            $objEntryForm->province_id = $province_id;
                            $objEntryForm->district_id = $district_id;
                            $objEntryForm->local_gov_id = $local_gov_id;
                            $objEntryForm->from_date = $from_date;
                            $objEntryForm->to_date = $to_date;
                            $objEntryForm->status = 'Y';

                            $user_level_id = Auth::user()->user_group_id;
                            $user_level = UserGroup::find($user_level_id);
                            $user_id = Auth::user()->id;

                            if (!empty($user_level->user_group_slug)) {
                                if ($user_level->user_group_slug == 'data-entry') {
                                    $objEntryForm->entered_by = $user_id;
                                } elseif ($user_level->user_group_slug == 'qa' || $user_level->user_group_slug == 'supervisor') {
                                    $objEntryForm->qa_by = $user_id;
                                    $objEntryForm->published_by = $user_id;
                                }

                            } else {
                                $objEntryForm->entered_by = $user_id;
                                $objEntryForm->qa_by = $user_id;
                                $objEntryForm->published_by = $user_id;
                            }

                            if ($objEntryForm->save()) {

                                EnergyFormMeta::where('energy_form_id', $objEntryForm->id)
                                    ->where('energy_form_topic', 'consumption')
                                    ->where('energy_topic', 'sector')
                                    ->where('energy_id', $the_overall['energy_id'])
                                    ->where('energy_topic_id', $the_overall['energy_topic_id'])
                                    ->delete();

                                $natural_qty = (!empty($the_overall['natural_qty'])) ? $the_overall['natural_qty'] : null;

                                if ($natural_qty != '') {

                                    $objEnergyFormMeta = new EnergyFormMeta();
                                    $objEnergyFormMeta->energy_form_id = $objEntryForm->id;
                                    $objEnergyFormMeta->energy_form_topic = 'consumption';
                                    $objEnergyFormMeta->energy_id = $the_overall['energy_id'];
                                    $objEnergyFormMeta->energy_topic = 'sector';
                                    $objEnergyFormMeta->energy_topic_id = $the_overall['energy_topic_id'];
                                    $objEnergyFormMeta->natural_qty = $natural_qty;
                                    $objEnergyFormMeta->natural_unit = (!empty($the_overall['natural_unit'])) ? $the_overall['natural_unit'] : null;
                                    $objEnergyFormMeta->scientific_qty = (!empty($the_overall['scientific_qty'])) ? $the_overall['scientific_qty'] : null;
                                    $objEnergyFormMeta->status = 'Y';
                                    $objEnergyFormMeta->save();

                                }
                            }
                        }
                    }
                }
            }

        }else{

            foreach ($all_arr as $overall) {
                if (is_array($overall) && count($overall) > 0) {
                    foreach ($overall as $the_overall) {

//                    echo '<pre>';
//                    print_r($the_overall);
//                    echo '<hr />';
//                    echo '</pre>';

                        if (!empty($the_overall['energy_id']) && $the_overall['energy_id'] != '') {

                            $objCheckConsumptionEnergyForm = ConsumptionEnergyForm::where('energy_id', '=', $the_overall['energy_id'])
                                ->where('central_id', '=', $central_id)
                                ->where('province_id', '=', $province_id)
                                ->where('district_id', '=', $district_id)
                                ->where('local_gov_id', '=', $local_gov_id)
                                ->where('from_date', '=', $from_date)
                                ->first();

                            if (!empty($objCheckConsumptionEnergyForm->id) && $objCheckConsumptionEnergyForm->id > 0) {
                                $objEntryForm = ConsumptionEnergyForm::find($objCheckConsumptionEnergyForm->id);
                            } else {
                                $objEntryForm = new ConsumptionEnergyForm();
                            }

                            $objEntryForm->energy_id = $the_overall['energy_id'];
                            $objEntryForm->central_id = 1;
                            $objEntryForm->province_id = $province_id;
                            $objEntryForm->district_id = $district_id;
                            $objEntryForm->local_gov_id = $local_gov_id;
                            $objEntryForm->from_date = $from_date;
                            $objEntryForm->to_date = $to_date;
                            $objEntryForm->status = 'Y';

                            $user_level_id = Auth::user()->user_group_id;
                            $user_level = UserGroup::find($user_level_id);
                            $user_id = Auth::user()->id;

                            if (!empty($user_level->user_group_slug)) {
                                if ($user_level->user_group_slug == 'data-entry') {
                                    $objEntryForm->entered_by = $user_id;
                                } elseif ($user_level->user_group_slug == 'qa' || $user_level->user_group_slug == 'supervisor') {
                                    $objEntryForm->qa_by = $user_id;
                                    $objEntryForm->published_by = $user_id;
                                }

                            } else {
                                $objEntryForm->entered_by = $user_id;
                                $objEntryForm->qa_by = $user_id;
                                $objEntryForm->published_by = $user_id;
                            }

                            if ($objEntryForm->save()) {

//                                echo 'ID: '.$objEntryForm->id;
//                                echo '&';
//                                echo 'energy_topic_id: '.$the_overall['energy_topic_id'];
//                                echo '<pre>';
//                                print_r($the_overall);
//                                echo '</pre>';
//                                echo '<hr />';

                                EnergyFormMeta::where('energy_form_id', $objEntryForm->id)
                                    ->where('energy_form_topic', 'consumption')
                                    ->where('energy_topic', 'sector')
                                    ->where('energy_id', $the_overall['energy_id'])
                                    ->where('energy_topic_id', $the_overall['energy_topic_id'])
                                    ->delete();

                                $natural_qty = (!empty($the_overall['natural_qty'])) ? $the_overall['natural_qty'] : null;

                                if ($natural_qty != '') {

                                    $objEnergyFormMeta = new EnergyFormMeta();
                                    $objEnergyFormMeta->energy_form_id = $objEntryForm->id;
                                    $objEnergyFormMeta->energy_form_topic = 'consumption';
                                    $objEnergyFormMeta->energy_id = $the_overall['energy_id'];
                                    $objEnergyFormMeta->energy_topic = 'sector';
                                    $objEnergyFormMeta->energy_topic_id = $the_overall['energy_topic_id'];
                                    $objEnergyFormMeta->natural_qty = $natural_qty;
                                    $objEnergyFormMeta->natural_unit = (!empty($the_overall['natural_unit'])) ? $the_overall['natural_unit'] : null;
                                    $objEnergyFormMeta->scientific_qty = (!empty($the_overall['scientific_qty'])) ? $the_overall['scientific_qty'] : null;
                                    $objEnergyFormMeta->status = 'Y';
                                    $objEnergyFormMeta->save();

                                }
                            }
                        }
                    }
                }
            }
        }

//        exit();

        $objLog = new LogTable();
        $log_details = array('Consumption Energy Form Entry');
        $data = array(
            'log_details'   => serialize($log_details),
            'menu_name'     => 'New Consumption Energy Form Entry',
            'created_by'    => Auth::user()->id
        );
        $objLog->insertIntoLogTable($data);

//        exit();

        $current_url_this = $request->url();

        return redirect($current_url_this.'?year='.$from_date.'&province_id='.$province_id.'&district_id='.$district_id.'&local_gov_id='.$local_gov_id)
            ->with('success', 'Consumption Energy Form Entry done successfully!');

    }

    public function entryFormProvinceEnergyForm($province_slug, $start, $end, $energy_type_slug, $energy_slug) {

        $this_province = Location::where('location_slug', $province_slug)->where('status', 'Y')->first();

        $central = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'central')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->first();

        $this_energy = Energy::where('energy_slug', $energy_slug)->first();

        $data = new StdClass();
        $data->id = '';
        $data->energy_id = $this_energy->id;
        $data->central_id = $central->id;
        $data->province_id = $this_province->id;
        $data->district_id = '';
        $data->local_gov_id = '';
        $data->from_date = '';
        $data->to_date = '';

        $field_topics = EnergyTypeTopicMapping::where('energy_type_topic', $energy_type_slug)
            ->where('energy_id', $this_energy->id)
            ->pluck('energy_field_topic')->toArray();

        $land_types = LandType::where('status', 'Y')->get();
        $sectors = Sector::where('status', 'Y')->orderBy('entry_order', 'ASC')->get();
        $geographic_regions = GeographicRegion::where('status', 'Y')->get();
        $rivers = River::where('status', 'Y')->get();
        $overall = new stdClass();
        $overall->natural_unit = '';

        $units = Unit::join('energy_conversion', 'energy_conversion.natural_unit', '=', 'unit.id')
            ->where('unit.status', 'Y')
            ->where('energy_conversion.energy_id', $this_energy->id)
            ->select('unit.*', 'energy_conversion.scientific_qty')
            ->groupBy('unit.id')
            ->get();

        return view('dashboard/energy_form_add')
            ->with('this_province', $this_province)
            ->with('data', $data)
            ->with('this_energy', $this_energy)
            ->with('central', $central)
            ->with('land_types', $land_types)
            ->with('sectors', $sectors)
            ->with('geographic_regions', $geographic_regions)
            ->with('rivers', $rivers)
            ->with('overall', $overall)
            ->with('units', $units)
            ->with('field_topics', $field_topics)
            ->with('start', $start)
            ->with('end', $end)
            ->with('energy_type', $energy_type_slug)
            ->with('route', 'add');
    }

    public function entryFormDistrictEnergyForm($province_slug, $district_slug, $start, $end, $energy_type_slug, $energy_slug) {

        $this_province = Location::where('location_slug', $province_slug)->where('status', 'Y')->first();

        $this_district = Location::where('location_slug', $district_slug)->where('status', 'Y')->first();

        $central = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'central')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->first();

        $this_energy = Energy::where('energy_slug', $energy_slug)->first();

        $data = new StdClass();
        $data->id = '';
        $data->energy_id = $this_energy->id;
        $data->central_id = $central->id;
        $data->province_id = $this_province->id;
        $data->district_id = $this_district->id;
        $data->local_gov_id = '';
        $data->from_date = '';
        $data->to_date = '';

        $field_topics = EnergyTypeTopicMapping::where('energy_type_topic', $energy_type_slug)
            ->where('energy_id', $this_energy->id)
            ->pluck('energy_field_topic')->toArray();

        $land_types = LandType::where('status', 'Y')->get();
        $sectors = Sector::where('status', 'Y')->orderBy('entry_order', 'ASC')->get();
        $geographic_regions = GeographicRegion::where('status', 'Y')->get();
        $rivers = River::where('status', 'Y')->get();
        $overall = new stdClass();
        $overall->natural_unit = '';

        $units = Unit::join('energy_conversion', 'energy_conversion.natural_unit', '=', 'unit.id')
            ->where('unit.status', 'Y')
            ->where('energy_conversion.energy_id', $this_energy->id)
            ->select('unit.*', 'energy_conversion.scientific_qty')
            ->groupBy('unit.id')
            ->get();

        return view('dashboard/energy_form_add')
            ->with('this_province', $this_province)
            ->with('this_district', $this_district)
            ->with('data', $data)
            ->with('this_energy', $this_energy)
            ->with('central', $central)
            ->with('land_types', $land_types)
            ->with('sectors', $sectors)
            ->with('geographic_regions', $geographic_regions)
            ->with('rivers', $rivers)
            ->with('units', $units)
            ->with('overall', $overall)
            ->with('field_topics', $field_topics)
            ->with('start', $start)
            ->with('end', $end)
            ->with('energy_type', $energy_type_slug)
            ->with('route', 'add');
    }

    public function entryFormLocalEnergyForm($province_slug, $district_slug, $local_slug, $start, $end, $energy_type_slug, $energy_slug) {

        $this_province = Location::where('location_slug', $province_slug)->where('status', 'Y')->first();

        $this_district = Location::where('location_slug', $district_slug)->where('status', 'Y')->first();

        $this_local = Location::where('location_slug', $local_slug)->where('status', 'Y')->first();

        $central = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'central')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->first();

        $this_energy = Energy::where('energy_slug', $energy_slug)->first();

        $data = new StdClass();
        $data->id = '';
        $data->energy_id = $this_energy->id;
        $data->central_id = $central->id;
        $data->province_id = $this_province->id;
        $data->district_id = $this_district->id;
        $data->local_gov_id = '';
        $data->from_date = '';
        $data->to_date = '';

        $field_topics = EnergyTypeTopicMapping::where('energy_type_topic', $energy_type_slug)
            ->where('energy_id', $this_energy->id)
            ->pluck('energy_field_topic')->toArray();

//        $field_topics = array('production', 'resources', 'consumption', 'import', 'export');

        $land_types = LandType::where('status', 'Y')->get();
        $sectors = Sector::where('status', 'Y')->orderBy('entry_order', 'ASC')->get();
        $geographic_regions = GeographicRegion::where('status', 'Y')->get();
        $rivers = River::where('status', 'Y')->get();
        $overall = new stdClass();
        $overall->natural_unit = '';

        $units = Unit::join('energy_conversion', 'energy_conversion.natural_unit', '=', 'unit.id')
            ->where('unit.status', 'Y')
            ->where('energy_conversion.energy_id', $this_energy->id)
            ->select('unit.*', 'energy_conversion.scientific_qty')
            ->groupBy('unit.id')
            ->get();

//        echo '<pre>';
//        print_r(json_decode($units));
//        echo '</pre>';
//        exit();

        return view('dashboard/energy_form_add')
            ->with('this_province', $this_province)
            ->with('this_district', $this_district)
            ->with('this_local', $this_local)
            ->with('data', $data)
            ->with('this_energy', $this_energy)
            ->with('central', $central)
            ->with('land_types', $land_types)
            ->with('sectors', $sectors)
            ->with('geographic_regions', $geographic_regions)
            ->with('rivers', $rivers)
            ->with('units', $units)
            ->with('overall', $overall)
            ->with('field_topics', $field_topics)
            ->with('start', $start)
            ->with('end', $end)
            ->with('energy_type', $energy_type_slug)
            ->with('route', 'add');
    }

    public function postCreate(Request $request) {
        $formdata = $request->formdata;
        $land_type = $request->land_type;
        $sector = $request->sector;
        $energy_type = $request->energy_type;
        $overall = $request->overall;

        $objProductionEnergyForm = new ProductionEnergyForm();
        $objProductionEnergyForm->energy_id = $formdata['energy_id'];
        $objProductionEnergyForm->central_id = (!empty($formdata['central_id']))?$formdata['central_id']:null;
        $objProductionEnergyForm->province_id = (!empty($formdata['province_id']))?$formdata['province_id']:null;
        $objProductionEnergyForm->district_id = (!empty($formdata['district_id']))?$formdata['district_id']:null;
        $objProductionEnergyForm->local_gov_id = (!empty($formdata['local_gov_id']))?$formdata['local_gov_id']:null;
        $objProductionEnergyForm->from_date = (!empty($formdata['from_date']))?$formdata['from_date']:null;
        $objProductionEnergyForm->to_date = (!empty($formdata['to_date']))?$formdata['to_date']:null;
        $objProductionEnergyForm->status = 'Y';

        if($objProductionEnergyForm->save()){

            $energy_form_id = $objProductionEnergyForm->id;
            $energy_id = $formdata['energy_id'];
            $energy_topic = 'overall';
            $energy_topic_ids = $overall['id'];
            $natural_qty = $overall['natural_qty'];
            $natural_unit = $overall['natural_unit'];
            $scientific_qty = $overall['scientific_qty'];
            $scientific_unit = $overall['scientific_unit'];

            if(is_array($overall)) {
                $objEnergyFormMeta = new EnergyFormMeta();
                $objEnergyFormMeta->energy_form_id = $energy_form_id;
                $objEnergyFormMeta->energy_id = $energy_id;
                $objEnergyFormMeta->energy_topic = $energy_topic;
                $objEnergyFormMeta->energy_topic_id = $energy_topic_ids;
                $objEnergyFormMeta->natural_qty = (!empty($natural_qty))?$natural_qty:null;
                $objEnergyFormMeta->natural_unit = (!empty($natural_unit))?$natural_unit:null;
                $objEnergyFormMeta->scientific_qty = (!empty($scientific_qty))?$scientific_qty:null;
                $objEnergyFormMeta->scientific_unit = (!empty($scientific_unit))?$scientific_unit:null;
                $objEnergyFormMeta->energy_form_topic = 'overall';
                $objEnergyFormMeta->status = 'Y';

                $objEnergyFormMeta->save();
            }

            if(is_array($land_type)){
                $energy_form_id = $objProductionEnergyForm->id;
                $energy_id = $formdata['energy_id'];
                $energy_topic = 'land_type';
                $energy_topic_ids = $land_type['id'];
                $natural_qty = $land_type['natural_qty'];
                $natural_unit = $land_type['natural_unit'];
                $scientific_qty = $land_type['scientific_qty'];
                $scientific_unit = $land_type['scientific_unit'];

                if(is_array($energy_topic_ids)){
                    for($i = 0; $i < count($energy_topic_ids); $i++){
                        $objEnergyFormMeta = new EnergyFormMeta();
                        $objEnergyFormMeta->energy_form_id = $energy_form_id;
                        $objEnergyFormMeta->energy_id = $energy_id;
                        $objEnergyFormMeta->energy_topic = $energy_topic;
                        $objEnergyFormMeta->energy_topic_id = $energy_topic_ids[$i];
                        $objEnergyFormMeta->natural_qty = (!empty($natural_qty[$i]))?$natural_qty[$i]:null;
                        $objEnergyFormMeta->natural_unit = (!empty($natural_unit[$i]))?$natural_unit[$i]:null;
                        $objEnergyFormMeta->scientific_qty = (!empty($scientific_qty[$i]))?$scientific_qty[$i]:null;
                        $objEnergyFormMeta->scientific_unit = (!empty($scientific_unit[$i]))?$scientific_unit[$i]:null;
                        $objEnergyFormMeta->energy_form_topic = 'production';
                        $objEnergyFormMeta->status = 'Y';

                        $objEnergyFormMeta->save();
                    }
                }

            }

            if(is_array($sector)){
                $energy_form_id = $objProductionEnergyForm->id;
                $energy_id = $formdata['energy_id'];
                $energy_topic = 'sector';
                $energy_topic_ids = $sector['id'];
                $natural_qty = $sector['natural_qty'];
                $natural_unit = $sector['natural_unit'];
                $scientific_qty = $sector['scientific_qty'];
                $scientific_unit = $sector['scientific_unit'];

                if(is_array($energy_topic_ids)){
                    for($i = 0; $i < count($energy_topic_ids); $i++){
                        $objEnergyFormMeta = new EnergyFormMeta();
                        $objEnergyFormMeta->energy_form_id = $energy_form_id;
                        $objEnergyFormMeta->energy_id = $energy_id;
                        $objEnergyFormMeta->energy_topic = $energy_topic;
                        $objEnergyFormMeta->energy_topic_id = $energy_topic_ids[$i];
                        $objEnergyFormMeta->natural_qty = (!empty($natural_qty[$i]))?$natural_qty[$i]:null;
                        $objEnergyFormMeta->natural_unit = (!empty($natural_unit[$i]))?$natural_unit[$i]:null;
                        $objEnergyFormMeta->scientific_qty = (!empty($scientific_qty[$i]))?$scientific_qty[$i]:null;
                        $objEnergyFormMeta->scientific_unit = (!empty($scientific_unit[$i]))?$scientific_unit[$i]:null;
                        $objEnergyFormMeta->energy_form_topic = 'production';
                        $objEnergyFormMeta->status = 'Y';

                        $objEnergyFormMeta->save();
                    }
                }

            }

            if(is_array($energy_type)){
                $energy_form_id = $objProductionEnergyForm->id;
                $energy_id = $formdata['energy_id'];
                $energy_topic = 'energy_type';
                $energy_topic_ids = $energy_type['id'];
                $natural_qty = $energy_type['natural_qty'];
                $natural_unit = $energy_type['natural_unit'];
                $scientific_qty = $energy_type['scientific_qty'];
                $scientific_unit = $energy_type['scientific_unit'];

                if(is_array($energy_topic_ids)){
                    for($i = 0; $i < count($energy_topic_ids); $i++){
                        $objEnergyFormMeta = new EnergyFormMeta();
                        $objEnergyFormMeta->energy_form_id = $energy_form_id;
                        $objEnergyFormMeta->energy_id = $energy_id;
                        $objEnergyFormMeta->energy_topic = $energy_topic;
                        $objEnergyFormMeta->energy_topic_id = $energy_topic_ids[$i];
                        $objEnergyFormMeta->natural_qty = (!empty($natural_qty[$i]))?$natural_qty[$i]:null;
                        $objEnergyFormMeta->natural_unit = (!empty($natural_unit[$i]))?$natural_unit[$i]:null;
                        $objEnergyFormMeta->scientific_qty = (!empty($scientific_qty[$i]))?$scientific_qty[$i]:null;
                        $objEnergyFormMeta->scientific_unit = (!empty($scientific_unit[$i]))?$scientific_unit[$i]:null;
                        $objEnergyFormMeta->energy_form_topic = 'production';
                        $objEnergyFormMeta->status = 'Y';
                        $objEnergyFormMeta->save();
                    }
                }

            }

            $objLog = new LogTable();
            $log_details = array('Production Energy Form Entry for energy ID: '.$energy_id);
            $data = array(
                'log_details'   => serialize($log_details),
                'menu_name'     => 'New Production Energy Form Entry',
                'created_by'    => Auth::user()->id
            );
            $objLog->insertIntoLogTable($data);

//            return redirect('dashboard/production-energy-form/edit/'.$objProductionEnergyForm->id)->with('success', 'Production Energy Form Entry done successfully!');

        }else{
//            return redirect('dashboard/production-energy-form')->with('error', 'Production Energy Form Entry cannot be added!');
        }

    }

    public function reportEnergyYear(Request $request){

        $energy_years = EnergyYear::where('status', 'Y')->orderBy('energy_year_start', 'ASC')->get();

//        echo '<pre>';
//        print_r(json_decode($energy_years));
//        exit();

        return view('dashboard/report_energy_year_listing')
            ->with('url', $request->url())
            ->with('energy_years', $energy_years);

    }

    public function reportEnergyTypeListing($start, $end, Request $request) {

        $energy_types = EnergyTypes::where('status', 'Y')->get();

        return view('dashboard/report_energy_type_listing')
            ->with('url', $request->url())
            ->with('start', $start)
            ->with('end', $end)
            ->with('energy_types', $energy_types);

    }

    public function reportEnergyTypeEnergyTopicListing($start, $end, $energy_type_slug, Request $request) {

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $energy_topics = EnergyFormMeta::where('energy_form_topic', '=', $energy_type_slug)
            ->where('energy_topic', '!=', 'overall')
            ->groupBy('energy_topic')
            ->pluck('energy_topic');

                    // echo '<hr><pre>';
                    // print_r($energy_topics);
                    // echo '</pre><hr>';
                    
                    // exit();

        if(!empty($this_energy_type)){

            $energy_lists = Energy::where('status', 'Y')->get();

            return view('dashboard/report_energy_type_energy_topic_listing')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topics', $energy_topics)
                ->with('energy_lists', $energy_lists);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }

    }

    public function reportProvinceWiseEnergyTypeEnergyTopicListing($start, $end, $province_slug, $energy_type_slug, Request $request) {

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $energy_topics = EnergyFormMeta::where('energy_form_topic', '=', $energy_type_slug)
            ->groupBy('energy_topic')
            ->pluck('energy_topic');

                    // echo '<hr><pre>';
                    // print_r($energy_topics);
                    // echo '</pre><hr>';

                    // exit();

        if(!empty($this_energy_type)){

            $energy_lists = Energy::where('status', 'Y')->get();

            return view('dashboard/report_energy_type_energy_topic_listing')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topics', $energy_topics)
                ->with('province_slug', $province_slug)
                ->with('energy_lists', $energy_lists);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }

    }

    public function reportEnergyTypeEnergyTopicLocationWise($start, $end, $energy_type_slug, $energy_topic, Request $request) {

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug')
            ->get();

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_province_listing')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('provinces', $provinces);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }

    }

    public function reportCentralProductionEnergyTopic($start, $end, $energy_topic, Request $request) {

        $energy_type_slug = 'production';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'ASC')
            ->get();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('production_energy_form.province_id', '=', $the_province->id)
                            ->where('production_energy_form.from_date', '=', $start)
                            ->where('production_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('production_energy_form.province_id', '=', $the_province->id)
                            ->where('production_energy_form.from_date', '=', $start)
                            ->where('production_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                            ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('production_energy_form.province_id', '=', $the_province->id)
                            ->where('production_energy_form.from_date', '=', $start)
                            ->where('production_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->river_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'sector'){
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('production_energy_form.province_id', '=', $the_province->id)
                            ->where('production_energy_form.from_date', '=', $start)
                            ->where('production_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->sector_name] = $inner_col;
                }
            }
        }else{
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', 'sector')
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                            ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', 'sector')
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('production_energy_form.province_id', '=', $the_province->id)
                            ->where('production_energy_form.from_date', '=', $start)
                            ->where('production_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->sector_name] = $inner_col;
                }
            }
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', 'geographic_region')
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', 'geographic_region')
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('production_energy_form.province_id', '=', $the_province->id)
                            ->where('production_energy_form.from_date', '=', $start)
                            ->where('production_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_name] = $inner_col;
                }
            }
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', 'land_type')
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', 'land_type')
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('production_energy_form.province_id', '=', $the_province->id)
                            ->where('production_energy_form.from_date', '=', $start)
                            ->where('production_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_name] = $inner_col;
                }
            }

        }

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('provinces', $provinces)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);
        }else{
            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');
        }
    }

    public function reportEnergySupplyDemandBalance($start, $end, Request $request) {

        $production = 'production';

        $import = 'import';

        $export = 'export';

        $energy_topic = 'sector';

        $final_result = array();

        $col_keys = '';

        if($energy_topic == 'sector'){


            $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->select('energy.*', 'fuel_type.fuel_type_name')
                ->where('energy_type_topic_mapping.energy_field_topic', '=', $energy_topic)
                ->where('energy.status', '=', 'Y')
                ->groupBy('energy.id')
                ->orderBy('energy.energy_order', 'asc')
                ->get();

//            $rows = Energy::join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
//                ->select('energy.*', 'fuel_type.fuel_type_name')
//                ->groupBy('energy.id')
//                ->orderBy('energy.energy_order', 'asc')
//                ->get();

            $col_keys = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.sector_name as key', 'sector.id')
                ->get();

            $col_send = array();
            array_push($col_send, 'Production');
            array_push($col_send, 'Import');
            array_push($col_send, 'Export');
            array_push($col_send, 'Total Primary Supply/Sale');
            array_push($col_send, 'Statistical Differences');
            array_push($col_send, 'Thermal Generation');
            array_push($col_send, 'Energy Loss');
            array_push($col_send, 'Final Supply');

            if(!empty($col_keys)){
                foreach($col_keys as $this_col_key){
                    array_push($col_send, $this_col_key->key);
                }
            }

//            echo '<pre>';
//            print_r(json_decode($col_production_keys));
//            exit();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;

                    $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;

                    $objEnergyMetaForm = EnergyFormMeta::join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                        ->where('energy_form_meta.energy_id', '=', $the_row->id)
                        ->where('energy_form_meta.energy_form_topic', '=', 'production')
                        ->where('production_energy_form.from_date', '=', $start)
                        ->where('production_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();

                    $inner_col[$counter] += (float)$objEnergyMetaForm->qty;

                    $counter++;

                    $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;

                    $objEnergyMetaForm = EnergyFormMeta::join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                        ->where('energy_form_meta.energy_id', '=', $the_row->id)
                        ->where('energy_form_meta.energy_form_topic', '=', 'import')
                        ->where('import_energy_form.from_date', '=', $start)
                        ->where('import_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();

                    $inner_col[$counter] += (float)$objEnergyMetaForm->qty;

                    $counter++;

                    $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;

                    $objEnergyMetaForm = EnergyFormMeta::join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                        ->where('energy_form_meta.energy_id', '=', $the_row->id)
                        ->where('energy_form_meta.energy_form_topic', '=', 'export')
                        ->where('export_energy_form.from_date', '=', $start)
                        ->where('export_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                    $counter++;

                    // Total Primary Supply/Sales
                    $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                    $inner_col[$counter] += ($inner_col[0] + $inner_col[1] + $inner_col[2]);
                    $counter++;

                    // Statistical Differences
                    $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                    $inner_col[$counter] = 0;
                    $counter++;

                    // Thermal Generation
                    $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                    $inner_col[$counter] = 0;
                    $counter++;

                    // Energy Loss
                    $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                    $inner_col[$counter] = 0;
                    $counter++;

                    // Final Supply
                    $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                    $inner_col[$counter] += ($inner_col[3] - $inner_col[4] - $inner_col[5] - $inner_col[6]);
                    $counter++;

                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $objEnergyMetaForm = EnergyFormMeta::join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('production_energy_form.from_date', '=', $start)
                            ->where('production_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $objEnergyMetaForm = EnergyFormMeta::join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('resources_energy_form.from_date', '=', $start)
                            ->where('resources_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $objEnergyMetaForm = EnergyFormMeta::join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('import_energy_form.from_date', '=', $start)
                            ->where('import_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $objEnergyMetaForm = EnergyFormMeta::join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('export_energy_form.from_date', '=', $start)
                            ->where('export_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
//                        array_push($inner_col, json_decode($objEnergyMetaForm));
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }

//                echo '<pre>';
//                print_r($final_result);
//                exit();
            }
        }

        return view('dashboard/report_energy_supply_demand_balance')
            ->with('start', $start)
            ->with('end', $end)
            ->with('col_send', $col_send)
            ->with('final_result', $final_result);

    }



    public function reportEnergyVersesEnergyTypeTabular($start, $end, $energy_type_slug, $energy_topic, Request $request) {


        $final_result = array();

        $col_keys = '';

//        $rows = Energy::join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
//            ->select('energy.*', 'fuel_type.fuel_type_name')
//            ->groupBy('energy.id')
//            ->orderBy('energy.energy_order', 'asc')
//            ->get();

        $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
            ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
            ->select('energy.*', 'fuel_type.fuel_type_name')
            ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
            ->where('energy.status', '=', 'Y')
            ->groupBy('energy.id')
            ->orderBy('energy.energy_order', 'asc')
            ->get();

        if($energy_topic == 'river') {
            $col_keys = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.river_name as key', 'river.id')
                ->get();
        }else if($energy_topic == 'land_type') {
            $col_keys = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.land_type_name as key', 'land_type.id')
                ->get();
        }else if($energy_topic == 'geographic_region') {
            $col_keys = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.geographic_region_name as key', 'geographic_region.id')
                ->get();
        }else{
            $col_keys = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.sector_name as key', 'sector.id')
                ->get();
        }

        $col_send = array();

        if(!empty($col_keys)){
            foreach($col_keys as $this_col_key){
                array_push($col_send, $this_col_key->key);
            }
        }

        if($energy_type_slug == 'consumption'){ // consumption_energy_form
            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }
        }else if($energy_type_slug == 'production'){ // production_energy_form
            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('production_energy_form.from_date', '=', $start)
                            ->where('production_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }
        }else if($energy_type_slug == 'resources'){ // resources_energy_form
            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('resources_energy_form.from_date', '=', $start)
                            ->where('resources_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }
        }else if($energy_type_slug == 'import'){ // import_energy_form
            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('import_energy_form.from_date', '=', $start)
                            ->where('import_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }
        }else if($energy_type_slug == 'export'){ // export_energy_form
            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('export_energy_form.from_date', '=', $start)
                            ->where('export_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }
        }

        return view('dashboard/report_energy_verses_energy_type_tabular')
        ->with('start', $start)
        ->with('end', $end)
        ->with('col_send', $col_send)
        ->with('energy_type_slug', $energy_type_slug)
        ->with('energy_topic', $energy_topic)
        ->with('final_result', $final_result);

    }



    public function reportProvinceWiseEnergyVersesEnergyTypeTabular($start, $end, $province_slug, $energy_type_slug, $energy_topic, Request $request) {

//        return 1;

        $final_result = array();

        $col_keys = '';

//        $rows = Energy::join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
//            ->select('energy.*', 'fuel_type.fuel_type_name')
//            ->groupBy('energy.id')
//            ->orderBy('energy.energy_order', 'asc')
//            ->get();

        $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
            ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
            ->select('energy.*', 'fuel_type.fuel_type_name')
            ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
            ->where('energy.status', '=', 'Y')
            ->groupBy('energy.id')
            ->orderBy('energy.energy_order', 'asc')
            ->get();

        if($energy_topic == 'river') {
            $col_keys = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.river_name as key', 'river.id')
                ->orderBy('river.entry_order', 'asc')
                ->get();
        }else if($energy_topic == 'land_type') {
            $col_keys = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.land_type_name as key', 'land_type.id')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();
        }else if($energy_topic == 'geographic_region') {
            $col_keys = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.geographic_region_name as key', 'geographic_region.id')
                ->orderBy('geographic_region.entry_order', 'asc')
                ->get();
        }else{
            $col_keys = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', 'sector')
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.sector_name as key', 'sector.id')
                ->orderBy('sector.entry_order', 'asc')
                ->get();
        }

        $col_send = array();

        if(!empty($col_keys)){
            foreach($col_keys as $this_col_key){
                array_push($col_send, $this_col_key->key);
            }
        }

//        echo '<pre>';
//        print_r(json_decode($rows));
//        echo '<hr />';
//        print_r($col_send);
//        echo '</pre>';
//        exit();

        if($energy_type_slug == 'consumption'){ // consumption_energy_form
            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->join('location', 'consumption_energy_form.province_id', '=', 'location.id')
                            ->where('location.location_slug', '=', $province_slug)
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }
        }else if($energy_type_slug == 'production'){ // production_energy_form
            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->join('location', 'production_energy_form.province_id', '=', 'location.id')
                            ->where('location.location_slug', '=', $province_slug)
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('production_energy_form.from_date', '=', $start)
                            ->where('production_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }
        }else if($energy_type_slug == 'resources'){ // resources_energy_form
            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                            ->join('location', 'resources_energy_form.province_id', '=', 'location.id')
                            ->where('location.location_slug', '=', $province_slug)
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('resources_energy_form.from_date', '=', $start)
                            ->where('resources_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }
        }else if($energy_type_slug == 'import'){ // import_energy_form
            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                            ->join('location', 'import_energy_form.province_id', '=', 'location.id')
                            ->where('location.location_slug', '=', $province_slug)
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('import_energy_form.from_date', '=', $start)
                            ->where('import_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }
        }else if($energy_type_slug == 'export'){ // export_energy_form
            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                            ->join('location', 'export_energy_form.province_id', '=', 'location.id')
                            ->where('location.location_slug', '=', $province_slug)
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('export_energy_form.from_date', '=', $start)
                            ->where('export_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }
        }

        return view('dashboard/report_energy_verses_energy_type_tabular')
        ->with('start', $start)
        ->with('end', $end)
        ->with('col_send', $col_send)
        ->with('energy_type_slug', $energy_type_slug)
        ->with('energy_topic', $energy_topic)
        ->with('final_result', $final_result);

    }

    public function reportCentralProductionEnergyTopicTrend($start, $end, $energy_topic, Request $request) {

        $energy_type_slug = 'production';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->orderBy('geographic_region.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){

                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('production_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('production_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->orderBy('river.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                            ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('production_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->river_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'sector'){
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->orderBy('sector.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('production_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();

                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }

                    $final_result[$the_row->sector_name] = $inner_col;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct_line')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralEnergyTypeEnergyTrend($start, $end, $energy_type_slug, Request $request) {

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        if(!empty($this_energy_type)){

            $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->select('energy.*', 'fuel_type.fuel_type_name')
                ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
                ->where('energy.status', '=', 'Y')
                ->groupBy('energy.id')
                ->orderBy('energy.energy_order', 'asc')
                ->get();
//
//            $rows = Energy::join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
//                ->select('energy.*', 'fuel_type.fuel_type_name')
//                ->groupBy('energy.id')
//                ->orderBy('energy.energy_order', 'asc')
//                ->get();

            if (!empty($rows)) {
                foreach ($rows as $the_row) {
                    $inner_col = array();
                    $inner_col_count = 0;

                    for ($year = $start; $year < $end; $year++) {

                        $inner_col[$inner_col_count] = (!empty($inner_col[$inner_col_count])) ? $inner_col[$inner_col_count] : 0;

                        if ($energy_type_slug == 'production') { // production_energy_form
                            $objEnergyMetaForm = EnergyFormMeta::join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                                ->where('energy_form_meta.energy_topic', '!=', 'overall')
                                ->where('energy_form_meta.energy_id', '=', $the_row->id)
                                ->where('production_energy_form.from_date', '=', $year)
                                ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                                ->first();
                            $inner_col[$inner_col_count] += (float)$objEnergyMetaForm->qty;
                        } else if ($energy_type_slug == 'resources') { // resources_energy_form
                            $objEnergyMetaForm = EnergyFormMeta::join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                                ->where('energy_form_meta.energy_topic', '!=', 'overall')
                                ->where('energy_form_meta.energy_id', '=', $the_row->id)
                                ->where('resources_energy_form.from_date', '=', $year)
                                ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                                ->first();
                            $inner_col[$inner_col_count] += (float)$objEnergyMetaForm->qty;
                        } else if ($energy_type_slug == 'import') { // import_energy_form
                            $objEnergyMetaForm = EnergyFormMeta::join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                                ->where('energy_form_meta.energy_topic', '=', 'overall')
                                ->where('energy_form_meta.energy_id', '=', $the_row->id)
                                ->where('import_energy_form.from_date', '=', $year)
                                ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                                ->first();
                            $inner_col[$inner_col_count] += (float)$objEnergyMetaForm->qty;
                        } else if ($energy_type_slug == 'export') { // export_energy_form
                            $objEnergyMetaForm = EnergyFormMeta::join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                                ->where('energy_form_meta.energy_topic', '=', 'overall')
                                ->where('energy_form_meta.energy_id', '=', $the_row->id)
                                ->where('export_energy_form.from_date', '=', $year)
                                ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                                ->first();
                            $inner_col[$inner_col_count] += (float)$objEnergyMetaForm->qty;
                        } else { // consumption_energy_form

                            $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                                ->where('energy_form_meta.energy_topic', '!=', 'overall')
                                ->where('energy_form_meta.energy_id', '=', $the_row->id)
                                ->where('consumption_energy_form.from_date', '=', $year)
                                ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                                ->first();
                            $inner_col[$inner_col_count] += (float)$objEnergyMetaForm->qty;
                        }
                        $inner_col_count++;
                    }
                    $final_result[$the_row->fuel_type_name . '-' . $the_row->energy_name] = $inner_col;
                }
            }

//            echo '<pre>';
//            print_r($final_result);
//            echo '</pre>';
//            exit();

            return view('dashboard/report_energy_type_energy_direct_line')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralConsumptionEnergyTopicTrend($start, $end, $energy_topic, Request $request) {

        $energy_type_slug = 'consumption';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->orderBy('geographic_region.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){

                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->orderBy('river.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->river_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'sector'){
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->orderBy('sector.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();

//                        echo '<pre>';
//                        print_r(json_decode($objEnergyMetaForm));

                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }

                    $final_result[$the_row->sector_name] = $inner_col;
                }
            }
        }

//        exit();

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct_line')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralResourcesEnergyTopicTrend($start, $end, $energy_topic, Request $request) {

        $energy_type_slug = 'resources';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->orderBy('geographic_region.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){

                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('resources_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('resources_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->orderBy('river.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                            ->join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('resources_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->river_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'sector'){
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->orderBy('sector.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('resources_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();

//                        echo '<pre>';
//                        print_r(json_decode($objEnergyMetaForm));

                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }

                    $final_result[$the_row->sector_name] = $inner_col;
                }
            }
        }

//        exit();

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct_line')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralImportEnergyTopicTrend($start, $end, $energy_topic, Request $request) {

        $energy_type_slug = 'import';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->orderBy('geographic_region.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){

                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('import_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('import_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->orderBy('river.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                            ->join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('import_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->river_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'sector'){
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->orderBy('sector.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('import_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();

//                        echo '<pre>';
//                        print_r(json_decode($objEnergyMetaForm));

                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }

                    $final_result[$the_row->sector_name] = $inner_col;
                }
            }
        }

//        exit();

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct_line')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralExportEnergyTopicTrend($start, $end, $energy_topic, Request $request) {

        $energy_type_slug = 'export';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->orderBy('geographic_region.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){

                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('export_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('export_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->orderBy('river.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                            ->join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('export_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->river_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'sector'){
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->orderBy('sector.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('export_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();

//                        echo '<pre>';
//                        print_r(json_decode($objEnergyMetaForm));

                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }

                    $final_result[$the_row->sector_name] = $inner_col;
                }
            }
        }

//        exit();

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct_line')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralProductionEnergyTopicPie($start, $end, $energy_topic, Request $request) {

        $energy_type_slug = 'production';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

//        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
//            ->where('location_type.location_type_slug', 'province')
//            ->where('location.status', 'Y')
//            ->select('location.*')
//            ->orderBy('location.location_slug', 'ASC')
//            ->get();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->orderBy('geographic_region.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('production_energy_form.from_date', '=', $start)
                        ->where('production_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->geographic_region_name] = json_decode($objEnergyMetaForm);
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                        ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('production_energy_form.from_date', '=', $start)
                        ->where('production_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->land_type_name] = $objEnergyMetaForm;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->orderBy('river.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                        ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('production_energy_form.from_date', '=', $start)
                        ->where('production_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->river_name] = $objEnergyMetaForm;
                }
            }
        }elseif($energy_topic == 'sector'){
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->orderBy('sector.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('production_energy_form.from_date', '=', $start)
                        ->where('production_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->sector_name] = $objEnergyMetaForm;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct_pie')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralConsumptionEnergyTopicPie($start, $end, $energy_topic, Request $request) {

        $energy_type_slug = 'consumption';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->orderBy('geographic_region.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->geographic_region_name] = json_decode($objEnergyMetaForm);
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->land_type_name] = $objEnergyMetaForm;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->orderBy('river.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->river_name] = $objEnergyMetaForm;
                }
            }
        }elseif($energy_topic == 'sector'){
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->orderBy('sector.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->sector_name] = $objEnergyMetaForm;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct_pie')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportProvinceWiseConsumptionEnergyTopicPie($start, $end, $province_slug, $energy_topic, Request $request) {

        $energy_type_slug = 'consumption';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->orderBy('geographic_region.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->geographic_region_name] = json_decode($objEnergyMetaForm);
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->land_type_name] = $objEnergyMetaForm;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->orderBy('river.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->river_name] = $objEnergyMetaForm;
                }
            }
        }else{
            $energy_topic = 'sector';
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->orderBy('sector.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->join('location', 'consumption_energy_form.province_id', '=', 'location.id')
                        ->where('location.location_slug', '=', $province_slug)
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->sector_name] = $objEnergyMetaForm;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct_pie')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }
    }


    public function reportProvinceWiseConsumptionEnergyTopicFuelTypePie($start, $end, $province_slug, $energy_topic, Request $request) {

        $energy_type_slug = 'consumption';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        if($energy_topic == 'geographic_region'){

            $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->select('fuel_type.*')
                ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
                ->where('energy.status', '=', 'Y')
                ->groupBy('fuel_type.id')
                ->orderBy('energy.energy_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->join('location', 'consumption_energy_form.province_id', '=', 'location.id')
                        ->join('energy', 'energy_form_meta.energy_id', '=', 'energy.id')
                        ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                        ->where('location.location_slug', '=', $province_slug)
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('fuel_type.id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->fuel_type_name] = $objEnergyMetaForm;
                }
            }

        }elseif($energy_topic == 'land_type'){

            $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->select('fuel_type.*')
                ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
                ->where('energy.status', '=', 'Y')
                ->groupBy('fuel_type.id')
                ->orderBy('energy.energy_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->join('location', 'consumption_energy_form.province_id', '=', 'location.id')
                        ->join('energy', 'energy_form_meta.energy_id', '=', 'energy.id')
                        ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                        ->where('location.location_slug', '=', $province_slug)
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('fuel_type.id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->fuel_type_name] = $objEnergyMetaForm;
                }
            }

        }elseif($energy_topic == 'river'){

            $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->select('fuel_type.*')
                ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
                ->where('energy.status', '=', 'Y')
                ->groupBy('fuel_type.id')
                ->orderBy('energy.energy_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->join('location', 'consumption_energy_form.province_id', '=', 'location.id')
                        ->join('energy', 'energy_form_meta.energy_id', '=', 'energy.id')
                        ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                        ->where('location.location_slug', '=', $province_slug)
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('fuel_type.id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->fuel_type_name] = $objEnergyMetaForm;
                }
            }

        }else{
            $energy_topic = 'sector';

            $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->select('fuel_type.*')
                ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
                ->where('energy.status', '=', 'Y')
                ->groupBy('fuel_type.id')
                ->orderBy('energy.energy_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->join('location', 'consumption_energy_form.province_id', '=', 'location.id')
                        ->join('energy', 'energy_form_meta.energy_id', '=', 'energy.id')
                        ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                        ->where('location.location_slug', '=', $province_slug)
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('fuel_type.id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->fuel_type_name] = $objEnergyMetaForm;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct_pie')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }
    }


    public function reportProvinceWiseConsumptionEnergyTopicEnergyPie($start, $end, $province_slug, $energy_topic, Request $request) {

        $energy_type_slug = 'consumption';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
            ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
            ->select('energy.*')
            ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
            ->where('energy.status', '=', 'Y')
            ->groupBy('energy.id')
            ->orderBy('energy.energy_name', 'desc')
            ->get();

        if($energy_topic == 'geographic_region'){

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->join('location', 'consumption_energy_form.province_id', '=', 'location.id')
                        ->join('energy', 'energy_form_meta.energy_id', '=', 'energy.id')
                        ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                        ->where('location.location_slug', '=', $province_slug)
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('fuel_type.id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->energy_name] = $objEnergyMetaForm;
                }
            }

        }elseif($energy_topic == 'land_type'){

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->join('location', 'consumption_energy_form.province_id', '=', 'location.id')
                        ->join('energy', 'energy_form_meta.energy_id', '=', 'energy.id')
                        ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                        ->where('location.location_slug', '=', $province_slug)
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('fuel_type.id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->energy_name] = $objEnergyMetaForm;
                }
            }

        }elseif($energy_topic == 'river'){

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->join('location', 'consumption_energy_form.province_id', '=', 'location.id')
                        ->join('energy', 'energy_form_meta.energy_id', '=', 'energy.id')
                        ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                        ->where('location.location_slug', '=', $province_slug)
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('fuel_type.id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->energy_name] = $objEnergyMetaForm;
                }
            }

        }else{
            $energy_topic = 'sector';

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->join('location', 'consumption_energy_form.province_id', '=', 'location.id')
                        ->where('location.location_slug', '=', $province_slug)
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->energy_name] = $objEnergyMetaForm;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct_pie')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralResourcesEnergyTopicPie($start, $end, $energy_topic, Request $request) {

        $energy_type_slug = 'resources';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->orderBy('geographic_region.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('resources_energy_form.from_date', '=', $start)
                        ->where('resources_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->geographic_region_name] = json_decode($objEnergyMetaForm);
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                        ->join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('resources_energy_form.from_date', '=', $start)
                        ->where('resources_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->land_type_name] = $objEnergyMetaForm;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->orderBy('river.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                        ->join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('resources_energy_form.from_date', '=', $start)
                        ->where('resources_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->river_name] = $objEnergyMetaForm;
                }
            }
        }elseif($energy_topic == 'sector'){
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->orderBy('sector.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('resources_energy_form.from_date', '=', $start)
                        ->where('resources_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->sector_name] = $objEnergyMetaForm;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct_pie')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralImportEnergyTopicPie($start, $end, $energy_topic, Request $request) {

        $energy_type_slug = 'import';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('import_energy_form.from_date', '=', $start)
                        ->where('import_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->geographic_region_name] = json_decode($objEnergyMetaForm);
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                        ->join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('import_energy_form.from_date', '=', $start)
                        ->where('import_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->land_type_name] = $objEnergyMetaForm;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->orderBy('river.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                        ->join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('import_energy_form.from_date', '=', $start)
                        ->where('import_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->river_name] = $objEnergyMetaForm;
                }
            }
        }elseif($energy_topic == 'sector'){
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->orderBy('sector.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('import_energy_form.from_date', '=', $start)
                        ->where('import_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->sector_name] = $objEnergyMetaForm;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct_pie')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralExportEnergyTopicPie($start, $end, $energy_topic, Request $request) {

        $energy_type_slug = 'consumption';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->orderBy('geographic_region.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->geographic_region_name] = json_decode($objEnergyMetaForm);
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->land_type_name] = $objEnergyMetaForm;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->orderBy('river.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->river_name] = $objEnergyMetaForm;
                }
            }
        }elseif($energy_topic == 'sector'){
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->orderBy('sector.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->sector_name] = $objEnergyMetaForm;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct_pie')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralConsumptionEnergyTopic($start, $end, $energy_topic, Request $request) {

        $energy_type_slug = 'consumption';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'ASC')
            ->get();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->orderBy('geographic_region.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.province_id', '=', $the_province->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.province_id', '=', $the_province->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->orderBy('river.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.province_id', '=', $the_province->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->river_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'sector'){
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->orderBy('sector.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.province_id', '=', $the_province->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->sector_name] = $inner_col;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('provinces', $provinces)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }

    }

    public function reportProvinceWiseConsumptionEnergyTopic($start, $end, $province_slug, $energy_topic, Request $request) {

        $energy_type_slug = 'consumption';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $this_province = Location::where('location_slug', $province_slug)->where('status', 'Y')->first();

        $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->join('location AS loc_parent', 'loc_parent.id', '=', 'location.parent_id')
            ->where('loc_parent.location_slug', '=', $province_slug)
            ->where('location_type.location_type_slug', 'district')
            ->where('location.status', 'Y')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->groupBy('location.id')
            ->orderBy('location.location_slug', 'ASC')
            ->get();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->orderBy('geographic_region.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($districts as $the_district){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.district_id', '=', $the_district->id)
                            ->where('consumption_energy_form.province_id', '=', $this_province->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($districts as $the_district){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.district_id', '=', $the_district->id)
                            ->where('consumption_energy_form.province_id', '=', $this_province->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->orderBy('river.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($districts as $the_district){
                        $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.district_id', '=', $the_district->id)
                            ->where('consumption_energy_form.province_id', '=', $this_province->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->river_name] = $inner_col;
                }
            }
        }else{

            $energy_topic = 'sector';

            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->orderBy('sector.entry_order', 'asc')
                ->get();
//
//            echo '<pre>';
//            print_r(json_decode($rows));
//            echo '</pre>';
//            exit();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($districts as $the_district){
                        $objEnergyMetaForm = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.district_id', '=', $the_district->id)
                            ->where('consumption_energy_form.province_id', '=', $this_province->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->sector_name] = $inner_col;

//                    echo '<pre>';
//                    print_r($final_result);
//                    echo '</pre>';
//                    exit();
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('provinces', $districts)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }

    }

    public function reportCentralResourcesEnergyTopic($start, $end, $energy_topic, Request $request) {

        $energy_type_slug = 'resources';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'ASC')
            ->get();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->orderBy('geographic_region.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('resources_energy_form.province_id', '=', $the_province->id)
                            ->where('resources_energy_form.from_date', '=', $start)
                            ->where('resources_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('resources_energy_form.province_id', '=', $the_province->id)
                            ->where('resources_energy_form.from_date', '=', $start)
                            ->where('resources_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->orderBy('river.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                            ->join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('resources_energy_form.province_id', '=', $the_province->id)
                            ->where('resources_energy_form.from_date', '=', $start)
                            ->where('resources_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->river_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'sector'){
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->orderBy('sector.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('resources_energy_form.province_id', '=', $the_province->id)
                            ->where('resources_energy_form.from_date', '=', $start)
                            ->where('resources_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->sector_name] = $inner_col;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('provinces', $provinces)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }

    }

    public function reportCentralImportEnergyTopic($start, $end, $energy_topic, Request $request) {

        $energy_type_slug = 'import';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'ASC')
            ->get();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->orderBy('geographic_region.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('import_energy_form.province_id', '=', $the_province->id)
                            ->where('import_energy_form.from_date', '=', $start)
                            ->where('import_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('import_energy_form.province_id', '=', $the_province->id)
                            ->where('import_energy_form.from_date', '=', $start)
                            ->where('import_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->orderBy('river.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                            ->join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('import_energy_form.province_id', '=', $the_province->id)
                            ->where('import_energy_form.from_date', '=', $start)
                            ->where('import_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->river_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'sector'){
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->orderBy('sector.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('import_energy_form.province_id', '=', $the_province->id)
                            ->where('import_energy_form.from_date', '=', $start)
                            ->where('import_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->sector_name] = $inner_col;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('provinces', $provinces)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }

    }

    public function reportCentralExportEnergyTopic($start, $end, $energy_topic, Request $request) {

        $energy_type_slug = 'export';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'ASC')
            ->get();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->orderBy('geographic_region.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('export_energy_form.province_id', '=', $the_province->id)
                            ->where('export_energy_form.from_date', '=', $start)
                            ->where('export_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('export_energy_form.province_id', '=', $the_province->id)
                            ->where('export_energy_form.from_date', '=', $start)
                            ->where('export_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->orderBy('river.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                            ->join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('export_energy_form.province_id', '=', $the_province->id)
                            ->where('export_energy_form.from_date', '=', $start)
                            ->where('export_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->river_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'sector'){
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->orderBy('sector.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('export_energy_form.province_id', '=', $the_province->id)
                            ->where('export_energy_form.from_date', '=', $start)
                            ->where('export_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->sector_name] = $inner_col;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('provinces', $provinces)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }

    }

}
