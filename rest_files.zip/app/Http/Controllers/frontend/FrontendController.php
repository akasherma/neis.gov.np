<?php

namespace App\Http\Controllers\frontend;

use App\Energy;
use App\EnergyConversion;
use App\EnergyFormMeta;
use App\EnergyTypes;
use App\EnergyYear;
use App\GeographicRegion;
use App\LandType;
use App\Location;
use App\Menu;
use App\Page;
use App\River;
use App\Sector;
use App\Unit;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\ConsumptionEnergyForm;
use App\ProductionEnergyForm;
use App\ResourcesEnergyForm;

class FrontendController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
     
    // $result = Log::join('product', 'product.id', '=', 'log.product_id')
    //         ->select('product.product_id', 'product.product_name','log.updated_at', 'log.item', 'log.rate', 'log.record')
    //         ->get();
    public function homepage(){
        //     $post_type = Posttype::all();
        //     $about = Post::where('post_slug', 'whatweserve')->first();
        //     $logo = Post::where('post_slug','logo')->first();
        //     $slogan = Post::where('post_slug','slogan')->first();
        //     $sliderleftimage = Post::where('post_slug','sliderleftimage')->first();
        //     $belowsliderleft = Post::where('post_slug','belowsliderleft')->first();
        //     $belowsliderright = Post::where('post_slug','belowsliderright')->first();
        //     $belowwhatweserve = Post::where('post_slug','belowwhatweserve')->first();
        //
        //     $slider = Post::join('post_types as pt', 'pt.id', '=', 'posts.post_types_id')
        //                ->where('pt.post_type_slug', 'slider')
        //                ->get();
        //      $team = Post::join('post_types as pt', 'pt.id', '=', 'posts.post_types_id')
        //                ->where('pt.post_type_slug', 'team')
        //                ->get();
        //      $testimonial = Post::join('post_types as pt', 'pt.id', '=', 'posts.post_types_id')
        //                ->where('pt.post_type_slug', 'testimonial')
        //                ->get();
        // dd($slider);

        $welcome = Page::where('page_slug', 'welcome-note')->first();

        $mission = Page::where('page_slug', 'mission')->first();

        $vision = Page::where('page_slug', 'vision')->first();

        return view('frontend/homepage')
            ->with('welcome', $welcome)
            ->with('mission', $mission)
            ->with('vision', $vision);

        // ->with('whatweare',$about);



    }

    public function viewPage($page_slug){
        
        $this_page = Page::where('page_slug', $page_slug)->first();

        if(!empty($this_page)){
            return view('frontend/normalpage')->with('this_page', $this_page);
        }else{
            return view('frontend/normalpage')->with('error', 'No Such Page Found! ');
        }
    }

      public function searchFilter(Request $request){
            $searchdata = $request->searchdata;
//            echo '<pre>';
//            print_r($searchdata);
//
//            exit();

//          date_from] => 1995
//    [date_to] => 2018
//    [energy_type] => consumption
//          [energy_topic] => sector
//          [output] => direct

          $date_from = (!empty($searchdata['date_from']))?(int)$searchdata['date_from']:(date('Y')-1);
          $date_to = $date_from + 1;

          $year_range = (!empty($searchdata['year_range']))?$searchdata['year_range']:array();

          if(!empty($year_range) && is_array($year_range) && count($year_range) > 0){
              $date_from = $year_range[0];
              $date_to = $year_range[(count($year_range) - 1)];
          }

          $energy_type = (!empty($searchdata['energy_type']))?'/'.$searchdata['energy_type']:'/consumption';
          $energy_topic = (!empty($searchdata['energy_topic']))?'/'.$searchdata['energy_topic']:'';
          $output = (!empty($searchdata['output']))?'/'.$searchdata['output']:'/direct';

//          $date_to = ($date_from > $date_to)?($date_from + 1):$date_to;

          $route = '/report'.$energy_type.$energy_topic.$output.'/'.$date_from.'/'.$date_to;

          return redirect($route);


//            exit();
      }

    public function reportEnergyYear(Request $request){

        $energy_years = EnergyYear::where('status', 'Y')->orderBy('energy_year_start', 'ASC')->get();

//        echo '<pre>';
//        print_r(json_decode($energy_years));
//        exit();

        return view('frontend/report_energy_year_listing')
            ->with('url', $request->url())
            ->with('energy_years', $energy_years);

    }

    public function reportEnergyTypeListing($start, $end, Request $request) {

        $energy_types = EnergyTypes::where('status', 'Y')->get();

        return view('frontend/report_energy_type_listing')
            ->with('url', $request->url())
            ->with('start', $start)
            ->with('end', $end)
            ->with('energy_types', $energy_types);

    }

    public function reportEnergyTypeEnergyTopicListing($start, $end, $energy_type_slug, Request $request) {

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $energy_topics = EnergyFormMeta::where('energy_form_topic', '=', $energy_type_slug)
            ->where('energy_topic', '!=', 'overall')
            ->groupBy('energy_topic')
            ->pluck('energy_topic');

        if(!empty($this_energy_type)){

//            $energy_lists = Energy::where('status', 'Y')->get();


            $energy_lists = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->select('energy.*')
                ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
                ->groupBy('energy.id')
                ->orderBy('fuel_type.fuel_type_name', 'DESC')
                ->get();

//            $energy_lists = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
//                ->select('energy.*')
//                ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
//                ->where('energy.status', 'Y')
//                ->groupBy('energy.id')
//                ->orderBy('energy.energy_order', 'asc')
//                ->get();

            return view('frontend/report_energy_type_energy_topic_listing')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topics', $energy_topics)
                ->with('energy_lists', $energy_lists);

        }else{

            return redirect('frontend/report')->with('warning', 'No such Energy Type!');

        }

    }

    public function reportEnergyTypeEnergyTopicLocationWise($start, $end, $energy_type_slug, $energy_topic, Request $request) {

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug')
            ->get();

        if(!empty($this_energy_type)){

            return view('frontend/report_energy_type_energy_topic_province_listing')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('provinces', $provinces);

        }else{

            return redirect('frontend/report')->with('warning', 'No such Energy Type!');

        }

    }

    public function reportEnergySupplyDemandBalance(Request $request) {

//        $start, $end,

        $start = (!empty($_GET['start']) && is_numeric($_GET['start']) && $_GET['start'] > 1990 && $_GET['start'] <= (date('Y') - 1) )?$_GET['start']:2019;

        $end = $start + 1;

        $production = 'production';

        $import = 'import';

        $export = 'export';

        $energy_topic = 'sector';

        $final_result = array();

        $col_keys = '';

        if($energy_topic == 'sector'){

            $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->select('energy.*', 'fuel_type.fuel_type_name', 'fuel_type.fuel_order')
                ->where('energy_type_topic_mapping.energy_type_topic', '=', $production)
                ->where('energy.status', 'Y')
                ->where('fuel_type.fuel_order', '!=', '')
                ->groupBy('energy.id')
                ->orderBy('energy.energy_order', 'asc')
                ->get();

            $col_keys = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.sector_name as key', 'sector.id')
                ->get();

            $col_send = array();
            array_push($col_send, 'Production');
            array_push($col_send, 'Import');
            array_push($col_send, 'Export');
            array_push($col_send, 'Total Primary Supply/Sale');
            array_push($col_send, 'Statistical Differences');
            array_push($col_send, 'Thermal Generation');
            array_push($col_send, 'Energy Loss');
            array_push($col_send, 'Final Supply');

            if(!empty($col_keys)){
                foreach($col_keys as $this_col_key){
                    array_push($col_send, $this_col_key->key);
                }
            }

//            echo '<pre>';
//            print_r(json_decode($col_production_keys));
//            exit();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;

                    $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;

                    $objEnergyMetaForm = EnergyFormMeta::join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                        ->where('energy_form_meta.energy_id', '=', $the_row->id)
                        ->where('energy_form_meta.energy_form_topic', '=', 'production')
                        ->where('production_energy_form.from_date', '=', $start)
                        ->where('production_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();

                    $inner_col[$counter] += (float)$objEnergyMetaForm->qty;

                    $counter++;

                    $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;

                    $objEnergyMetaForm = EnergyFormMeta::join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                        ->where('energy_form_meta.energy_id', '=', $the_row->id)
                        ->where('energy_form_meta.energy_form_topic', '=', 'import')
                        ->where('import_energy_form.from_date', '=', $start)
                        ->where('import_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();

                    $inner_col[$counter] += (float)$objEnergyMetaForm->qty;

                    $counter++;

                    $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;

                    $objEnergyMetaForm = EnergyFormMeta::join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                        ->where('energy_form_meta.energy_id', '=', $the_row->id)
                        ->where('energy_form_meta.energy_form_topic', '=', 'export')
                        ->where('export_energy_form.from_date', '=', $start)
                        ->where('export_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                    $counter++;

                    // Total Primary Supply/Sales
                    $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                    $inner_col[$counter] += ($inner_col[0] + $inner_col[1] + $inner_col[2]);
                    $counter++;

                    // Statistical Differences
                    $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                    $inner_col[$counter] = 0;
                    $counter++;

                    // Thermal Generation
                    $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                    $inner_col[$counter] = 0;
                    $counter++;

                    // Energy Loss
                    $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                    $inner_col[$counter] = 0;
                    $counter++;

                    // Final Supply
                    $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                    $inner_col[$counter] += ($inner_col[3] - $inner_col[4] - $inner_col[5] - $inner_col[6]);
                    $counter++;

                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $objEnergyMetaForm = EnergyFormMeta::join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('production_energy_form.from_date', '=', $start)
                            ->where('production_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $objEnergyMetaForm = EnergyFormMeta::join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('resources_energy_form.from_date', '=', $start)
                            ->where('resources_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $objEnergyMetaForm = EnergyFormMeta::join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('import_energy_form.from_date', '=', $start)
                            ->where('import_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $objEnergyMetaForm = EnergyFormMeta::join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('export_energy_form.from_date', '=', $start)
                            ->where('export_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
//                        array_push($inner_col, json_decode($objEnergyMetaForm));
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }

//                echo '<pre>';
//                print_r($final_result);
//                exit();
            }
        }

        return view('frontend/report/report_energy_supply_demand_balance')
            ->with('url', $request->url())
            ->with('start', $start)
            ->with('end', $end)
            ->with('col_send', $col_send)
            ->with('final_result', $final_result);

    }



    public function reportEnergyVersesEnergyTypeTabular($energy_type_slug, $energy_topic='', $start, $end, Request $request) {


        $final_result = array();

        $energy_topic = (!empty($energy_topic))?$energy_topic:'sector';

        $col_keys = '';

        $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
            ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
            ->select('energy.*', 'fuel_type.fuel_type_name')
            ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
            ->where('fuel_type.fuel_order', '!=', '')
            ->groupBy('energy.id')
            ->orderBy('energy.energy_order', 'asc')
            ->get();

        if($energy_topic == 'river') {
            $col_keys = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.river_name as key', 'river.id')
                ->get();
        }else if($energy_topic == 'land_type') {
            $col_keys = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.land_type_name as key', 'land_type.id')
                ->get();
        }else if($energy_topic == 'geographic_region') {
            $col_keys = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.geographic_region_name as key', 'geographic_region.id')
                ->get();
        }else{
            $col_keys = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', 'sector')
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.sector_name as key', 'sector.id')
                ->get();
        }

        $col_send = array();

        if(!empty($col_keys)){
            foreach($col_keys as $this_col_key){
                array_push($col_send, $this_col_key->key);
            }
        }

        if($energy_type_slug == 'consumption'){ // consumption_energy_form
            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }
        }else if($energy_type_slug == 'production'){ // production_energy_form
            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('production_energy_form.from_date', '=', $start)
                            ->where('production_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }
        }else if($energy_type_slug == 'resources'){ // resources_energy_form
            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('resources_energy_form.from_date', '=', $start)
                            ->where('resources_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }
        }else if($energy_type_slug == 'import'){ // import_energy_form
            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('import_energy_form.from_date', '=', $start)
                            ->where('import_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }
        }else if($energy_type_slug == 'export'){ // export_energy_form
            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('export_energy_form.from_date', '=', $start)
                            ->where('export_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }
        }

        return view('frontend/report_energy_verses_energy_type_tabular')
            ->with('start', $start)
            ->with('end', $end)
            ->with('col_send', $col_send)
            ->with('output', 'tabular')
            ->with('energy_type_slug', $energy_type_slug)
            ->with('energy_topic', $energy_topic)
            ->with('final_result', $final_result);

    }

    public function reportEnergyVersesEnergyTypeDirectTabular($energy_type_slug, $start, $end, Request $request) {


        $final_result = array();

        $energy_topic = 'sector';

        $col_keys = '';

        $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
            ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
            ->select('energy.*', 'fuel_type.fuel_type_name')
            ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
            ->where('fuel_type.fuel_order', '!=', '')
            ->groupBy('energy.id')
            ->orderBy('energy.energy_order', 'asc')
            ->get();

//        $rows = Energy::join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
//            ->select('energy.*', 'fuel_type.fuel_type_name')
//            ->groupBy('energy.id')
//            ->orderBy('fuel_type.fuel_type_name', 'DESC')
//            ->get();

        $col_keys = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.sector_name as key', 'sector.id')
                ->get();

        $col_send = array();

        if(!empty($col_keys)){
            foreach($col_keys as $this_col_key){
                array_push($col_send, $this_col_key->key);
            }
        }

        if($energy_type_slug == 'consumption'){ // consumption_energy_form
            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }
        }else if($energy_type_slug == 'production'){ // production_energy_form
            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('production_energy_form.from_date', '=', $start)
                            ->where('production_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }
        }else if($energy_type_slug == 'resources'){ // resources_energy_form
            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('resources_energy_form.from_date', '=', $start)
                            ->where('resources_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }
        }else if($energy_type_slug == 'import'){ // import_energy_form
            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('import_energy_form.from_date', '=', $start)
                            ->where('import_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }
        }else if($energy_type_slug == 'export'){ // export_energy_form
            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('export_energy_form.from_date', '=', $start)
                            ->where('export_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }
        }

        return view('frontend/report_energy_verses_energy_type_tabular')
            ->with('start', $start)
            ->with('end', $end)
            ->with('col_send', $col_send)
            ->with('output', 'tabular')
            ->with('energy_type_slug', $energy_type_slug)
            ->with('energy_topic', '')
            ->with('final_result', $final_result);

    }

    public function reportCentralProductionEnergyTopicTrend($energy_topic, $start, $end, Request $request) {

        $energy_type_slug = 'production';

        $output = 'trend';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){

                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('production_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_slug] = $inner_col;
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('production_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                            ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('production_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->river_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'sector'){
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('production_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();

                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }

                    $final_result[$the_row->sector_slug] = $inner_col;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('frontend/report_energy_type_energy_topic_direct_line')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('output', $output)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('frontend/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralEnergyTypeEnergyTrend($energy_type_slug, $start, $end, Request $request) {

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        $output = 'trend';

        if(!empty($this_energy_type)){


            $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->select('energy.*', 'fuel_type.fuel_type_name')
                ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
                ->where('fuel_type.fuel_order', '!=', '')
                ->groupBy('energy.id')
                ->orderBy('energy.energy_order', 'asc')
                ->get();

//            $rows = Energy::join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
//                ->select('energy.*', 'fuel_type.fuel_type_name')
//                ->groupBy('energy.id')
//                ->orderBy('fuel_type.fuel_type_name', 'DESC')
//                ->get();

            if (!empty($rows)) {
                foreach ($rows as $the_row) {
                    $inner_col = array();
                    $inner_col_count = 0;

                    for ($year = $start; $year < $end; $year++) {

                        $inner_col[$inner_col_count] = (!empty($inner_col[$inner_col_count])) ? $inner_col[$inner_col_count] : 0;

                        if ($energy_type_slug == 'production') { // production_energy_form
                            $objEnergyMetaForm = EnergyFormMeta::join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                                ->where('energy_form_meta.energy_topic', '!=', 'overall')
                                ->where('energy_form_meta.energy_id', '=', $the_row->id)
                                ->where('production_energy_form.from_date', '=', $year)
                                ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                                ->first();
                            $inner_col[$inner_col_count] += (float)$objEnergyMetaForm->qty;
                        } else if ($energy_type_slug == 'resources') { // resources_energy_form
                            $objEnergyMetaForm = EnergyFormMeta::join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                                ->where('energy_form_meta.energy_topic', '!=', 'overall')
                                ->where('energy_form_meta.energy_id', '=', $the_row->id)
                                ->where('resources_energy_form.from_date', '=', $year)
                                ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                                ->first();
                            $inner_col[$inner_col_count] += (float)$objEnergyMetaForm->qty;
                        } else if ($energy_type_slug == 'import') { // import_energy_form
                            $objEnergyMetaForm = EnergyFormMeta::join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                                ->where('energy_form_meta.energy_topic', '=', 'overall')
                                ->where('energy_form_meta.energy_id', '=', $the_row->id)
                                ->where('import_energy_form.from_date', '=', $year)
                                ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                                ->first();
                            $inner_col[$inner_col_count] += (float)$objEnergyMetaForm->qty;
                        } else if ($energy_type_slug == 'export') { // export_energy_form
                            $objEnergyMetaForm = EnergyFormMeta::join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                                ->where('energy_form_meta.energy_topic', '=', 'overall')
                                ->where('energy_form_meta.energy_id', '=', $the_row->id)
                                ->where('export_energy_form.from_date', '=', $year)
                                ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                                ->first();
                            $inner_col[$inner_col_count] += (float)$objEnergyMetaForm->qty;
                        } else { // consumption_energy_form

                            $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                                ->where('energy_form_meta.energy_topic', '!=', 'overall')
                                ->where('energy_form_meta.energy_id', '=', $the_row->id)
                                ->where('consumption_energy_form.from_date', '=', $year)
                                ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                                ->first();
                            $inner_col[$inner_col_count] += (float)$objEnergyMetaForm->qty;
                        }
                        $inner_col_count++;
                    }
                    $final_result[$the_row->fuel_type_name . '-' . $the_row->energy_name] = $inner_col;
                }
            }

//            echo '<pre>';
//            print_r($final_result);
//            echo '</pre>';
//            exit();

            return view('frontend/report_energy_type_energy_direct_line')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('output', $output)
                ->with('final_result', $final_result);

        }else{

            return redirect('frontend/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralConsumptionEnergyTopicTrend($energy_topic, $start, $end, Request $request) {

        $energy_type_slug = 'consumption';

        $output = 'trend';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){

                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_slug] = $inner_col;
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_slug] = $inner_col;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->river_slug] = $inner_col;
                }
            }
        }elseif($energy_topic == 'sector'){
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();

//                        echo '<pre>';
//                        print_r(json_decode($objEnergyMetaForm));

                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }

                    $final_result[$the_row->sector_slug] = $inner_col;
                }
            }
        }

//        exit();

        if(!empty($this_energy_type)){

            return view('frontend/report_energy_type_energy_topic_direct_line')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('output', $output)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('frontend/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralResourcesEnergyTopicTrend($energy_topic, $start, $end, Request $request) {

        $energy_type_slug = 'resources';

        $output = 'trend';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){

                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('resources_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_slug] = $inner_col;
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('resources_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_slug] = $inner_col;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                            ->join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('resources_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->river_slug] = $inner_col;
                }
            }
        }elseif($energy_topic == 'sector'){
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('resources_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();

//                        echo '<pre>';
//                        print_r(json_decode($objEnergyMetaForm));

                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }

                    $final_result[$the_row->sector_slug] = $inner_col;
                }
            }
        }

//        exit();

        if(!empty($this_energy_type)){

            return view('frontend/report_energy_type_energy_topic_direct_line')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('output', $output)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('frontend/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralImportEnergyTopicTrend($energy_topic, $start, $end, Request $request) {

        $energy_type_slug = 'import';

        $output = 'trend';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){

                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('import_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_slug] = $inner_col;
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('import_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_slug] = $inner_col;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                            ->join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('import_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->river_slug] = $inner_col;
                }
            }
        }elseif($energy_topic == 'sector'){
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('import_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();

//                        echo '<pre>';
//                        print_r(json_decode($objEnergyMetaForm));

                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }

                    $final_result[$the_row->sector_slug] = $inner_col;
                }
            }
        }

//        exit();

        if(!empty($this_energy_type)){

            return view('frontend/report_energy_type_energy_topic_direct_line')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('output', $output)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('frontend/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralExportEnergyTopicTrend($energy_topic='', $start='', $end='', Request $request) {

        $start = (!empty($start))?$start:'2017';

        $end = (!empty($end))?$end:'2018';

        $energy_topic = (!empty($energy_topic))?$energy_topic:'sector';

        $energy_type_slug = 'export';

        $output = 'trend';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){

                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('export_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_slug] = $inner_col;
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('export_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_slug] = $inner_col;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                            ->join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('export_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->river_slug] = $inner_col;
                }
            }
        }else{
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', 'sector')
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', 'sector')
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('export_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();

//                        echo '<pre>';
//                        print_r(json_decode($objEnergyMetaForm));

                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }

                    $final_result[$the_row->sector_slug] = $inner_col;
                }
            }
        }

//        exit();

        if(!empty($this_energy_type)){

            return view('frontend/report_energy_type_energy_topic_direct_line')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('output', $output)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('frontend/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralProductionEnergyTopicPie($energy_topic='', $start='', $end='', Request $request) {

        $start = (!empty($start))?$start:'2017';

        $end = (!empty($end))?$end:'2018';

        $energy_type_slug = 'production';

        $output = 'direct';

        $energy_topic = (!empty($energy_topic))?$energy_topic:'sector';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

//        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
//            ->where('location_type.location_type_slug', 'province')
//            ->where('location.status', 'Y')
//            ->select('location.*')
//            ->orderBy('location.location_slug', 'ASC')
//            ->get();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('production_energy_form.from_date', '=', $start)
                        ->where('production_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->geographic_region_slug] = json_decode($objEnergyMetaForm);
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                        ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('production_energy_form.from_date', '=', $start)
                        ->where('production_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->land_type_slug] = $objEnergyMetaForm;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                        ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('production_energy_form.from_date', '=', $start)
                        ->where('production_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->river_slug] = $objEnergyMetaForm;
                }
            }
        }else{
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', 'sector')
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', 'sector')
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('production_energy_form.from_date', '=', $start)
                        ->where('production_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->sector_slug] = $objEnergyMetaForm;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('frontend/report_energy_type_energy_topic_direct_pie')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('output', $output)
                ->with('energy_type', $energy_type_slug)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('frontend/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralConsumptionEnergyTopicPie($energy_topic='', $start='', $end='', Request $request) {

        $start = (!empty($start))?$start:'2017';

        $end = (!empty($end))?$end:'2018';

        $energy_type_slug = 'consumption';

        $output = 'direct';

        $energy_topic = (!empty($energy_topic))?$energy_topic:'sector';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

//        echo '-start.-'.$start.'-end-'.$end.'-energy-type-'.$energy_type_slug.'-energy_topic-'.$energy_topic.'-';
//
//        exit();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->geographic_region_slug] = json_decode($objEnergyMetaForm);
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->land_type_slug] = $objEnergyMetaForm;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->river_slug] = $objEnergyMetaForm;
                }
            }
        }else{
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', 'sector')
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', 'sector')
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->sector_slug] = $objEnergyMetaForm;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('frontend/report_energy_type_energy_topic_direct_pie')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('output', $output)
                ->with('energy_type', $energy_type_slug)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('frontend/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralResourcesEnergyTopicPie($energy_topic='', $start='', $end='', Request $request) {

        $start = (!empty($start))?$start:'2017';

        $end = (!empty($end))?$end:'2018';

        $output = 'direct';

        $energy_topic = (!empty($energy_topic))?$energy_topic:'sector';

        $energy_type_slug = 'resources';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('resources_energy_form.from_date', '=', $start)
                        ->where('resources_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->geographic_region_slug] = json_decode($objEnergyMetaForm);
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                        ->join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('resources_energy_form.from_date', '=', $start)
                        ->where('resources_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->land_type_slug] = $objEnergyMetaForm;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                        ->join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('resources_energy_form.from_date', '=', $start)
                        ->where('resources_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->river_slug] = $objEnergyMetaForm;
                }
            }
        }else{
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', 'sector')
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', 'sector')
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('resources_energy_form.from_date', '=', $start)
                        ->where('resources_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->sector_slug] = $objEnergyMetaForm;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('frontend/report_energy_type_energy_topic_direct_pie')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('output', $output)
                ->with('energy_type', $energy_type_slug)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('frontend/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralImportEnergyTopicPie($energy_topic='', $start='', $end='', Request $request) {

        $start = (!empty($start))?$start:'2017';

        $end = (!empty($end))?$end:'2018';

        $output = 'direct';

        $energy_topic = (!empty($energy_topic))?$energy_topic:'sector';

        $energy_type_slug = 'import';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('import_energy_form.from_date', '=', $start)
                        ->where('import_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->geographic_region_slug] = json_decode($objEnergyMetaForm);
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                        ->join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('import_energy_form.from_date', '=', $start)
                        ->where('import_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->land_type_slug] = $objEnergyMetaForm;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                        ->join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('import_energy_form.from_date', '=', $start)
                        ->where('import_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->river_slug] = $objEnergyMetaForm;
                }
            }
        }else{
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', 'sector')
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', 'sector')
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('import_energy_form.from_date', '=', $start)
                        ->where('import_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->sector_slug] = $objEnergyMetaForm;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('frontend/report_energy_type_energy_topic_direct_pie')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('output', $output)
                ->with('energy_type', $energy_type_slug)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('frontend/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralExportEnergyTopicPie($energy_topic='', $start='', $end='', Request $request) {

        $start = (!empty($start))?$start:'2017';

        $end = (!empty($end))?$end:'2018';

        $output = 'direct';

        $energy_topic = (!empty($energy_topic))?$energy_topic:'sector';

        $energy_type_slug = 'consumption';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->geographic_region_slug] = json_decode($objEnergyMetaForm);
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->land_type_slug] = $objEnergyMetaForm;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->river_slug] = $objEnergyMetaForm;
                }
            }
        }else{
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', 'sector')
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', 'sector')
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->sector_slug] = $objEnergyMetaForm;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('frontend/report_energy_type_energy_topic_direct_pie')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('output', $output)
                ->with('energy_type', $energy_type_slug)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('frontend/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralConsumptionEnergyTopicProvince($energy_topic='', $start='', $end='', Request $request) {

        $start = (!empty($start))?$start:'2017';

        $end = (!empty($end))?$end:'2018';

        $output = 'provincewise';

        $energy_topic = (!empty($energy_topic))?$energy_topic:'sector';

        $energy_type_slug = 'consumption';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'ASC')
            ->get();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.province_id', '=', $the_province->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_slug] = $inner_col;
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.province_id', '=', $the_province->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_slug] = $inner_col;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.province_id', '=', $the_province->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->river_slug] = $inner_col;
                }
            }
        }else{
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', 'sector')
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', 'sector')
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.province_id', '=', $the_province->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->sector_slug] = $inner_col;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('frontend/report_energy_type_energy_topic_direct')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('provinces', $provinces)
                ->with('start', $start)
                ->with('end', $end)
                ->with('output', $output)
                ->with('energy_type', $energy_type_slug)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('frontend/report')->with('warning', 'No such Energy Type!');

        }

    }

    public function reportCentralProductionEnergyTopicProvince($energy_topic, $start, $end, Request $request) {

        $start = (!empty($start))?$start:'2017';

        $end = (!empty($end))?$end:'2018';

        $output = 'provincewise';

        $energy_topic = (!empty($energy_topic))?$energy_topic:'sector';

        $energy_type_slug = 'production';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'ASC')
            ->get();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('production_energy_form.province_id', '=', $the_province->id)
                            ->where('production_energy_form.from_date', '=', $start)
                            ->where('production_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_slug] = $inner_col;
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('production_energy_form.province_id', '=', $the_province->id)
                            ->where('production_energy_form.from_date', '=', $start)
                            ->where('production_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_slug] = $inner_col;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                            ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('production_energy_form.province_id', '=', $the_province->id)
                            ->where('production_energy_form.from_date', '=', $start)
                            ->where('production_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->river_slug] = $inner_col;
                }
            }
        }elseif($energy_topic == 'sector'){
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('production_energy_form.province_id', '=', $the_province->id)
                            ->where('production_energy_form.from_date', '=', $start)
                            ->where('production_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->sector_slug] = $inner_col;
                }
            }
        }else{
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', 'sector')
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                            ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', 'sector')
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('production_energy_form.province_id', '=', $the_province->id)
                            ->where('production_energy_form.from_date', '=', $start)
                            ->where('production_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->sector_slug] = $inner_col;
                }
            }
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', 'geographic_region')
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', 'geographic_region')
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('production_energy_form.province_id', '=', $the_province->id)
                            ->where('production_energy_form.from_date', '=', $start)
                            ->where('production_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_slug] = $inner_col;
                }
            }
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', 'land_type')
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', 'land_type')
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('production_energy_form.province_id', '=', $the_province->id)
                            ->where('production_energy_form.from_date', '=', $start)
                            ->where('production_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_slug] = $inner_col;
                }
            }

        }

        if(!empty($this_energy_type)){

            return view('frontend/report_energy_type_energy_topic_direct')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('provinces', $provinces)
                ->with('start', $start)
                ->with('end', $end)
                ->with('output', $output)
                ->with('energy_type', $energy_type_slug)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);
        }else{
            return redirect('frontend/report')->with('warning', 'No such Energy Type!');
        }
    }

    public function reportCentralResourcesEnergyTopicProvince($energy_topic='', $start='', $end='', Request $request) {

        $start = (!empty($start))?$start:'2017';

        $end = (!empty($end))?$end:'2018';

        $output = 'provincewise';

        $energy_topic = (!empty($energy_topic))?$energy_topic:'sector';

        $energy_type_slug = 'resources';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'ASC')
            ->get();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('resources_energy_form.province_id', '=', $the_province->id)
                            ->where('resources_energy_form.from_date', '=', $start)
                            ->where('resources_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_slug] = $inner_col;
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('resources_energy_form.province_id', '=', $the_province->id)
                            ->where('resources_energy_form.from_date', '=', $start)
                            ->where('resources_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_slug] = $inner_col;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                            ->join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('resources_energy_form.province_id', '=', $the_province->id)
                            ->where('resources_energy_form.from_date', '=', $start)
                            ->where('resources_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->river_slug] = $inner_col;
                }
            }
        }else{
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', 'sector')
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', 'sector')
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('resources_energy_form.province_id', '=', $the_province->id)
                            ->where('resources_energy_form.from_date', '=', $start)
                            ->where('resources_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->sector_slug] = $inner_col;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('frontend/report_energy_type_energy_topic_direct')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('provinces', $provinces)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('output', $output)
                ->with('energy_type', $energy_type_slug)
                ->with('final_result', $final_result);

        }else{

            return redirect('frontend/report')->with('warning', 'No such Energy Type!');

        }

    }

    public function reportCentralImportEnergyTopicProvince($energy_topic, $start, $end, Request $request) {

        $start = (!empty($start))?$start:'2017';

        $end = (!empty($end))?$end:'2018';

        $output = 'provincewise';

        $energy_topic = (!empty($energy_topic))?$energy_topic:'sector';

        $energy_type_slug = 'import';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'ASC')
            ->get();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('import_energy_form.province_id', '=', $the_province->id)
                            ->where('import_energy_form.from_date', '=', $start)
                            ->where('import_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_slug] = $inner_col;
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('import_energy_form.province_id', '=', $the_province->id)
                            ->where('import_energy_form.from_date', '=', $start)
                            ->where('import_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_slug] = $inner_col;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                            ->join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('import_energy_form.province_id', '=', $the_province->id)
                            ->where('import_energy_form.from_date', '=', $start)
                            ->where('import_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->river_slug] = $inner_col;
                }
            }
        }elseif($energy_topic == 'sector'){
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('import_energy_form.province_id', '=', $the_province->id)
                            ->where('import_energy_form.from_date', '=', $start)
                            ->where('import_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->sector_slug] = $inner_col;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('frontend/report_energy_type_energy_topic_direct')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('provinces', $provinces)
                ->with('start', $start)
                ->with('end', $end)
                ->with('output', $output)
                ->with('energy_topic', $energy_topic)
                ->with('energy_type', $energy_type_slug)
                ->with('final_result', $final_result);

        }else{

            return redirect('frontend/report')->with('warning', 'No such Energy Type!');

        }

    }

    public function reportCentralExportEnergyTopicProvince($energy_topic, $start, $end, Request $request) {

        $start = (!empty($start))?$start:'2017';

        $end = (!empty($end))?$end:'2018';

        $output = 'provincewise';

        $energy_topic = (!empty($energy_topic))?$energy_topic:'sector';

        $energy_type_slug = 'export';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'ASC')
            ->get();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('export_energy_form.province_id', '=', $the_province->id)
                            ->where('export_energy_form.from_date', '=', $start)
                            ->where('export_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_slug] = $inner_col;
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('export_energy_form.province_id', '=', $the_province->id)
                            ->where('export_energy_form.from_date', '=', $start)
                            ->where('export_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_slug] = $inner_col;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                            ->join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('export_energy_form.province_id', '=', $the_province->id)
                            ->where('export_energy_form.from_date', '=', $start)
                            ->where('export_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->river_slug] = $inner_col;
                }
            }
        }else{
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', 'sector')
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', 'sector')
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('export_energy_form.province_id', '=', $the_province->id)
                            ->where('export_energy_form.from_date', '=', $start)
                            ->where('export_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->sector_slug] = $inner_col;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('frontend/report_energy_type_energy_topic_direct')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('provinces', $provinces)
                ->with('start', $start)
                ->with('end', $end)
                ->with('output', $output)
                ->with('energy_topic', $energy_topic)
                ->with('energy_type', $energy_type_slug)
                ->with('final_result', $final_result);

        }else{

            return redirect('frontend/report')->with('warning', 'No such Energy Type!');

        }

    }

    public function reportCentralExportEnergyTopicWithEnergy($energy_topic, $start, $end, $energy_topic_name, Request $request) {

        $start = (!empty($start))?$start:'2017';

        $end = (!empty($end))?$end:'2018';

        $energy_type_slug = 'export';

        $output = 'direct';

        $energy_topic = (!empty($energy_topic))?$energy_topic:'sector';

        $energy_topic_name = (!empty($energy_topic_name))?$energy_topic_name:'industrial';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $this_energy_topic_all = array();

//        echo '-start.-'.$start.'-end-'.$end.'-energy-type-'.$energy_type_slug.'-energy_topic-'.$energy_topic.'-';
//
//        exit();

        $final_result = array();

        $energy_topic_id = 0;

        if($energy_topic == 'sector'){
            $this_energy_topic_all = Sector::where('status', 'Y')->pluck('sector_slug as energy_topic');
            $this_energy_topic_name = Sector::where('sector_slug', $energy_topic_name)->first();
            if(!empty($this_energy_topic_name))
                $energy_topic_id = $this_energy_topic_name->id;
        }else if($energy_topic == 'landtype'){
            $this_energy_topic_all = LandType::where('status', 'Y')->pluck('land_type_slug as energy_topic');
            $this_energy_topic_name = LandType::where('land_type_slug', $energy_topic_name)->first();
            if(!empty($this_energy_topic_name))
                $energy_topic_id = $this_energy_topic_name->id;
        }else if($energy_topic == 'geographic_region'){
            $this_energy_topic_all = GeographicRegion::where('status', 'Y')->pluck('geographic_region_slug as energy_topic');
            $this_energy_topic_name = GeographicRegion::where('geographic_region_slug', $energy_topic_name)->first();
            if(!empty($this_energy_topic_name))
                $energy_topic_id = $this_energy_topic_name->id;
        }else if($energy_topic == 'river'){
            $this_energy_topic_all = River::where('status', 'Y')->pluck('river_slug as energy_topic');
            $this_energy_topic_name = River::where('river_slug', $energy_topic_name)->first();
            if(!empty($this_energy_topic_name))
                $energy_topic_id = $this_energy_topic_name->id;
        }

        $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
            ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
            ->join('energy_form_meta', 'energy_form_meta.energy_id', '=', 'energy.id')
            ->where('energy_form_meta.energy_topic', $energy_topic)
            ->select('energy.*')
            ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
            ->where('energy_form_meta.energy_topic_id', $energy_topic_id)
            ->groupBy('energy.id')
            ->orderBy('fuel_type.fuel_type_name', 'DESC')
            ->get();

//        $rows = Energy::join('energy_form_meta', 'energy_form_meta.energy_id', '=', 'energy.id')
//            ->where('energy_form_meta.energy_topic', $energy_topic)
//            ->where('energy_form_meta.energy_topic_id', $energy_topic_id)
//            ->select('energy.*')
//            ->groupBy('energy.id')
//            ->get();

        if(!empty($rows)){
            foreach($rows as $the_row){
                $inner_col = array();
                $objEnergyMetaForm = EnergyFormMeta::join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                    ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                    ->where('energy_form_meta.energy_topic_id', '=', $energy_topic_id)
                    ->where('energy_form_meta.energy_id', '=', $the_row->id)
                    ->where('export_energy_form.from_date', '=', $start)
                    ->where('export_energy_form.to_date', '=', $end)
                    ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                    ->first();
                $final_result[$the_row->energy_name] = $objEnergyMetaForm;
            }
        }

        if(!empty($this_energy_type)){

            return view('frontend/report_energy_type_energy_topic_and_energy_direct_pie')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('energy_topic_name', $energy_topic_name)
                ->with('start', $start)
                ->with('end', $end)
                ->with('output', $output)
                ->with('energy_type', $energy_type_slug)
                ->with('energy_topic', $energy_topic)
                ->with('this_energy_topic_all', $this_energy_topic_all)
                ->with('final_result', $final_result);

        }else{

            return redirect('frontend/report')->with('warning', 'No such Energy Type!');

        }

    }

    public function reportCentralConsumptionEnergyTopicWithEnergy($energy_topic, $start, $end, $energy_topic_name, Request $request) {

        $start = (!empty($start))?$start:'2017';

        $end = (!empty($end))?$end:'2018';

        $energy_type_slug = 'consumption';

        $output = 'direct';

        $energy_topic = (!empty($energy_topic))?$energy_topic:'sector';

        $energy_topic_name = (!empty($energy_topic_name))?$energy_topic_name:'industrial';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

//        echo '-start.-'.$start.'-end-'.$end.'-energy-type-'.$energy_type_slug.'-energy_topic-'.$energy_topic.'-';
//
//        exit();

        $final_result = array();

        $energy_topic_id = 0;

        $this_energy_topic_all = array();

        if($energy_topic == 'sector'){
            $this_energy_topic_all = Sector::where('status', 'Y')->pluck('sector_slug as energy_topic');
            $this_energy_topic_name = Sector::where('sector_slug', $energy_topic_name)->first();
            if(!empty($this_energy_topic_name))
                $energy_topic_id = $this_energy_topic_name->id;
        }else if($energy_topic == 'landtype'){
            $this_energy_topic_all = LandType::where('status', 'Y')->pluck('land_type_slug as energy_topic');
            $this_energy_topic_name = LandType::where('land_type_slug', $energy_topic_name)->first();
            if(!empty($this_energy_topic_name))
                $energy_topic_id = $this_energy_topic_name->id;
        }else if($energy_topic == 'geographic_region'){
            $this_energy_topic_all = GeographicRegion::where('status', 'Y')->pluck('geographic_region_slug as energy_topic');
            $this_energy_topic_name = GeographicRegion::where('geographic_region_slug', $energy_topic_name)->first();
            if(!empty($this_energy_topic_name))
                $energy_topic_id = $this_energy_topic_name->id;
        }else if($energy_topic == 'river'){
            $this_energy_topic_all = River::where('status', 'Y')->pluck('river_slug as energy_topic');
            $this_energy_topic_name = River::where('river_slug', $energy_topic_name)->first();
            if(!empty($this_energy_topic_name))
                $energy_topic_id = $this_energy_topic_name->id;
        }


        $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
            ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
            ->join('energy_form_meta', 'energy_form_meta.energy_id', '=', 'energy.id')
            ->where('energy_form_meta.energy_topic', $energy_topic)
            ->select('energy.*')
            ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
            ->where('energy_form_meta.energy_topic_id', $energy_topic_id)
            ->groupBy('energy.id')
            ->orderBy('fuel_type.fuel_type_name', 'DESC')
            ->get();


//        $rows = Energy::join('energy_form_meta', 'energy_form_meta.energy_id', '=', 'energy.id')
//            ->where('energy_form_meta.energy_topic', $energy_topic)
//            ->where('energy_form_meta.energy_topic_id', $energy_topic_id)
//            ->select('energy.*')
//            ->groupBy('energy.id')
//            ->get();

        if(!empty($rows)){
            foreach($rows as $the_row){
                $inner_col = array();
                $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                    ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                    ->where('energy_form_meta.energy_topic_id', '=', $energy_topic_id)
                    ->where('energy_form_meta.energy_id', '=', $the_row->id)
                    ->where('consumption_energy_form.from_date', '=', $start)
                    ->where('consumption_energy_form.to_date', '=', $end)
                    ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                    ->first();
                $final_result[$the_row->energy_name] = $objEnergyMetaForm;
            }
        }

        if(!empty($this_energy_type)){

            return view('frontend/report_energy_type_energy_topic_and_energy_direct_pie')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('energy_topic_name', $energy_topic_name)
                ->with('start', $start)
                ->with('end', $end)
                ->with('output', $output)
                ->with('energy_type', $energy_type_slug)
                ->with('this_energy_topic_all', $this_energy_topic_all)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('frontend/report')->with('warning', 'No such Energy Type!');

        }

    }

    public function reportCentralProductionEnergyTopicWithEnergy($energy_topic, $start, $end, $energy_topic_name, Request $request)
    {

        $start = (!empty($start)) ? $start : '2017';

        $end = (!empty($end)) ? $end : '2018';

        $energy_type_slug = 'production';

        $output = 'direct';

        $energy_topic = (!empty($energy_topic)) ? $energy_topic : 'sector';

        $energy_topic_name = (!empty($energy_topic_name)) ? $energy_topic_name : 'industrial';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

//        echo '-start.-'.$start.'-end-'.$end.'-energy-type-'.$energy_type_slug.'-energy_topic-'.$energy_topic.'-';
//
//        exit();

        $final_result = array();

        $energy_topic_id = 0;

        $this_energy_topic_all = array();

        if($energy_topic == 'sector'){
            $this_energy_topic_all = Sector::where('status', 'Y')->pluck('sector_slug as energy_topic');
            $this_energy_topic_name = Sector::where('sector_slug', $energy_topic_name)->first();
            if(!empty($this_energy_topic_name))
                $energy_topic_id = $this_energy_topic_name->id;
        }else if($energy_topic == 'landtype'){
            $this_energy_topic_all = LandType::where('status', 'Y')->pluck('land_type_slug as energy_topic');
            $this_energy_topic_name = LandType::where('land_type_slug', $energy_topic_name)->first();
            if(!empty($this_energy_topic_name))
                $energy_topic_id = $this_energy_topic_name->id;
        }else if($energy_topic == 'geographic_region'){
            $this_energy_topic_all = GeographicRegion::where('status', 'Y')->pluck('geographic_region_slug as energy_topic');
            $this_energy_topic_name = GeographicRegion::where('geographic_region_slug', $energy_topic_name)->first();
            if(!empty($this_energy_topic_name))
                $energy_topic_id = $this_energy_topic_name->id;
        }else if($energy_topic == 'river'){
            $this_energy_topic_all = River::where('status', 'Y')->pluck('river_slug as energy_topic');
            $this_energy_topic_name = River::where('river_slug', $energy_topic_name)->first();
            if(!empty($this_energy_topic_name))
                $energy_topic_id = $this_energy_topic_name->id;
        }

        $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
            ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
            ->join('energy_form_meta', 'energy_form_meta.energy_id', '=', 'energy.id')
            ->where('energy_form_meta.energy_topic', $energy_topic)
            ->select('energy.*')
            ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
            ->where('energy_form_meta.energy_topic_id', $energy_topic_id)
            ->groupBy('energy.id')
            ->orderBy('fuel_type.fuel_type_name', 'DESC')
            ->get();

//        $rows = Energy::join('energy_form_meta', 'energy_form_meta.energy_id', '=', 'energy.id')
//            ->where('energy_form_meta.energy_topic', $energy_topic)
//            ->where('energy_form_meta.energy_topic_id', $energy_topic_id)
//            ->select('energy.*')
//            ->groupBy('energy.id')
//            ->get();

        if (!empty($rows)) {
            foreach ($rows as $the_row) {
                $inner_col = array();
                $objEnergyMetaForm = EnergyFormMeta::join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                    ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                    ->where('energy_form_meta.energy_topic_id', '=', $energy_topic_id)
                    ->where('energy_form_meta.energy_id', '=', $the_row->id)
                    ->where('production_energy_form.from_date', '=', $start)
                    ->where('production_energy_form.to_date', '=', $end)
                    ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                    ->first();
                $final_result[$the_row->energy_name] = $objEnergyMetaForm;
            }
        }

        if (!empty($this_energy_type)) {

            return view('frontend/report_energy_type_energy_topic_and_energy_direct_pie')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('energy_topic_name', $energy_topic_name)
                ->with('start', $start)
                ->with('end', $end)
                ->with('output', $output)
                ->with('energy_type', $energy_type_slug)
                ->with('this_energy_topic_all', $this_energy_topic_all)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        } else {

            return redirect('frontend/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralResourcesEnergyTopicWithEnergy($energy_topic, $start, $end, $energy_topic_name, Request $request) {

        $start = (!empty($start))?$start:'2017';

        $end = (!empty($end))?$end:'2018';

        $energy_type_slug = 'resources';

        $output = 'direct';

        $energy_topic = (!empty($energy_topic))?$energy_topic:'sector';

        $energy_topic_name = (!empty($energy_topic_name))?$energy_topic_name:'industrial';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

//        echo '-start.-'.$start.'-end-'.$end.'-energy-type-'.$energy_type_slug.'-energy_topic-'.$energy_topic.'-';
//
//        exit();

        $final_result = array();

        $energy_topic_id = 0;

        $this_energy_topic_all = array();

        if($energy_topic == 'sector'){
            $this_energy_topic_all = Sector::where('status', 'Y')->pluck('sector_slug as energy_topic');
            $this_energy_topic_name = Sector::where('sector_slug', $energy_topic_name)->first();
            if(!empty($this_energy_topic_name))
                $energy_topic_id = $this_energy_topic_name->id;
        }else if($energy_topic == 'landtype'){
            $this_energy_topic_all = LandType::where('status', 'Y')->pluck('land_type_slug as energy_topic');
            $this_energy_topic_name = LandType::where('land_type_slug', $energy_topic_name)->first();
            if(!empty($this_energy_topic_name))
                $energy_topic_id = $this_energy_topic_name->id;
        }else if($energy_topic == 'geographic_region'){
            $this_energy_topic_all = GeographicRegion::where('status', 'Y')->pluck('geographic_region_slug as energy_topic');
            $this_energy_topic_name = GeographicRegion::where('geographic_region_slug', $energy_topic_name)->first();
            if(!empty($this_energy_topic_name))
                $energy_topic_id = $this_energy_topic_name->id;
        }else if($energy_topic == 'river'){
            $this_energy_topic_all = River::where('status', 'Y')->pluck('river_slug as energy_topic');
            $this_energy_topic_name = River::where('river_slug', $energy_topic_name)->first();
            if(!empty($this_energy_topic_name))
                $energy_topic_id = $this_energy_topic_name->id;
        }


        $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
            ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
            ->join('energy_form_meta', 'energy_form_meta.energy_id', '=', 'energy.id')
            ->where('energy_form_meta.energy_topic', $energy_topic)
            ->select('energy.*')
            ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
            ->where('energy_form_meta.energy_topic_id', $energy_topic_id)
            ->groupBy('energy.id')
            ->orderBy('fuel_type.fuel_type_name', 'DESC')
            ->get();

//        $rows = Energy::join('energy_form_meta', 'energy_form_meta.energy_id', '=', 'energy.id')
//            ->where('energy_form_meta.energy_topic', $energy_topic)
//            ->where('energy_form_meta.energy_topic_id', $energy_topic_id)
//            ->select('energy.*')
//            ->groupBy('energy.id')
//            ->get();

        if(!empty($rows)){
            foreach($rows as $the_row){
                $inner_col = array();
                $objEnergyMetaForm = EnergyFormMeta::join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                    ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                    ->where('energy_form_meta.energy_topic_id', '=', $energy_topic_id)
                    ->where('energy_form_meta.energy_id', '=', $the_row->id)
                    ->where('resources_energy_form.from_date', '=', $start)
                    ->where('resources_energy_form.to_date', '=', $end)
                    ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                    ->first();
                $final_result[$the_row->energy_name] = $objEnergyMetaForm;
            }
        }

        if(!empty($this_energy_type)){

            return view('frontend/report_energy_type_energy_topic_and_energy_direct_pie')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('energy_topic_name', $energy_topic_name)
                ->with('start', $start)
                ->with('end', $end)
                ->with('output', $output)
                ->with('energy_type', $energy_type_slug)
                ->with('this_energy_topic_all', $this_energy_topic_all)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('frontend/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralImportEnergyTopicWithEnergy($energy_topic, $start, $end, $energy_topic_name, Request $request) {

        $start = (!empty($start))?$start:'2017';

        $end = (!empty($end))?$end:'2018';

        $energy_type_slug = 'import';

        $output = 'direct';

        $energy_topic = (!empty($energy_topic))?$energy_topic:'sector';

        $energy_topic_name = (!empty($energy_topic_name))?$energy_topic_name:'industrial';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

//        echo '-start.-'.$start.'-end-'.$end.'-energy-type-'.$energy_type_slug.'-energy_topic-'.$energy_topic.'-';
//
//        exit();

        $final_result = array();

        $energy_topic_id = 0;

        $this_energy_topic_all = array();

        if($energy_topic == 'sector'){
            $this_energy_topic_all = Sector::where('status', 'Y')->pluck('sector_slug as energy_topic');
            $this_energy_topic_name = Sector::where('sector_slug', $energy_topic_name)->first();
            if(!empty($this_energy_topic_name))
                $energy_topic_id = $this_energy_topic_name->id;
        }else if($energy_topic == 'landtype'){
            $this_energy_topic_all = LandType::where('status', 'Y')->pluck('land_type_slug as energy_topic');
            $this_energy_topic_name = LandType::where('land_type_slug', $energy_topic_name)->first();
            if(!empty($this_energy_topic_name))
                $energy_topic_id = $this_energy_topic_name->id;
        }else if($energy_topic == 'geographic_region'){
            $this_energy_topic_all = GeographicRegion::where('status', 'Y')->pluck('geographic_region_slug as energy_topic');
            $this_energy_topic_name = GeographicRegion::where('geographic_region_slug', $energy_topic_name)->first();
            if(!empty($this_energy_topic_name))
                $energy_topic_id = $this_energy_topic_name->id;
        }else if($energy_topic == 'river'){
            $this_energy_topic_all = River::where('status', 'Y')->pluck('river_slug as energy_topic');
            $this_energy_topic_name = River::where('river_slug', $energy_topic_name)->first();
            if(!empty($this_energy_topic_name))
                $energy_topic_id = $this_energy_topic_name->id;
        }


        $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
            ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
            ->join('energy_form_meta', 'energy_form_meta.energy_id', '=', 'energy.id')
            ->where('energy_form_meta.energy_topic', $energy_topic)
            ->select('energy.*')
            ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
            ->where('energy_form_meta.energy_topic_id', $energy_topic_id)
            ->groupBy('energy.id')
            ->orderBy('fuel_type.fuel_type_name', 'DESC')
            ->get();

//        $rows = Energy::join('energy_form_meta', 'energy_form_meta.energy_id', '=', 'energy.id')
//            ->where('energy_form_meta.energy_topic', $energy_topic)
//            ->where('energy_form_meta.energy_topic_id', $energy_topic_id)
//            ->select('energy.*')
//            ->groupBy('energy.id')
//            ->get();

        if(!empty($rows)){
            foreach($rows as $the_row){
                $inner_col = array();
                $objEnergyMetaForm = EnergyFormMeta::join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                    ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                    ->where('energy_form_meta.energy_topic_id', '=', $energy_topic_id)
                    ->where('energy_form_meta.energy_id', '=', $the_row->id)
                    ->where('import_energy_form.from_date', '=', $start)
                    ->where('import_energy_form.to_date', '=', $end)
                    ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                    ->first();
                $final_result[$the_row->energy_name] = $objEnergyMetaForm;
            }
        }

        if(!empty($this_energy_type)){

            return view('frontend/report_energy_type_energy_topic_and_energy_direct_pie')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('energy_topic_name', $energy_topic_name)
                ->with('start', $start)
                ->with('end', $end)
                ->with('output', $output)
                ->with('energy_type', $energy_type_slug)
                ->with('this_energy_topic_all', $this_energy_topic_all)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('frontend/report')->with('warning', 'No such Energy Type!');

        }
    }

//report_energy_type_energy_topic_and_energy_direct_pie

    public function recordList(){

        $recordlist = Menu::join('menu_type', 'menu_type.id', '=', 'menu.menu_type_id')
            ->select('menu.*')
            ->where('menu_type.menu_type_slug', '=', 'records')
            ->where('menu.status', '=', 'Y')
            ->get();

        $topic_arr = array();

        foreach($recordlist as $the_result){
            array_push($topic_arr, $the_result->menu_slug);
        }

        $topic_arr[0] = (!empty($topic_arr[0]))?$topic_arr[0]:'';

        $topic = (!empty($_GET['topic']) && in_array($_GET['topic'], $topic_arr))?$_GET['topic']:$topic_arr[0];

        $data_map = Menu::join('records', 'records.menu_id', '=', 'menu.id')
            ->select('records.*')
            ->where('menu.menu_slug', '=', $topic)
            ->where('records.lat', '!=', '')
            ->where('records.lang', '!=', '')
            ->where('records.status', '=', 'Y')
            ->get();


//        echo '<pre>';
//        print_r(json_decode($data_map));
//        echo '<hr />';
//        print_r($topic);
//        echo '</pre>';
//        exit();

        return view('frontend/recordlist')
            ->with('recordlist', $recordlist)
            ->with('topic', $topic)
            ->with('data_map', $data_map);

    }

    public function provincewisereport($province_slug, Request $request){


//        echo $province_slug;
//
//        return 1;

        $start = 2019;
        $end = 2020;

        if($province_slug == 'province-1' || $province_slug == 'province-2' || $province_slug == 'province-3' || $province_slug == 'province-4' || $province_slug == 'province-5' || $province_slug == 'province-6' || $province_slug == 'province-7'){

            $objProvince = Location::where('location_slug', $province_slug)->first();

            $energy_type_slug = 'consumption';

            $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

            $start = 2019;
            $end = $start + 1;

            $output = (!empty($request->get('output')))?$request->get('output'):'overall';

//            echo $output; // overall
//
//            return 1;

            $energy_year = EnergyYear::where('status', 'Y')->where('is_completed', 'N')->get();

            $energy_listing = Energy::join('energy_type_verses_energy_mapping AS etvem', 'etvem.energy_id', '=', 'energy.id')
                ->join('fuel_type AS ft', 'ft.id', '=', 'energy.fuel_type_id')
                ->select('energy.*', 'ft.fuel_type_name')
                ->where('etvem.energy_type_id', $this_energy_type->id)
                ->where('energy.id', '<', 40)
                ->orderBy('energy.energy_order', 'asc')
                ->get();

            $data = array();

            if(!empty($energy_listing[0])){
                foreach($energy_listing as $the_energy){
                    $arr = ConsumptionEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'consumption_energy_form.id')
                        ->select('efm.*')
                        ->where('consumption_energy_form.energy_id', '=', $the_energy->id)
                        ->where('consumption_energy_form.province_id', '=', $objProvince->id)
                        ->where('efm.energy_form_topic', '=', 'consumption')
                        ->where('efm.energy_topic', '=', 'overall')
                        ->first();

                    $data[$the_energy->id] = $arr;

                }
            }

            $final_result = array();

            if($output == 'fueltype'){

                $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
                    ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
                    ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                    ->select('energy.*', 'fuel_type.fuel_type_name', 'fuel_type.fuel_order')
                    ->where('et.energy_type_slug', '=', 'consumption')
                    ->where('energy.status', 'Y')
                    ->where('fuel_type.fuel_order', '!=', '')
                    ->where('energy.id', '<', 40)
                    ->groupBy('energy.id')
                    ->orderBy('energy.energy_order', 'asc')
                    ->get();

//                echo '<pre>';
//                print_r(json_decode($rows));
//                echo '</pre>';
//                exit();

                if(!empty($rows)){
                    foreach($rows as $the_row){
                        $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_form_topic', '=', 'consumption')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->where('consumption_energy_form.province_id', '=', $objProvince->id)
                            ->where('consumption_energy_form.district_id', '=', null)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        if(!empty($objEnergyMetaForm->qty)){
                            $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_name] = $objEnergyMetaForm->qty;
                        }else{
                            $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_name] = 0;
                        }
                    }
                }

//                echo '<pre>';
//                print_r($final_result);
//                echo '</pre>';
//                exit();

//            exit();

                $province_name = $objProvince;
                
                if($province_slug == 'province-1' || $province_slug == 'province-2'){
                    $start = 2019;
                    $end = 2020;
                }elseif($province_slug == 'province-3'){
                    $start = 2021;
                    $end = 2022;
                }else{
                    $start = 2022;
                    $end = 2023;
                }

                return view('frontend/provincereport/energy_report_new_consumption_bar')
                    ->with('url', $request->url())
                    ->with('this_energy_type', $this_energy_type)
                    ->with('start', $start)
                    ->with('end', $end)
                    ->with('energy_topic', $rows)
                    ->with('output', $output)
                    ->with('energy_type', $energy_type_slug)
                    ->with('energy_year', $energy_year)
                    ->with('col_send', $rows)
                    ->with('province_name', $province_name)
                    ->with('final_result', $final_result);

            }elseif($output == 'districtwise'){

                $final_result = array();

                $col_keys = Location::join('location_type as lt', 'lt.id', '=', 'location.location_type_id')
                    ->where('lt.location_type_slug', 'district')
                    ->where('location.parent_id', $objProvince->id)
                    ->select('location.*')
                    ->groupBy('location.id')
                    ->orderBy('location.location_name', 'asc')
                    ->get();

                $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
                    ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                    ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
                    ->select('energy.*', 'fuel_type.fuel_type_name', 'fuel_type.fuel_order')
                    ->where('et.energy_type_slug', '=', 'consumption')
                    ->where('energy.status', 'Y')
                    ->where('fuel_type.fuel_order', '!=', '')
                    ->where('energy.id', '<', 40)
                    ->groupBy('energy.id')
                    ->orderBy('energy.energy_order', 'asc')
                    ->get();

//                echo '<pre>';
//                print_r(json_decode($rows));
//                echo '</pre>';

//                exit();

                $col_send = array();

                if(!empty($col_keys)){
                    foreach($col_keys as $this_col_key){
                        array_push($col_send, $this_col_key->location_name);
                    }
                }

//            echo '<pre>';
//            print_r($col_send);
//            exit();

                if(!empty($rows)){
                    foreach($rows as $the_row){
                        $inner_col = array();
                        $counter = 0;
                        foreach($col_keys as $the_col){
                            $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                            $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                                ->where('energy_form_meta.energy_form_topic', '=', 'consumption')
                                ->where('energy_form_meta.energy_id', '=', $the_row->id)
                                ->where('consumption_energy_form.from_date', '=', $start)
                                ->where('consumption_energy_form.to_date', '=', $end)
                                ->where('consumption_energy_form.province_id', '=', $objProvince->id)
                                ->where('consumption_energy_form.district_id', '=', $the_col->id)
                                ->where('consumption_energy_form.local_gov_id', '=', null)
                                ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                                ->first();

                            $inner_col[$counter] += (!empty($objEnergyMetaForm->qty))?(float)$objEnergyMetaForm->qty:0;
                            $counter++;
                        }
                        $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                    }
                }

//            exit();

                $province_name = $objProvince;
                
                if($province_slug == 'province-1' || $province_slug == 'province-2'){
                    $start = 2019;
                    $end = 2020;
                }elseif($province_slug == 'province-3'){
                    $start = 2021;
                    $end = 2022;
                }else{
                    $start = 2022;
                    $end = 2023;
                }

                return view('frontend/provincereport/energy_report_new_consumption_bar_districtwise2')
                    ->with('url', $request->url())
                    ->with('this_energy_type', $this_energy_type)
                    ->with('start', $start)
                    ->with('end', $end)
                    ->with('energy_topic', $rows)
                    ->with('energy_type', $energy_type_slug)
                    ->with('energy_year', $energy_year)
                    ->with('col_send', $rows)
                    ->with('col_send', $col_send)
                    ->with('output', $output)
                    ->with('energy_type_slug', $energy_type_slug)
                    ->with('energy_topic', 'Overall')
                    ->with('province_name', $province_name)
                    ->with('final_result', $final_result);

            }elseif($output == 'sectorwise'){

//                return 1;

                $final_result = array();

                $col_keys = Sector::where('status', 'Y')->orderBy('entry_order', 'ASC')->get();

//            $col_keys = Location::join('location_type as lt', 'lt.id', '=', 'location.location_type_id')
//                ->where('lt.location_type_slug', 'district')
//                ->where('location.parent_id', $province_id)
//                ->select('location.*')
//                ->groupBy('location.id')
//                ->orderBy('location.location_name', 'asc')
//                ->get();

                $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
                    ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                    ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
                    ->select('energy.*', 'fuel_type.fuel_type_name', 'fuel_type.fuel_order')
                    ->where('et.energy_type_slug', '=', 'consumption')
                    ->where('energy.status', 'Y')
                    ->where('fuel_type.fuel_order', '!=', '')
                    ->where('energy.id', '<', 40)
                    ->groupBy('energy.id')
                    ->orderBy('energy.energy_order', 'asc')
                    ->get();

                $col_send = array();

                if(!empty($col_keys)){
                    foreach($col_keys as $this_col_key){
                        array_push($col_send, $this_col_key->sector_name);
                    }
                }

//            echo '<pre>';
//            print_r(json_decode($rows));
//            exit();

                if(!empty($rows)){
                    foreach($rows as $the_row){
                        $inner_col = array();
                        $counter = 0;
                        foreach($col_keys as $the_col){
                            $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                            $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                                ->where('energy_form_meta.energy_form_topic', '=', 'consumption')
                                ->where('energy_form_meta.energy_id', '=', $the_row->id)
                                ->where('consumption_energy_form.from_date', '=', $start)
                                ->where('consumption_energy_form.to_date', '=', $end)
                                ->where('consumption_energy_form.province_id', '=', $objProvince->id)
                                ->where('consumption_energy_form.district_id', '=', null)
                                ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                                ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                                ->first();

                            $inner_col[$counter] += (!empty($objEnergyMetaForm->qty))?(float)$objEnergyMetaForm->qty:0;
                            $counter++;
                        }
                        $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                    }
                }

//            exit();

                $province_name = $objProvince;
                
                if($province_slug == 'province-1' || $province_slug == 'province-2'){
                    $start = 2019;
                    $end = 2020;
                }elseif($province_slug == 'province-3'){
                    $start = 2021;
                    $end = 2022;
                }else{
                    $start = 2022;
                    $end = 2023;
                }

                return view('frontend/provincereport/energy_report_new_consumption_bar_sectorwise2')
                    ->with('url', $request->url())
                    ->with('this_energy_type', $this_energy_type)
                    ->with('start', $start)
                    ->with('end', $end)
                    ->with('output', $output)
                    ->with('energy_topic', $rows)
                    ->with('energy_type', $energy_type_slug)
                    ->with('energy_year', $energy_year)
                    ->with('col_send', $rows)
                    ->with('col_send', $col_send)
                    ->with('energy_type_slug', $energy_type_slug)
                    ->with('energy_topic', 'Overall')
                    ->with('province_name', $province_name)
                    ->with('final_result', $final_result);

            }elseif($output == 'overall_sectorwise'){

                $rows = Sector::where('status', 'Y')->orderBy('entry_order', 'ASC')->get();

//            $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
//                ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
//                ->where('et.energy_type_slug', '=', 'consumption')
//                ->select('energy.*')
//                ->groupBy('energy.id')
//                ->orderBy('energy.energy_order', 'asc')
//                ->get();

                if(!empty($rows)){
                    foreach($rows as $the_row){
                        $inner_col = array();
                        $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_form_topic', '=', 'consumption')
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->where('consumption_energy_form.province_id', '=', $objProvince->id)
                            ->where('consumption_energy_form.district_id', '=', null)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        if(!empty($objEnergyMetaForm->qty)){
                            $final_result[$the_row->sector_name] = $objEnergyMetaForm->qty;
                        }else{
                            $final_result[$the_row->sector_name] = 0;
                        }

//                    echo '<pre>';
//                    print_r(json_decode($objEnergyMetaForm));
                    }
                }

//            exit();

                $province_name = $objProvince;
                
                if($province_slug == 'province-1' || $province_slug == 'province-2'){
                    $start = 2019;
                    $end = 2020;
                }elseif($province_slug == 'province-3'){
                    $start = 2021;
                    $end = 2022;
                }else{
                    $start = 2022;
                    $end = 2023;
                }

                return view('frontend/provincereport/energy_report_new_consumption_pie_sectorwise')
                    ->with('url', $request->url())
                    ->with('this_energy_type', $this_energy_type)
                    ->with('start', $start)
                    ->with('end', $end)
                    ->with('output', $output)
                    ->with('energy_topic', $rows)
                    ->with('energy_type', $energy_type_slug)
                    ->with('energy_year', $energy_year)
                    ->with('province_name', $province_name)
                    ->with('final_result', $final_result);

            }else{

//                return 1;

                $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
                    ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
                    ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                    ->select('energy.*', 'fuel_type.fuel_type_name', 'fuel_type.fuel_order')
                    ->where('et.energy_type_slug', '=', 'consumption')
                    ->where('energy.status', 'Y')
                    ->where('fuel_type.fuel_order', '!=', '')
                    ->where('energy.id', '<', 40)
                    ->groupBy('energy.id')
                    ->orderBy('energy.energy_order', 'asc')
                    ->get();

                if(!empty($rows)){
                    foreach($rows as $the_row){
                        $inner_col = array();
                        $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
//                        ->where('energy_form_meta.energy_topic', '=', 'overall')
                            ->where('energy_form_meta.energy_form_topic', '=', 'consumption')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->where('consumption_energy_form.province_id', '=', $objProvince->id)
                            ->where('consumption_energy_form.district_id', '=', null)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        if(!empty($objEnergyMetaForm->qty)){
                            $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $objEnergyMetaForm->qty;
                        }else{
                            $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = 0;
                        }

//                    echo '<pre>';
//                    print_r(json_decode($objEnergyMetaForm));
                    }
                }

//            exit();

                $province_name = $objProvince;
                
                if($province_slug == 'province-1' || $province_slug == 'province-2'){
                    $start = 2019;
                    $end = 2020;
                }elseif($province_slug == 'province-3'){
                    $start = 2021;
                    $end = 2022;
                }else{
                    $start = 2022;
                    $end = 2023;
                }

                return view('frontend/provincereport/energy_report_new_consumption_pie')
                    ->with('url', $request->url())
                    ->with('this_energy_type', $this_energy_type)
                    ->with('start', $start)
                    ->with('end', $end)
                    ->with('energy_topic', $rows)
                    ->with('energy_type', $energy_type_slug)
                    ->with('energy_year', $energy_year)
                    ->with('province_name', $province_name)
                    ->with('final_result', $final_result);

            }

        }else{

            return view('frontend/provincereport');

        }


    }

    public function reportCentralConsumptionEnergyByFuelTypesPie(Request $request){

        $start = (!empty($request->get('start')))?intval($request->get('start')):2023;

        $end = $start + 1;

        $energy_type_slug = 'consumption';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

//        $start = 2019;
//        $end = $start + 1;

        $output = (!empty($request->get('output')))?$request->get('output'):'overall';

        $energy_year = EnergyYear::where('status', 'Y')->where('is_completed', 'N')->get();

        $energy_listing = Energy::join('energy_type_verses_energy_mapping AS etvem', 'etvem.energy_id', '=', 'energy.id')
            ->join('fuel_type AS ft', 'ft.id', '=', 'energy.fuel_type_id')
            ->select('energy.*', 'ft.fuel_type_name')
            ->where('etvem.energy_type_id', $this_energy_type->id)
            ->where('energy.economic_survey_status', 'Y')
            ->orderBy('energy.energy_order', 'asc')
            ->get();

        $data = array();

        if(!empty($energy_listing[0])){
            foreach($energy_listing as $the_energy){
                $arr = ConsumptionEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'consumption_energy_form.id')
                    ->select('efm.*')
                    ->where('consumption_energy_form.energy_id', '=', $the_energy->id)
                    ->where('consumption_energy_form.central_id', '=', 1)
                    ->where('consumption_energy_form.province_id', '=', null)
                    ->where('consumption_energy_form.district_id', '=', null)
                    ->where('efm.energy_form_topic', '=', 'consumption')
                    ->where('efm.energy_topic', '=', 'sector')
                    ->first();

                $data[$the_energy->id] = $arr;

            }
        }

        $final_result = array();

        if($output == 'fueltype'){

            $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
                ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->select('energy.*', 'fuel_type.fuel_type_name', 'fuel_type.fuel_order')
                ->where('et.energy_type_slug', '=', 'consumption')
                ->where('energy.economic_survey_status', 'Y')
                ->where('fuel_type.fuel_order', '!=', '')
                ->groupBy('energy.id')
                ->orderBy('energy.energy_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_form_topic', '=', 'consumption')
                        ->where('energy_form_meta.energy_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->where('consumption_energy_form.central_id', '=', 1)
                        ->where('consumption_energy_form.province_id', '=', null)
                        ->where('consumption_energy_form.district_id', '=', null)
                        ->where('consumption_energy_form.district_id', '=', null)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    if(!empty($objEnergyMetaForm->qty)){
                        $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $objEnergyMetaForm->qty;
                    }else{
                        $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = 0;
                    }
                }
            }

//            exit();

            return view('frontend/federalreport/energy_report_new_consumption_bar')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('output', $output)
                ->with('energy_topic', $rows)
                ->with('energy_type', $energy_type_slug)
                ->with('energy_year', $energy_year)
                ->with('col_send', $rows)
                ->with('final_result', $final_result);

        }elseif($output == 'sectorwise'){

            $final_result = array();

            $col_keys = Sector::where('status', 'Y')->orderBy('entry_order', 'ASC')->get();

//            $col_keys = Location::join('location_type as lt', 'lt.id', '=', 'location.location_type_id')
//                ->where('lt.location_type_slug', 'district')
//                ->where('location.parent_id', $province_id)
//                ->select('location.*')
//                ->groupBy('location.id')
//                ->orderBy('location.location_name', 'asc')
//                ->get();

            $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
                ->select('energy.*', 'fuel_type.fuel_type_name')
                ->where('et.energy_type_slug', '=', 'consumption')
                ->where('energy.economic_survey_status', 'Y')
                ->groupBy('energy.id')
                ->orderBy('energy.energy_order', 'asc')
                ->get();

            $col_send = array();

            if(!empty($col_keys)){
                foreach($col_keys as $this_col_key){
                    array_push($col_send, $this_col_key->sector_name);
                }
            }

//            echo '<pre>';
//            print_r($col_send);
//            exit();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_form_topic', '=', 'consumption')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->where('consumption_energy_form.central_id', '=', 1)
                            ->where('consumption_energy_form.province_id', '=', null)
                            ->where('consumption_energy_form.district_id', '=', null)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();

                        $inner_col[$counter] += (!empty($objEnergyMetaForm->qty))?(float)$objEnergyMetaForm->qty:0;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }

//            exit();

            return view('frontend/federalreport/energy_report_new_consumption_bar_sectorwise2')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('output', $output)
                ->with('energy_topic', $rows)
                ->with('energy_type', $energy_type_slug)
                ->with('energy_year', $energy_year)
                ->with('col_send', $rows)
                ->with('col_send', $col_send)
                ->with('energy_type_slug', $energy_type_slug)
                ->with('energy_topic', 'Overall')
                ->with('final_result', $final_result);

        }elseif($output == 'overall_sectorwise'){

            $rows = Sector::where('status', 'Y')->orderBy('entry_order', 'ASC')->get();

//            $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
//                ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
//                ->where('et.energy_type_slug', '=', 'consumption')
//                ->select('energy.*')
//                ->groupBy('energy.id')
//                ->orderBy('energy.energy_order', 'asc')
//                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_form_topic', '=', 'consumption')
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->where('consumption_energy_form.central_id', '=', 1)
                        ->where('consumption_energy_form.province_id', '=', null)
                        ->where('consumption_energy_form.district_id', '=', null)
                        ->where('consumption_energy_form.district_id', '=', null)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    if(!empty($objEnergyMetaForm->qty)){
                        $final_result[$the_row->sector_name] = $objEnergyMetaForm->qty;
                    }else{
                        $final_result[$the_row->sector_name] = 0;
                    }

//                    echo '<pre>';
//                    print_r(json_decode($objEnergyMetaForm));
                }
            }

//            exit();

            return view('frontend/federalreport/energy_report_new_consumption_pie_sectorwise')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('output', $output)
                ->with('energy_topic', $rows)
                ->with('energy_type', $energy_type_slug)
                ->with('energy_year', $energy_year)
                ->with('final_result', $final_result);

        }else{
            $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
                ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->select('energy.*', 'fuel_type.fuel_type_name', 'fuel_type.fuel_order')
                ->where('et.energy_type_slug', '=', 'consumption')
                ->where('energy.economic_survey_status', 'Y')
                ->where('fuel_type.fuel_order', '!=', '')
                ->groupBy('energy.id')
                ->orderBy('energy.energy_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_form_topic', '=', 'consumption')
                        ->where('energy_form_meta.energy_topic', '=', 'sector')
                        ->where('energy_form_meta.energy_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->where('consumption_energy_form.central_id', '=', 1)
                        ->where('consumption_energy_form.province_id', '=', null)
                        ->where('consumption_energy_form.district_id', '=', null)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    if(!empty($objEnergyMetaForm->qty)){
                        $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $objEnergyMetaForm->qty;
                    }else{
                        $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = 0;
                    }

//                    echo '<pre>';
//                    print_r(json_decode($objEnergyMetaForm));
                }
            }

//            exit();


            return view('frontend/federalreport/energy_report_new_consumption_pie')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('output', $output)
                ->with('energy_topic', $rows)
                ->with('energy_type', $energy_type_slug)
                ->with('energy_year', $energy_year)
                ->with('final_result', $final_result);

        }

    }

    public function reportFederalCentralConsumptionEnergyByFuelTypesPie(Request $request){

        $start = (!empty($request->get('start')))?intval($request->get('start')):2019;

        $end = $start + 1;

        $energy_type_slug = 'consumption';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

//        $start = 2019;
//        $end = $start + 1;

        $output = (!empty($request->get('output')))?$request->get('output'):'overall';

        $energy_year = EnergyYear::where('status', 'Y')->where('is_completed', 'N')->get();

        $energy_listing = Energy::join('energy_type_verses_energy_mapping AS etvem', 'etvem.energy_id', '=', 'energy.id')
            ->join('fuel_type AS ft', 'ft.id', '=', 'energy.fuel_type_id')
            ->select('energy.*', 'ft.fuel_type_name')
            ->where('etvem.energy_type_id', $this_energy_type->id)
            ->orderBy('energy.energy_order', 'asc')
            ->get();

        $data = array();

        if(!empty($energy_listing[0])){
            foreach($energy_listing as $the_energy){
                $arr = ConsumptionEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'consumption_energy_form.id')
                    ->select('efm.*')
                    ->where('consumption_energy_form.energy_id', '=', $the_energy->id)
                    ->where('consumption_energy_form.central_id', '=', 1)
                    ->where('consumption_energy_form.province_id', '=', null)
                    ->where('consumption_energy_form.district_id', '=', null)
                    ->where('efm.energy_form_topic', '=', 'consumption')
                    ->where('efm.energy_topic', '=', 'sector')
                    ->first();

                $data[$the_energy->id] = $arr;

            }
        }

        $final_result = array();

        if($output == 'fueltype'){

            $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
                ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->select('energy.*', 'fuel_type.fuel_type_name', 'fuel_type.fuel_order')
                ->where('et.energy_type_slug', '=', 'consumption')
                ->where('energy.status', 'Y')
                ->where('fuel_type.fuel_order', '!=', '')
                ->groupBy('energy.id')
                ->orderBy('energy.energy_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_form_topic', '=', 'consumption')
                        ->where('energy_form_meta.energy_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->where('consumption_energy_form.central_id', '=', 1)
                        ->where('consumption_energy_form.province_id', '=', null)
                        ->where('consumption_energy_form.district_id', '=', null)
                        ->where('consumption_energy_form.district_id', '=', null)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    if(!empty($objEnergyMetaForm->qty)){
                        $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $objEnergyMetaForm->qty;
                    }else{
                        $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = 0;
                    }
                }
            }

//            exit();

            return view('frontend/federalreport/energy_report_new_consumption_bar')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('output', $output)
                ->with('energy_topic', $rows)
                ->with('energy_type', $energy_type_slug)
                ->with('energy_year', $energy_year)
                ->with('col_send', $rows)
                ->with('final_result', $final_result);

        }elseif($output == 'sectorwise'){

            $final_result = array();

            $col_keys = Sector::where('status', 'Y')->orderBy('entry_order', 'ASC')->get();

//            $col_keys = Location::join('location_type as lt', 'lt.id', '=', 'location.location_type_id')
//                ->where('lt.location_type_slug', 'district')
//                ->where('location.parent_id', $province_id)
//                ->select('location.*')
//                ->groupBy('location.id')
//                ->orderBy('location.location_name', 'asc')
//                ->get();

            $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
                ->select('energy.*', 'fuel_type.fuel_type_name')
                ->where('et.energy_type_slug', '=', 'consumption')
                ->where('energy.status', 'Y')
                ->groupBy('energy.id')
                ->orderBy('energy.energy_order', 'asc')
                ->get();

            $col_send = array();

            if(!empty($col_keys)){
                foreach($col_keys as $this_col_key){
                    array_push($col_send, $this_col_key->sector_name);
                }
            }

//            echo '<pre>';
//            print_r($col_send);
//            exit();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_form_topic', '=', 'consumption')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->where('consumption_energy_form.central_id', '=', 1)
                            ->where('consumption_energy_form.province_id', '=', null)
                            ->where('consumption_energy_form.district_id', '=', null)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();

                        $inner_col[$counter] += (!empty($objEnergyMetaForm->qty))?(float)$objEnergyMetaForm->qty:0;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }

//            exit();

            return view('frontend/federalreport/energy_report_new_consumption_bar_sectorwise2')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('output', $output)
                ->with('energy_topic', $rows)
                ->with('energy_type', $energy_type_slug)
                ->with('energy_year', $energy_year)
                ->with('col_send', $rows)
                ->with('col_send', $col_send)
                ->with('energy_type_slug', $energy_type_slug)
                ->with('energy_topic', 'Overall')
                ->with('final_result', $final_result);

        }elseif($output == 'overall_sectorwise'){

            $rows = Sector::where('status', 'Y')->orderBy('entry_order', 'ASC')->get();

//            $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
//                ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
//                ->where('et.energy_type_slug', '=', 'consumption')
//                ->select('energy.*')
//                ->groupBy('energy.id')
//                ->orderBy('energy.energy_order', 'asc')
//                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_form_topic', '=', 'consumption')
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->where('consumption_energy_form.central_id', '=', 1)
                        ->where('consumption_energy_form.province_id', '=', null)
                        ->where('consumption_energy_form.district_id', '=', null)
                        ->where('consumption_energy_form.district_id', '=', null)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    if(!empty($objEnergyMetaForm->qty)){
                        $final_result[$the_row->sector_name] = $objEnergyMetaForm->qty;
                    }else{
                        $final_result[$the_row->sector_name] = 0;
                    }

//                    echo '<pre>';
//                    print_r(json_decode($objEnergyMetaForm));
                }
            }

//            exit();

            return view('frontend/federalreport/energy_report_new_consumption_pie_sectorwise')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('output', $output)
                ->with('energy_topic', $rows)
                ->with('energy_type', $energy_type_slug)
                ->with('energy_year', $energy_year)
                ->with('final_result', $final_result);

        }else{
            $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
                ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->select('energy.*', 'fuel_type.fuel_type_name', 'fuel_type.fuel_order')
                ->where('et.energy_type_slug', '=', 'consumption')
                ->where('energy.status', 'Y')
                ->where('fuel_type.fuel_order', '!=', '')
                ->groupBy('energy.id')
                ->orderBy('energy.energy_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_form_topic', '=', 'consumption')
                        ->where('energy_form_meta.energy_topic', '=', 'sector')
                        ->where('energy_form_meta.energy_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->where('consumption_energy_form.central_id', '=', 1)
                        ->where('consumption_energy_form.province_id', '=', null)
                        ->where('consumption_energy_form.district_id', '=', null)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    if(!empty($objEnergyMetaForm->qty)){
                        $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $objEnergyMetaForm->qty;
                    }else{
                        $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = 0;
                    }

//                    echo '<pre>';
//                    print_r(json_decode($objEnergyMetaForm));
                }
            }

//            exit();


            return view('frontend/federalreport/energy_report_new_consumption_pie')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('output', $output)
                ->with('energy_topic', $rows)
                ->with('energy_type', $energy_type_slug)
                ->with('energy_year', $energy_year)
                ->with('final_result', $final_result);

        }

    }

    public function reportCentralConsumptionEnergyBySectors(Request $request){

//        return 1;

        $start = (!empty($request->get('start')))?intval($request->get('start')):2023;

        $end = $start + 1;

        $energy_type_slug = 'consumption';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

//        $start = 2019;
//        $end = $start + 1;

        $output = 'sectorwise';

        $energy_year = EnergyYear::where('status', 'Y')->where('is_completed', 'N')->get();

        $energy_listing = Energy::join('energy_type_verses_energy_mapping AS etvem', 'etvem.energy_id', '=', 'energy.id')
            ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
            ->select('energy.*', 'fuel_type.fuel_type_name', 'fuel_type.fuel_order')
            ->where('energy.status', 'Y')
            ->where('fuel_type.fuel_order', '!=', '')
            ->where('etvem.energy_type_id', $this_energy_type->id)
            ->groupBy('energy.id')
            ->orderBy('energy.energy_order', 'asc')
            ->get();

        $data = array();

        if(!empty($energy_listing[0])){
            foreach($energy_listing as $the_energy){
                $arr = ConsumptionEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'consumption_energy_form.id')
                    ->select('efm.*')
                    ->where('consumption_energy_form.energy_id', '=', $the_energy->id)
                    ->where('consumption_energy_form.central_id', '=', 1)
                    ->where('consumption_energy_form.province_id', '=', null)
                    ->where('consumption_energy_form.district_id', '=', null)
                    ->where('efm.energy_form_topic', '=', 'consumption')
                    ->where('efm.energy_topic', '=', 'sector')
                    ->first();

                $data[$the_energy->id] = $arr;

            }
        }

        $final_result = array();

        if($output == 'fueltype'){

            $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
                ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->select('energy.*', 'fuel_type.fuel_type_name', 'fuel_type.fuel_order')
                ->where('et.energy_type_slug', '=', 'consumption')
                ->where('energy.status', 'Y')
                ->where('fuel_type.fuel_order', '!=', '')
                ->groupBy('energy.id')
                ->orderBy('energy.energy_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_form_topic', '=', 'consumption')
                        ->where('energy_form_meta.energy_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->where('consumption_energy_form.central_id', '=', 1)
                        ->where('consumption_energy_form.province_id', '=', null)
                        ->where('consumption_energy_form.district_id', '=', null)
                        ->where('consumption_energy_form.district_id', '=', null)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    if(!empty($objEnergyMetaForm->qty)){
                        $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $objEnergyMetaForm->qty;
                    }else{
                        $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = 0;
                    }
                }
            }

//                exit();

            return view('frontend/federalreport/energy_report_new_consumption_bar')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('output', $output)
                ->with('energy_topic', $rows)
                ->with('energy_type', $energy_type_slug)
                ->with('energy_year', $energy_year)
                ->with('col_send', $rows)
                ->with('final_result', $final_result);

        }elseif($output == 'sectorwise'){

//            return 123;

            $final_result = array();

            $col_keys = Sector::where('status', 'Y')->orderBy('entry_order', 'ASC')->get();

//            $col_keys = Location::join('location_type as lt', 'lt.id', '=', 'location.location_type_id')
//                ->where('lt.location_type_slug', 'district')
//                ->where('location.parent_id', $province_id)
//                ->select('location.*')
//                ->groupBy('location.id')
//                ->orderBy('location.location_name', 'asc')
//                ->get();

            $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
                ->select('energy.*', 'fuel_type.fuel_type_name', 'fuel_type.fuel_order')
                ->where('et.energy_type_slug', '=', 'consumption')
                ->where('energy.status', 'Y')
                ->where('fuel_type.fuel_order', '!=', '')
                ->groupBy('energy.id')
                ->orderBy('energy.energy_order', 'asc')
                ->get();

            $col_send = array();

            if(!empty($col_keys)){
                foreach($col_keys as $this_col_key){
                    array_push($col_send, $this_col_key->sector_name);
                }
            }

//            echo '<pre>';
//            print_r($col_send);
//            exit();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;

                        $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_form_topic', '=', 'consumption')
                            ->where('energy_form_meta.energy_topic', '=', 'sector')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->where('consumption_energy_form.central_id', '=', 1)
                            ->where('consumption_energy_form.province_id', '=', null)
                            ->where('consumption_energy_form.district_id', '=', null)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();

                        $inner_col[$counter] += (!empty($objEnergyMetaForm->qty))?$objEnergyMetaForm->qty:0;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }

//                echo '<pre>';
//                print_r($final_result);
//                echo '</pre>';

//                exit();

//            exit();

            return view('frontend/federalreport/energy_report_new_consumption_bar_sectorwise2')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('output', $output)
                ->with('energy_topic', $rows)
                ->with('energy_type', $energy_type_slug)
                ->with('energy_year', $energy_year)
                ->with('col_send', $rows)
                ->with('col_send', $col_send)
                ->with('energy_type_slug', $energy_type_slug)
                ->with('energy_topic', 'Overall')
                ->with('final_result', $final_result);

        }elseif($output == 'overall_sectorwise'){

            $rows = Sector::where('status', 'Y')->orderBy('entry_order', 'ASC')->get();

//            $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
//                ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
//                ->where('et.energy_type_slug', '=', 'consumption')
//                ->select('energy.*')
//                ->groupBy('energy.id')
//                ->orderBy('energy.energy_order', 'asc')
//                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_form_topic', '=', 'consumption')
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->where('consumption_energy_form.central_id', '=', 1)
                        ->where('consumption_energy_form.province_id', '=', null)
                        ->where('consumption_energy_form.district_id', '=', null)
                        ->where('consumption_energy_form.district_id', '=', null)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    if(!empty($objEnergyMetaForm->qty)){
                        $final_result[$the_row->sector_name] = $objEnergyMetaForm->qty;
                    }else{
                        $final_result[$the_row->sector_name] = 0;
                    }

//                    echo '<pre>';
//                    print_r(json_decode($objEnergyMetaForm));
                }
            }

//            exit();

            return view('frontend/federalreport/energy_report_new_consumption_pie_sectorwise')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('output', $output)
                ->with('energy_topic', $rows)
                ->with('energy_type', $energy_type_slug)
                ->with('energy_year', $energy_year)
                ->with('final_result', $final_result);

        }else{
            $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
                ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->select('energy.*', 'fuel_type.fuel_type_name', 'fuel_type.fuel_order')
                ->where('et.energy_type_slug', '=', 'consumption')
                ->where('energy.status', 'Y')
                ->where('fuel_type.fuel_order', '!=', '')
                ->groupBy('energy.id')
                ->orderBy('energy.energy_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_form_topic', '=', 'consumption')
                        ->where('energy_form_meta.energy_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->where('consumption_energy_form.central_id', '=', 1)
                        ->where('consumption_energy_form.province_id', '=', null)
                        ->where('consumption_energy_form.district_id', '=', null)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    if(!empty($objEnergyMetaForm->qty)){
                        $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_name] = $objEnergyMetaForm->qty;
                    }else{
                        $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_name] = 0;
                    }

//                    echo '<pre>';
//                    print_r(json_decode($objEnergyMetaForm));
                }
            }

//            exit();


            return view('frontend/federalreport/energy_report_new_consumption_pie')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('output', $output)
                ->with('energy_topic', $rows)
                ->with('energy_type', $energy_type_slug)
                ->with('energy_year', $energy_year)
                ->with('final_result', $final_result);

        }

    }

    public function reportCentralConsumptionEnergyByBarGraph(Request $request){

//        return 1;
        $start = (!empty($_GET['start']) && is_numeric($_GET['start']) && $_GET['start'] > 1990 && $_GET['start'] <= (date('Y') - 1) )?$_GET['start']:2005;

        $end = (!empty($_GET['end']) && is_numeric($_GET['end']) && $_GET['end'] > 1990 && $_GET['end'] <= date('Y') )?$_GET['end']:date('Y');

        $end = ($end > $start)?$end:($start + 1);

//        echo $start;
//        echo '<hr />';
//        echo $end;

//        exit();

        $energy_type_slug = 'consumption';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

//        $start = 2019;
//        $end = $start + 1;

        $output = 'sectorwise';

        $energy_year = EnergyYear::where('status', 'Y')->where('is_completed', 'N')->get();

        $energy_listing = Energy::join('energy_type_verses_energy_mapping AS etvem', 'etvem.energy_id', '=', 'energy.id')
            ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
            ->select('energy.*', 'fuel_type.fuel_type_name', 'fuel_type.fuel_order')
            ->where('energy.economic_survey_status', 'Y')
            ->where('fuel_type.fuel_order', '!=', '')
            ->where('etvem.energy_type_id', $this_energy_type->id)
            ->groupBy('energy.id')
            ->orderBy('energy.energy_order', 'asc')
            ->get();

        $data = array();
                
        // echo '<pre>';
        // print_r(json_decode($energy_listing));
        // echo '</pre>';
        
        // echo '<hr />';

        if(!empty($energy_listing[0])){
            foreach($energy_listing as $the_energy){
                $arr = ConsumptionEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'consumption_energy_form.id')
                    ->select('efm.*')
                    ->where('consumption_energy_form.energy_id', '=', $the_energy->id)
                    ->where('consumption_energy_form.central_id', '=', 1)
                    ->where('consumption_energy_form.province_id', '=', null)
                    ->where('consumption_energy_form.district_id', '=', null)
                    ->where('efm.energy_form_topic', '=', 'consumption')
                    ->where('efm.energy_topic', '=', 'sector')
                    ->first();

                $data[$the_energy->id] = $arr;
                
                // echo '<pre>';
                // print_r(json_decode($arr));
                // echo '</pre>';

            }
        }
        
        // exit();

        $final_result = array();



//            return 123;

            $final_result = array();

//        $col_keys = Sector::where('status', 'Y')->orderBy('entry_order', 'ASC')->get();

//            $col_keys = Location::join('location_type as lt', 'lt.id', '=', 'location.location_type_id')
//                ->where('lt.location_type_slug', 'district')
//                ->where('location.parent_id', $province_id)
//                ->select('location.*')
//                ->groupBy('location.id')
//                ->orderBy('location.location_name', 'asc')
//                ->get();

            $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
                ->select('energy.*', 'fuel_type.fuel_type_name', 'fuel_type.fuel_order')
                ->where('et.energy_type_slug', '=', 'consumption')
                ->where('energy.economic_survey_status', 'Y')
                ->where('fuel_type.fuel_order', '!=', '')
                ->groupBy('energy.id')
                ->orderBy('energy.energy_order', 'asc')
                ->get();

            $col_send = array();

//            if(!empty($col_keys)){
//                foreach($col_keys as $this_col_key){
//                    array_push($col_send, $this_col_key->energy_year_start);
//                }
//            }

//            echo '<pre>';
//            print_r($col_send);
//            exit();



        $final_result = array();

//        $col_keys = Sector::where('status', 'Y')->orderBy('entry_order', 'ASC')->get();

        $col_keys = EnergyYear::where('status', 'Y')
            ->where('energy_year_start', '>=', $start)
            ->where('energy_year_start', '<=', $end)
            ->orderBy('energy_year_start', 'asc')
            ->get();


//        echo '<pre>';
//        print_r($col_keys);
//        exit();

        $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
            ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
            ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
            ->select('energy.*', 'fuel_type.fuel_type_name', 'fuel_type.fuel_order')
            ->where('et.energy_type_slug', '=', 'consumption')
            ->where('energy.economic_survey_status', 'Y')
            ->where('fuel_type.fuel_order', '!=', '')
            ->groupBy('energy.id')
            ->orderBy('energy.energy_order', 'asc')
            ->get();

        $col_send = array();

        if(!empty($col_keys)){
            foreach($col_keys as $this_col_key){
                array_push($col_send, $this_col_key->energy_year_start);
            }
        }

//        echo '<pre>';
//        print_r($col_send);
//        exit();

        if(!empty($rows)){
            foreach($rows as $the_row){
                $inner_col = array();
                $counter = 0;
                foreach($col_send as $the_col){
                    $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;

                    $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_form_topic', '=', 'consumption')
                        ->where('energy_form_meta.energy_topic', '=', 'sector')
                        ->where('energy_form_meta.energy_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $the_col)
                        ->where('consumption_energy_form.central_id', '=', 1)
                        ->where('consumption_energy_form.province_id', '=', null)
                        ->where('consumption_energy_form.district_id', '=', null)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();

                    $inner_col[$counter] += (!empty($objEnergyMetaForm->qty))?$objEnergyMetaForm->qty:0;
                    $counter++;
                    
                                
            
                    // echo '<pre>';
                    // print_r($the_col);
                    // print_r($the_row->id);
                    // print_r(json_decode($objEnergyMetaForm));
                    // echo '<hr />';
                    
                    // echo '</pre>';
                    
                }
                $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
            }
        }

        // echo '<pre>';
        // print_r($col_send);
        // echo '<hr />';
        
        // echo '</pre>';

        // exit();

        return view('frontend/federalreport/energy_report_new_consumption_bar_trend')
            ->with('url', $request->url())
            ->with('this_energy_type', $this_energy_type)
            ->with('start', $start)
            ->with('end', $end)
            ->with('output', $output)
            ->with('energy_topic', $rows)
            ->with('energy_type', $energy_type_slug)
            ->with('energy_year', $energy_year)
//            ->with('col_send', $rows)
            ->with('col_send', $col_send)
            ->with('energy_type_slug', $energy_type_slug)
            ->with('energy_topic', 'Overall')
            ->with('final_result', $final_result);



    }

    public function reportCentralConsumptionEnergyByFueltypes(Request $request){

            $start = (!empty($request->get('start')))?intval($request->get('start')):2019;

            $end = $start + 1;

            $energy_type_slug = 'consumption';

            $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

    //        $start = 2019;
    //        $end = $start + 1;

            $output = 'fueltype';

            $energy_year = EnergyYear::where('status', 'Y')->where('is_completed', 'N')->get();

            $energy_listing = Energy::join('energy_type_verses_energy_mapping AS etvem', 'etvem.energy_id', '=', 'energy.id')
                ->join('fuel_type AS ft', 'ft.id', '=', 'energy.fuel_type_id')
                ->select('energy.*', 'ft.fuel_type_name')
                ->where('etvem.energy_type_id', $this_energy_type->id)
                ->orderBy('energy.energy_order', 'asc')
                ->get();

            $data = array();

            if(!empty($energy_listing[0])){
                foreach($energy_listing as $the_energy){
                    $arr = ConsumptionEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'consumption_energy_form.id')
                        ->select('efm.*')
                        ->where('consumption_energy_form.energy_id', '=', $the_energy->id)
                        ->where('consumption_energy_form.central_id', '=', 1)
                        ->where('consumption_energy_form.province_id', '=', null)
                        ->where('consumption_energy_form.district_id', '=', null)
                        ->where('efm.energy_form_topic', '=', 'consumption')
                        ->where('efm.energy_topic', '=', 'sector')
                        ->first();

                    $data[$the_energy->id] = $arr;

                }
            }

            $final_result = array();

            if($output == 'fueltype'){

                $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
                    ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
                    ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                    ->select('energy.*', 'fuel_type.fuel_type_name', 'fuel_type.fuel_order')
                    ->where('et.energy_type_slug', '=', 'consumption')
                    ->where('energy.status', 'Y')
                    ->where('fuel_type.fuel_order', '!=', '')
                    ->groupBy('energy.id')
                    ->orderBy('energy.energy_order', 'asc')
                    ->get();

                if(!empty($rows)){
                    foreach($rows as $the_row){
                        $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_form_topic', '=', 'consumption')
                            ->where('energy_form_meta.energy_topic', '=', 'sector')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->where('consumption_energy_form.central_id', '=', 1)
                            ->where('consumption_energy_form.province_id', '=', null)
                            ->where('consumption_energy_form.district_id', '=', null)
                            ->where('consumption_energy_form.district_id', '=', null)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        if(!empty($objEnergyMetaForm->qty)){
                            $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $objEnergyMetaForm->qty;
                        }else{
                            $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = 0;
                        }
                    }
                }

    //            exit();

                return view('frontend/federalreport/energy_report_new_consumption_bar')
                    ->with('url', $request->url())
                    ->with('this_energy_type', $this_energy_type)
                    ->with('start', $start)
                    ->with('end', $end)
                    ->with('output', $output)
                    ->with('energy_topic', $rows)
                    ->with('energy_type', $energy_type_slug)
                    ->with('energy_year', $energy_year)
                    ->with('col_send', $rows)
                    ->with('final_result', $final_result);

            }elseif($output == 'sectorwise'){

                $final_result = array();

                $col_keys = Sector::where('status', 'Y')->orderBy('entry_order', 'ASC')->get();

    //            $col_keys = Location::join('location_type as lt', 'lt.id', '=', 'location.location_type_id')
    //                ->where('lt.location_type_slug', 'district')
    //                ->where('location.parent_id', $province_id)
    //                ->select('location.*')
    //                ->groupBy('location.id')
    //                ->orderBy('location.location_name', 'asc')
    //                ->get();

                $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
                    ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                    ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
                    ->select('energy.*', 'fuel_type.fuel_type_name')
                    ->where('et.energy_type_slug', '=', 'consumption')
                    ->where('energy.status', 'Y')
                    ->groupBy('energy.id')
                    ->orderBy('energy.energy_order', 'asc')
                    ->get();

                $col_send = array();

                if(!empty($col_keys)){
                    foreach($col_keys as $this_col_key){
                        array_push($col_send, $this_col_key->sector_name);
                    }
                }

    //            echo '<pre>';
    //            print_r($col_send);
    //            exit();

                if(!empty($rows)){
                    foreach($rows as $the_row){
                        $inner_col = array();
                        $counter = 0;
                        foreach($col_keys as $the_col){
                            $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                            $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                                ->where('energy_form_meta.energy_form_topic', '=', 'consumption')
                                ->where('energy_form_meta.energy_id', '=', $the_row->id)
                                ->where('consumption_energy_form.from_date', '=', $start)
                                ->where('consumption_energy_form.to_date', '=', $end)
                                ->where('consumption_energy_form.central_id', '=', 1)
                                ->where('consumption_energy_form.province_id', '=', null)
                                ->where('consumption_energy_form.district_id', '=', null)
                                ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                                ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                                ->first();

                            $inner_col[$counter] += (!empty($objEnergyMetaForm->qty))?(float)$objEnergyMetaForm->qty:0;
                            $counter++;
                        }
                        $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                    }
                }

    //            exit();

                return view('frontend/federalreport/energy_report_new_consumption_bar_sectorwise2')
                    ->with('url', $request->url())
                    ->with('this_energy_type', $this_energy_type)
                    ->with('start', $start)
                    ->with('end', $end)
                    ->with('output', $output)
                    ->with('energy_topic', $rows)
                    ->with('energy_type', $energy_type_slug)
                    ->with('energy_year', $energy_year)
                    ->with('col_send', $rows)
                    ->with('col_send', $col_send)
                    ->with('energy_type_slug', $energy_type_slug)
                    ->with('energy_topic', 'Overall')
                    ->with('final_result', $final_result);

            }elseif($output == 'overall_sectorwise'){

                $rows = Sector::where('status', 'Y')->orderBy('entry_order', 'ASC')->get();

    //            $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
    //                ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
    //                ->where('et.energy_type_slug', '=', 'consumption')
    //                ->select('energy.*')
    //                ->groupBy('energy.id')
    //                ->orderBy('energy.energy_order', 'asc')
    //                ->get();

                if(!empty($rows)){
                    foreach($rows as $the_row){
                        $inner_col = array();
                        $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_form_topic', '=', 'consumption')
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->where('consumption_energy_form.central_id', '=', 1)
                            ->where('consumption_energy_form.province_id', '=', null)
                            ->where('consumption_energy_form.district_id', '=', null)
                            ->where('consumption_energy_form.district_id', '=', null)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        if(!empty($objEnergyMetaForm->qty)){
                            $final_result[$the_row->sector_name] = $objEnergyMetaForm->qty;
                        }else{
                            $final_result[$the_row->sector_name] = 0;
                        }

    //                    echo '<pre>';
    //                    print_r(json_decode($objEnergyMetaForm));
                    }
                }

    //            exit();

                return view('frontend/federalreport/energy_report_new_consumption_pie_sectorwise')
                    ->with('url', $request->url())
                    ->with('this_energy_type', $this_energy_type)
                    ->with('start', $start)
                    ->with('end', $end)
                    ->with('output', $output)
                    ->with('energy_topic', $rows)
                    ->with('energy_type', $energy_type_slug)
                    ->with('energy_year', $energy_year)
                    ->with('final_result', $final_result);

            }else{
                $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
                    ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
                    ->where('et.energy_type_slug', '=', 'consumption')
                    ->select('energy.*')
                    ->groupBy('energy.id')
                    ->orderBy('energy.energy_order', 'asc')
                    ->get();

                if(!empty($rows)){
                    foreach($rows as $the_row){
                        $inner_col = array();
                        $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_form_topic', '=', 'consumption')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->where('consumption_energy_form.central_id', '=', 1)
                            ->where('consumption_energy_form.province_id', '=', null)
                            ->where('consumption_energy_form.district_id', '=', null)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        if(!empty($objEnergyMetaForm->qty)){
                            $final_result[$the_row->energy_name] = $objEnergyMetaForm->qty;
                        }else{
                            $final_result[$the_row->energy_name] = 0;
                        }

    //                    echo '<pre>';
    //                    print_r(json_decode($objEnergyMetaForm));
                    }
                }

    //            exit();


                return view('frontend/federalreport/energy_report_new_consumption_pie')
                    ->with('url', $request->url())
                    ->with('this_energy_type', $this_energy_type)
                    ->with('start', $start)
                    ->with('end', $end)
                    ->with('output', $output)
                    ->with('energy_topic', $rows)
                    ->with('energy_type', $energy_type_slug)
                    ->with('energy_year', $energy_year)
                    ->with('final_result', $final_result);

            }

        }

    public function reportCentralConsumptionEnergyBySectorsPie(Request $request){

            $start = (!empty($request->get('start')))?intval($request->get('start')):2023;

            $end = $start + 1;

            $energy_type_slug = 'consumption';

            $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

    //        $start = 2019;
    //        $end = $start + 1;

            $output = 'overall_sectorwise';

            $energy_year = EnergyYear::where('status', 'Y')->where('is_completed', 'N')->get();

            $energy_listing = Energy::join('energy_type_verses_energy_mapping AS etvem', 'etvem.energy_id', '=', 'energy.id')
                ->join('fuel_type AS ft', 'ft.id', '=', 'energy.fuel_type_id')
                ->select('energy.*', 'ft.fuel_type_name')
                ->where('etvem.energy_type_id', $this_energy_type->id)
                ->orderBy('ft.fuel_order', 'asc')
                ->get();

            $data = array();

            if(!empty($energy_listing[0])){
                foreach($energy_listing as $the_energy){
                    $arr = ConsumptionEnergyForm::join('energy_form_meta as efm', 'efm.energy_form_id', '=', 'consumption_energy_form.id')
                        ->select('efm.*')
                        ->where('consumption_energy_form.energy_id', '=', $the_energy->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.central_id', '=', 1)
                        ->where('consumption_energy_form.province_id', '=', null)
                        ->where('consumption_energy_form.district_id', '=', null)
                        ->where('efm.energy_form_topic', '=', 'consumption')
                        ->where('efm.energy_topic', '=', 'sector')
                        ->first();

                    $data[$the_energy->id] = $arr;

                }
            }

            $final_result = array();

            if($output == 'fueltype'){

                $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
                    ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
                    ->where('et.energy_type_slug', '=', 'consumption')
                    ->select('energy.*')
                    ->groupBy('energy.id')
                    ->orderBy('energy.energy_order', 'asc')
                    ->get();

                if(!empty($rows)){
                    foreach($rows as $the_row){
                        $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_form_topic', '=', 'consumption')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->where('consumption_energy_form.central_id', '=', 1)
                            ->where('consumption_energy_form.province_id', '=', null)
                            ->where('consumption_energy_form.district_id', '=', null)
                            ->where('consumption_energy_form.district_id', '=', null)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        if(!empty($objEnergyMetaForm->qty)){
                            $final_result[$the_row->energy_name] = $objEnergyMetaForm->qty;
                        }else{
                            $final_result[$the_row->energy_name] = 0;
                        }
                    }
                }

    //            exit();

                return view('frontend/federalreport/energy_report_new_consumption_bar')
                    ->with('url', $request->url())
                    ->with('this_energy_type', $this_energy_type)
                    ->with('start', $start)
                    ->with('end', $end)
                    ->with('energy_topic', $rows)
                    ->with('energy_type', $energy_type_slug)
                    ->with('energy_year', $energy_year)
                    ->with('col_send', $rows)
                    ->with('output', $output)
                    ->with('final_result', $final_result);

            }elseif($output == 'sectorwise'){

                $final_result = array();

                $col_keys = Sector::where('status', 'Y')->orderBy('entry_order', 'ASC')->get();

    //            $col_keys = Location::join('location_type as lt', 'lt.id', '=', 'location.location_type_id')
    //                ->where('lt.location_type_slug', 'district')
    //                ->where('location.parent_id', $province_id)
    //                ->select('location.*')
    //                ->groupBy('location.id')
    //                ->orderBy('location.location_name', 'asc')
    //                ->get();

                $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
                    ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                    ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
                    ->select('energy.*', 'fuel_type.fuel_type_name')
                    ->where('et.energy_type_slug', '=', 'consumption')
                    ->where('energy.status', 'Y')
                    ->groupBy('energy.id')
                    ->orderBy('energy.energy_order', 'asc')
                    ->get();

                $col_send = array();

                if(!empty($col_keys)){
                    foreach($col_keys as $this_col_key){
                        array_push($col_send, $this_col_key->sector_name);
                    }
                }

    //            echo '<pre>';
    //            print_r($col_send);
    //            exit();

                if(!empty($rows)){
                    foreach($rows as $the_row){
                        $inner_col = array();
                        $counter = 0;
                        foreach($col_keys as $the_col){
                            $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                            $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                                ->where('energy_form_meta.energy_form_topic', '=', 'consumption')
                                ->where('energy_form_meta.energy_id', '=', $the_row->id)
                                ->where('consumption_energy_form.from_date', '=', $start)
                                ->where('consumption_energy_form.to_date', '=', $end)
                                ->where('consumption_energy_form.central_id', '=', 1)
                                ->where('consumption_energy_form.province_id', '=', null)
                                ->where('consumption_energy_form.district_id', '=', null)
                                ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                                ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                                ->first();

                            $inner_col[$counter] += (!empty($objEnergyMetaForm->qty))?(float)$objEnergyMetaForm->qty:0;
                            $counter++;
                        }
                        $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                    }
                }

    //            exit();

                return view('frontend/federalreport/energy_report_new_consumption_bar_sectorwise2')
                    ->with('url', $request->url())
                    ->with('this_energy_type', $this_energy_type)
                    ->with('start', $start)
                    ->with('end', $end)
                    ->with('energy_topic', $rows)
                    ->with('energy_type', $energy_type_slug)
                    ->with('energy_year', $energy_year)
                    ->with('col_send', $rows)
                    ->with('col_send', $col_send)
                    ->with('output', $output)
                    ->with('energy_type_slug', $energy_type_slug)
                    ->with('energy_topic', 'Overall')
                    ->with('final_result', $final_result);

            }elseif($output == 'overall_sectorwise'){

                $rows = Sector::where('status', 'Y')->orderBy('entry_order', 'ASC')->get();

    //            $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
    //                ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
    //                ->where('et.energy_type_slug', '=', 'consumption')
    //                ->select('energy.*')
    //                ->groupBy('energy.id')
    //                ->orderBy('energy.energy_order', 'asc')
    //                ->get();

                $all_energy = Energy::where('status', 'Y')->pluck('id')->toArray();


//                echo '<pre>';
//                print_r($all_energy);
//                echo '</pre>';


                if(!empty($rows)){
                    foreach($rows as $the_row){

                        $inner_col = array();
                        $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_form_topic', '=', 'consumption')
                            ->where('energy_form_meta.energy_topic', '=', 'sector')
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->whereIn('energy_form_meta.energy_id', $all_energy)
                            ->where('consumption_energy_form.central_id', '=', 1)
                            ->where('consumption_energy_form.province_id', '=', null)
                            ->where('consumption_energy_form.district_id', '=', null)
                            ->where('consumption_energy_form.local_gov_id', '=', null)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();

                        if(!empty($objEnergyMetaForm->qty)){
                            $final_result[$the_row->sector_name] = $objEnergyMetaForm->qty;
                        }else{
                            $final_result[$the_row->sector_name] = 0;
                        }

    //                    echo '<pre>';
    //                    print_r(json_decode($objEnergyMetaForm));
                    }
                }

//                echo '<pre>';
//                print_r($final_result);
//                echo '</pre>';

    //            exit();

                return view('frontend/federalreport/energy_report_new_consumption_pie_sectorwise')
                    ->with('url', $request->url())
                    ->with('this_energy_type', $this_energy_type)
                    ->with('start', $start)
                    ->with('end', $end)
                    ->with('output', $output)
                    ->with('energy_topic', $rows)
                    ->with('energy_type', $energy_type_slug)
                    ->with('energy_year', $energy_year)
                    ->with('final_result', $final_result);

            }else{
                $rows = Energy::join('energy_type_verses_energy_mapping as etvem', 'etvem.energy_id', '=', 'energy.id')
                    ->join('energy_type as et', 'et.id', '=', 'etvem.energy_type_id')
                    ->where('et.energy_type_slug', '=', 'consumption')
                    ->select('energy.*')
                    ->groupBy('energy.id')
                    ->orderBy('energy.energy_order', 'asc')
                    ->get();

                if(!empty($rows)){
                    foreach($rows as $the_row){
                        $inner_col = array();
                        $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_form_topic', '=', 'consumption')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->where('consumption_energy_form.central_id', '=', 1)
                            ->where('consumption_energy_form.province_id', '=', null)
                            ->where('consumption_energy_form.district_id', '=', null)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        if(!empty($objEnergyMetaForm->qty)){
                            $final_result[$the_row->energy_name] = $objEnergyMetaForm->qty;
                        }else{
                            $final_result[$the_row->energy_name] = 0;
                        }

    //                    echo '<pre>';
    //                    print_r(json_decode($objEnergyMetaForm));
                    }
                }

    //            exit();


                return view('frontend/federalreport/energy_report_new_consumption_pie')
                    ->with('url', $request->url())
                    ->with('this_energy_type', $this_energy_type)
                    ->with('start', $start)
                    ->with('end', $end)
                    ->with('output', $output)
                    ->with('energy_topic', $rows)
                    ->with('energy_type', $energy_type_slug)
                    ->with('energy_year', $energy_year)
                    ->with('final_result', $final_result);

            }

        }

        public function energyConversion(Request $request){
//            return 1;

            $this_energy = (!empty($request->get('energy')))?$request->get('energy'):'';
            $this_unit = (!empty($request->get('unit')))?$request->get('unit'):'';
            $this_qty = (!empty($request->get('qty')))?intval($request->get('qty')):1;

            $energy_list = Energy::where('status', 'Y')->get();

            $from_units = Unit::where('status', 'Y')->get();

            $result = '';

            if($this_unit != '' && $this_energy != ''){

                $result = EnergyConversion::join('energy', 'energy.id', '=', 'energy_conversion.energy_id')
                    ->join('unit', 'unit.id', '=', 'energy_conversion.natural_unit')
                    ->select('energy_conversion.scientific_qty', 'energy_conversion.scientific_unit')
                    ->where('energy.energy_slug', '=', $this_energy)
                    ->where('unit.unit_slug', '=', $this_unit)
                    ->groupBy('energy_conversion.id')
                    ->first();

            }

            $energy_list_with = array();

            if(!empty($energy_list)){

                foreach(json_decode($energy_list) as $the_energy){

                    $natural_units = EnergyConversion::join('unit', 'unit.id', '=', 'energy_conversion.natural_unit')
                        ->select('unit.*')
                        ->where('energy_conversion.energy_id', '=', $the_energy->id)
                        ->where('unit.status', '=', 'Y')
                        ->groupBy('energy_conversion.id')
                        ->get();

                    if(!empty($natural_units)){

                        $energy_list_with[$the_energy->energy_slug] = $natural_units;

                    }

                }

            }

            return view('frontend/energy_conversion')
                ->with('url', $request->url())
                ->with('energy_list_with', $energy_list_with)
                ->with('energy_list', $energy_list)
                ->with('this_energy', $this_energy)
                ->with('this_unit', $this_unit)
                ->with('this_qty', $this_qty)
                ->with('result', $result);

//            echo '<pre>';
//            print_r($energy_list_with);
//            echo '</pre>';
//
//            return $result;





        }

        public function sdgPage(Request $request){
//            return 1;



            return view('frontend/sdg-page')
                ->with('url', $request->url());

//            echo '<pre>';
//            print_r($energy_list_with);
//            echo '</pre>';
//
//            return $result;





        }

}
