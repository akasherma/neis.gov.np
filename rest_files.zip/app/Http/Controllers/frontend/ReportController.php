<?php

namespace App\Http\Controllers\frontend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Energy;
use App\EnergyFormMeta;
use App\EnergyTypes;
use App\EnergyTypeTopicMapping;
use App\EnergyYear;
use App\GeographicRegion;
use App\LandType;
use App\Location;
use App\LogTable;
use App\ProductionEnergyForm;
use App\River;
use App\Sector;
use App\Unit;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use stdClass;

class ReportController extends Controller
{

    public function reportCentralConsumptionEnergyTopic(Request $request) {

        $start = (!empty($_GET['start']) && is_numeric($_GET['start']) && $_GET['start'] > 1990 && $_GET['start'] <= (date('Y') - 1) )?$_GET['start']:(date('Y') - 1);

        $end = (!empty($_GET['end']) && is_numeric($_GET['end']) && $_GET['end'] > 1990 && $_GET['end'] <= date('Y') )?$_GET['end']:date('Y');

        $energy_type_slug = 'consumption';

        $energy_topic = (!empty($_GET['energy_topic']) && in_array($_GET['energy_topic'], ['sector', 'land_type', 'geographic_region', 'river']))?$_GET['energy_topic']:'sector';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'ASC')
            ->get();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->orderBy('geographic_region.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.province_id', '=', $the_province->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->whereNull('consumption_energy_form.district_id')
                            ->whereNull('consumption_energy_form.local_gov_id')
                            ->select(DB::raw('(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.province_id', '=', $the_province->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->whereNull('consumption_energy_form.district_id')
                            ->whereNull('consumption_energy_form.local_gov_id')
                            ->select(DB::raw('(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->orderBy('river.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.province_id', '=', $the_province->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->whereNull('consumption_energy_form.district_id')
                            ->whereNull('consumption_energy_form.local_gov_id')
                            ->select(DB::raw('(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->river_name] = $inner_col;
                }
            }
        }else{

            $energy_topic == 'sector';

            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->orderBy('sector.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.province_id', '=', $the_province->id)
                            ->whereNull('consumption_energy_form.district_id')
                            ->whereNull('consumption_energy_form.local_gov_id')
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();

//        echo '<pre>';
//        print_r(json_decode($objEnergyMetaForm));
//        echo '<hr />';
////        print_r($final_result);
//        echo '</pre>';

                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->sector_name] = $inner_col;
                }
            }
        }

//        exit();

//        echo '<pre>';
////        print_r(json_decode($rows));
////        echo '<hr />';
//        print_r($final_result);
//        echo '</pre>';
//        exit();

        if(!empty($this_energy_type)){

            return view('frontend/report/report_energy_type_energy_topic_direct')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('provinces', $provinces)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('/')->with('warning', 'No such Energy Type!');

        }

    }

    public function reportProvinceWiseEnergyVersesEnergyTypeTabular(Request $request) {

        $start = (!empty($_GET['start']) && is_numeric($_GET['start']) && $_GET['start'] > 1990 && $_GET['start'] <= (date('Y') - 1) )?$_GET['start']:(date('Y') - 1);

        $end = (!empty($_GET['end']) && is_numeric($_GET['end']) && $_GET['end'] > 1990 && $_GET['end'] <= date('Y') )?$_GET['end']:date('Y');

        $energy_type_slug = 'consumption';

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'ASC')
            ->get();

        $province_slugs = array();
        if(!is_null($provinces)){
            foreach($provinces as $the_province){
                array_push( $province_slugs, $the_province->location_slug);
            }
        }

        $province = (!empty($_GET['province']) && in_array($_GET['province'], $province_slugs))?$_GET['province']:'province-2';

        $province_slug = $province;

        $energy_topic = (!empty($_GET['energy_topic']) && in_array($_GET['energy_topic'], ['sector', 'land_type', 'geographic_region', 'river']))?$_GET['energy_topic']:'sector';

//        return 1;

        $final_result = array();

        $col_keys = '';

//        $rows = Energy::join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
//            ->select('energy.*', 'fuel_type.fuel_type_name')
//            ->groupBy('energy.id')
//            ->orderBy('fuel_type.fuel_type_name', 'DESC')
//            ->get();

        $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
            ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
            ->select('energy.*', 'fuel_type.fuel_type_name')
            ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
            ->where('energy.status', 'Y')
            ->groupBy('energy.id')
            ->orderBy('fuel_type.fuel_type_name', 'desc')
            ->get();

        if($energy_topic == 'river') {
            $col_keys = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.river_name as key', 'river.id')
                ->orderBy('river.entry_order', 'asc')
                ->get();
        }else if($energy_topic == 'land_type') {
            $col_keys = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.land_type_name as key', 'land_type.id')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();
        }else if($energy_topic == 'geographic_region') {
            $col_keys = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.geographic_region_name as key', 'geographic_region.id')
                ->orderBy('geographic_region.entry_order', 'asc')
                ->get();
        }else{
            $col_keys = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', 'sector')
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.sector_name as key', 'sector.id')
                ->orderBy('sector.entry_order', 'asc')
                ->get();
        }

        $col_send = array();

        if(!empty($col_keys)){
            foreach($col_keys as $this_col_key){
                array_push($col_send, $this_col_key->key);
            }
        }

        if(!empty($rows)){
            foreach($rows as $the_row){
                $inner_col = array();
                $counter = 0;
                foreach($col_keys as $the_col){
                    $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                    $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->join('location', 'consumption_energy_form.province_id', '=', 'location.id')
                        ->where('location.location_slug', '=', $province_slug)
                        ->where('energy_form_meta.energy_id', '=', $the_row->id)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                        ->where('energy_form_meta.energy_topic', '!=', 'overall')
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->where('energy_form_meta.energy_topic', '!=', 'overall')
                        ->select('energy_form_meta.scientific_qty as qty')
                        ->first();
                    $inner_col[$counter] += (!empty($objEnergyMetaForm->qty))?(float)$objEnergyMetaForm->qty:0;
                    $counter++;
                }
                $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
            }
        }

//        echo '<pre>';
//        print_r(json_decode($rows));
//        echo '<hr />';
//        print_r($final_result);
//        echo '</pre>';
//        exit();


        return view('frontend/report/provincewise_report_energy_verses_energy_type_tabular')
            ->with('start', $start)
            ->with('end', $end)
            ->with('url', $request->url())
            ->with('col_send', $col_send)
            ->with('energy_type_slug', $energy_type_slug)
            ->with('energy_topic', $energy_topic)
            ->with('province_list', $provinces)
            ->with('final_result', $final_result);

    }

    public function reportProvinceWiseConsumptionEnergyTopicPie(Request $request) {

        $start = (!empty($_GET['start']) && is_numeric($_GET['start']) && $_GET['start'] > 1990 && $_GET['start'] <= (date('Y') - 1) )?$_GET['start']:(date('Y') - 1);

        $end = (!empty($_GET['end']) && is_numeric($_GET['end']) && $_GET['end'] > 1990 && $_GET['end'] <= date('Y') )?$_GET['end']:date('Y');

        $energy_type_slug = 'consumption';

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'ASC')
            ->get();

        $province_slugs = array();
        if(!is_null($provinces)){
            foreach($provinces as $the_province){
                array_push( $province_slugs, $the_province->location_slug);
            }
        }

        $province = (!empty($_GET['province']) && in_array($_GET['province'], $province_slugs))?$_GET['province']:'province-2';

        $province_slug = $province;

        $energy_topic = (!empty($_GET['energy_topic']) && in_array($_GET['energy_topic'], ['sector', 'land_type', 'geographic_region', 'river']))?$_GET['energy_topic']:'sector';

//        $energy_type_slug = 'consumption';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->orderBy('geographic_region.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->where('energy_form_meta.energy_topic', '!=', 'overall')
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->geographic_region_name] = json_decode($objEnergyMetaForm);
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->where('energy_form_meta.energy_topic', '!=', 'overall')
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->land_type_name] = $objEnergyMetaForm;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->orderBy('river.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->where('energy_form_meta.energy_topic', '!=', 'overall')
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->river_name] = $objEnergyMetaForm;
                }
            }
        }else{
            $energy_topic = 'sector';
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->orderBy('sector.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->join('location', 'consumption_energy_form.province_id', '=', 'location.id')
                        ->where('location.location_slug', '=', $province_slug)
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->whereNull('consumption_energy_form.district_id')
                        ->whereNull('consumption_energy_form.local_gov_id')
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->sector_name] = $objEnergyMetaForm;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('frontend/report/report_energy_type_energy_topic_direct_pie')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('province_list', $provinces)
                ->with('final_result', $final_result);

        }else{

            return redirect('/')->with('warning', 'No such Energy Type!');

        }
    }


    public function reportProvinceWiseConsumptionEnergyTopicFuelTypePie(Request $request) {

        $start = (!empty($_GET['start']) && is_numeric($_GET['start']) && $_GET['start'] > 1990 && $_GET['start'] <= (date('Y') - 1) )?$_GET['start']:(date('Y') - 1);

        $end = (!empty($_GET['end']) && is_numeric($_GET['end']) && $_GET['end'] > 1990 && $_GET['end'] <= date('Y') )?$_GET['end']:date('Y');

        $energy_type_slug = 'consumption';

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'ASC')
            ->get();

        $province_slugs = array();
        if(!is_null($provinces)){
            foreach($provinces as $the_province){
                array_push( $province_slugs, $the_province->location_slug);
            }
        }

        $province = (!empty($_GET['province']) && in_array($_GET['province'], $province_slugs))?$_GET['province']:'province-2';

        $province_slug = $province;

        $energy_topic = (!empty($_GET['energy_topic']) && in_array($_GET['energy_topic'], ['sector', 'land_type', 'geographic_region', 'river']))?$_GET['energy_topic']:'sector';

//        $energy_type_slug = 'consumption';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        if($energy_topic == 'geographic_region'){

            $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->select('fuel_type.*')
                ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
                ->where('energy.status', 'Y')
                ->groupBy('fuel_type.id')
                ->orderBy('fuel_type.fuel_type_name', 'desc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->join('location', 'consumption_energy_form.province_id', '=', 'location.id')
                        ->join('energy', 'energy_form_meta.energy_id', '=', 'energy.id')
                        ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                        ->where('location.location_slug', '=', $province_slug)
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('fuel_type.id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->where('energy_form_meta.energy_topic', '!=', 'overall')
                        ->whereNull('consumption_energy_form.district_id')
                        ->whereNull('consumption_energy_form.local_gov_id')
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->fuel_type_name] = $objEnergyMetaForm;
                }
            }

        }elseif($energy_topic == 'land_type'){

            $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->select('fuel_type.*')
                ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
                ->where('energy.status', 'Y')
                ->groupBy('fuel_type.id')
                ->orderBy('fuel_type.fuel_type_name', 'desc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->join('location', 'consumption_energy_form.province_id', '=', 'location.id')
                        ->join('energy', 'energy_form_meta.energy_id', '=', 'energy.id')
                        ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                        ->where('location.location_slug', '=', $province_slug)
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('fuel_type.id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->where('energy_form_meta.energy_topic', '!=', 'overall')
                        ->whereNull('consumption_energy_form.district_id')
                        ->whereNull('consumption_energy_form.local_gov_id')
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->fuel_type_name] = $objEnergyMetaForm;
                }
            }

        }elseif($energy_topic == 'river'){

            $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->select('fuel_type.*')
                ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
                ->where('energy.status', 'Y')
                ->groupBy('fuel_type.id')
                ->orderBy('fuel_type.fuel_type_name', 'desc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->join('location', 'consumption_energy_form.province_id', '=', 'location.id')
                        ->join('energy', 'energy_form_meta.energy_id', '=', 'energy.id')
                        ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                        ->where('location.location_slug', '=', $province_slug)
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('fuel_type.id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->where('energy_form_meta.energy_topic', '!=', 'overall')
                        ->whereNull('consumption_energy_form.district_id')
                        ->whereNull('consumption_energy_form.local_gov_id')
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->fuel_type_name] = $objEnergyMetaForm;
                }
            }

        }else{
            $energy_topic = 'sector';

            $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->select('fuel_type.*')
                ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
                ->where('energy.status', 'Y')
                ->groupBy('fuel_type.id')
                ->orderBy('fuel_type.fuel_type_name', 'desc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->join('location', 'consumption_energy_form.province_id', '=', 'location.id')
                        ->join('energy', 'energy_form_meta.energy_id', '=', 'energy.id')
                        ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                        ->where('location.location_slug', '=', $province_slug)
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('fuel_type.id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->where('energy_form_meta.energy_topic', '!=', 'overall')
                        ->whereNull('consumption_energy_form.district_id')
                        ->whereNull('consumption_energy_form.local_gov_id')
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->fuel_type_name] = $objEnergyMetaForm;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('frontend/report/report_energy_type_energy_topic_direct_fueltype_pie')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('province_list', $provinces)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('/')->with('warning', 'No such Energy Type!');

        }
    }


    public function reportProvinceWiseConsumptionEnergyTopicEnergyPie(Request $request) {

        $start = (!empty($_GET['start']) && is_numeric($_GET['start']) && $_GET['start'] > 1990 && $_GET['start'] <= (date('Y') - 1) )?$_GET['start']:(date('Y') - 1);

        $end = (!empty($_GET['end']) && is_numeric($_GET['end']) && $_GET['end'] > 1990 && $_GET['end'] <= date('Y') )?$_GET['end']:date('Y');

        $energy_type_slug = 'consumption';

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'ASC')
            ->get();

        $province_slugs = array();
        if(!is_null($provinces)){
            foreach($provinces as $the_province){
                array_push( $province_slugs, $the_province->location_slug);
            }
        }

        $province = (!empty($_GET['province']) && in_array($_GET['province'], $province_slugs))?$_GET['province']:'province-2';

        $province_slug = $province;

        $energy_topic = (!empty($_GET['energy_topic']) && in_array($_GET['energy_topic'], ['sector', 'land_type', 'geographic_region', 'river']))?$_GET['energy_topic']:'sector';

        // $energy_type_slug = 'consumption';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
            ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
            ->select('energy.*')
            ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
            ->where('energy.status', 'Y')
            ->groupBy('energy.id')
            ->orderBy('energy.energy_name', 'desc')
            ->get();

        if($energy_topic == 'geographic_region'){

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->join('location', 'consumption_energy_form.province_id', '=', 'location.id')
                        ->join('energy', 'energy_form_meta.energy_id', '=', 'energy.id')
                        ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                        ->where('location.location_slug', '=', $province_slug)
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('fuel_type.id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->where('energy_form_meta.energy_topic', '!=', 'overall')
                        ->whereNull('consumption_energy_form.district_id')
                        ->whereNull('consumption_energy_form.local_gov_id')
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->energy_name] = $objEnergyMetaForm;
                }
            }

        }elseif($energy_topic == 'land_type'){

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->join('location', 'consumption_energy_form.province_id', '=', 'location.id')
                        ->join('energy', 'energy_form_meta.energy_id', '=', 'energy.id')
                        ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                        ->where('location.location_slug', '=', $province_slug)
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('fuel_type.id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->where('energy_form_meta.energy_topic', '!=', 'overall')
                        ->whereNull('consumption_energy_form.district_id')
                        ->whereNull('consumption_energy_form.local_gov_id')
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->energy_name] = $objEnergyMetaForm;
                }
            }

        }elseif($energy_topic == 'river'){

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->join('location', 'consumption_energy_form.province_id', '=', 'location.id')
                        ->join('energy', 'energy_form_meta.energy_id', '=', 'energy.id')
                        ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                        ->where('location.location_slug', '=', $province_slug)
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('fuel_type.id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->where('energy_form_meta.energy_topic', '!=', 'overall')
                        ->whereNull('consumption_energy_form.district_id')
                        ->whereNull('consumption_energy_form.local_gov_id')
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->energy_name] = $objEnergyMetaForm;
                }
            }

        }else{
            $energy_topic = 'sector';

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->join('location', 'consumption_energy_form.province_id', '=', 'location.id')
                        ->where('location.location_slug', '=', $province_slug)
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->where('energy_form_meta.energy_topic', '!=', 'overall')
                        ->whereNull('consumption_energy_form.district_id')
                        ->whereNull('consumption_energy_form.local_gov_id')
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->energy_name] = $objEnergyMetaForm;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('frontend/report/report_energy_type_energy_topic_direct_pie')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('province_list', $provinces)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }
    }


    public function reportProvinceWiseConsumptionEnergyTopic(Request $request) {

        $start = (!empty($_GET['start']) && is_numeric($_GET['start']) && $_GET['start'] > 1990 && $_GET['start'] <= (date('Y') - 1) )?$_GET['start']:(date('Y') - 1);

        $end = (!empty($_GET['end']) && is_numeric($_GET['end']) && $_GET['end'] > 1990 && $_GET['end'] <= date('Y') )?$_GET['end']:date('Y');

        $energy_type_slug = 'consumption';

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'ASC')
            ->get();

        $province_slugs = array();
        if(!is_null($provinces)){
            foreach($provinces as $the_province){
                array_push( $province_slugs, $the_province->location_slug);
            }
        }

        $province = (!empty($_GET['province']) && in_array($_GET['province'], $province_slugs))?$_GET['province']:'province-2';

        $province_slug = $province;

        $energy_topic = (!empty($_GET['energy_topic']) && in_array($_GET['energy_topic'], ['sector', 'land_type', 'geographic_region', 'river']))?$_GET['energy_topic']:'sector';

        // $energy_type_slug = 'consumption';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $this_province = Location::where('location_slug', $province_slug)->where('status', 'Y')->first();

        $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->join('location AS loc_parent', 'loc_parent.id', '=', 'location.parent_id')
            ->where('loc_parent.location_slug', '=', $province_slug)
            ->where('location_type.location_type_slug', 'district')
            ->where('location.status', 'Y')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->groupBy('location.id')
            ->orderBy('location.location_slug', 'ASC')
            ->get();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->orderBy('geographic_region.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($districts as $the_district){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.district_id', '=', $the_district->id)
                            ->where('consumption_energy_form.province_id', '=', $this_province->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->where('energy_form_meta.energy_topic', '!=', 'overall')
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($districts as $the_district){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.district_id', '=', $the_district->id)
                            ->where('consumption_energy_form.province_id', '=', $this_province->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->where('energy_form_meta.energy_topic', '!=', 'overall')
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->orderBy('river.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($districts as $the_district){
                        $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.district_id', '=', $the_district->id)
                            ->where('consumption_energy_form.province_id', '=', $this_province->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->where('energy_form_meta.energy_topic', '!=', 'overall')
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->river_name] = $inner_col;
                }
            }
        }else{

            $energy_topic = 'sector';

            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->orderBy('sector.entry_order', 'asc')
                ->get();
//
//            echo '<pre>';
//            print_r(json_decode($rows));
//            echo '</pre>';
//            exit();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($districts as $the_district){
                        $objEnergyMetaForm = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.district_id', '=', $the_district->id)
                            ->where('consumption_energy_form.province_id', '=', $this_province->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->where('energy_form_meta.energy_topic', '!=', 'overall')
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->sector_name] = $inner_col;

//                    echo '<pre>';
//                    print_r($final_result);
//                    echo '</pre>';
//                    exit();
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('frontend/report/districtwise_report_energy_type_energy_topic_direct')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('provinces', $districts)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('province_list', $provinces)
                ->with('final_result', $final_result);

        }else{

            return redirect('/')->with('warning', 'No such Energy Type!');

        }

    }


    public function reportProvinceWiseConsumptionEnergyTopicIndividualLine(Request $request) {

        $start = (!empty($_GET['start']) && is_numeric($_GET['start']) && $_GET['start'] > 1990 && $_GET['start'] <= (date('Y') - 1) )?$_GET['start']:(date('Y') - 1);

        $end = (!empty($_GET['end']) && is_numeric($_GET['end']) && $_GET['end'] > 1990 && $_GET['end'] <= date('Y') )?$_GET['end']:date('Y');

        $energy_type_slug = 'consumption';

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'ASC')
            ->get();

        $province_slugs = array();
        if(!is_null($provinces)){
            foreach($provinces as $the_province){
                array_push( $province_slugs, $the_province->location_slug);
            }
        }

        $province = (!empty($_GET['province']) && in_array($_GET['province'], $province_slugs))?$_GET['province']:'province-2';

        $energy_topic_slug = (!empty($_GET['energy_topic_slug']))?$_GET['energy_topic_slug']:'';

        $province_slug = $province;

        $energy_topic = (!empty($_GET['energy_topic']) && in_array($_GET['energy_topic'], ['sector', 'land_type', 'geographic_region', 'river']))?$_GET['energy_topic']:'sector';

        // $energy_type_slug = 'consumption';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
            ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
            ->select('energy.*')
            ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
            ->where('energy.status', 'Y')
            ->groupBy('energy.id')
            ->orderBy('energy.energy_name', 'desc')
            ->get();

        if($energy_topic == 'geographic_region'){

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->join('location', 'consumption_energy_form.province_id', '=', 'location.id')
                        ->join('energy', 'energy_form_meta.energy_id', '=', 'energy.id')
                        ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                        ->where('location.location_slug', '=', $province_slug)
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('fuel_type.id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->where('energy_form_meta.energy_topic', '!=', 'overall')
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->energy_name] = $objEnergyMetaForm;
                }
            }

        }elseif($energy_topic == 'land_type'){

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->join('location', 'consumption_energy_form.province_id', '=', 'location.id')
                        ->join('energy', 'energy_form_meta.energy_id', '=', 'energy.id')
                        ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                        ->where('location.location_slug', '=', $province_slug)
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('fuel_type.id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->where('energy_form_meta.energy_topic', '!=', 'overall')
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->energy_name] = $objEnergyMetaForm;
                }
            }

        }elseif($energy_topic == 'river'){

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->join('location', 'consumption_energy_form.province_id', '=', 'location.id')
                        ->join('energy', 'energy_form_meta.energy_id', '=', 'energy.id')
                        ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                        ->where('location.location_slug', '=', $province_slug)
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('fuel_type.id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->where('energy_form_meta.energy_topic', '!=', 'overall')
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->energy_name] = $objEnergyMetaForm;
                }
            }

        }else{

            $energy_topic = 'sector';
            $sector_slug_arr = Sector::where('status', 'Y')->pluck('sector_slug')->toArray();

            $energy_topic_slug = (is_array($sector_slug_arr) && in_array($energy_topic_slug, $sector_slug_arr))?$energy_topic_slug:$sector_slug_arr[0];

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->join('location', 'consumption_energy_form.province_id', '=', 'location.id')
                        ->where('location.location_slug', '=', $province_slug)
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('sector.sector_slug', '=', $energy_topic_slug)
                        ->where('energy_form_meta.energy_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->where('energy_form_meta.energy_topic', '!=', 'overall')
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->energy_name] = $objEnergyMetaForm;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('frontend/report/report_energy_type_energy_topic_direct_line')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('province_list', $provinces)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('/')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralConsumptionEnergyTopicTrend(Request $request) {

        $energy_type_slug = 'consumption';

        $start = (!empty($_GET['start']) && is_numeric($_GET['start']) && $_GET['start'] > 1990 && $_GET['start'] <= (date('Y') - 1) )?$_GET['start']:1995;

        $end = (!empty($_GET['end']) && is_numeric($_GET['end']) && $_GET['end'] > 1990 && $_GET['end'] <= date('Y') )?$_GET['end']:2007;

        $energy_topic = (!empty($_GET['energy_topic']) && is_numeric($_GET['energy_topic']) && $_GET['energy_topic'] != '' && in_array($_GET['energy_topic'], ['sector','land_type','geographic_region','river']) )?$_GET['energy_topic']:'sector';

        $energy_type_slug = 'consumption';

        $output = 'trend';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year <= $end; $year++){

                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_slug] = $inner_col;
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year <= $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_slug] = $inner_col;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year <= $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->river_slug] = $inner_col;
                }
            }
        }else{

            $energy_topic == 'sector';

            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->orderBy('sector.sector_name', 'asc')
                ->get();

            if(!empty($rows)){

                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year <= $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();

//                        echo '<pre>';
//                        print_r(json_decode($objEnergyMetaForm));

                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }

                    $final_result[$the_row->sector_slug] = $inner_col;
                }
            }
        }

//        exit();

        if(!empty($this_energy_type)){

            return view('frontend/report/report_energy_type_energy_topic_trend')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('output', $output)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('frontend/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralConsumptionEnergyTopicEnergyTrend(Request $request) {


        $start = (!empty($_GET['start']) && is_numeric($_GET['start']) && $_GET['start'] > 1990 && $_GET['start'] <= (date('Y') - 1) )?$_GET['start']:2010;

        $end = (!empty($_GET['end']) && is_numeric($_GET['end']) && $_GET['end'] > 1990 && $_GET['end'] <= date('Y') )?$_GET['end']:2023;

        $energy_topic = (!empty($_GET['energy_topic']) && $_GET['energy_topic'] != '' && in_array($_GET['energy_topic'], ['sector','land_type','geographic_region','river']) )?$_GET['energy_topic']:'sector';

        $energy_type_slug = 'consumption';

        $output = 'trend';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

//        echo '<pre>';
//        print_r(json_decode($this_energy_type));
//        echo '</pre>';
//
//        exit();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year <= $end; $year++){

                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->fuel_type_name.'#'.$the_row->energy_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'land_type'){

            $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->select('energy.*', 'fuel_type.fuel_type_name')
                ->where('energy_type_topic_mapping.energy_field_topic', '=', $energy_topic)
                ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
                ->where('energy.status', 'Y')
                ->groupBy('energy.id')
                ->orderBy('fuel_type.fuel_type_name', 'desc')
                ->get();
//
//            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
//                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
//                ->groupBy('energy_form_meta.energy_topic_id')
//                ->select('land_type.*')
//                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year <= $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->fuel_type_name.'#'.$the_row->energy_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'river'){

            $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->select('energy.*', 'fuel_type.fuel_type_name')
                ->where('energy_type_topic_mapping.energy_field_topic', '=', $energy_topic)
                ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
                ->where('energy.status', 'Y')
                ->groupBy('energy.id')
                ->orderBy('fuel_type.fuel_type_name', 'desc')
                ->get();

//            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
//                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
//                ->groupBy('energy_form_meta.energy_topic_id')
//                ->select('river.*')
//                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year <= $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->fuel_type_name.'#'.$the_row->energy_name] = $inner_col;
                }
            }
        }else{

            $energy_topic == 'sector';

//            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
//                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
//                ->groupBy('energy_form_meta.energy_topic_id')
//                ->select('sector.*')
//                ->orderBy('sector.sector_name', 'asc')
//                ->get();

            $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->select('energy.*', 'fuel_type.fuel_type_name')
                ->where('energy_type_topic_mapping.energy_field_topic', '=', $energy_topic)
                ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
                ->where('energy.status', 'Y')
                ->groupBy('energy.id')
                ->orderBy('fuel_type.fuel_type_name', 'desc')
                ->get();

//            echo '<pre>';
//            print_r(json_decode($rows));
//            echo '</pre>';
//
//            exit();

            if(!empty($rows)){

                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year <= $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();

//                        echo '<pre>';
//                        print_r(json_decode($objEnergyMetaForm));

                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }

                    $final_result[$the_row->fuel_type_name.'#'.$the_row->energy_name] = $inner_col;
                }
            }
        }

//        exit();

        if(!empty($this_energy_type)){

            return view('frontend/report/report_energy_topic_energy_trend')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('output', $output)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('frontend/report')->with('warning', 'No such Energy Type!');

        }
    }


    public function reportCentralConsumptionEnergyTopicEnergyTrendLineGraph(Request $request) {

        $start = (!empty($_GET['start']) && is_numeric($_GET['start']) && $_GET['start'] > 1990 && $_GET['start'] <= (date('Y') - 1) )?$_GET['start']:2005;

        $end = (!empty($_GET['end']) && is_numeric($_GET['end']) && $_GET['end'] > 1990 && $_GET['end'] <= date('Y') )?$_GET['end']:2023;

        $end = ($end > $start)?$end:($start + 1);

        $energy_topic = (!empty($_GET['energy_topic']) && $_GET['energy_topic'] != '' && in_array($_GET['energy_topic'], ['sector','land_type','geographic_region','river']) )?$_GET['energy_topic']:'sector';

        $energy_type_slug = 'consumption';

        $output = 'trend';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

//        echo '<pre>';
//        print_r(json_decode($this_energy_type));
//        echo '</pre>';
//
//        exit();

        $final_result = array();



        $energy_topic == 'sector';

        $rows = Energy::join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
            ->select('energy.*', 'fuel_type.fuel_type_name')
            ->where('energy.economic_survey_status', 'Y')
            ->groupBy('energy.id')
            ->orderBy('energy.energy_order', 'asc')
            ->get();

//            echo '<pre>';
//            print_r(json_decode($rows));
//            echo '</pre>';
//
//            exit();

        if(!empty($rows)){

            foreach($rows as $the_row){
                $inner_col = array();
                for($year = $start; $year <= $end; $year++){
                    $objEnergyMetaForm = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_id', '=', $the_row->id)
                        ->where('energy_form_meta.energy_topic', '=', 'sector')
                        ->where('consumption_energy_form.central_id', '=', 1)
                        ->where('consumption_energy_form.province_id', '=', null)
                        ->where('consumption_energy_form.district_id', '=', null)
                        ->where('consumption_energy_form.from_date', '=', $year)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();

//                        echo '<pre>';
//                        print_r(json_decode($objEnergyMetaForm));


                    if(empty($objEnergyMetaForm)){
                        $objEnergyMetaForm = new stdClass();
                    }

                    array_push($inner_col, json_decode($objEnergyMetaForm));


                }

                $final_result[$the_row->fuel_type_name.'#'.$the_row->energy_name] = $inner_col;
            }
        }

//        exit();

//        echo '<pre>';
//        print_r($final_result);
//        echo '</pre>';
//
//        exit();

        if(!empty($this_energy_type)){

            return view('frontend/report/report_energy_topic_energy_trend_bar_graph')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('output', $output)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('frontend/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralConsumptionEnergyTopicEnergyTotalTrend(Request $request) {

        $start = (!empty($_GET['start']) && is_numeric($_GET['start']) && $_GET['start'] > 1990 && $_GET['start'] <= (date('Y') - 1) )?$_GET['start']:2010;

        $end = (!empty($_GET['end']) && is_numeric($_GET['end']) && $_GET['end'] > 1990 && $_GET['end'] <= date('Y') )?$_GET['end']:2023;

        $energy_topic = (!empty($_GET['energy_topic']) && $_GET['energy_topic'] != '' && in_array($_GET['energy_topic'], ['sector','land_type','geographic_region','river']) )?$_GET['energy_topic']:'sector';

        $energy_type_slug = 'consumption';

        $output = 'trend';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

//        echo '<pre>';
//        print_r(json_decode($this_energy_type));
//        echo '</pre>';
//
//        exit();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year <= $end; $year++){

                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->fuel_type_name.'#'.$the_row->energy_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'land_type'){

            $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->select('energy.*', 'fuel_type.fuel_type_name')
                ->where('energy_type_topic_mapping.energy_field_topic', '=', $energy_topic)
                ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
                ->where('energy.status', 'Y')
                ->groupBy('energy.id')
                ->orderBy('fuel_type.fuel_type_name', 'desc')
                ->get();
//
//            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
//                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
//                ->groupBy('energy_form_meta.energy_topic_id')
//                ->select('land_type.*')
//                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year <= $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->fuel_type_name.'#'.$the_row->energy_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'river'){

            $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->select('energy.*', 'fuel_type.fuel_type_name')
                ->where('energy_type_topic_mapping.energy_field_topic', '=', $energy_topic)
                ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
                ->where('energy.status', 'Y')
                ->groupBy('energy.id')
                ->orderBy('fuel_type.fuel_type_name', 'desc')
                ->get();

//            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
//                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
//                ->groupBy('energy_form_meta.energy_topic_id')
//                ->select('river.*')
//                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year <= $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->fuel_type_name.'#'.$the_row->energy_name] = $inner_col;
                }
            }
        }else{

            $energy_topic == 'sector';

//            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
//                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
//                ->groupBy('energy_form_meta.energy_topic_id')
//                ->select('sector.*')
//                ->orderBy('sector.sector_name', 'asc')
//                ->get();

            $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->select('energy.*', 'fuel_type.fuel_type_name')
                ->where('energy_type_topic_mapping.energy_field_topic', '=', $energy_topic)
                ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
                ->where('energy.status', 'Y')
                ->groupBy('energy.id')
                ->orderBy('fuel_type.fuel_type_name', 'desc')
                ->get();

//            echo '<pre>';
//            print_r(json_decode($rows));
//            echo '</pre>';
//
//            exit();

            if(!empty($rows)){

                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year <= $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();

//                        echo '<pre>';
//                        print_r(json_decode($objEnergyMetaForm));

                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }

                    $final_result[$the_row->fuel_type_name.'#'.$the_row->energy_name] = $inner_col;
                }
            }
        }

//        exit();

        if(!empty($this_energy_type)){

            return view('frontend/report/report_energy_topic_energy_total_trend')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('output', $output)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('frontend/report')->with('warning', 'No such Energy Type!');

        }
    }





}
