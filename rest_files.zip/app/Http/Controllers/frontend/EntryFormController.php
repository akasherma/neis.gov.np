<?php

namespace App\Http\Controllers\dashboard;

use App\Energy;
use App\EnergyFormMeta;
use App\EnergyTypes;
use App\EnergyTypeTopicMapping;
use App\EnergyYear;
use App\GeographicRegion;
use App\LandType;
use App\Location;
use App\LogTable;
use App\ProductionEnergyForm;
use App\River;
use App\Sector;
use App\Unit;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use stdClass;

class EntryFormController extends Controller
{

    public function entryFormProvinceListing(Request $request){

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->get();

        $central = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'central')
            ->first();

        return view('dashboard/entry_form_province_listing')
            ->with('url', $request->url())
            ->with('provinces', $provinces)
            ->with('central', $central);

    }
    public function reportProvinceListing(Request $request){

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->get();

        $central = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'central')
            ->first();

        return view('dashboard/report_province_listing')
            ->with('url', $request->url())
            ->with('provinces', $provinces)
            ->with('central', $central);


    }

    public function entryFormDistrictListing($province_slug, Request $request){

        $this_province = Location::where('location_slug', $province_slug)->where('status', 'Y')->first();

        $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'district')
            ->where('location.status', 'Y')
            ->where('location.parent_id', $this_province->id)
            ->select('location.*')
            ->get();

        return view('dashboard/entry_form_district_listing')
            ->with('url', $request->url())
            ->with('districts', $districts)
            ->with('this_province', $this_province);

    }

    public function entryFormLocalListing($province_slug, $district_slug, Request $request){

        $this_province = Location::where('location_slug', $province_slug)->where('status', 'Y')->first();

        $this_district = Location::where('location_slug', $district_slug)->where('status', 'Y')->first();

        $locals = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'local-government')
            ->where('location.status', 'Y')
            ->where('location.parent_id', $this_district->id)
            ->select('location.*')
            ->get();

        return view('dashboard/entry_form_local_listing')
            ->with('url', $request->url())
            ->with('locals', $locals)
            ->with('this_province', $this_province)
            ->with('this_district', $this_district);

    }

    public function entryFormEnergyYearListing(Request $request) {

//        echo $request->url();
//        exit();

        $energy_years = EnergyYear::where('status', 'Y')->orderBy('energy_year_start', 'ASC')->get();

        return view('dashboard/entry_form_energy_year_listing')
            ->with('url', $request->url())
            ->with('energy_years', $energy_years);

    }

    public function entryFormProvinceEnergyYearListing($province_slug, Request $request) {

        $this_province = Location::where('location_slug', $province_slug)->where('status', 'Y')->first();

        $energy_years = EnergyYear::where('status', 'Y')->orderBy('energy_year_start', 'ASC')->get();

        return view('dashboard/entry_form_energy_year_listing')
            ->with('url', $request->url())
            ->with('energy_years', $energy_years)
            ->with('this_province', $this_province);

    }

    public function entryFormDistrictEnergyYearListing($province_slug, $district_slug, Request $request) {

        $this_province = Location::where('location_slug', $province_slug)->where('status', 'Y')->first();

        $this_district = Location::where('location_slug', $district_slug)->where('status', 'Y')->first();

        $energy_years = EnergyYear::where('status', 'Y')->orderBy('energy_year_start', 'ASC')->get();

        return view('dashboard/entry_form_energy_year_listing')
            ->with('url', $request->url())
            ->with('energy_years', $energy_years)
            ->with('this_province', $this_province)
            ->with('this_district', $this_district);

    }

    public function entryFormLocalEnergyYearListing($province_slug, $district_slug, $local_slug, Request $request) {

        $this_province = Location::where('location_slug', $province_slug)->where('status', 'Y')->first();

        $this_district = Location::where('location_slug', $district_slug)->where('status', 'Y')->first();

        $this_local = Location::where('location_slug', $local_slug)->where('status', 'Y')->first();

        $energy_years = EnergyYear::where('status', 'Y')->orderBy('energy_year_start', 'ASC')->get();

        return view('dashboard/entry_form_energy_year_listing')
            ->with('url', $request->url())
            ->with('energy_years', $energy_years)
            ->with('this_province', $this_province)
            ->with('this_district', $this_district)
            ->with('this_local', $this_local);

    }

    public function entryFormEnergyTypeEnergyListing($start, $end, $energy_type_slug, Request $request) {

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        if(!empty($this_energy_type)){

//            $energy_lists = Energy::leftJoin('energy_type_topic_mapping', function ($join) use ($energy_type_slug) {
//                $join->on('energy_type_topic_mapping.energy_id', '=', 'energy.id');
//                $join->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug);
//            })
//                ->select('energy.*')
//                ->where('energy.status', 'Y')
//                ->groupBy('energy.id')
//                ->get();



//            $energy_lists = Energy::where('status', 'Y')->get();

//            $energy_lists = Energy::where('status', 'Y')->get();

            $energy_lists = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
                ->select('energy.*')
                ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
                ->where('energy.status', 'Y')
                ->groupBy('energy.id')
                ->orderBy('energy.energy_name', 'asc')
                ->get();

            return view('dashboard/entry_form_energy_type_energy_listing')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_lists', $energy_lists);

        }else{

            return redirect('dashboard/entry-form')->with('warning', 'No such Energy Type!');

        }

    }

    public function entryFormProvinceEnergyTypeEnergyListing($province_slug, $start, $end, $energy_type_slug, Request $request) {

        $this_province = Location::where('location_slug', $province_slug)->where('status', 'Y')->first();

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        if(!empty($this_energy_type)){

//            $final_energy = Energy::where('status', 'Y')->orderBy('energy.energy_name', 'ASC')->get();

            $final_energy = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
                ->select('energy.*')
                ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
                ->where('energy.status', 'Y')
                ->groupBy('energy.id')
                ->orderBy('energy.energy_name', 'asc')
                ->get();

            $energy_lists  = array();

            $result_energy = array();

            if($energy_type_slug == 'production'){
                $energy_list_with = Energy::join('energy_form_meta', function ($join) use ($energy_type_slug) {
                    $join->on('energy_form_meta.energy_id', '=', 'energy.id');
                    $join->where('energy_form_meta.energy_form_topic', '=', $energy_type_slug);
                })
                    ->join('export_energy_form', function ($join) use ($this_province) {
                        $join->on('energy_form_meta.energy_form_id', '=', 'production_energy_form.id');
                        $join->where('production_energy_form.province_id', '=', $this_province->id);
                    })
                    ->select('energy_form_meta.energy_id', 'production_energy_form.id as form_id')
                    ->where('energy.status', 'Y')
                    ->groupBy('energy.id')
                    ->orderBy('energy.energy_name', 'ASC')
                    ->get()
                    ->toArray();

                if(is_array($energy_list_with) && count($energy_list_with)){
                    foreach($energy_list_with as $the_energy){
                        $result_energy[$the_energy['energy_id']] = $the_energy['form_id'];
                    }
                }

            }else if($energy_type_slug == 'resources'){
                $energy_list_with = Energy::join('energy_form_meta', function ($join) use ($energy_type_slug) {
                    $join->on('energy_form_meta.energy_id', '=', 'energy.id');
                    $join->where('energy_form_meta.energy_form_topic', '=', $energy_type_slug);
                })
                    ->join('export_energy_form', function ($join) use ($this_province) {
                        $join->on('energy_form_meta.energy_form_id', '=', 'resources_energy_form.id');
                        $join->where('resources_energy_form.province_id', '=', $this_province->id);
                    })
                    ->select('energy_form_meta.energy_id', 'resources_energy_form.id as form_id')
                    ->where('energy.status', 'Y')
                    ->groupBy('energy.id')
                    ->orderBy('energy.energy_name', 'ASC')
                    ->get()
                    ->toArray();

                if(is_array($energy_list_with) && count($energy_list_with)){
                    foreach($energy_list_with as $the_energy){
                        $result_energy[$the_energy['energy_id']] = $the_energy['form_id'];
                    }
                }

            }else if($energy_type_slug == 'import'){
                $energy_list_with = Energy::join('energy_form_meta', function ($join) use ($energy_type_slug) {
                    $join->on('energy_form_meta.energy_id', '=', 'energy.id');
                    $join->where('energy_form_meta.energy_form_topic', '=', $energy_type_slug);
                })
                    ->join('export_energy_form', function ($join) use ($this_province) {
                        $join->on('energy_form_meta.energy_form_id', '=', 'import_energy_form.id');
                        $join->where('import_energy_form.province_id', '=', $this_province->id);
                    })
                    ->select('energy_form_meta.energy_id', 'import_energy_form.id as form_id')
                    ->where('energy.status', 'Y')
                    ->groupBy('energy.id')
                    ->orderBy('energy.energy_name', 'ASC')
                    ->get()
                    ->toArray();

                if(is_array($energy_list_with) && count($energy_list_with)){
                    foreach($energy_list_with as $the_energy){
                        $result_energy[$the_energy['energy_id']] = $the_energy['form_id'];
                    }
                }

            }else if($energy_type_slug == 'export'){
                $energy_list_with = Energy::join('energy_form_meta', function ($join) use ($energy_type_slug) {
                    $join->on('energy_form_meta.energy_id', '=', 'energy.id');
                    $join->where('energy_form_meta.energy_form_topic', '=', $energy_type_slug);
                })
                    ->join('export_energy_form', function ($join) use ($this_province) {
                        $join->on('energy_form_meta.energy_form_id', '=', 'export_energy_form.id');
                        $join->where('export_energy_form.province_id', '=', $this_province->id);
                    })
                    ->select('energy_form_meta.energy_id', 'export_energy_form.id as form_id')
                    ->where('energy.status', 'Y')
                    ->groupBy('energy.id')
                    ->orderBy('energy.energy_name', 'ASC')
                    ->get()
                    ->toArray();

                if(is_array($energy_list_with) && count($energy_list_with)){
                    foreach($energy_list_with as $the_energy){
                        $result_energy[$the_energy['energy_id']] = $the_energy['form_id'];
                    }
                }

            }else{
                $energy_list_with = Energy::join('energy_form_meta', function ($join) use ($energy_type_slug) {
                        $join->on('energy_form_meta.energy_id', '=', 'energy.id');
                        $join->where('energy_form_meta.energy_form_topic', '=', $energy_type_slug);
                    })
                    ->join('consumption_energy_form', function ($join) use ($this_province) {
                        $join->on('energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id');
                        $join->where('consumption_energy_form.province_id', '=', $this_province->id);
                    })
                    ->select('energy_form_meta.energy_id', 'consumption_energy_form.id as form_id')
                    ->where('energy.status', 'Y')
                    ->groupBy('energy.id')
                    ->orderBy('energy.energy_name', 'ASC')
                    ->get()
                    ->toArray();

                if(is_array($energy_list_with) && count($energy_list_with)){
                    foreach($energy_list_with as $the_energy){
                        $result_energy[$the_energy['energy_id']] = $the_energy['form_id'];
                    }
                }

            }

            if(!empty($final_energy)){
                foreach($final_energy as $the_energy){
                    if(!empty($result_energy[$the_energy->id]) && $result_energy[$the_energy->id] != ''){
                        $the_energy->form_id = $result_energy[$the_energy->id];
                    }
                    array_push($energy_lists, json_decode($the_energy));
                }
            }

//            echo '<pre>';
//            print_r($energy_lists);
//            exit();

//            echo '<pre>';
//            print_r($final_energy);
//            exit();

            return view('dashboard/entry_form_energy_type_energy_listing')
                ->with('url', $request->url())
                ->with('this_province', $this_province)
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_lists', $energy_lists);

        }else{

            return redirect('dashboard/entry-form')->with('warning', 'No such Energy Type!');

        }

    }

    public function entryFormDistrictEnergyTypeEnergyListing($province_slug, $district_slug, $start, $end, $energy_type_slug, Request $request) {

        $this_province = Location::where('location_slug', $province_slug)->where('status', 'Y')->first();

        $this_district = Location::where('location_slug', $district_slug)->where('status', 'Y')->first();

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        if(!empty($this_energy_type)){

            $final_energy = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
                ->select('energy.*')
                ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
                ->where('energy.status', 'Y')
                ->groupBy('energy.id')
                ->orderBy('energy.energy_name', 'asc')
                ->get();

            $energy_lists  = array();

            $result_energy = array();

            if($energy_type_slug == 'production'){
                $energy_list_with = Energy::join('energy_form_meta', function ($join) use ($energy_type_slug) {
                    $join->on('energy_form_meta.energy_id', '=', 'energy.id');
                    $join->where('energy_form_meta.energy_form_topic', '=', $energy_type_slug);
                })
                    ->join('export_energy_form', function ($join) use ($this_province) {
                        $join->on('energy_form_meta.energy_form_id', '=', 'production_energy_form.id');
                        $join->where('production_energy_form.province_id', '=', $this_province->id);
                    })
                    ->select('energy_form_meta.energy_id', 'production_energy_form.id as form_id')
                    ->where('energy.status', 'Y')
                    ->groupBy('energy.id')
                    ->orderBy('energy.energy_name', 'ASC')
                    ->get()
                    ->toArray();

                if(is_array($energy_list_with) && count($energy_list_with)){
                    foreach($energy_list_with as $the_energy){
                        $result_energy[$the_energy['energy_id']] = $the_energy['form_id'];
                    }
                }

            }else if($energy_type_slug == 'resources'){
                $energy_list_with = Energy::join('energy_form_meta', function ($join) use ($energy_type_slug) {
                    $join->on('energy_form_meta.energy_id', '=', 'energy.id');
                    $join->where('energy_form_meta.energy_form_topic', '=', $energy_type_slug);
                })
                    ->join('export_energy_form', function ($join) use ($this_province, $this_district) {
                        $join->on('energy_form_meta.energy_form_id', '=', 'resources_energy_form.id');
                        $join->where('resources_energy_form.province_id', '=', $this_province->id);
                        $join->where('resources_energy_form.district_id', '=', $this_district->id);
                    })
                    ->select('energy_form_meta.energy_id', 'resources_energy_form.id as form_id')
                    ->where('energy.status', 'Y')
                    ->groupBy('energy.id')
                    ->orderBy('energy.energy_name', 'ASC')
                    ->get()
                    ->toArray();

                if(is_array($energy_list_with) && count($energy_list_with)){
                    foreach($energy_list_with as $the_energy){
                        $result_energy[$the_energy['energy_id']] = $the_energy['form_id'];
                    }
                }

            }else if($energy_type_slug == 'import'){
                $energy_list_with = Energy::join('energy_form_meta', function ($join) use ($energy_type_slug) {
                    $join->on('energy_form_meta.energy_id', '=', 'energy.id');
                    $join->where('energy_form_meta.energy_form_topic', '=', $energy_type_slug);
                })
                    ->join('export_energy_form', function ($join) use ($this_province, $this_district) {
                        $join->on('energy_form_meta.energy_form_id', '=', 'import_energy_form.id');
                        $join->where('import_energy_form.province_id', '=', $this_province->id);
                        $join->where('import_energy_form.district_id', '=', $this_district->id);
                    })
                    ->select('energy_form_meta.energy_id', 'import_energy_form.id as form_id')
                    ->where('energy.status', 'Y')
                    ->groupBy('energy.id')
                    ->orderBy('energy.energy_name', 'ASC')
                    ->get()
                    ->toArray();

                if(is_array($energy_list_with) && count($energy_list_with)){
                    foreach($energy_list_with as $the_energy){
                        $result_energy[$the_energy['energy_id']] = $the_energy['form_id'];
                    }
                }

            }else if($energy_type_slug == 'export'){
                $energy_list_with = Energy::join('energy_form_meta', function ($join) use ($energy_type_slug) {
                    $join->on('energy_form_meta.energy_id', '=', 'energy.id');
                    $join->where('energy_form_meta.energy_form_topic', '=', $energy_type_slug);
                })
                    ->join('export_energy_form', function ($join) use ($this_province, $this_district) {
                        $join->on('energy_form_meta.energy_form_id', '=', 'export_energy_form.id');
                        $join->where('export_energy_form.province_id', '=', $this_province->id);
                        $join->where('export_energy_form.district_id', '=', $this_district->id);
                    })
                    ->select('energy_form_meta.energy_id', 'export_energy_form.id as form_id')
                    ->where('energy.status', 'Y')
                    ->groupBy('energy.id')
                    ->orderBy('energy.energy_name', 'ASC')
                    ->get()
                    ->toArray();

                if(is_array($energy_list_with) && count($energy_list_with)){
                    foreach($energy_list_with as $the_energy){
                        $result_energy[$the_energy['energy_id']] = $the_energy['form_id'];
                    }
                }

            }else{
                $energy_list_with = Energy::join('energy_form_meta', function ($join) use ($energy_type_slug) {
                    $join->on('energy_form_meta.energy_id', '=', 'energy.id');
                    $join->where('energy_form_meta.energy_form_topic', '=', $energy_type_slug);
                })
                    ->join('consumption_energy_form', function ($join) use ($this_province, $this_district) {
                        $join->on('energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id');
                        $join->where('consumption_energy_form.province_id', '=', $this_province->id);
                        $join->where('consumption_energy_form.district_id', '=', $this_district->id);
                    })
                    ->select('energy_form_meta.energy_id', 'consumption_energy_form.id as form_id')
                    ->where('energy.status', 'Y')
                    ->groupBy('energy.id')
                    ->orderBy('energy.energy_name', 'ASC')
                    ->get()
                    ->toArray();

                if(is_array($energy_list_with) && count($energy_list_with)){
                    foreach($energy_list_with as $the_energy){
                        $result_energy[$the_energy['energy_id']] = $the_energy['form_id'];
                    }
                }

            }

            if(!empty($final_energy)){
                foreach($final_energy as $the_energy){
                    if(!empty($result_energy[$the_energy->id]) && $result_energy[$the_energy->id] != ''){
                        $the_energy->form_id = $result_energy[$the_energy->id];
                    }
                    array_push($energy_lists, json_decode($the_energy));
                }
            }

//            echo '<pre>';
//            print_r($energy_lists);
//            exit();

//            echo '<pre>';
//            print_r($final_energy);
//            exit();

            return view('dashboard/entry_form_energy_type_energy_listing')
                ->with('url', $request->url())
                ->with('this_province', $this_province)
                ->with('this_district', $this_district)
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_lists', $energy_lists);

//            $energy_lists = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
//                ->select('energy.*')
//                ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
//                ->where('energy.status', 'Y')
//                ->groupBy('energy.id')
//                ->orderBy('energy.energy_name', 'asc')
//                ->get();
//
//            return view('dashboard/entry_form_energy_type_energy_listing')
//                ->with('url', $request->url())
//                ->with('this_province', $this_province)
//                ->with('this_district', $this_district)
//                ->with('this_energy_type', $this_energy_type)
//                ->with('start', $start)
//                ->with('end', $end)
//                ->with('energy_lists', $energy_lists);

        }else{

            return redirect('dashboard/entry-form')->with('warning', 'No such Energy Type!');

        }

    }

    public function entryFormLocalEnergyTypeEnergyListing($province_slug, $district_slug, $local_slug, $start, $end, $energy_type_slug, Request $request) {

        $this_province = Location::where('location_slug', $province_slug)->where('status', 'Y')->first();

        $this_district = Location::where('location_slug', $district_slug)->where('status', 'Y')->first();

        $this_local = Location::where('location_slug', $local_slug)->where('status', 'Y')->first();

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        if(!empty($this_energy_type)){

//            $energy_lists = Energy::join('energy_type_topic_mapping', function ($join) use ($energy_type_slug) {
//                $join->on('energy_type_topic_mapping.energy_id', '=', 'energy.id');
//                $join->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug);
//            })
//                ->select('energy.*')
//                ->where('energy.status', 'Y')
//                ->groupBy('energy.id')
//                ->get();

            $energy_lists = Energy::where('status', 'Y')->get();

            return view('dashboard/entry_form_energy_type_energy_listing')
                ->with('url', $request->url())
                ->with('this_province', $this_province)
                ->with('this_district', $this_district)
                ->with('this_local', $this_local)
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_lists', $energy_lists);

        }else{

            return redirect('dashboard/entry-form')->with('warning', 'No such Energy Type!');

        }

    }

    public function EntryFormController($province_slug, $district_slug, $local_slug, $start, $end, $energy_type_slug) {

        $this_province = Location::where('location_slug', $province_slug)->where('status', 'Y')->first();

        $this_district = Location::where('location_slug', $district_slug)->where('status', 'Y')->first();

        $this_local = Location::where('location_slug', $local_slug)->where('status', 'Y')->first();

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        if(!empty($this_energy_type)){

            $energy_lists = Energy::join('energy_type_topic_mapping', function ($join) use ($energy_type_slug) {
                $join->on('energy_type_topic_mapping.energy_id', '=', 'energy.id');
                $join->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug);
            })
                ->select('energy.*')
                ->where('energy.status', 'Y')
                ->groupBy('energy.id')
                ->get();

            return view('dashboard/entry_form_energy_type_energy_listing')
                ->with('this_province', $this_province)
                ->with('this_district', $this_district)
                ->with('this_local', $this_local)
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_lists', $energy_lists);

        }else{

            return redirect('dashboard/entry-form')->with('warning', 'No such Energy Type!');

        }

    }

    public function entryFormEnergyTypeListing($start, $end, Request $request) {

        $energy_types = EnergyTypes::where('status', 'Y')->get();

        return view('dashboard/entry_form_energy_type_listing')
            ->with('url', $request->url())
            ->with('start', $start)
            ->with('end', $end)
            ->with('energy_types', $energy_types);

    }

    public function entryFormProvinceEnergyTypeListing($province_slug, $start, $end, Request $request) {

        $this_province = Location::where('location_slug', $province_slug)->where('status', 'Y')->first();

        $energy_types = EnergyTypes::where('status', 'Y')->get();

        return view('dashboard/entry_form_energy_type_listing')
            ->with('url', $request->url())
            ->with('this_province', $this_province)
            ->with('start', $start)
            ->with('end', $end)
            ->with('energy_types', $energy_types);

    }

    public function entryFormDistrictEnergyTypeListing($province_slug, $district_slug, $start, $end, Request $request) {

        $this_province = Location::where('location_slug', $province_slug)->where('status', 'Y')->first();

        $this_district = Location::where('location_slug', $district_slug)->where('status', 'Y')->first();

        $energy_types = EnergyTypes::where('status', 'Y')->get();

        return view('dashboard/entry_form_energy_type_listing')
            ->with('url', $request->url())
            ->with('this_province', $this_province)
            ->with('this_district', $this_district)
            ->with('start', $start)
            ->with('end', $end)
            ->with('energy_types', $energy_types);

    }

    public function entryFormLocalEnergyTypeListing($province_slug, $district_slug, $local_slug, $start, $end, Request $request) {
//return 1;

        $this_province = Location::where('location_slug', $province_slug)->where('status', 'Y')->first();

        $this_district = Location::where('location_slug', $district_slug)->where('status', 'Y')->first();

        $this_local = Location::where('location_slug', $local_slug)->where('status', 'Y')->first();

        $energy_types = EnergyTypes::where('status', 'Y')->get();

        return view('dashboard/entry_form_energy_type_listing')
            ->with('url', $request->url())
            ->with('this_province', $this_province)
            ->with('this_district', $this_district)
            ->with('this_local', $this_local)
            ->with('start', $start)
            ->with('end', $end)
            ->with('energy_types', $energy_types);

    }

    public function entryFormEnergyForm($start, $end, $energy_type_slug, $energy_slug) {

        $data = new StdClass();
        $data->id = '';
        $data->energy_id = '';
        $data->central_id = '';
        $data->province_id = '';
        $data->district_id = '';
        $data->local_gov_id = '';
        $data->from_date = '';
        $data->to_date = '';

        $central = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'central')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'asc')
            ->first();

        $this_energy = Energy::where('energy_slug', $energy_slug)->first();

        $field_topics = EnergyTypeTopicMapping::where('energy_type_topic', $energy_type_slug)
            ->where('energy_id', $this_energy->id)
            ->orderBy('energy_field_topic', 'asc')
            ->pluck('energy_field_topic')->toArray();

//        $field_topics = array('production', 'resources', 'consumption', 'import', 'export');

        $land_types = LandType::where('status', 'Y')->get();
        $sectors = Sector::where('status', 'Y')->orderBy('entry_order', 'ASC')->orderBy('sector_name', 'ASC')->get();
        $geographic_regions = GeographicRegion::where('status', 'Y')->get();
        $rivers = River::where('status', 'Y')->get();
        $overall = new stdClass();
        $overall->natural_unit = '';

        $units = Unit::join('energy_conversion', 'energy_conversion.natural_unit', '=', 'unit.id')
            ->where('unit.status', 'Y')
            ->where('energy_conversion.energy_id', $this_energy->id)
            ->select('unit.*', 'energy_conversion.scientific_qty')
            ->groupBy('unit.id')
            ->get();

        return view('dashboard/energy_form_add')
            ->with('data', $data)
            ->with('this_energy', $this_energy)
            ->with('central', $central)
            ->with('land_types', $land_types)
            ->with('sectors', $sectors)
            ->with('geographic_regions', $geographic_regions)
            ->with('rivers', $rivers)
            ->with('overall', $overall)
            ->with('units', $units)
            ->with('field_topics', $field_topics)
            ->with('start', $start)
            ->with('end', $end)
            ->with('energy_type', $energy_type_slug)
            ->with('route', 'add');
    }

    public function entryFormProvinceEnergyForm($province_slug, $start, $end, $energy_type_slug, $energy_slug) {

        $this_province = Location::where('location_slug', $province_slug)->where('status', 'Y')->first();

        $central = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'central')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->first();

        $this_energy = Energy::where('energy_slug', $energy_slug)->first();

        $data = new StdClass();
        $data->id = '';
        $data->energy_id = $this_energy->id;
        $data->central_id = $central->id;
        $data->province_id = $this_province->id;
        $data->district_id = '';
        $data->local_gov_id = '';
        $data->from_date = '';
        $data->to_date = '';

        $field_topics = EnergyTypeTopicMapping::where('energy_type_topic', $energy_type_slug)
            ->where('energy_id', $this_energy->id)
            ->pluck('energy_field_topic')->toArray();

        $land_types = LandType::where('status', 'Y')->get();
        $sectors = Sector::where('status', 'Y')->orderBy('entry_order', 'ASC')->get();
        $geographic_regions = GeographicRegion::where('status', 'Y')->get();
        $rivers = River::where('status', 'Y')->get();
        $overall = new stdClass();
        $overall->natural_unit = '';

        $units = Unit::join('energy_conversion', 'energy_conversion.natural_unit', '=', 'unit.id')
            ->where('unit.status', 'Y')
            ->where('energy_conversion.energy_id', $this_energy->id)
            ->select('unit.*', 'energy_conversion.scientific_qty')
            ->groupBy('unit.id')
            ->get();

        return view('dashboard/energy_form_add')
            ->with('this_province', $this_province)
            ->with('data', $data)
            ->with('this_energy', $this_energy)
            ->with('central', $central)
            ->with('land_types', $land_types)
            ->with('sectors', $sectors)
            ->with('geographic_regions', $geographic_regions)
            ->with('rivers', $rivers)
            ->with('overall', $overall)
            ->with('units', $units)
            ->with('field_topics', $field_topics)
            ->with('start', $start)
            ->with('end', $end)
            ->with('energy_type', $energy_type_slug)
            ->with('route', 'add');
    }

    public function entryFormDistrictEnergyForm($province_slug, $district_slug, $start, $end, $energy_type_slug, $energy_slug) {

        $this_province = Location::where('location_slug', $province_slug)->where('status', 'Y')->first();

        $this_district = Location::where('location_slug', $district_slug)->where('status', 'Y')->first();

        $central = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'central')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->first();

        $this_energy = Energy::where('energy_slug', $energy_slug)->first();

        $data = new StdClass();
        $data->id = '';
        $data->energy_id = $this_energy->id;
        $data->central_id = $central->id;
        $data->province_id = $this_province->id;
        $data->district_id = $this_district->id;
        $data->local_gov_id = '';
        $data->from_date = '';
        $data->to_date = '';

        $field_topics = EnergyTypeTopicMapping::where('energy_type_topic', $energy_type_slug)
            ->where('energy_id', $this_energy->id)
            ->pluck('energy_field_topic')->toArray();

        $land_types = LandType::where('status', 'Y')->get();
        $sectors = Sector::where('status', 'Y')->orderBy('entry_order', 'ASC')->get();
        $geographic_regions = GeographicRegion::where('status', 'Y')->get();
        $rivers = River::where('status', 'Y')->get();
        $overall = new stdClass();
        $overall->natural_unit = '';

        $units = Unit::join('energy_conversion', 'energy_conversion.natural_unit', '=', 'unit.id')
            ->where('unit.status', 'Y')
            ->where('energy_conversion.energy_id', $this_energy->id)
            ->select('unit.*', 'energy_conversion.scientific_qty')
            ->groupBy('unit.id')
            ->get();

        return view('dashboard/energy_form_add')
            ->with('this_province', $this_province)
            ->with('this_district', $this_district)
            ->with('data', $data)
            ->with('this_energy', $this_energy)
            ->with('central', $central)
            ->with('land_types', $land_types)
            ->with('sectors', $sectors)
            ->with('geographic_regions', $geographic_regions)
            ->with('rivers', $rivers)
            ->with('units', $units)
            ->with('overall', $overall)
            ->with('field_topics', $field_topics)
            ->with('start', $start)
            ->with('end', $end)
            ->with('energy_type', $energy_type_slug)
            ->with('route', 'add');
    }

    public function entryFormLocalEnergyForm($province_slug, $district_slug, $local_slug, $start, $end, $energy_type_slug, $energy_slug) {

        $this_province = Location::where('location_slug', $province_slug)->where('status', 'Y')->first();

        $this_district = Location::where('location_slug', $district_slug)->where('status', 'Y')->first();

        $this_local = Location::where('location_slug', $local_slug)->where('status', 'Y')->first();

        $central = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'central')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->first();

        $this_energy = Energy::where('energy_slug', $energy_slug)->first();

        $data = new StdClass();
        $data->id = '';
        $data->energy_id = $this_energy->id;
        $data->central_id = $central->id;
        $data->province_id = $this_province->id;
        $data->district_id = $this_district->id;
        $data->local_gov_id = '';
        $data->from_date = '';
        $data->to_date = '';

        $field_topics = EnergyTypeTopicMapping::where('energy_type_topic', $energy_type_slug)
            ->where('energy_id', $this_energy->id)
            ->pluck('energy_field_topic')->toArray();

//        $field_topics = array('production', 'resources', 'consumption', 'import', 'export');

        $land_types = LandType::where('status', 'Y')->get();
        $sectors = Sector::where('status', 'Y')->orderBy('entry_order', 'ASC')->get();
        $geographic_regions = GeographicRegion::where('status', 'Y')->get();
        $rivers = River::where('status', 'Y')->get();
        $overall = new stdClass();
        $overall->natural_unit = '';

        $units = Unit::join('energy_conversion', 'energy_conversion.natural_unit', '=', 'unit.id')
            ->where('unit.status', 'Y')
            ->where('energy_conversion.energy_id', $this_energy->id)
            ->select('unit.*', 'energy_conversion.scientific_qty')
            ->groupBy('unit.id')
            ->get();

//        echo '<pre>';
//        print_r(json_decode($units));
//        echo '</pre>';
//        exit();

        return view('dashboard/energy_form_add')
            ->with('this_province', $this_province)
            ->with('this_district', $this_district)
            ->with('this_local', $this_local)
            ->with('data', $data)
            ->with('this_energy', $this_energy)
            ->with('central', $central)
            ->with('land_types', $land_types)
            ->with('sectors', $sectors)
            ->with('geographic_regions', $geographic_regions)
            ->with('rivers', $rivers)
            ->with('units', $units)
            ->with('overall', $overall)
            ->with('field_topics', $field_topics)
            ->with('start', $start)
            ->with('end', $end)
            ->with('energy_type', $energy_type_slug)
            ->with('route', 'add');
    }

    public function postCreate(Request $request) {
        $formdata = $request->formdata;
        $land_type = $request->land_type;
        $sector = $request->sector;
        $energy_type = $request->energy_type;
        $overall = $request->overall;

        $objProductionEnergyForm = new ProductionEnergyForm();
        $objProductionEnergyForm->energy_id = $formdata['energy_id'];
        $objProductionEnergyForm->central_id = (!empty($formdata['central_id']))?$formdata['central_id']:null;
        $objProductionEnergyForm->province_id = (!empty($formdata['province_id']))?$formdata['province_id']:null;
        $objProductionEnergyForm->district_id = (!empty($formdata['district_id']))?$formdata['district_id']:null;
        $objProductionEnergyForm->local_gov_id = (!empty($formdata['local_gov_id']))?$formdata['local_gov_id']:null;
        $objProductionEnergyForm->from_date = (!empty($formdata['from_date']))?$formdata['from_date']:null;
        $objProductionEnergyForm->to_date = (!empty($formdata['to_date']))?$formdata['to_date']:null;
        $objProductionEnergyForm->status = 'Y';

        if($objProductionEnergyForm->save()){

            $energy_form_id = $objProductionEnergyForm->id;
            $energy_id = $formdata['energy_id'];
            $energy_topic = 'overall';
            $energy_topic_ids = $overall['id'];
            $natural_qty = $overall['natural_qty'];
            $natural_unit = $overall['natural_unit'];
            $scientific_qty = $overall['scientific_qty'];
            $scientific_unit = $overall['scientific_unit'];

            if(is_array($overall)) {
                $objEnergyFormMeta = new EnergyFormMeta();
                $objEnergyFormMeta->energy_form_id = $energy_form_id;
                $objEnergyFormMeta->energy_id = $energy_id;
                $objEnergyFormMeta->energy_topic = $energy_topic;
                $objEnergyFormMeta->energy_topic_id = $energy_topic_ids;
                $objEnergyFormMeta->natural_qty = (!empty($natural_qty))?$natural_qty:null;
                $objEnergyFormMeta->natural_unit = (!empty($natural_unit))?$natural_unit:null;
                $objEnergyFormMeta->scientific_qty = (!empty($scientific_qty))?$scientific_qty:null;
                $objEnergyFormMeta->scientific_unit = (!empty($scientific_unit))?$scientific_unit:null;
                $objEnergyFormMeta->energy_form_topic = 'overall';
                $objEnergyFormMeta->status = 'Y';

                $objEnergyFormMeta->save();
            }

            if(is_array($land_type)){
                $energy_form_id = $objProductionEnergyForm->id;
                $energy_id = $formdata['energy_id'];
                $energy_topic = 'land_type';
                $energy_topic_ids = $land_type['id'];
                $natural_qty = $land_type['natural_qty'];
                $natural_unit = $land_type['natural_unit'];
                $scientific_qty = $land_type['scientific_qty'];
                $scientific_unit = $land_type['scientific_unit'];

                if(is_array($energy_topic_ids)){
                    for($i = 0; $i < count($energy_topic_ids); $i++){
                        $objEnergyFormMeta = new EnergyFormMeta();
                        $objEnergyFormMeta->energy_form_id = $energy_form_id;
                        $objEnergyFormMeta->energy_id = $energy_id;
                        $objEnergyFormMeta->energy_topic = $energy_topic;
                        $objEnergyFormMeta->energy_topic_id = $energy_topic_ids[$i];
                        $objEnergyFormMeta->natural_qty = (!empty($natural_qty[$i]))?$natural_qty[$i]:null;
                        $objEnergyFormMeta->natural_unit = (!empty($natural_unit[$i]))?$natural_unit[$i]:null;
                        $objEnergyFormMeta->scientific_qty = (!empty($scientific_qty[$i]))?$scientific_qty[$i]:null;
                        $objEnergyFormMeta->scientific_unit = (!empty($scientific_unit[$i]))?$scientific_unit[$i]:null;
                        $objEnergyFormMeta->energy_form_topic = 'production';
                        $objEnergyFormMeta->status = 'Y';

                        $objEnergyFormMeta->save();
                    }
                }

            }

            if(is_array($sector)){
                $energy_form_id = $objProductionEnergyForm->id;
                $energy_id = $formdata['energy_id'];
                $energy_topic = 'sector';
                $energy_topic_ids = $sector['id'];
                $natural_qty = $sector['natural_qty'];
                $natural_unit = $sector['natural_unit'];
                $scientific_qty = $sector['scientific_qty'];
                $scientific_unit = $sector['scientific_unit'];

                if(is_array($energy_topic_ids)){
                    for($i = 0; $i < count($energy_topic_ids); $i++){
                        $objEnergyFormMeta = new EnergyFormMeta();
                        $objEnergyFormMeta->energy_form_id = $energy_form_id;
                        $objEnergyFormMeta->energy_id = $energy_id;
                        $objEnergyFormMeta->energy_topic = $energy_topic;
                        $objEnergyFormMeta->energy_topic_id = $energy_topic_ids[$i];
                        $objEnergyFormMeta->natural_qty = (!empty($natural_qty[$i]))?$natural_qty[$i]:null;
                        $objEnergyFormMeta->natural_unit = (!empty($natural_unit[$i]))?$natural_unit[$i]:null;
                        $objEnergyFormMeta->scientific_qty = (!empty($scientific_qty[$i]))?$scientific_qty[$i]:null;
                        $objEnergyFormMeta->scientific_unit = (!empty($scientific_unit[$i]))?$scientific_unit[$i]:null;
                        $objEnergyFormMeta->energy_form_topic = 'production';
                        $objEnergyFormMeta->status = 'Y';

                        $objEnergyFormMeta->save();
                    }
                }

            }

            if(is_array($energy_type)){
                $energy_form_id = $objProductionEnergyForm->id;
                $energy_id = $formdata['energy_id'];
                $energy_topic = 'energy_type';
                $energy_topic_ids = $energy_type['id'];
                $natural_qty = $energy_type['natural_qty'];
                $natural_unit = $energy_type['natural_unit'];
                $scientific_qty = $energy_type['scientific_qty'];
                $scientific_unit = $energy_type['scientific_unit'];

                if(is_array($energy_topic_ids)){
                    for($i = 0; $i < count($energy_topic_ids); $i++){
                        $objEnergyFormMeta = new EnergyFormMeta();
                        $objEnergyFormMeta->energy_form_id = $energy_form_id;
                        $objEnergyFormMeta->energy_id = $energy_id;
                        $objEnergyFormMeta->energy_topic = $energy_topic;
                        $objEnergyFormMeta->energy_topic_id = $energy_topic_ids[$i];
                        $objEnergyFormMeta->natural_qty = (!empty($natural_qty[$i]))?$natural_qty[$i]:null;
                        $objEnergyFormMeta->natural_unit = (!empty($natural_unit[$i]))?$natural_unit[$i]:null;
                        $objEnergyFormMeta->scientific_qty = (!empty($scientific_qty[$i]))?$scientific_qty[$i]:null;
                        $objEnergyFormMeta->scientific_unit = (!empty($scientific_unit[$i]))?$scientific_unit[$i]:null;
                        $objEnergyFormMeta->energy_form_topic = 'production';
                        $objEnergyFormMeta->status = 'Y';
                        $objEnergyFormMeta->save();
                    }
                }

            }

            $objLog = new LogTable();
            $log_details = array('Production Energy Form Entry for energy ID: '.$energy_id);
            $data = array(
                'log_details'   => serialize($log_details),
                'menu_name'     => 'New Production Energy Form Entry',
                'created_by'    => Auth::user()->id
            );
            $objLog->insertIntoLogTable($data);

//            return redirect('dashboard/production-energy-form/edit/'.$objProductionEnergyForm->id)->with('success', 'Production Energy Form Entry done successfully!');

        }else{
//            return redirect('dashboard/production-energy-form')->with('error', 'Production Energy Form Entry cannot be added!');
        }

    }

    public function reportEnergyYear(Request $request){

        $energy_years = EnergyYear::where('status', 'Y')->orderBy('energy_year_start', 'ASC')->get();

//        echo '<pre>';
//        print_r(json_decode($energy_years));
//        exit();

        return view('dashboard/report_energy_year_listing')
            ->with('url', $request->url())
            ->with('energy_years', $energy_years);

    }

    public function reportEnergyTypeListing($start, $end, Request $request) {

        $energy_types = EnergyTypes::where('status', 'Y')->get();

        return view('dashboard/report_energy_type_listing')
            ->with('url', $request->url())
            ->with('start', $start)
            ->with('end', $end)
            ->with('energy_types', $energy_types);

    }

    public function reportEnergyTypeEnergyTopicListing($start, $end, $energy_type_slug, Request $request) {

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $energy_topics = EnergyFormMeta::where('energy_form_topic', '=', $energy_type_slug)
            ->where('energy_topic', '!=', 'overall')
            ->groupBy('energy_topic')
            ->pluck('energy_topic');

                    // echo '<hr><pre>';
                    // print_r($energy_topics);
                    // echo '</pre><hr>';
                    
                    // exit();

        if(!empty($this_energy_type)){

            $energy_lists = Energy::where('status', 'Y')->get();

            return view('dashboard/report_energy_type_energy_topic_listing')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topics', $energy_topics)
                ->with('energy_lists', $energy_lists);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }

    }

    public function reportProvinceWiseEnergyTypeEnergyTopicListing($start, $end, $province_slug, $energy_type_slug, Request $request) {

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $energy_topics = EnergyFormMeta::where('energy_form_topic', '=', $energy_type_slug)
            ->where('energy_topic', '!=', 'overall')
            ->groupBy('energy_topic')
            ->pluck('energy_topic');

                    // echo '<hr><pre>';
                    // print_r($energy_topics);
                    // echo '</pre><hr>';

                    // exit();

        if(!empty($this_energy_type)){

            $energy_lists = Energy::where('status', 'Y')->get();

            return view('dashboard/report_energy_type_energy_topic_listing')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topics', $energy_topics)
                ->with('province_slug', $province_slug)
                ->with('energy_lists', $energy_lists);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }

    }

    public function reportEnergyTypeEnergyTopicLocationWise($start, $end, $energy_type_slug, $energy_topic, Request $request) {

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug')
            ->get();

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_province_listing')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('provinces', $provinces);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }

    }

    public function reportCentralProductionEnergyTopic($start, $end, $energy_topic, Request $request) {

        $energy_type_slug = 'production';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'ASC')
            ->get();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('production_energy_form.province_id', '=', $the_province->id)
                            ->where('production_energy_form.from_date', '=', $start)
                            ->where('production_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('production_energy_form.province_id', '=', $the_province->id)
                            ->where('production_energy_form.from_date', '=', $start)
                            ->where('production_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                            ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('production_energy_form.province_id', '=', $the_province->id)
                            ->where('production_energy_form.from_date', '=', $start)
                            ->where('production_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->river_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'sector'){
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('production_energy_form.province_id', '=', $the_province->id)
                            ->where('production_energy_form.from_date', '=', $start)
                            ->where('production_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->sector_name] = $inner_col;
                }
            }
        }else{
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', 'sector')
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                            ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', 'sector')
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('production_energy_form.province_id', '=', $the_province->id)
                            ->where('production_energy_form.from_date', '=', $start)
                            ->where('production_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->sector_name] = $inner_col;
                }
            }
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', 'geographic_region')
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', 'geographic_region')
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('production_energy_form.province_id', '=', $the_province->id)
                            ->where('production_energy_form.from_date', '=', $start)
                            ->where('production_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_name] = $inner_col;
                }
            }
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', 'land_type')
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', 'land_type')
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('production_energy_form.province_id', '=', $the_province->id)
                            ->where('production_energy_form.from_date', '=', $start)
                            ->where('production_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_name] = $inner_col;
                }
            }

        }

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('provinces', $provinces)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);
        }else{
            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');
        }
    }

    public function reportEnergySupplyDemandBalance($start, $end, Request $request) {

        $production = 'production';

        $import = 'import';

        $export = 'export';

        $energy_topic = 'sector';

        $final_result = array();

        $col_keys = '';

        if($energy_topic == 'sector'){


            $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->select('energy.*', 'fuel_type.fuel_type_name')
                ->where('energy_type_topic_mapping.energy_field_topic', '=', $energy_topic)
                ->where('energy.status', 'Y')
                ->groupBy('energy.id')
                ->orderBy('fuel_type.fuel_type_name', 'desc')
                ->get();

//            $rows = Energy::join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
//                ->select('energy.*', 'fuel_type.fuel_type_name')
//                ->groupBy('energy.id')
//                ->orderBy('fuel_type.fuel_type_name', 'DESC')
//                ->get();

            $col_keys = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.sector_name as key', 'sector.id')
                ->get();

            $col_send = array();
            array_push($col_send, 'Production');
            array_push($col_send, 'Import');
            array_push($col_send, 'Export');
            array_push($col_send, 'Total Primary Supply/Sale');
            array_push($col_send, 'Statistical Differences');
            array_push($col_send, 'Thermal Generation');
            array_push($col_send, 'Energy Loss');
            array_push($col_send, 'Final Supply');

            if(!empty($col_keys)){
                foreach($col_keys as $this_col_key){
                    array_push($col_send, $this_col_key->key);
                }
            }

//            echo '<pre>';
//            print_r(json_decode($col_production_keys));
//            exit();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;

                    $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;

                    $objEnergyMetaForm = EnergyFormMeta::join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                        ->where('energy_form_meta.energy_id', '=', $the_row->id)
                        ->where('energy_form_meta.energy_form_topic', '=', 'production')
                        ->where('production_energy_form.from_date', '=', $start)
                        ->where('production_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();

                    $inner_col[$counter] += (float)$objEnergyMetaForm->qty;

                    $counter++;

                    $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;

                    $objEnergyMetaForm = EnergyFormMeta::join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                        ->where('energy_form_meta.energy_id', '=', $the_row->id)
                        ->where('energy_form_meta.energy_form_topic', '=', 'import')
                        ->where('import_energy_form.from_date', '=', $start)
                        ->where('import_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();

                    $inner_col[$counter] += (float)$objEnergyMetaForm->qty;

                    $counter++;

                    $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;

                    $objEnergyMetaForm = EnergyFormMeta::join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                        ->where('energy_form_meta.energy_id', '=', $the_row->id)
                        ->where('energy_form_meta.energy_form_topic', '=', 'export')
                        ->where('export_energy_form.from_date', '=', $start)
                        ->where('export_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                    $counter++;

                    // Total Primary Supply/Sales
                    $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                    $inner_col[$counter] += ($inner_col[0] + $inner_col[1] + $inner_col[2]);
                    $counter++;

                    // Statistical Differences
                    $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                    $inner_col[$counter] = 0;
                    $counter++;

                    // Thermal Generation
                    $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                    $inner_col[$counter] = 0;
                    $counter++;

                    // Energy Loss
                    $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                    $inner_col[$counter] = 0;
                    $counter++;

                    // Final Supply
                    $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                    $inner_col[$counter] += ($inner_col[3] - $inner_col[4] - $inner_col[5] - $inner_col[6]);
                    $counter++;

                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $objEnergyMetaForm = EnergyFormMeta::join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('production_energy_form.from_date', '=', $start)
                            ->where('production_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $objEnergyMetaForm = EnergyFormMeta::join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('resources_energy_form.from_date', '=', $start)
                            ->where('resources_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $objEnergyMetaForm = EnergyFormMeta::join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('import_energy_form.from_date', '=', $start)
                            ->where('import_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $objEnergyMetaForm = EnergyFormMeta::join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('export_energy_form.from_date', '=', $start)
                            ->where('export_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
//                        array_push($inner_col, json_decode($objEnergyMetaForm));
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }

//                echo '<pre>';
//                print_r($final_result);
//                exit();
            }
        }

        return view('dashboard/report_energy_supply_demand_balance')
            ->with('start', $start)
            ->with('end', $end)
            ->with('col_send', $col_send)
            ->with('final_result', $final_result);

    }



    public function reportEnergyVersesEnergyTypeTabular($start, $end, $energy_type_slug, $energy_topic, Request $request) {


        $final_result = array();

        $col_keys = '';

//        $rows = Energy::join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
//            ->select('energy.*', 'fuel_type.fuel_type_name')
//            ->groupBy('energy.id')
//            ->orderBy('fuel_type.fuel_type_name', 'DESC')
//            ->get();

        $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
            ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
            ->select('energy.*', 'fuel_type.fuel_type_name')
            ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
            ->where('energy.status', 'Y')
            ->groupBy('energy.id')
            ->orderBy('fuel_type.fuel_type_name', 'desc')
            ->get();

        if($energy_topic == 'river') {
            $col_keys = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.river_name as key', 'river.id')
                ->get();
        }else if($energy_topic == 'land_type') {
            $col_keys = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.land_type_name as key', 'land_type.id')
                ->get();
        }else if($energy_topic == 'geographic_region') {
            $col_keys = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.geographic_region_name as key', 'geographic_region.id')
                ->get();
        }else{
            $col_keys = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.sector_name as key', 'sector.id')
                ->get();
        }

        $col_send = array();

        if(!empty($col_keys)){
            foreach($col_keys as $this_col_key){
                array_push($col_send, $this_col_key->key);
            }
        }

        if($energy_type_slug == 'consumption'){ // consumption_energy_form
            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }
        }else if($energy_type_slug == 'production'){ // production_energy_form
            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('production_energy_form.from_date', '=', $start)
                            ->where('production_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }
        }else if($energy_type_slug == 'resources'){ // resources_energy_form
            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('resources_energy_form.from_date', '=', $start)
                            ->where('resources_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }
        }else if($energy_type_slug == 'import'){ // import_energy_form
            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('import_energy_form.from_date', '=', $start)
                            ->where('import_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }
        }else if($energy_type_slug == 'export'){ // export_energy_form
            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('export_energy_form.from_date', '=', $start)
                            ->where('export_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }
        }

        return view('dashboard/report_energy_verses_energy_type_tabular')
        ->with('start', $start)
        ->with('end', $end)
        ->with('col_send', $col_send)
        ->with('energy_type_slug', $energy_type_slug)
        ->with('energy_topic', $energy_topic)
        ->with('final_result', $final_result);

    }



    public function reportProvinceWiseEnergyVersesEnergyTypeTabular($start, $end, $province_slug, $energy_type_slug, $energy_topic, Request $request) {

//        return 1;

        $final_result = array();

        $col_keys = '';

//        $rows = Energy::join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
//            ->select('energy.*', 'fuel_type.fuel_type_name')
//            ->groupBy('energy.id')
//            ->orderBy('fuel_type.fuel_type_name', 'DESC')
//            ->get();

        $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
            ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
            ->select('energy.*', 'fuel_type.fuel_type_name')
            ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
            ->where('energy.status', 'Y')
            ->groupBy('energy.id')
            ->orderBy('fuel_type.fuel_type_name', 'desc')
            ->get();

        if($energy_topic == 'river') {
            $col_keys = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.river_name as key', 'river.id')
                ->orderBy('river.entry_order', 'asc')
                ->get();
        }else if($energy_topic == 'land_type') {
            $col_keys = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.land_type_name as key', 'land_type.id')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();
        }else if($energy_topic == 'geographic_region') {
            $col_keys = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.geographic_region_name as key', 'geographic_region.id')
                ->orderBy('geographic_region.entry_order', 'asc')
                ->get();
        }else{
            $col_keys = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', 'sector')
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.sector_name as key', 'sector.id')
                ->orderBy('sector.entry_order', 'asc')
                ->get();
        }

        $col_send = array();

        if(!empty($col_keys)){
            foreach($col_keys as $this_col_key){
                array_push($col_send, $this_col_key->key);
            }
        }

//        echo '<pre>';
//        print_r(json_decode($rows));
//        echo '<hr />';
//        print_r($col_send);
//        echo '</pre>';
//        exit();

        if($energy_type_slug == 'consumption'){ // consumption_energy_form
            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->join('location', 'consumption_energy_form.province_id', '=', 'location.id')
                            ->where('location.location_slug', '=', $province_slug)
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }
        }else if($energy_type_slug == 'production'){ // production_energy_form
            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->join('location', 'production_energy_form.province_id', '=', 'location.id')
                            ->where('location.location_slug', '=', $province_slug)
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('production_energy_form.from_date', '=', $start)
                            ->where('production_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }
        }else if($energy_type_slug == 'resources'){ // resources_energy_form
            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                            ->join('location', 'resources_energy_form.province_id', '=', 'location.id')
                            ->where('location.location_slug', '=', $province_slug)
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('resources_energy_form.from_date', '=', $start)
                            ->where('resources_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }
        }else if($energy_type_slug == 'import'){ // import_energy_form
            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                            ->join('location', 'import_energy_form.province_id', '=', 'location.id')
                            ->where('location.location_slug', '=', $province_slug)
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('import_energy_form.from_date', '=', $start)
                            ->where('import_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }
        }else if($energy_type_slug == 'export'){ // export_energy_form
            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $counter = 0;
                    foreach($col_keys as $the_col){
                        $inner_col[$counter] = (!empty($inner_col[$counter]))?$inner_col[$counter]:0;
                        $objEnergyMetaForm = EnergyFormMeta::join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                            ->join('location', 'export_energy_form.province_id', '=', 'location.id')
                            ->where('location.location_slug', '=', $province_slug)
                            ->where('energy_form_meta.energy_id', '=', $the_row->id)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_col->id)
                            ->where('export_energy_form.from_date', '=', $start)
                            ->where('export_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        $inner_col[$counter] += (float)$objEnergyMetaForm->qty;
                        $counter++;
                    }
                    $final_result[$the_row->fuel_type_name.'-'.$the_row->energy_slug] = $inner_col;
                }
            }
        }

        return view('dashboard/report_energy_verses_energy_type_tabular')
        ->with('start', $start)
        ->with('end', $end)
        ->with('col_send', $col_send)
        ->with('energy_type_slug', $energy_type_slug)
        ->with('energy_topic', $energy_topic)
        ->with('final_result', $final_result);

    }

    public function reportCentralProductionEnergyTopicTrend($start, $end, $energy_topic, Request $request) {

        $energy_type_slug = 'production';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->orderBy('geographic_region.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){

                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('production_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('production_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->orderBy('river.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                            ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('production_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->river_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'sector'){
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->orderBy('sector.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('production_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();

                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }

                    $final_result[$the_row->sector_name] = $inner_col;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct_line')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralEnergyTypeEnergyTrend($start, $end, $energy_type_slug, Request $request) {

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        if(!empty($this_energy_type)){

            $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->select('energy.*', 'fuel_type.fuel_type_name')
                ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
                ->where('energy.status', 'Y')
                ->groupBy('energy.id')
                ->orderBy('fuel_type.fuel_type_name', 'desc')
                ->get();
//
//            $rows = Energy::join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
//                ->select('energy.*', 'fuel_type.fuel_type_name')
//                ->groupBy('energy.id')
//                ->orderBy('fuel_type.fuel_type_name', 'DESC')
//                ->get();

            if (!empty($rows)) {
                foreach ($rows as $the_row) {
                    $inner_col = array();
                    $inner_col_count = 0;

                    for ($year = $start; $year < $end; $year++) {

                        $inner_col[$inner_col_count] = (!empty($inner_col[$inner_col_count])) ? $inner_col[$inner_col_count] : 0;

                        if ($energy_type_slug == 'production') { // production_energy_form
                            $objEnergyMetaForm = EnergyFormMeta::join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                                ->where('energy_form_meta.energy_topic', '!=', 'overall')
                                ->where('energy_form_meta.energy_id', '=', $the_row->id)
                                ->where('production_energy_form.from_date', '=', $year)
                                ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                                ->first();
                            $inner_col[$inner_col_count] += (float)$objEnergyMetaForm->qty;
                        } else if ($energy_type_slug == 'resources') { // resources_energy_form
                            $objEnergyMetaForm = EnergyFormMeta::join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                                ->where('energy_form_meta.energy_topic', '!=', 'overall')
                                ->where('energy_form_meta.energy_id', '=', $the_row->id)
                                ->where('resources_energy_form.from_date', '=', $year)
                                ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                                ->first();
                            $inner_col[$inner_col_count] += (float)$objEnergyMetaForm->qty;
                        } else if ($energy_type_slug == 'import') { // import_energy_form
                            $objEnergyMetaForm = EnergyFormMeta::join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                                ->where('energy_form_meta.energy_topic', '=', 'overall')
                                ->where('energy_form_meta.energy_id', '=', $the_row->id)
                                ->where('import_energy_form.from_date', '=', $year)
                                ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                                ->first();
                            $inner_col[$inner_col_count] += (float)$objEnergyMetaForm->qty;
                        } else if ($energy_type_slug == 'export') { // export_energy_form
                            $objEnergyMetaForm = EnergyFormMeta::join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                                ->where('energy_form_meta.energy_topic', '=', 'overall')
                                ->where('energy_form_meta.energy_id', '=', $the_row->id)
                                ->where('export_energy_form.from_date', '=', $year)
                                ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                                ->first();
                            $inner_col[$inner_col_count] += (float)$objEnergyMetaForm->qty;
                        } else { // consumption_energy_form

                            $objEnergyMetaForm = EnergyFormMeta::join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                                ->where('energy_form_meta.energy_topic', '!=', 'overall')
                                ->where('energy_form_meta.energy_id', '=', $the_row->id)
                                ->where('consumption_energy_form.from_date', '=', $year)
                                ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                                ->first();
                            $inner_col[$inner_col_count] += (float)$objEnergyMetaForm->qty;
                        }
                        $inner_col_count++;
                    }
                    $final_result[$the_row->fuel_type_name . '-' . $the_row->energy_name] = $inner_col;
                }
            }

//            echo '<pre>';
//            print_r($final_result);
//            echo '</pre>';
//            exit();

            return view('dashboard/report_energy_type_energy_direct_line')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralConsumptionEnergyTopicTrend($start, $end, $energy_topic, Request $request) {

        $energy_type_slug = 'consumption';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->orderBy('geographic_region.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){

                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->orderBy('river.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->river_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'sector'){
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->orderBy('sector.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();

//                        echo '<pre>';
//                        print_r(json_decode($objEnergyMetaForm));

                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }

                    $final_result[$the_row->sector_name] = $inner_col;
                }
            }
        }

//        exit();

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct_line')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralResourcesEnergyTopicTrend($start, $end, $energy_topic, Request $request) {

        $energy_type_slug = 'resources';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->orderBy('geographic_region.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){

                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('resources_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('resources_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->orderBy('river.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                            ->join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('resources_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->river_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'sector'){
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->orderBy('sector.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('resources_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();

//                        echo '<pre>';
//                        print_r(json_decode($objEnergyMetaForm));

                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }

                    $final_result[$the_row->sector_name] = $inner_col;
                }
            }
        }

//        exit();

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct_line')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralImportEnergyTopicTrend($start, $end, $energy_topic, Request $request) {

        $energy_type_slug = 'import';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->orderBy('geographic_region.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){

                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('import_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('import_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->orderBy('river.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                            ->join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('import_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->river_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'sector'){
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->orderBy('sector.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('import_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();

//                        echo '<pre>';
//                        print_r(json_decode($objEnergyMetaForm));

                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }

                    $final_result[$the_row->sector_name] = $inner_col;
                }
            }
        }

//        exit();

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct_line')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralExportEnergyTopicTrend($start, $end, $energy_topic, Request $request) {

        $energy_type_slug = 'export';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->orderBy('geographic_region.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){

                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('export_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('export_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->orderBy('river.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                            ->join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('export_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->river_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'sector'){
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->orderBy('sector.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    for($year = $start; $year < $end; $year++){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('export_energy_form.from_date', '=', $year)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();

//                        echo '<pre>';
//                        print_r(json_decode($objEnergyMetaForm));

                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }

                    $final_result[$the_row->sector_name] = $inner_col;
                }
            }
        }

//        exit();

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct_line')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralProductionEnergyTopicPie($start, $end, $energy_topic, Request $request) {

        $energy_type_slug = 'production';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

//        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
//            ->where('location_type.location_type_slug', 'province')
//            ->where('location.status', 'Y')
//            ->select('location.*')
//            ->orderBy('location.location_slug', 'ASC')
//            ->get();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->orderBy('geographic_region.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('production_energy_form.from_date', '=', $start)
                        ->where('production_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->geographic_region_name] = json_decode($objEnergyMetaForm);
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                        ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('production_energy_form.from_date', '=', $start)
                        ->where('production_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->land_type_name] = $objEnergyMetaForm;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->orderBy('river.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                        ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('production_energy_form.from_date', '=', $start)
                        ->where('production_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->river_name] = $objEnergyMetaForm;
                }
            }
        }elseif($energy_topic == 'sector'){
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->orderBy('sector.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('production_energy_form', 'energy_form_meta.energy_form_id', '=', 'production_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('production_energy_form.from_date', '=', $start)
                        ->where('production_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->sector_name] = $objEnergyMetaForm;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct_pie')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralConsumptionEnergyTopicPie($start, $end, $energy_topic, Request $request) {

        $energy_type_slug = 'consumption';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->orderBy('geographic_region.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->geographic_region_name] = json_decode($objEnergyMetaForm);
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->land_type_name] = $objEnergyMetaForm;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->orderBy('river.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->river_name] = $objEnergyMetaForm;
                }
            }
        }elseif($energy_topic == 'sector'){
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->orderBy('sector.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->sector_name] = $objEnergyMetaForm;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct_pie')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportProvinceWiseConsumptionEnergyTopicPie($start, $end, $province_slug, $energy_topic, Request $request) {

        $energy_type_slug = 'consumption';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->orderBy('geographic_region.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->geographic_region_name] = json_decode($objEnergyMetaForm);
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->land_type_name] = $objEnergyMetaForm;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->orderBy('river.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->river_name] = $objEnergyMetaForm;
                }
            }
        }else{
            $energy_topic = 'sector';
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->orderBy('sector.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->join('location', 'consumption_energy_form.province_id', '=', 'location.id')
                        ->where('location.location_slug', '=', $province_slug)
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->sector_name] = $objEnergyMetaForm;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct_pie')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }
    }


    public function reportProvinceWiseConsumptionEnergyTopicFuelTypePie($start, $end, $province_slug, $energy_topic, Request $request) {

        $energy_type_slug = 'consumption';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        if($energy_topic == 'geographic_region'){

            $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->select('fuel_type.*')
                ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
                ->where('energy.status', 'Y')
                ->groupBy('fuel_type.id')
                ->orderBy('fuel_type.fuel_type_name', 'desc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->join('location', 'consumption_energy_form.province_id', '=', 'location.id')
                        ->join('energy', 'energy_form_meta.energy_id', '=', 'energy.id')
                        ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                        ->where('location.location_slug', '=', $province_slug)
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('fuel_type.id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->fuel_type_name] = $objEnergyMetaForm;
                }
            }

        }elseif($energy_topic == 'land_type'){

            $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->select('fuel_type.*')
                ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
                ->where('energy.status', 'Y')
                ->groupBy('fuel_type.id')
                ->orderBy('fuel_type.fuel_type_name', 'desc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->join('location', 'consumption_energy_form.province_id', '=', 'location.id')
                        ->join('energy', 'energy_form_meta.energy_id', '=', 'energy.id')
                        ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                        ->where('location.location_slug', '=', $province_slug)
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('fuel_type.id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->fuel_type_name] = $objEnergyMetaForm;
                }
            }

        }elseif($energy_topic == 'river'){

            $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->select('fuel_type.*')
                ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
                ->where('energy.status', 'Y')
                ->groupBy('fuel_type.id')
                ->orderBy('fuel_type.fuel_type_name', 'desc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->join('location', 'consumption_energy_form.province_id', '=', 'location.id')
                        ->join('energy', 'energy_form_meta.energy_id', '=', 'energy.id')
                        ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                        ->where('location.location_slug', '=', $province_slug)
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('fuel_type.id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->fuel_type_name] = $objEnergyMetaForm;
                }
            }

        }else{
            $energy_topic = 'sector';

            $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
                ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                ->select('fuel_type.*')
                ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
                ->where('energy.status', 'Y')
                ->groupBy('fuel_type.id')
                ->orderBy('fuel_type.fuel_type_name', 'desc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->join('location', 'consumption_energy_form.province_id', '=', 'location.id')
                        ->join('energy', 'energy_form_meta.energy_id', '=', 'energy.id')
                        ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                        ->where('location.location_slug', '=', $province_slug)
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('fuel_type.id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->fuel_type_name] = $objEnergyMetaForm;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct_pie')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }
    }


    public function reportProvinceWiseConsumptionEnergyTopicEnergyPie($start, $end, $province_slug, $energy_topic, Request $request) {

        $energy_type_slug = 'consumption';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        $rows = Energy::join('energy_type_topic_mapping', 'energy_type_topic_mapping.energy_id', '=', 'energy.id')
            ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
            ->select('energy.*')
            ->where('energy_type_topic_mapping.energy_type_topic', '=', $energy_type_slug)
            ->where('energy.status', 'Y')
            ->groupBy('energy.id')
            ->orderBy('energy.energy_name', 'desc')
            ->get();

        if($energy_topic == 'geographic_region'){

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->join('location', 'consumption_energy_form.province_id', '=', 'location.id')
                        ->join('energy', 'energy_form_meta.energy_id', '=', 'energy.id')
                        ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                        ->where('location.location_slug', '=', $province_slug)
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('fuel_type.id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->energy_name] = $objEnergyMetaForm;
                }
            }

        }elseif($energy_topic == 'land_type'){

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->join('location', 'consumption_energy_form.province_id', '=', 'location.id')
                        ->join('energy', 'energy_form_meta.energy_id', '=', 'energy.id')
                        ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                        ->where('location.location_slug', '=', $province_slug)
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('fuel_type.id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->energy_name] = $objEnergyMetaForm;
                }
            }

        }elseif($energy_topic == 'river'){

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->join('location', 'consumption_energy_form.province_id', '=', 'location.id')
                        ->join('energy', 'energy_form_meta.energy_id', '=', 'energy.id')
                        ->join('fuel_type', 'fuel_type.id', '=', 'energy.fuel_type_id')
                        ->where('location.location_slug', '=', $province_slug)
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('fuel_type.id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->energy_name] = $objEnergyMetaForm;
                }
            }

        }else{
            $energy_topic = 'sector';

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->join('location', 'consumption_energy_form.province_id', '=', 'location.id')
                        ->where('location.location_slug', '=', $province_slug)
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->energy_name] = $objEnergyMetaForm;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct_pie')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralResourcesEnergyTopicPie($start, $end, $energy_topic, Request $request) {

        $energy_type_slug = 'resources';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->orderBy('geographic_region.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('resources_energy_form.from_date', '=', $start)
                        ->where('resources_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->geographic_region_name] = json_decode($objEnergyMetaForm);
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                        ->join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('resources_energy_form.from_date', '=', $start)
                        ->where('resources_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->land_type_name] = $objEnergyMetaForm;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->orderBy('river.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                        ->join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('resources_energy_form.from_date', '=', $start)
                        ->where('resources_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->river_name] = $objEnergyMetaForm;
                }
            }
        }elseif($energy_topic == 'sector'){
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->orderBy('sector.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('resources_energy_form.from_date', '=', $start)
                        ->where('resources_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->sector_name] = $objEnergyMetaForm;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct_pie')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralImportEnergyTopicPie($start, $end, $energy_topic, Request $request) {

        $energy_type_slug = 'import';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('import_energy_form.from_date', '=', $start)
                        ->where('import_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->geographic_region_name] = json_decode($objEnergyMetaForm);
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                        ->join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('import_energy_form.from_date', '=', $start)
                        ->where('import_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->land_type_name] = $objEnergyMetaForm;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->orderBy('river.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                        ->join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('import_energy_form.from_date', '=', $start)
                        ->where('import_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->river_name] = $objEnergyMetaForm;
                }
            }
        }elseif($energy_topic == 'sector'){
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->orderBy('sector.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('import_energy_form.from_date', '=', $start)
                        ->where('import_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->sector_name] = $objEnergyMetaForm;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct_pie')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralExportEnergyTopicPie($start, $end, $energy_topic, Request $request) {

        $energy_type_slug = 'consumption';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->orderBy('geographic_region.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->geographic_region_name] = json_decode($objEnergyMetaForm);
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->land_type_name] = $objEnergyMetaForm;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->orderBy('river.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->river_name] = $objEnergyMetaForm;
                }
            }
        }elseif($energy_topic == 'sector'){
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->orderBy('sector.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                        ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                        ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                        ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                        ->where('consumption_energy_form.from_date', '=', $start)
                        ->where('consumption_energy_form.to_date', '=', $end)
                        ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                        ->first();
                    $final_result[$the_row->sector_name] = $objEnergyMetaForm;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct_pie')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }
    }

    public function reportCentralConsumptionEnergyTopic($start, $end, $energy_topic, Request $request) {

        $energy_type_slug = 'consumption';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'ASC')
            ->get();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->orderBy('geographic_region.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.province_id', '=', $the_province->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.province_id', '=', $the_province->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->orderBy('river.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.province_id', '=', $the_province->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->river_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'sector'){
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->orderBy('sector.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.province_id', '=', $the_province->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->sector_name] = $inner_col;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('provinces', $provinces)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }

    }

    public function reportProvinceWiseConsumptionEnergyTopic($start, $end, $province_slug, $energy_topic, Request $request) {

        $energy_type_slug = 'consumption';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $this_province = Location::where('location_slug', $province_slug)->where('status', 'Y')->first();

        $districts = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->join('location AS loc_parent', 'loc_parent.id', '=', 'location.parent_id')
            ->where('loc_parent.location_slug', '=', $province_slug)
            ->where('location_type.location_type_slug', 'district')
            ->where('location.status', 'Y')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->groupBy('location.id')
            ->orderBy('location.location_slug', 'ASC')
            ->get();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->orderBy('geographic_region.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($districts as $the_district){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.district_id', '=', $the_district->id)
                            ->where('consumption_energy_form.province_id', '=', $this_province->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($districts as $the_district){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.district_id', '=', $the_district->id)
                            ->where('consumption_energy_form.province_id', '=', $this_province->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->orderBy('river.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($districts as $the_district){
                        $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.district_id', '=', $the_district->id)
                            ->where('consumption_energy_form.province_id', '=', $this_province->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->river_name] = $inner_col;
                }
            }
        }else{

            $energy_topic = 'sector';

            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->orderBy('sector.entry_order', 'asc')
                ->get();
//
//            echo '<pre>';
//            print_r(json_decode($rows));
//            echo '</pre>';
//            exit();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($districts as $the_district){
                        $objEnergyMetaForm = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                            ->join('consumption_energy_form', 'energy_form_meta.energy_form_id', '=', 'consumption_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('consumption_energy_form.district_id', '=', $the_district->id)
                            ->where('consumption_energy_form.province_id', '=', $this_province->id)
                            ->where('consumption_energy_form.from_date', '=', $start)
                            ->where('consumption_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->sector_name] = $inner_col;

//                    echo '<pre>';
//                    print_r($final_result);
//                    echo '</pre>';
//                    exit();
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('provinces', $districts)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }

    }

    public function reportCentralResourcesEnergyTopic($start, $end, $energy_topic, Request $request) {

        $energy_type_slug = 'resources';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'ASC')
            ->get();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->orderBy('geographic_region.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('resources_energy_form.province_id', '=', $the_province->id)
                            ->where('resources_energy_form.from_date', '=', $start)
                            ->where('resources_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('resources_energy_form.province_id', '=', $the_province->id)
                            ->where('resources_energy_form.from_date', '=', $start)
                            ->where('resources_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->orderBy('river.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                            ->join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('resources_energy_form.province_id', '=', $the_province->id)
                            ->where('resources_energy_form.from_date', '=', $start)
                            ->where('resources_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->river_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'sector'){
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->orderBy('sector.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('resources_energy_form', 'energy_form_meta.energy_form_id', '=', 'resources_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('resources_energy_form.province_id', '=', $the_province->id)
                            ->where('resources_energy_form.from_date', '=', $start)
                            ->where('resources_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->sector_name] = $inner_col;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('provinces', $provinces)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }

    }

    public function reportCentralImportEnergyTopic($start, $end, $energy_topic, Request $request) {

        $energy_type_slug = 'import';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'ASC')
            ->get();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->orderBy('geographic_region.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('import_energy_form.province_id', '=', $the_province->id)
                            ->where('import_energy_form.from_date', '=', $start)
                            ->where('import_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('import_energy_form.province_id', '=', $the_province->id)
                            ->where('import_energy_form.from_date', '=', $start)
                            ->where('import_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->orderBy('river.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                            ->join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('import_energy_form.province_id', '=', $the_province->id)
                            ->where('import_energy_form.from_date', '=', $start)
                            ->where('import_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->river_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'sector'){
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->orderBy('sector.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('import_energy_form', 'energy_form_meta.energy_form_id', '=', 'import_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('import_energy_form.province_id', '=', $the_province->id)
                            ->where('import_energy_form.from_date', '=', $start)
                            ->where('import_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->sector_name] = $inner_col;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('provinces', $provinces)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }

    }

    public function reportCentralExportEnergyTopic($start, $end, $energy_topic, Request $request) {

        $energy_type_slug = 'export';

        $this_energy_type = EnergyTypes::where('energy_type_slug', $energy_type_slug)->first();

        $provinces = Location::join('location_type', 'location_type.id', '=', 'location.location_type_id')
            ->where('location_type.location_type_slug', 'province')
            ->where('location.status', 'Y')
            ->select('location.*')
            ->orderBy('location.location_slug', 'ASC')
            ->get();

        $final_result = array();

        if($energy_topic == 'geographic_region'){
            $rows = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('geographic_region.*')
                ->orderBy('geographic_region.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('export_energy_form.province_id', '=', $the_province->id)
                            ->where('export_energy_form.from_date', '=', $start)
                            ->where('export_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->geographic_region_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'land_type'){
            $rows = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('land_type.*')
                ->orderBy('land_type.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('land_type', 'energy_form_meta.energy_topic_id', '=', 'land_type.id')
                            ->join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('export_energy_form.province_id', '=', $the_province->id)
                            ->where('export_energy_form.from_date', '=', $start)
                            ->where('export_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->land_type_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'river'){
            $rows = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('river.*')
                ->orderBy('river.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('river', 'energy_form_meta.energy_topic_id', '=', 'river.id')
                            ->join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('export_energy_form.province_id', '=', $the_province->id)
                            ->where('export_energy_form.from_date', '=', $start)
                            ->where('export_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->river_name] = $inner_col;
                }
            }
        }elseif($energy_topic == 'sector'){
            $rows = EnergyFormMeta::join('sector', 'energy_form_meta.energy_topic_id', '=', 'sector.id')
                ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                ->groupBy('energy_form_meta.energy_topic_id')
                ->select('sector.*')
                ->orderBy('sector.entry_order', 'asc')
                ->get();

            if(!empty($rows)){
                foreach($rows as $the_row){
                    $inner_col = array();
                    foreach($provinces as $the_province){
                        $objEnergyMetaForm = EnergyFormMeta::join('geographic_region', 'energy_form_meta.energy_topic_id', '=', 'geographic_region.id')
                            ->join('export_energy_form', 'energy_form_meta.energy_form_id', '=', 'export_energy_form.id')
                            ->where('energy_form_meta.energy_topic', '=', $energy_topic)
                            ->where('energy_form_meta.energy_topic_id', '=', $the_row->id)
                            ->where('export_energy_form.province_id', '=', $the_province->id)
                            ->where('export_energy_form.from_date', '=', $start)
                            ->where('export_energy_form.to_date', '=', $end)
                            ->select(DB::raw('sum(energy_form_meta.scientific_qty) as qty'))
                            ->first();
                        array_push($inner_col, json_decode($objEnergyMetaForm));
                    }
                    $final_result[$the_row->sector_name] = $inner_col;
                }
            }
        }

        if(!empty($this_energy_type)){

            return view('dashboard/report_energy_type_energy_topic_direct')
                ->with('url', $request->url())
                ->with('this_energy_type', $this_energy_type)
                ->with('provinces', $provinces)
                ->with('start', $start)
                ->with('end', $end)
                ->with('energy_topic', $energy_topic)
                ->with('final_result', $final_result);

        }else{

            return redirect('dashboard/report')->with('warning', 'No such Energy Type!');

        }

    }

}
