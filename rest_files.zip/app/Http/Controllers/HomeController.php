<?php

namespace App\Http\Controllers;

use App\LogTable;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $one_month_date = date('Y-m-d', (strtotime(date('Y-m-d')) - 30*24*60*60 ));
        $log_data = LogTable::where('created_at', '>', $one_month_date)->orderBy('created_at', 'desc')->get();

        $log_data = LogTable::join('users', 'users.id', '=', 'log.created_by')
            ->where('log.created_at', '>', $one_month_date)
            ->select('users.name', 'log.*')
            ->orderBy('log.created_at', 'desc')
            ->get();

//        echo '<pre>';
//        print_r(json_decode($log_data));
//        exit();
        return view('dashboard/dashboard')->with('data', $log_data);
    }
}
