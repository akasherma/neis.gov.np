<?php

namespace App\Http\Controllers;

use App\User;
use App\Usertype;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use stdClass;

class JsonController extends Controller
{

    public function postRegister(Request $request){

        $usertypeid = Usertype::where('user_type_slug', 'student')->first();

        $email = $request->email;
        $password = $request->password;
        $re_password = $request->re_password;
        $f_name = $request->f_name;
        $m_name = $request->m_name;
        $l_name = $request->l_name;
        $phone = $request->phone;
        $gendar = $request->gendar;
        $college = $request->college;
        $username = $request->username;

        $userId = User::where('email', $email)->first();

//        echo '<pre>';
//        print_r($formdata['email']);
//        echo '</pre>';
//        exit();
        if(!is_null($userId)){
            $result = array(
                'code'=>'400', 
                'message'=>'Your email address has already Registered!'
            );
        
            return response(json_encode($result), 400)->header('Content-Type', 'application/json; charset=utf-8');
        }

        if($password != $re_password){
            $result = array(
                'code'=>'400', 
                'message'=>'Your password did not match!'
            );
        
            return response(json_encode($result), 400)->header('Content-Type', 'application/json; charset=utf-8');

        }

        $objReg = new User();
        if(!is_null($request->image)){
           $this->validate($request, [
               'image' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
           ]);
    
           $image = $request->file('image');
           $input['imagename'] = time().'.'.$image->getClientOriginalExtension();
           $destinationPath = public_path('/images');
           $image->move($destinationPath, $input['imagename']);
           $objReg->image = $input['imagename'];
        }
        $objReg->f_name = $f_name;
        $objReg->m_name = $m_name;
        $objReg->l_name = $l_name;
        $objReg->phone = $phone;
        $objReg->gendar = $gendar;
        $objReg->college = $college;
        $objReg->password = md5($password);
        $objReg->email = $email;
        $objReg->username = $username;
        $objReg->user_types_id = $usertypeid->id;
        $objReg->status = '1';
        $objReg->save();

        $subject = "Registration on Nepaeducation as Student";

        $message = "
            <html>
            <head>
            <title>".$subject."</title>
            </head>
            <body>
            <strong>Dear ".$f_name.", </strong>
            <p>You have successfully registered student account.</a></p>
            <p>Thank you,</p>
            </body>
            </html>
            ";

        // Always set content-type when sending HTML email
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

        // More headers
        $headers .= 'From: <info.nepaeducation@gmail.com>' . "\r\n";
        $headers .= 'Cc: info.nepaeducation@gmail.com' . "\r\n";

        if(mail($email,$subject,$message,$headers)){

            $result = array(
                'code'=>'200', 
                'message'=>'Mail sent to your email. Please check it out!'
            );
            
            return response()->json($result)->header('Content-Type', 'application/json; charset=utf-8', 'status', '200');

        }else{
            $result = array(
                'code'=>'400', 
                'message'=>'Mail hasnot been sent to your email!'
            );
        
            return response(json_encode($result), 400)->header('Content-Type', 'application/json; charset=utf-8');

        }
    }

    public function login_json(Request $request){

        $email = (!is_null($request->email))?$request->email:'';
        $password = (!is_null($request->password))?$request->password:'';
      
        $this_profile = json_decode(User::where('email', $email)->first());
      
//       echo $this_profile->password;
      
//       echo $this_profile->user_type_id;
      
//         echo '1<pre>';
//         print_r($this_profile);
//         echo '</pre>';
      
//       exit();
      
        if($this_profile->user_types_id > 1){
          
          $result = User::where('email', '=', $email)->where('password', '=', md5($password))->first();
          
        }else{
          $result = array();
        }
        
        // echo '<pre>';
        // print_r($result);
        // echo '</pre>';
        
        if(empty($result)){
            $result = array(
                'code'=>'400', 
                'message'=>'Invalid Username or Password!'
            );
        
            return response(json_encode($result), 400)->header('Content-Type', 'application/json; charset=utf-8');
        }
        
        return response()->json($result)->header('Content-Type', 'application/json; charset=utf-8', 'status', '200');

        //exit();
        
    }
    
  
  public function user_profile_update_post(Request $request){
        
        $user_id = (!is_null($request->user_id))?$request->user_id:0;
    
    
        $fname = (!is_null($request->fname))?$request->fname:'';
        $mname = (!is_null($request->mname))?$request->mname:'';
        $lname = (!is_null($request->lname))?$request->lname:'';
        $address = (!is_null($request->address))?$request->address:'';
        // $email = (!is_null($request->email))?$request->email:'';
        $phone = (!is_null($request->phone))?$request->phone:'';
        $company = (!is_null($request->company))?$request->company:'';
        // $img_src = (!is_null($full_filename))?$full_filename :'';
        $description = (!is_null($request->description))?$request->description:'';
        $status = (!is_null($request->status))?$request->status:'N';
        $lat = (!is_null($request->lat))?$request->lat:0;
        $lng = (!is_null($request->lng))?$request->lng:0;
    
        $full_filename = '';

        if($user_id > 0){

            $objClient = User::find($user_id);
    
            if(!is_null($request->file('img_src'))){

              $this->validate($request, [
                  'img_src' => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
              ]);

              $image = $request->file('img_src');

              $input['imagename'] = time().'.'.$image->getClientOriginalExtension();
              $destinationPath = public_path('/images');

              if($image->move($destinationPath, $input['imagename']))
                $full_filename = url('/').'/public/images/'.$input['imagename'];
              
              $objClient->img_src = $full_filename;
              
//               return $full_filename;

            }

            $objClient->fname = $fname;
            $objClient->mname = $mname;
            $objClient->lname = $lname;
        
            if(!is_null($request->password)){
                $objClient->password = $password;    
            }
            
            $objClient->address = $address;
            $objClient->phone = $phone;
            $objClient->company = $company;
            $objClient->description = $description;
            $objClient->status = $status;
            $objClient->lat = (double)$lat;
            $objClient->lng = (double)$lng;

            if($objClient->save()){
              
                $data = new stdClass();
                $data->fname = $objClient->fname;
                $data->mname = $objClient->mname;
                $data->lname = $objClient->lname;
                $data->address = $objClient->address;
                $data->img_src = $objClient->img_src;
                $data->email = $objClient->email;
                $data->phone = $objClient->phone;
                $data->company = $objClient->company;
                $data->description = $objClient->description;
                $data->status = $objClient->status;
              
              ini_set('serialize_precision', -1); ini_set('precision', 17);
                
                $data->lat = (double)$objClient->lat; 
                $data->lng = (double)$objClient->lng; 
              
//                 $data->lat = (double)substr(number_format((double)$objClient->lat, 20), 0, -1);
              
//                 $data->lng = (double)substr(number_format((double)$objClient->lng, 20), 0, -1);
                
//                 $data->lat = round((double)$objClient->lat, 20);
//                 $data->lng = round((double)$objClient->lng, 20);
                
                $result = array(
                    'message' =>  'User updated successfully!'
                );
            
                return response()->json($data)->header('Content-Type', 'application/json; charset=utf-8', 'status', '200');
            
            }else{
                $result = array(
                    'code'  => '400',
                    'message'=>'User cannot be updated!'
                );
                
                return response(json_encode($result), 400)->header('Content-Type', 'application/json; charset=utf-8');
            }
        }else{
            $result = array(
                'code'  => '400',
                'message'=>'User cannot be updated!'
            );
            
            return response(json_encode($result), 400)->header('Content-Type', 'application/json; charset=utf-8');
          
        }
    
  }
  
  

    public function postforgotpassword(Request $request){
      
      $to = $request->email;
      
      $route = 'login';
      
      $res_user = User::where('email', $to)->first();
      
      $user_type_id = $res_user->user_type_id;
      
//       echo '<pre>';
//       print_r($user_type_id);
//       echo '</pre>';
//       exit();
      
      if($user_type_id > 1)
        $route = 'user';
      
      $subject = "Reset code for ".$to;
      
      $msg = '';
      
      $time_plus = strtotime(date('Y-m-d H:i:s')) + 60*60;
      
      $encode = base64_encode($to.'-'.$time_plus);
      
      $message = "
      <html>
      <head>
      <title>".$subject."</title>
      </head>
      <body>
      <strong>Dear</strong>
      <p>Reset your activation code using<a href='".url('/').'/resetcode/'.$encode."'>".url('/').'/resetcode/'.$encode."</a></p>
      <p>Thank you,</p>
      </body>
      </html>
      ";

      // Always set content-type when sending HTML email
      $headers = "MIME-Version: 1.0" . "\r\n";
      $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

      // More headers
      $headers .= 'From: <info@innovts.com>' . "\r\n";
      $headers .= 'Cc: akasherma.shakha@gmail.com' . "\r\n";

      if(mail($to,$subject,$message,$headers)){
    
        $result = array(
            'code'  => '200',
            'message'=>'Mail has been sent to your email. Please check it out!'
        );
    
        return response()->json($result)->header('Content-Type', 'application/json; charset=utf-8', 'status', '200');
        
      }else{
        $result = array(
            'code'  => '400',
            'message'=>'Mail has not been sent to your email!'
        );
    
        return response()->json($result)->header('Content-Type', 'application/json; charset=utf-8', 'status', '400');
        
      }
      
    }
  
  

  public function postresetpwd(Request $request){
    
        $id = $request->user_id;
    
        $password = $request->password;
    
        $old_password = $request->old_password;
    
        $checkUser = User::find($id);
    
        $result = array(
            'code'  => '200',
            'message'=>'Password changed successfully!'
        );
    
        if($checkUser->user_type_id > 1 && $checkUser->password == md5($old_password)){
            $checkUser->password = md5($password);
            $checkUser->save();

            return response(json_encode($result), 200)->header('Content-Type', 'application/json; charset=utf-8');
          
        }else if($checkUser->user_type_id == 1 && Hash::check($old_password, $checkUser->password)) {
            $checkUser->password = Hash::make($password);
            $checkUser->save();

            return response(json_encode($result), 200)->header('Content-Type', 'application/json; charset=utf-8');
          
        }
    
        $result = array(
            'code'  => '400',
            'message'=>'Password cannot be changed!'
        );

        return response(json_encode($result), 400)->header('Content-Type', 'application/json; charset=utf-8');

    }
}