<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductionEnergyForm extends Model
{

    protected $table = 'production_energy_form';

    protected $fillable = ['energy_id', 'central_id', 'province_id', 'district_id', 'local_gov_id', 'entered_by', 'qa_by', 'published_by', 'from_date', 'to_date', 'status'];

}
