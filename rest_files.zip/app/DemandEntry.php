<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DemandEntry extends Model
{
    protected $table = 'demand_entry';

    protected $fillable = ['demand_id', 'position_id', 'required_qty', 'basic_salary','duty_hours', 'lodging', 'fooding', 'overtime', 'air_ticket', 'qualification', 'remarks'];

}
