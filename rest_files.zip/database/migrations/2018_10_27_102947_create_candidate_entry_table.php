<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCandidateEntryTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('candidate_entry', function (Blueprint $table) {
            $table->increments('id');
            $table->string('entry_reg_no')->nullable();
            $table->string('first_name')->nullable();
            $table->string('middle_name')->nullable();
            $table->string('last_name')->nullable();
            $table->string('passport_no')->unique();
            $table->string('dob')->nullable();
            $table->string('address')->nullable();
            $table->string('district')->nullable();
            $table->string('qualification')->nullable();
            $table->dateTime('passport_expiry_date')->nullable();
            $table->dateTime('passport_issue_date')->nullable();
            $table->string('place_of_issue')->nullable();
            $table->string('issuing_authority')->nullable();
            $table->string('gender')->nullable();
            $table->string('next_to_kin')->nullable();
            $table->string('relation_with_kin')->nullable();
            $table->string('reference_by')->nullable();
            $table->integer('country_applied_for')->nullable();
            $table->integer('company_applied_for')->nullable();
            $table->integer('position_applied_for')->nullable();
            $table->string('contact_no')->nullable();
            $table->text('attachment')->nullable();
            $table->text('certificates')->nullable();
            $table->text('photographs')->nullable();
            $table->text('remarks')->nullable();
            $table->integer('entry_by')->nullable();
            $table->integer('entry_status')->nullable();
            $table->enum('status', ['Y', 'N'])->default('N');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('candidate_entry');
    }
}
