<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDemandEntryTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('demand_entry', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('demand_id');
            $table->integer('position_id');
            $table->integer('required_qty')->nullable();
            $table->string('basic_salary')->nullable();
            $table->string('duty_hours')->nullable();
            $table->enum('lodging', ['Y', 'N'])->default('N');
            $table->enum('fooding', ['Y', 'N'])->default('N');
            $table->string('overtime')->nullable();
            $table->string('air_ticket')->nullable();
            $table->string('qualification')->nullable();
            $table->string('remarks')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('demand_entry');
    }
}
