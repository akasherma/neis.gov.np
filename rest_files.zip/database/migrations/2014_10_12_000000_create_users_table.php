<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name');
            $table->string('email');
            $table->string('password');
            $table->string('company_name')->nullable();
            $table->string('company_logo')->nullable();
            $table->string('other_logo')->nullable();
            $table->integer('parent_id')->nullable();
            $table->integer('user_type_id')->nullable();
            $table->enum('is_admin', ['Y', 'N'])->default('N');
            $table->enum('status', ['Y', 'N'])->default('N');

            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
