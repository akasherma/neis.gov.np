<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'frontend\FrontendController@homepage');

//Route::get('/', function () {
//     return view('frontend.homepage');
//    return redirect('login');
//});

Route::get('/user', function () {
    return redirect('login');
});

Auth::routes();

//Route::get('/home', 'HomeController@index')->name('home');

Route::get('/forgot-password', 'user\UserLoginController@forgotpassword');
Route::get('forgotpassword', 'user\UserLoginController@forgotpassword');
Route::post('forgotpwd', 'user\UserLoginController@postforgotpassword');
Route::get('/resetcode/{code}', 'user\UserLoginController@resetcode');
Route::post('/resetpwd', 'user\UserLoginController@postresetpwd');

Route::group(['middleware' => ['auth']], function() {

    Route::get('/dashboard', 'HomeController@index');

    Route::get('home', function () {
        return redirect('dashboard');
    });

    Route::get('dashboard/user', 'dashboard\UserController@index');
//
//    Route::post('/user', 'user\UserLoginController@postLogin');
//
//    Route::get('/signup', 'user\UserLoginController@register');
//
//    Route::post('/signup', 'user\UserLoginController@postRegister');
//

    Route::get('signout', 'user\UserLoginController@userLogout')->name('signout');

//    Route::get('dashboard', 'user\UserLoginController@dashboard');


//Sector Controller

    Route::get('/dashboard/sector', 'dashboard\SectorController@index');
    Route::get('/dashboard/sector/add', 'dashboard\SectorController@create');
    Route::post('/dashboard/sector/add', 'dashboard\SectorController@postCreate');
    Route::get('/dashboard/sector/update/{sector_id}', 'dashboard\SectorController@update');
    Route::post('/dashboard/sector/update', 'dashboard\SectorController@postUpdate');
    Route::get('/dashboard/sector/view/{sector_id}', 'dashboard\SectorController@view');

    Route::get('/dashboard/page', 'dashboard\PageController@index');
    Route::get('/dashboard/page/add', 'dashboard\PageController@create');
    Route::post('/dashboard/page/add', 'dashboard\PageController@postCreate');
    Route::get('/dashboard/page/update/{page_id}', 'dashboard\PageController@update');
    Route::post('/dashboard/page/update', 'dashboard\PageController@postUpdate');
    Route::get('/dashboard/page/view/{page_id}', 'dashboard\PageController@view');

//    energy_type

    Route::get('/dashboard/energy_type', 'dashboard\EnergyTypesController@index');
    Route::get('/dashboard/energy_type/add', 'dashboard\EnergyTypesController@create');
    Route::post('/dashboard/energy_type/add', 'dashboard\EnergyTypesController@postCreate');
    Route::get('/dashboard/energy_type/update/{energy_type_id}', 'dashboard\EnergyTypesController@update');
    Route::post('/dashboard/energy_type/update', 'dashboard\EnergyTypesController@postUpdate');
    Route::get('/dashboard/energy_type/view/{energy_type_id}', 'dashboard\EnergyTypesController@view');

    Route::get('/dashboard/energy_type/{energy_type_slug}', 'dashboard\EnergyTypesController@EnergyTypeEnergyListing');
    //    nature
    Route::get('/dashboard/energy_type/{energy_type_slug}/energy/{energy_id}', 'dashboard\EnergyTypesController@EnergyTypeTopicMappingPolicy');
    Route::post('/dashboard/energy_type/{energy_type_slug}/energy/{energy_id}', 'dashboard\EnergyTypesController@EnergyTypeTopicMappingPolicyPost');
    //    nature
    //    nature

    Route::get('/dashboard/energy_type/{energy_type_slug}/energylisting/', 'dashboard\EnergyTypesController@EnergyTypeTopicMappingPolicyEnergyListing');
    Route::post('/dashboard/energy_type/{energy_type_slug}/energylisting/store', 'dashboard\EnergyTypesController@EnergyTypeTopicMappingPolicyEnergyListingPost');
    //    nature

    Route::get('/dashboard/nature', 'dashboard\NatureController@index');
    Route::get('/dashboard/nature/add', 'dashboard\NatureController@create');
    Route::post('/dashboard/nature/add', 'dashboard\NatureController@postCreate');
    Route::get('/dashboard/nature/update/{nature_id}', 'dashboard\NatureController@update');
    Route::post('/dashboard/nature/update', 'dashboard\NatureController@postUpdate');
    Route::get('/dashboard/nature/view/{nature_id}', 'dashboard\NatureController@view');

    //    source

    Route::get('/dashboard/source', 'dashboard\SourceController@index');
    Route::get('/dashboard/source/add', 'dashboard\SourceController@create');
    Route::post('/dashboard/source/add', 'dashboard\SourceController@postCreate');
    Route::get('/dashboard/source/update/{source_id}', 'dashboard\SourceController@update');
    Route::post('/dashboard/source/update', 'dashboard\SourceController@postUpdate');
    Route::get('/dashboard/source/view/{source_id}', 'dashboard\SourceController@view');

    Route::get('/user/dashboard/check_passport_no/{ppno}', 'user\CandidateController@checkPassportNo');

    Route::get('/user/dashboard/candidate/{table}/{name}', 'user\CandidateController@createTableName');

// Geographic Region Controller
    Route::get('dashboard/geographic-region', 'dashboard\GeographicRegionController@index');
    Route::get('dashboard/geographic-region/add', 'dashboard\GeographicRegionController@create');
    Route::post('dashboard/geographic-region/add', 'dashboard\GeographicRegionController@postCreate');
    Route::get('dashboard/geographic-region/update/{id}','dashboard\GeographicRegionController@update');
    Route::post('dashboard/geographic-region/update','dashboard\GeographicRegionController@postUpdate');
    Route::get('dashboard/geographic-region/delete/{id}','dashboard\GeographicRegionController@delete');

//  Fuel Type Controller
    Route::get('dashboard/fuel-type', 'dashboard\FuelTypeController@index');
    Route::get('dashboard/fuel-type/add', 'dashboard\FuelTypeController@create');
    Route::post('dashboard/fuel-type/add', 'dashboard\FuelTypeController@postCreate');
    Route::get('dashboard/fuel-type/update/{id}','dashboard\FuelTypeController@update');
    Route::post('dashboard/fuel-type/update','dashboard\FuelTypeController@postUpdate');
    Route::get('dashboard/fuel-type/delete/{id}','dashboard\FuelTypeController@delete');

//  Energy Conversion Controller
    Route::get('dashboard/energy-conversion', 'dashboard\EnergyConversionController@index');
    Route::get('dashboard/energy-conversion/add', 'dashboard\EnergyConversionController@create');
    Route::post('dashboard/energy-conversion/add', 'dashboard\EnergyConversionController@postCreate');
    Route::get('dashboard/energy-conversion/update/{id}','dashboard\EnergyConversionController@update');
    Route::post('dashboard/energy-conversion/update','dashboard\EnergyConversionController@postUpdate');
    Route::get('dashboard/energy-conversion/delete/{id}','dashboard\EnergyConversionController@delete');

//  Energy Controller
    Route::get('dashboard/energy', 'dashboard\EnergyController@index');
    Route::get('dashboard/energy/add', 'dashboard\EnergyController@create');
    Route::post('dashboard/energy/add', 'dashboard\EnergyController@postCreate');
    Route::get('dashboard/energy/update/{id}','dashboard\EnergyController@update');
    Route::post('dashboard/energy/update','dashboard\EnergyController@postUpdate');
    Route::get('dashboard/energy/delete/{id}','dashboard\EnergyController@delete');
    
// Location Type Controller
    Route::get('dashboard/location-type','dashboard\LocationTypeController@index');
    Route::get('dashboard/location-type/add','dashboard\LocationTypeController@create');
    Route::post('dashboard/location-type/add','dashboard\LocationTypeController@postCreate');
    Route::get('dashboard/location-type/update/{id}','dashboard\LocationTypeController@update');
    Route::post('dashboard/location-type/update','dashboard\LocationTypeController@postUpdate');
    Route::get('dashboard/location-type/delete/{id}','dashboard\LocationTypeController@delete');

// Location Controller
    Route::get('dashboard/location','dashboard\LocationController@index');
    Route::get('dashboard/location/add','dashboard\LocationController@create');
    Route::post('dashboard/location/add','dashboard\LocationController@postCreate');
    Route::get('dashboard/location/update/{id}','dashboard\LocationController@update');
    Route::post('dashboard/location/update','dashboard\LocationController@postUpdate');
    Route::get('dashboard/location/delete/{id}','dashboard\LocationController@delete');

// Land Type Controller
    Route::get('dashboard/land-type','dashboard\LandTypeController@index');
    Route::get('dashboard/land-type/add','dashboard\LandTypeController@create');
    Route::post('dashboard/land-type/add','dashboard\LandTypeController@postCreate');
    Route::get('dashboard/land-type/update/{id}','dashboard\LandTypeController@update');
    Route::post('dashboard/land-type/update','dashboard\LandTypeController@postUpdate');
    Route::get('dashboard/land-type/delete/{id}','dashboard\LandTypeController@delete');

// User CRUD Operations
    Route::get('/dashboard/user','dashboard\UserController@index'); // Read Operation
    Route::get('/dashboard/user/add','dashboard\UserController@create');
    Route::post('/dashboard/user/add','dashboard\UserController@postcreate'); // Save Operation
    Route::get('/dashboard/user/edit/{id}','dashboard\UserController@update');
    Route::post('/dashboard/user/edit','dashboard\UserController@postupdate'); // Update Operation
    Route::get('/dashboard/user/delete/{id}', 'dashboard\UserController@delete'); // Delete Operation
    Route::get('dashboard/viewprofile','dashboard\UserController@viewprofile'); // View Profile
    Route::get('/dashboard/profileupdate','dashboard\UserController@profileupdate'); // User Profile Update
    Route::post('/dashboard/profileupdate','dashboard\UserController@postprofileupdate'); // User Profile Update Save
    Route::get('/dashboard/passwordupdate','dashboard\UserController@passwordupdate'); // Current User password update
    Route::post('/dashboard/passwordupdate','dashboard\UserController@postpasswordupdate'); // Current User password update Save

// profileupdate/1
// End of User CRUD Operations

// UserGroup CRUD Operations
    Route::get('/dashboard/user_group','dashboard\UserGroupController@index'); // Read Operation
    Route::get('/dashboard/user_group/add','dashboard\UserGroupController@create');
    Route::post('/dashboard/user_group/add','dashboard\UserGroupController@postcreate'); // Save Operation
    Route::get('/dashboard/user_group/edit/{id}','dashboard\UserGroupController@update');
    Route::post('/dashboard/user_group/edit','dashboard\UserGroupController@postupdate'); // Update Operation
    Route::get('/dashboard/user_group/policy/{user_group_id}','dashboard\UserGroupController@policy');
    Route::post('/dashboard/user_group/policy','dashboard\UserGroupController@updatepolicy');
//Route::get('/user/dashboard/user_group/delete/{id}', 'dashboard\UserGroupController@delete'); // Delete Operation
// End of UserType CRUD Operations

// MenutType CRUD Operations
    Route::get('/dashboard/menu_type','dashboard\MenuTypeController@index'); // Read Operation
    Route::get('/dashboard/menu_type/add','dashboard\MenuTypeController@create');
    Route::post('/dashboard/menu_type/add','dashboard\MenuTypeController@postcreate'); // Save Operation
    Route::get('/dashboard/menu_type/edit/{id}','dashboard\MenuTypeController@update');
    Route::post('/dashboard/menu_type/edit','dashboard\MenuTypeController@postupdate'); // Update Operation
    Route::get('/dashboard/menu_type/delete/{id}', 'dashboard\MenuTypeController@delete'); // Delete Operation
// End of MenutType CRUD Operations

// Menu CRUD Operations
    Route::get('/dashboard/menu','dashboard\MenuController@index'); // Read Operation
    Route::get('/dashboard/menu/add','dashboard\MenuController@create');
    Route::post('/dashboard/menu/add','dashboard\MenuController@postcreate'); // Save Operation
    Route::get('/dashboard/menu/edit/{id}','dashboard\MenuController@update');
    Route::post('/dashboard/menu/edit','dashboard\MenuController@postupdate'); // Update Operation
    Route::get('/dashboard/menu/delete/{id}', 'dashboard\MenuController@delete'); // Delete Operation
// End of Menu CRUD Operations

// unit CRUD Operations
    Route::get('/dashboard/unit','dashboard\UnitController@index'); // Read Operation
    Route::get('/dashboard/unit/add','dashboard\UnitController@create');
    Route::post('/dashboard/unit/add','dashboard\UnitController@postcreate'); // Save Operation
    Route::get('/dashboard/unit/edit/{id}','dashboard\UnitController@update');
    Route::post('/dashboard/unit/edit','dashboard\UnitController@postupdate'); // Update Operation
    Route::get('/dashboard/unit/delete/{id}', 'dashboard\UnitController@delete'); // Delete Operation
// End of unit CRUD Operations

// energy-year CRUD Operations
    Route::get('/dashboard/energy-year','dashboard\EnergyYearController@index'); // Read Operation
    Route::get('/dashboard/energy-year/add','dashboard\EnergyYearController@create');
    Route::post('/dashboard/energy-year/add','dashboard\EnergyYearController@postcreate'); // Save Operation
    Route::get('/dashboard/energy-year/edit/{id}','dashboard\EnergyYearController@update');
    Route::post('/dashboard/energy-year/edit','dashboard\EnergyYearController@postupdate'); // Update Operation
// End of energy-year CRUD Operations

// river CRUD Operations
    Route::get('/dashboard/river','dashboard\RiverController@index'); // Read Operation
    Route::get('/dashboard/river/add','dashboard\RiverController@create');
    Route::post('/dashboard/river/add','dashboard\RiverController@postcreate'); // Save Operation
    Route::get('/dashboard/river/edit/{id}','dashboard\RiverController@update');
    Route::post('/dashboard/river/edit','dashboard\RiverController@postupdate'); // Update Operation
    Route::get('/dashboard/river/delete/{id}', 'dashboard\RiverController@delete'); // Delete Operation
// End of river CRUD Operations

// river CRUD Operations
    Route::get('/dashboard/records/{record}','dashboard\RecordController@index'); // Read Operation
    Route::get('/dashboard/records/{record}/add','dashboard\RecordController@create');
    Route::post('/dashboard/records/{record}/add','dashboard\RecordController@postcreate'); // Save Operation
    Route::get('/dashboard/records/{record}/edit/{id}','dashboard\RecordController@update');
    Route::post('/dashboard/records/{record}/edit','dashboard\RecordController@postupdate'); // Update Operation
    Route::get('/dashboard/records/{record}/delete/{id}', 'dashboard\RecordController@delete'); // Delete Operation
// End of river CRUD Operations

// production-energy-form CRUD Operations
    Route::get('/dashboard/production-energy-form','dashboard\ProductionEnergyFormController@index'); // Read Operation
//    Route::get('/dashboard/production-energy-form/add','dashboard\ProductionEnergyFormController@create');
//    Route::post('/dashboard/production-energy-form/add','dashboard\ProductionEnergyFormController@postcreate'); // Save Operation
    Route::get('/dashboard/production-energy-form/delete/{id}', 'dashboard\ProductionEnergyFormController@delete'); // Delete Operation
    Route::get('/dashboard/production-energy-form/{route}/{id}','dashboard\ProductionEnergyFormController@update');
    Route::post('/dashboard/production-energy-form/edit','dashboard\ProductionEnergyFormController@postupdate'); // Update Operation

    Route::get('/dashboard/entryform', 'dashboard\EntryFormController@entryFormEnergyTypeListingNew'); // productionEnergyListing

    Route::get('/dashboard/entryform-province', 'dashboard\EntryFormController@entryFormEnergyTypeListingNewProvincial'); // productionEnergyListing

    Route::get('/dashboard/entryform/import', 'dashboard\EntryFormController@entryFormEnergyFormNewImport'); // ImportEnergyListing
    Route::post('/dashboard/entryform/import', 'dashboard\EntryFormController@entryFormEnergyFormNewImportPost'); // ImportEnergyListing

    Route::get('/dashboard/entryform/export', 'dashboard\EntryFormController@entryFormEnergyFormNewExport'); // ExportEnergyListing
    Route::post('/dashboard/entryform/export', 'dashboard\EntryFormController@entryFormEnergyFormNewExportPost'); // ExportEnergyListing

    Route::get('/dashboard/entryform/production', 'dashboard\EntryFormController@entryFormEnergyFormNewProduction'); // ProductionEnergyListing
    Route::post('/dashboard/entryform/production', 'dashboard\EntryFormController@entryFormEnergyFormNewProductionPost'); // ProductionEnergyListing

    Route::get('/dashboard/entryform/consumption', 'dashboard\EntryFormController@entryFormEnergyFormNewConsumption'); // ProductionEnergyListing
    Route::post('/dashboard/entryform/consumption', 'dashboard\EntryFormController@entryFormEnergyFormNewConsumptionPost'); // ProductionEnergyListing

    Route::get('/dashboard/entryform/resources', 'dashboard\EntryFormController@entryFormEnergyFormNewResources'); // ProductionEnergyListing
    Route::post('/dashboard/entryform/resources', 'dashboard\EntryFormController@entryFormEnergyFormNewResourcesPost'); // ProductionEnergyListing

    // For entry form new...


    // For entry form new...provincial....
    Route::get('/dashboard/entryform-province/production', 'dashboard\EntryFormController@entryFormEnergyFormNewProductionProvincial'); // ProductionEnergyListing
    Route::post('/dashboard/entryform-province/production', 'dashboard\EntryFormController@entryFormEnergyFormNewProductionPost'); // ProductionEnergyListing

    Route::get('/dashboard/entryform-province/resources', 'dashboard\EntryFormController@entryFormEnergyFormNewResourcesProvincial'); // ProductionEnergyListing
    Route::post('/dashboard/entryform-province/resources', 'dashboard\EntryFormController@entryFormEnergyFormNewResourcesPost'); // ProductionEnergyListing

    Route::get('/dashboard/entryform-province/import', 'dashboard\EntryFormController@entryFormEnergyFormNewImportProvincial'); // ProductionEnergyListing
    Route::post('/dashboard/entryform-province/import', 'dashboard\EntryFormController@entryFormEnergyFormNewImportPost'); // ProductionEnergyListing

    Route::get('/dashboard/entryform-province/export', 'dashboard\EntryFormController@entryFormEnergyFormNewExportProvincial'); // ProductionEnergyListing
    Route::post('/dashboard/entryform-province/export', 'dashboard\EntryFormController@entryFormEnergyFormNewExportPost'); // ProductionEnergyListing

    Route::get('/dashboard/entryform-province/consumption', 'dashboard\EntryFormController@entryFormEnergyFormNewConsumptionProvincial'); // ProductionEnergyListing
    Route::post('/dashboard/entryform-province/consumption', 'dashboard\EntryFormController@entryFormEnergyFormNewConsumptionPost'); // ProductionEnergyListing
    // For entry form new...provincial....

    // For entry form new...new direct provincial....districtwise

    Route::get('/dashboard/entryform-districtwise', 'dashboard\EntryFormController@entryFormEnergyTypeListingNewDistrictwise'); // productionEnergyListing

    Route::get('/dashboard/entryform-districtwise/production', 'dashboard\EntryFormController@entryFormEnergyFormNewDistrictwiseProduction'); // ProductionEnergyListing
    Route::post('/dashboard/entryform-districtwise/production', 'dashboard\EntryFormController@entryFormEnergyFormNewDistrictwiseProductionPost'); // ProductionEnergyListing


    Route::get('/dashboard/entryform-districtwise/resources', 'dashboard\EntryFormController@entryFormEnergyFormNewDistrictwiseResources'); // ProductionEnergyListing
    Route::post('/dashboard/entryform-districtwise/resources', 'dashboard\EntryFormController@entryFormEnergyFormNewDistrictwiseResourcesPost'); // ProductionEnergyListing


    Route::get('/dashboard/entryform-districtwise/import', 'dashboard\EntryFormController@entryFormEnergyFormNewDistrictwiseImport'); // ProductionEnergyListing
    Route::post('/dashboard/entryform-districtwise/import', 'dashboard\EntryFormController@entryFormEnergyFormNewDistrictwiseImportPost'); // ProductionEnergyListing


    Route::get('/dashboard/entryform-districtwise/export', 'dashboard\EntryFormController@entryFormEnergyFormNewDistrictwiseExport'); // ProductionEnergyListing
    Route::post('/dashboard/entryform-districtwise/export', 'dashboard\EntryFormController@entryFormEnergyFormNewDistrictwiseExportPost'); // ProductionEnergyListing

    Route::get('/dashboard/entryform-districtwise/consumption', 'dashboard\EntryFormController@entryFormEnergyFormNewDistrictwiseConsumption'); // ProductionEnergyListing
    Route::post('/dashboard/entryform-districtwise/consumption', 'dashboard\EntryFormController@entryFormEnergyFormNewDistrictwiseConsumptionPost'); // ProductionEnergyListing

    // For entry form new...new direct provincial....districtwise


    // For Report New Section...

    Route::get('/dashboard/reportnew', 'dashboard\EntryFormController@entryFormEnergyTypeListingNewReport'); // productionEnergyListing

    Route::get('/dashboard/reportnew/production', 'dashboard\EntryFormController@entryFormEnergyReportNewProduction'); // ProductionEnergyListing
    Route::get('/dashboard/reportnew/resources', 'dashboard\EntryFormController@entryFormEnergyReportNewResources'); // ProductionEnergyListing
    Route::get('/dashboard/reportnew/import', 'dashboard\EntryFormController@entryFormEnergyReportNewImport'); // ProductionEnergyListing
    Route::get('/dashboard/reportnew/export', 'dashboard\EntryFormController@entryFormEnergyReportNewExport'); // ProductionEnergyListing
    Route::get('/dashboard/reportnew/consumption', 'dashboard\EntryFormController@entryFormEnergyReportNewConsumption'); // ProductionEnergyListing


    Route::get('/dashboard/entry-form', 'dashboard\EntryFormController@entryFormEnergyYearListing'); // productionEnergyListing
    Route::get('/dashboard/entry-form/direct', 'dashboard\EntryFormController@entryFormEnergyYearListing'); // productionEnergyListing
    Route::get('/dashboard/entry-form/direct/fiscal-year/{start}/{end}', 'dashboard\EntryFormController@entryFormEnergyTypeListing'); // productionEnergyListing
    Route::get('/dashboard/entry-form/direct/fiscal-year/{start}/{end}/{energy_type_slug}', 'dashboard\EntryFormController@entryFormEnergyTypeEnergyListing'); // productionEnergyListing
    Route::get('/dashboard/entry-form/direct/fiscal-year/{start}/{end}/{energy_type_slug}/{energy_slug}', 'dashboard\EntryFormController@entryFormEnergyForm'); // productionEnergyListing

    Route::get('/dashboard/entry-form/province/{province_slug}', 'dashboard\EntryFormController@entryFormDistrictListing'); // productionEnergyListing
    Route::get('/dashboard/entry-form/province/{province_slug}/direct', 'dashboard\EntryFormController@entryFormProvinceEnergyYearListing'); // productionEnergyListing
    Route::get('/dashboard/entry-form/province/{province_slug}/direct/fiscal-year/{start}/{end}', 'dashboard\EntryFormController@entryFormProvinceEnergyTypeListing'); // productionEnergyListing
    Route::get('/dashboard/entry-form/province/{province_slug}/direct/fiscal-year/{start}/{end}/{energy_type_slug}', 'dashboard\EntryFormController@entryFormProvinceEnergyTypeEnergyListing'); // productionEnergyListing
    Route::get('/dashboard/entry-form/province/{province_slug}/direct/fiscal-year/{start}/{end}/{energy_type_slug}/{energy_slug}', 'dashboard\EntryFormController@entryFormProvinceEnergyForm'); // productionEnergyListing

    Route::get('/dashboard/entry-form/province/{province_slug}/district/{district_slug}', 'dashboard\EntryFormController@entryFormLocalListing'); // productionEnergyListing
    Route::get('/dashboard/entry-form/province/{province_slug}/district/{district_slug}/direct', 'dashboard\EntryFormController@entryFormDistrictEnergyYearListing'); // productionEnergyListing
    Route::get('/dashboard/entry-form/province/{province_slug}/district/{district_slug}/direct/fiscal-year/{start}/{end}', 'dashboard\EntryFormController@entryFormDistrictEnergyTypeListing'); // productionEnergyListing
    Route::get('/dashboard/entry-form/province/{province_slug}/district/{district_slug}/direct/fiscal-year/{start}/{end}/{energy_type_slug}', 'dashboard\EntryFormController@entryFormDistrictEnergyTypeEnergyListing'); // productionEnergyListing
    Route::get('/dashboard/entry-form/province/{province_slug}/district/{district_slug}/direct/fiscal-year/{start}/{end}/{energy_type_slug}/{energy_slug}', 'dashboard\EntryFormController@entryFormDistrictEnergyForm'); // productionEnergyListing

    Route::get('/dashboard/entry-form/province/{province_slug}/district/{district_slug}/local/{local_slug}/', 'dashboard\EntryFormController@entryFormLocalEnergyYearListing'); // productionEnergyListing
    Route::get('/dashboard/entry-form/province/{province_slug}/district/{district_slug}/local/{local_slug}/fiscal-year/{start}/{end}', 'dashboard\EntryFormController@entryFormLocalEnergyTypeListing'); // productionEnergyListing
    Route::get('/dashboard/entry-form/province/{province_slug}/district/{district_slug}/local/{local_slug}/fiscal-year/{start}/{end}/{energy_type_slug}', 'dashboard\EntryFormController@entryFormLocalEnergyTypeEnergyListing'); // productionEnergyListing
    Route::get('/dashboard/entry-form/province/{province_slug}/district/{district_slug}/local/{local_slug}/fiscal-year/{start}/{end}/{energy_type_slug}/{energy_slug}', 'dashboard\EntryFormController@entryFormLocalEnergyForm'); // productionEnergyListing

//    dashboard/entry-form/production/add

    Route::post('/dashboard/entry-form/add','dashboard\EntryFormController@postcreate'); // Save Operation
    Route::post('/dashboard/entry-form/production/add','dashboard\ProductionEnergyFormController@postcreate'); // Save Operation
    Route::post('/dashboard/entry-form/resources/add','dashboard\ResourcesEnergyFormController@postcreate'); // Save Operation
    Route::post('/dashboard/entry-form/consumption/add','dashboard\ConsumptionEnergyFormController@postcreate'); // Save Operation
    Route::post('/dashboard/entry-form/import/add','dashboard\ImportEnergyFormController@postcreate'); // Save Operation
    Route::post('/dashboard/entry-form/export/add','dashboard\ExportEnergyFormController@postcreate'); // Save Operation

    Route::post('/dashboard/entry-form/production/edit','dashboard\ProductionEnergyFormController@postupdate'); // Save Operation
    Route::post('/dashboard/entry-form/resources/edit','dashboard\ResourcesEnergyFormController@postupdate'); // Save Operation
    Route::post('/dashboard/entry-form/consumption/edit','dashboard\ConsumptionEnergyFormController@postupdate'); // Save Operation
    Route::post('/dashboard/entry-form/import/edit','dashboard\ImportEnergyFormController@postupdate'); // Save Operation
    Route::post('/dashboard/entry-form/export/edit','dashboard\ExportEnergyFormController@postupdate'); // Save Operation
//

//    http://localhost/mukesh_sir/wecs/dashboard/entry-form/province/province-1

    Route::get('/dashboard/entry-form/direct/{start}/{end}', 'dashboard\EntryFormController@entryFormEnergyTypeListing'); // productionEnergyListing
    Route::get('/dashboard/entry-form/{from}/{to}/{energy_type_slug}', 'dashboard\EntryFormController@entryFormEnergyTypeEnergyListing'); // productionEnergyListing
    Route::get('/dashboard/entry-form/production/energy/{energy_slug}', 'dashboard\ProductionEnergyFormController@entryFormEnergyForm'); // productionEnergyForm
//    dashboard/entry-form/consumption/energy/fuelwood
// End of production-energy-form CRUD Operations

// resources-energy-form CRUD Operations
    Route::get('/dashboard/resources-energy-form','dashboard\ResourcesEnergyFormController@index'); // Read Operation
//    Route::get('/dashboard/resources-energy-form/add','dashboard\ResourcesEnergyFormController@create');
//    Route::post('/dashboard/resources-energy-form/add','dashboard\ResourcesEnergyFormController@postcreate'); // Save Operation
    Route::get('/dashboard/resources-energy-form/{route}/{id}','dashboard\ResourcesEnergyFormController@update');
    Route::post('/dashboard/resources-energy-form/edit','dashboard\ResourcesEnergyFormController@postupdate'); // Update Operation
    Route::get('/dashboard/resources-energy-form/delete/{id}', 'dashboard\ResourcesEnergyFormController@delete'); // Delete Operation
// End of resources-energy-form CRUD Operations

// consumption-energy-form CRUD Operations
    Route::get('/dashboard/consumption-energy-form','dashboard\ConsumptionEnergyFormController@index'); // Read Operation
//    Route::get('/dashboard/consumption-energy-form/add','dashboard\ConsumptionEnergyFormController@create');
//    Route::post('/dashboard/consumption-energy-form/add','dashboard\ConsumptionEnergyFormController@postcreate'); // Save Operation
    Route::get('/dashboard/consumption-energy-form/{route}/{id}','dashboard\ConsumptionEnergyFormController@update');
    Route::post('/dashboard/consumption-energy-form/edit','dashboard\ConsumptionEnergyFormController@postupdate'); // Update Operation
    Route::get('/dashboard/consumption-energy-form/delete/{id}', 'dashboard\ConsumptionEnergyFormController@delete'); // Delete Operation
// End of consumption-energy-form CRUD Operations

// import-energy-form CRUD Operations
    Route::get('/dashboard/import-energy-form','dashboard\ImportEnergyFormController@index'); // Read Operation
//    Route::get('/dashboard/import-energy-form/add','dashboard\ImportEnergyFormController@create');
//    Route::post('/dashboard/import-energy-form/add','dashboard\ImportEnergyFormController@postcreate'); // Save Operation
    Route::get('/dashboard/import-energy-form/{route}/{id}','dashboard\ImportEnergyFormController@update');
    Route::post('/dashboard/import-energy-form/edit','dashboard\ImportEnergyFormController@postupdate'); // Update Operation
    Route::get('/dashboard/import-energy-form/delete/{id}', 'dashboard\ImportEnergyFormController@delete'); // Delete Operation
// End of import-energy-form CRUD Operations

// export-energy-form CRUD Operations
    Route::get('/dashboard/export-energy-form','dashboard\ExportEnergyFormController@index'); // Read Operation
//    Route::get('/dashboard/export-energy-form/add','dashboard\ExportEnergyFormController@create');
//    Route::post('/dashboard/export-energy-form/add','dashboard\ExportEnergyFormController@postcreate'); // Save Operation
    Route::get('/dashboard/export-energy-form/{route}/{id}','dashboard\ExportEnergyFormController@update');
    Route::post('/dashboard/export-energy-form/edit','dashboard\ExportEnergyFormController@postupdate'); // Update Operation
    Route::get('/dashboard/export-energy-form/delete/{id}', 'dashboard\ExportEnergyFormController@delete'); // Delete Operation

// End of export-energy-form CRUD Operations

    Route::get('/dashboard/report','dashboard\EntryFormController@reportEnergyYear'); // Read Operation

    Route::get('/dashboard/report/fiscal-year/{start}/{end}','dashboard\EntryFormController@reportProvinceListing'); // Read Operation

    Route::get('/dashboard/report/fiscal-year/{start}/{end}/energy-supply-demand-balance', 'dashboard\EntryFormController@reportEnergySupplyDemandBalance'); // productionEnergyListing

    Route::get('/dashboard/report/fiscal-year/{start}/{end}/direct','dashboard\EntryFormController@reportEnergyTypeListing'); // Read Operation

    Route::get('/dashboard/report/fiscal-year/{start}/{end}/province/{province_slug}','dashboard\EntryFormController@reportEnergyTypeListing'); // Read Operation

    Route::get('/dashboard/report/fiscal-year/{start}/{end}/direct/{energy_type_slug}', 'dashboard\EntryFormController@reportEnergyTypeEnergyTopicListing');

    Route::get('/dashboard/report/fiscal-year/{start}/{end}/province/{province_slug}/{energy_type_slug}', 'dashboard\EntryFormController@reportProvinceWiseEnergyTypeEnergyTopicListing');

    Route::get('/dashboard/report/fiscal-year/{start}/{end}/direct/{energy_type_slug}/energy-topic/{energy_topic}/tabular', 'dashboard\EntryFormController@reportEnergyVersesEnergyTypeTabular'); // productionEnergyListing

    Route::get('/dashboard/report/fiscal-year/{start}/{end}/province/{province_slug}/{energy_type_slug}/energy-topic/{energy_topic}/tabular', 'dashboard\EntryFormController@reportProvinceWiseEnergyVersesEnergyTypeTabular'); // productionEnergyListing

    Route::get('/dashboard/report/fiscal-year/{start}/{end}/production/energy-topic/{energy_topic}/direct', 'dashboard\EntryFormController@reportCentralProductionEnergyTopicPie'); // productionEnergyListing

    Route::get('/dashboard/report/fiscal-year/{start}/{end}/consumption/energy-topic/{energy_topic}/direct', 'dashboard\EntryFormController@reportCentralConsumptionEnergyTopicPie'); // productionEnergyListing

    Route::get('/dashboard/report/fiscal-year/{start}/{end}/province/{province_slug}/consumption/energy-topic/{energy_topic}/direct', 'dashboard\EntryFormController@reportProvinceWiseConsumptionEnergyTopicPie'); // productionEnergyListing

    Route::get('/dashboard/report/fiscal-year/{start}/{end}/province/{province_slug}/consumption/energy-topic/{energy_topic}/fueltype', 'dashboard\EntryFormController@reportProvinceWiseConsumptionEnergyTopicFuelTypePie'); // productionEnergyListing

    Route::get('/dashboard/report/fiscal-year/{start}/{end}/province/{province_slug}/consumption/energy-topic/{energy_topic}/energy', 'dashboard\EntryFormController@reportProvinceWiseConsumptionEnergyTopicEnergyPie'); // productionEnergyListing

    Route::get('/dashboard/report/fiscal-year/{start}/{end}/resources/energy-topic/{energy_topic}/direct', 'dashboard\EntryFormController@reportCentralResourcesEnergyTopicPie'); // productionEnergyListing

    Route::get('/dashboard/report/fiscal-year/{start}/{end}/import/energy-topic/{energy_topic}/direct', 'dashboard\EntryFormController@reportCentralImportEnergyTopicPie'); // productionEnergyListing

    Route::get('/dashboard/report/fiscal-year/{start}/{end}/export/energy-topic/{energy_topic}/direct', 'dashboard\EntryFormController@reportCentralExportEnergyTopicPie'); // productionEnergyListing

    Route::get('/dashboard/report/fiscal-year/{start}/{end}/production/energy-topic/{energy_topic}', 'dashboard\EntryFormController@reportCentralProductionEnergyTopic'); // productionEnergyListing

    Route::get('/dashboard/report/fiscal-year/{start}/{end}/consumption/energy-topic/{energy_topic}', 'dashboard\EntryFormController@reportCentralConsumptionEnergyTopic'); // productionEnergyListing

    Route::get('/dashboard/report/fiscal-year/{start}/{end}/province/{province_slug}/consumption/energy-topic/{energy_topic}', 'dashboard\EntryFormController@reportProvinceWiseConsumptionEnergyTopic'); // productionEnergyListing

    Route::get('/dashboard/report/fiscal-year/{start}/{end}/resources/energy-topic/{energy_topic}', 'dashboard\EntryFormController@reportCentralResourcesEnergyTopic'); // productionEnergyListing

    Route::get('/dashboard/report/fiscal-year/{start}/{end}/import/energy-topic/{energy_topic}', 'dashboard\EntryFormController@reportCentralImportEnergyTopic'); // productionEnergyListing

    Route::get('/dashboard/report/fiscal-year/{start}/{end}/export/energy-topic/{energy_topic}', 'dashboard\EntryFormController@reportCentralExportEnergyTopic'); // productionEnergyListing

    Route::get('/dashboard/report/trend/{start}/{end}','dashboard\EntryFormController@reportEnergyTypeListing'); // Read Operation

    Route::get('/dashboard/report/trend/{start}/{end}/{energy_type_slug}', 'dashboard\EntryFormController@reportEnergyTypeEnergyTopicListing'); // productionEnergyListing

    Route::get('/dashboard/report/trend/{start}/{end}/{energy_type_slug}/direct', 'dashboard\EntryFormController@reportCentralEnergyTypeEnergyTrend'); // productionEnergyListing

    Route::get('/dashboard/report/trend/{start}/{end}/production/energy-topic/{energy_topic}/direct', 'dashboard\EntryFormController@reportCentralProductionEnergyTopicTrend'); // productionEnergyListing

    Route::get('/dashboard/report/trend/{start}/{end}/consumption/energy-topic/{energy_topic}/direct', 'dashboard\EntryFormController@reportCentralConsumptionEnergyTopicTrend'); // productionEnergyListing

    Route::get('/dashboard/report/trend/{start}/{end}/resources/energy-topic/{energy_topic}/direct', 'dashboard\EntryFormController@reportCentralResourcesEnergyTopicTrend'); // productionEnergyListing

    Route::get('/dashboard/report/trend/{start}/{end}/import/energy-topic/{energy_topic}/direct', 'dashboard\EntryFormController@reportCentralImportEnergyTopicTrend'); // productionEnergyListing

    Route::get('/dashboard/report/trend/{start}/{end}/export/energy-topic/{energy_topic}/direct', 'dashboard\EntryFormController@reportCentralExportEnergyTopicTrend'); // productionEnergyListing

    // http://localhost/mukesh_sir/wecs/dashboard/report/fiscal-year/1995/2001/consumption/energy-topic/sector/trend
//    Route::get('/dashboard/report/fiscal-year/{start}/{end}/{energy_type_slug}/energy-topic/geographic_region/direct', 'dashboard\EntryFormController@reportEnergyTypeGeographicRegion'); // productionEnergyListing

//    Route::get('/dashboard/report/fiscal-year/{start}/{end}/production/energy-topic/{energy_topic}/direct', 'dashboard\EntryFormController@reportCentralProductionEnergyTopic'); // productionEnergyListing
//    Route::get('/dashboard/report/fiscal-year/{start}/{end}/consumption/energy-topic/{energy_topic}/direct', 'dashboard\EntryFormController@reportCentralProductionEnergyTopic'); // productionEnergyListing

    // /dashboard/report/fiscal-year/2017/2018/production/energy-topic/geographic_region

});



//Route::get('/report/fiscal-year/{start}/{end}','frontend\FrontendController@reportEnergyTypeListing'); // Read Operation

Route::post('/report', 'frontend\FrontendController@searchFilter');

Route::get('/page/{page_slug}', 'frontend\FrontendController@viewPage');

Route::get('/report', 'frontend\FrontendController@reportCentralConsumptionEnergyTopicPie');

Route::get('/report/energy-supply-demand-balance', 'frontend\FrontendController@reportEnergySupplyDemandBalance'); // productionEnergyListing
Route::get('/report/energy-supply-demand-balance/{start}/{end}', 'frontend\FrontendController@reportEnergySupplyDemandBalance'); // productionEnergyListing

Route::get('/report/consumption', 'frontend\FrontendController@reportCentralConsumptionEnergyTopicPie');
Route::get('/report/consumption/{energy_topic}', 'frontend\FrontendController@reportCentralConsumptionEnergyTopicPie');
Route::get('/report/consumption/direct/{start}/{end}', 'frontend\FrontendController@reportCentralConsumptionEnergyTopicPie'); // Pie Chart
Route::get('/report/consumption/{energy_topic}/direct/{start}/{end}', 'frontend\FrontendController@reportCentralConsumptionEnergyTopicPie'); // Pie Chart

Route::get('/report/production', 'frontend\FrontendController@reportCentralProductionEnergyTopicPie');
Route::get('/report/production/{energy_topic}', 'frontend\FrontendController@reportCentralProductionEnergyTopicPie');
Route::get('/report/production/direct/{start}/{end}', 'frontend\FrontendController@reportCentralProductionEnergyTopicPie');
Route::get('/report/production/{energy_topic}/direct/{start}/{end}', 'frontend\FrontendController@reportCentralProductionEnergyTopicPie');

Route::get('/report/resources', 'frontend\FrontendController@reportCentralResourcesEnergyTopicPie');
Route::get('/report/resources/{energy_topic}', 'frontend\FrontendController@reportCentralResourcesEnergyTopicPie');
Route::get('/report/resources/direct/{start}/{end}', 'frontend\FrontendController@reportCentralResourcesEnergyTopicPie'); // productionEnergyListing
Route::get('/report/resources/{energy_topic}/direct/{start}/{end}', 'frontend\FrontendController@reportCentralResourcesEnergyTopicPie'); // productionEnergyListing

Route::get('/report/import', 'frontend\FrontendController@reportCentralImportEnergyTopicPie'); // productionEnergyListing
Route::get('/report/import/{energy_topic}', 'frontend\FrontendController@reportCentralImportEnergyTopicPie'); // productionEnergyListing
Route::get('/report/import/direct/{start}/{end}', 'frontend\FrontendController@reportCentralImportEnergyTopicPie'); // productionEnergyListing
Route::get('/report/import/{energy_topic}/direct/{start}/{end}', 'frontend\FrontendController@reportCentralImportEnergyTopicPie'); // productionEnergyListing

Route::get('/report/export', 'frontend\FrontendController@reportCentralExportEnergyTopicPie');
Route::get('/report/export/{energy_topic}', 'frontend\FrontendController@reportCentralExportEnergyTopicPie');
Route::get('/report/export/direct/{start}/{end}', 'frontend\FrontendController@reportCentralExportEnergyTopicPie');
Route::get('/report/export/{energy_topic}/direct/{start}/{end}', 'frontend\FrontendController@reportCentralExportEnergyTopicPie');

Route::get('/report/{energy_type_slug}/{energy_topic}/tabular', 'frontend\FrontendController@reportEnergyVersesEnergyTypeTabular'); // Bar Diagram
Route::get('/report/{energy_type_slug}/tabular/{start}/{end}', 'frontend\FrontendController@reportEnergyVersesEnergyTypeDirectTabular'); // productionEnergyListing
Route::get('/report/{energy_type_slug}/{energy_topic}/tabular/{start}/{end}', 'frontend\FrontendController@reportEnergyVersesEnergyTypeTabular'); // productionEnergyListing

Route::get('/report/production/{energy_topic}/trend/{start}/{end}', 'frontend\FrontendController@reportCentralProductionEnergyTopicTrend'); // Line Graph
Route::get('/report/consumption/{energy_topic}/trend/{start}/{end}', 'frontend\FrontendController@reportCentralConsumptionEnergyTopicTrend'); // productionEnergyListing
Route::get('/report/resources/{energy_topic}/trend/{start}/{end}', 'frontend\FrontendController@reportCentralResourcesEnergyTopicTrend'); // productionEnergyListing
Route::get('/report/import/{energy_topic}/trend/{start}/{end}', 'frontend\FrontendController@reportCentralImportEnergyTopicTrend'); // productionEnergyListing
Route::get('/report/export/{energy_topic}/trend/{start}/{end}', 'frontend\FrontendController@reportCentralExportEnergyTopicTrend'); // productionEnergyListing

Route::get('/report/{energy_type_slug}/trend/{start}/{end}', 'frontend\FrontendController@reportCentralEnergyTypeEnergyTrend'); // productionEnergyListing

Route::get('/report/production/{energy_topic}/provincewise/{start}/{end}', 'frontend\FrontendController@reportCentralProductionEnergyTopicProvince');
Route::get('/report/consumption/{energy_topic}/provincewise/{start}/{end}', 'frontend\FrontendController@reportCentralConsumptionEnergyTopicProvince');
Route::get('/report/resources/{energy_topic}/provincewise/{start}/{end}', 'frontend\FrontendController@reportCentralResourcesEnergyTopicProvince');
Route::get('/report/import/{energy_topic}/provincewise/{start}/{end}', 'frontend\FrontendController@reportCentralImportEnergyTopicProvince');
Route::get('/report/export/{energy_topic}/provincewise/{start}/{end}', 'frontend\FrontendController@reportCentralExportEnergyTopicProvince');

Route::get('/report/consumption/{energy_topic}/direct/{start}/{end}/{energy_topic_name}', 'frontend\FrontendController@reportCentralConsumptionEnergyTopicWithEnergy');
Route::get('/report/production/{energy_topic}/direct/{start}/{end}/{energy_topic_name}', 'frontend\FrontendController@reportCentralProductionEnergyTopicWithEnergy');
Route::get('/report/resources/{energy_topic}/direct/{start}/{end}/{energy_topic_name}', 'frontend\FrontendController@reportCentralResourcesEnergyTopicWithEnergy');
Route::get('/report/import/{energy_topic}/direct/{start}/{end}/{energy_topic_name}', 'frontend\FrontendController@reportCentralImportEnergyTopicWithEnergy');
Route::get('/report/export/{energy_topic}/direct/{start}/{end}/{energy_topic_name}', 'frontend\FrontendController@reportCentralExportEnergyTopicWithEnergy');
//Route::get('/report/export/{energy_topic}/direct/{start}/{end}', 'frontend\FrontendController@reportCentralExportEnergyTopicPie');

//Route::get('/home', 'HomeController@index')->name('home');

Route::get('/energy-conversion', 'frontend\FrontendController@energyConversion');

Route::get('/sdg-7', 'frontend\FrontendController@sdgPage');

Route::get('/power-plant-storage', 'frontend\FrontendController@recordList');
Route::get('/power-plant-storage/{record}', 'frontend\FrontendController@recordView');

Route::get('/report/province/{province_slug}', 'frontend\FrontendController@provincewisereport');

Route::get('records', function () {
    return redirect('power-plant-storage');
});

// New Report ...

Route::get('/report/central-consumption-by-energy-topic', 'frontend\ReportController@reportCentralConsumptionEnergyTopic'); // productionEnergyListing
Route::get('/report/province-consumption-energy-by-energy-topic', 'frontend\ReportController@reportProvinceWiseEnergyVersesEnergyTypeTabular');
Route::get('/report/province-consumption-energy-by-energy-topic-overall', 'frontend\ReportController@reportProvinceWiseConsumptionEnergyTopicPie'); // productionEnergyListing

Route::get('/report/province-consumption-fueltype-by-energy-topic', 'frontend\ReportController@reportProvinceWiseConsumptionEnergyTopicFuelTypePie');

Route::get('/report/province-consumption-energy-topic-by-energy-pie', 'frontend\ReportController@reportProvinceWiseConsumptionEnergyTopicEnergyPie');

Route::get('/report/province-districtwise-consumption-by-energy-topic', 'frontend\ReportController@reportProvinceWiseConsumptionEnergyTopic');

//Route::get('/report/province-consumption-energy-topic-individual-pie', 'frontend\ReportController@reportProvinceWiseConsumptionEnergyTopicIndividualLine');

Route::get('/report/province-consumption-energy-topic-individual-pie', function () {
    return redirect('/report/province-districtwise-consumption-by-energy-topic');
});

Route::get('/report/consumption-energy-topic-trend', 'frontend\ReportController@reportCentralConsumptionEnergyTopicTrend');

Route::get('/report/consumption-energy-topic-energy-trend', 'frontend\ReportController@reportCentralConsumptionEnergyTopicEnergyTrend');

Route::get('/report/consumption-energy-topic-energy-line-graph', 'frontend\ReportController@reportCentralConsumptionEnergyTopicEnergyTrendLineGraph');

Route::get('/report/consumption-energy-topic-energy-total-trend', 'frontend\ReportController@reportCentralConsumptionEnergyTopicEnergyTotalTrend');

Route::get('/report/energy-consumption-share-by-fueltypes', 'frontend\FrontendController@reportCentralConsumptionEnergyByFuelTypesPie');

Route::get('/report/energy-consumption-share-by-sectors', 'frontend\FrontendController@reportCentralConsumptionEnergyBySectorsPie');

Route::get('/report/energy-consumption-by-sectors', 'frontend\FrontendController@reportCentralConsumptionEnergyBySectors');

Route::get('/report/energy-consumption-by-trend-bar-graph', 'frontend\FrontendController@reportCentralConsumptionEnergyByBarGraph');

//Route::get('/report/energy-consumption-by-fueltypes', 'frontend\FrontendController@reportCentralConsumptionEnergyByFueltypes');

Route::get('/report/federal/energy-consumption-share-by-fueltypes', 'frontend\FrontendController@reportFederalCentralConsumptionEnergyByFuelTypesPie');



Route::get('/clear-cache-all', function() {

    \Illuminate\Support\Facades\Artisan::call('cache:clear');
    \Illuminate\Support\Facades\Artisan::call('config:clear');
    \Illuminate\Support\Facades\Artisan::call('config:cache');
    \Illuminate\Support\Facades\Artisan::call('view:clear');

    return "Cleared!";

});