

<!--site footer-->
<footer class="footer-preset-03">
    <div class="container-fluid">
        <div class="footer-preset-wrapper">
            <div class="row">
                <div class="col-lg-5 col-md-4 col-sm-6 col-xs-12">
                    <div class="footer-quote-02">
                        <div class="footer-quote"><h5>National Energy Information System</h5><!--a href="index.php"><img src="assets/images/pda.png" alt="PDA"http://a-->
                            <div class="content">
                                <?php
                                $getFooterLinks = \App\Menu::getFooterLinks('footer-text');
                                ?>

                                <?php if(!empty($getFooterLinks->page_desc)): ?>
                                    <p>
                                        <?php echo strip_tags($getFooterLinks->page_desc); ?>

                                    </p>
                                <?php endif; ?>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <h5>USEFUL LINKS</h5>
                    <div class="links">
                        <?php
                        $getFooterLinks1 = \App\Menu::getFooterLinks('footer-links');
                        ?>

                        <?php if(!empty($getFooterLinks1->page_desc)): ?>

                            <?php echo $getFooterLinks1->page_desc; ?>


                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-offset-0 col-lg-3 col-md-4 col-sm-offset-3 col-sm-6 col-xs-12">
                    <h5>CONTACT US</h5>
                    <div class="contacts-info">
                        <address>
                            <i class="add-icon">&nbsp;</i>Singha Durbar, Kathmandu,<br>
                            &nbsp;Nepal
                        </address>
                        <div class="phone-footer"><i class="phone-icon">&nbsp;</i>+977 1 4211415, 4211417</div>
                        <div class="phone-footer"><i class="fax-icon">&nbsp;</i>+977 1 4211425</div>
                        <div class="email-footer"><i class="email-icon">&nbsp;</i>info@wecs.gov.np</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-foot text-center">
            <p>© Water and Energy Commission Secretariat. All Rights Reserved. Powered by: <a href="http://multitechnepal.com.np" target="_blank">MultiTechNepal</a></p>
        </div>
    </div>
</footer>
