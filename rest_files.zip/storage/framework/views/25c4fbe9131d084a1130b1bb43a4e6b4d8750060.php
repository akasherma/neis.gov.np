<?php $__env->startSection('content'); ?>
    <div class="content-body"><section class="flexbox-container">
            <div class="col-12 d-flex align-items-center justify-content-center">
                <div class="col-md-4 col-10 box-shadow-2 p-0">
                    <div class="card border-grey border-lighten-3 px-1 py-1 m-0">
                        <div class="card-header border-0">
                            <div class="font-large-1  text-center">
                                Sign Up
                            </div>
                        </div>
                        <div class="card-content">

                            <div class="card-body">

                    <form method="POST" class="form-horizontal" action="<?php echo e(route('register')); ?>" aria-label="<?php echo e(__('Register')); ?>">
                        <?php echo csrf_field(); ?>

                        <label for="name" class="col-form-label text-md-right"><?php echo e(__('Full Name')); ?></label>

                        <fieldset class="form-group position-relative has-icon-left">

                            <input id="name" type="text" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?> round" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

                            <?php if($errors->has('name')): ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                    </span>
                            <?php endif; ?>

                            <div class="form-control-position">
                                <i class="ft-user"></i>
                            </div>
                        </fieldset>

                        <label for="email" class="col-form-label text-md-right"><?php echo e(__('Email Address')); ?></label>

                        <fieldset class="form-group position-relative has-icon-left">

                            <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>

                            <?php if($errors->has('email')): ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                            <?php endif; ?>
                            <div class="form-control-position">
                                <i class="ft-mail"></i>
                            </div>
                        </fieldset>

                        <label for="password" class="col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

                        <fieldset class="form-group position-relative has-icon-left">


                            <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                            <?php if($errors->has('password')): ?>
                                <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                            <?php endif; ?>

                            <div class="form-control-position">
                                <i class="ft-lock"></i>
                            </div>
                        </fieldset>

                        <label for="password" class="col-form-label text-md-right"><?php echo e(__('Confirm Password')); ?></label>

                        <fieldset class="form-group position-relative has-icon-left">

                            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>

                            <div class="form-control-position">
                                <i class="ft-lock"></i>
                            </div>
                        </fieldset>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Register')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                            </div>

                            <p class="card-subtitle text-muted text-right font-small-3 mx-2 my-1">
                        <span>Already a member ?
                            <a href="<?php echo e(url('/')); ?>/login" class="card-link">Sign In</a>
                        </span>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>