<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="author" content="">
    <title>National Energy Information System :: Government of Nepal</title>
    <link rel="apple-touch-icon" href="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/images/ico/apple-icon-120.png">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/images/ico/favicon.ico">
    <link href="https://fonts.googleapis.com/css?family=Muli:400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="https://maxcdn.icons8.com/fonts/line-awesome/1.1/css/line-awesome-font-awesome.min.css" rel="stylesheet">
    <!-- BEGIN VENDOR CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/css/vendors.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/vendors/css/forms/toggle/switchery.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/css/plugins/forms/switch.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/css/core/colors/palette-switch.min.css">
    <!-- END VENDOR CSS-->
    <!-- BEGIN CHAMELEON  CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/css/app.min.css">
    <!-- END CHAMELEON  CSS-->
    <!-- BEGIN Page Level CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/resources/assets/ppentry/pp-assets/css/core/menu/menu-types/vertical-menu.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/css/core/colors/palette-gradient.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/css/pages/login-register.min.css">
    <!-- END Page Level CSS-->
    <!-- BEGIN Custom CSS-->
    <link rel="stylesheet" type="text/css" href="../../../assets/css/style.css">
    <!-- END Custom CSS-->
</head>
<body class="vertical-layout vertical-menu 1-column  bg-full-screen-image menu-expanded blank-page blank-page" data-open="click" data-menu="vertical-menu" data-color="bg-gradient-x-purple-blue" data-col="1-column">
<!-- ////////////////////////////////////////////////////////////////////////////-->
<div class="app-content content">
    <div class="content-wrapper">
        <div class="content-wrapper-before"></div>
        <div class="content-header row">
        </div>

        <?php echo $__env->yieldContent('content'); ?>

    </div>
</div>
<!-- ////////////////////////////////////////////////////////////////////////////-->

<!-- BEGIN VENDOR JS-->
<script src="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/vendors/js/vendors.min.js" type="text/javascript"></script>
<script src="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/vendors/js/forms/toggle/switchery.min.js" type="text/javascript"></script>
<script src="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/js/scripts/forms/switch.min.js" type="text/javascript"></script>
<!-- BEGIN VENDOR JS-->
<!-- BEGIN PAGE VENDOR JS-->
<script src="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/vendors/js/forms/validation/jqBootstrapValidation.js" type="text/javascript"></script>
<!-- END PAGE VENDOR JS-->
<!-- BEGIN CHAMELEON  JS-->
<script src="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/js/core/app-menu.min.js" type="text/javascript"></script>
<script src="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/js/core/app.min.js" type="text/javascript"></script>
<!-- END CHAMELEON  JS-->
<!-- BEGIN PAGE LEVEL JS-->
<script src="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/js/scripts/forms/form-login-register.min.js" type="text/javascript"></script>
<!-- END PAGE LEVEL JS-->
</body>
</html>



    
    
    

    
    

    

    
    

    
    
    

    
    


    
        
            
                
                    
                
                
                    
                

                
                    
                    

                    

                    
                    
                        
                        
                            
                                
                            
                            
                                
                            
                        
                            
                                
                                    
                                

                                
                                    
                                       
                                                     
                                        
                                    

                                    
                                        
                                    
                                
                            
                        
                    
                
            
        

        
            
        
    


