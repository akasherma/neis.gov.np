
<?php $__env->startSection('content'); ?>
<section id="horizontal-form-layouts">
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-md-9">

                        <h2 class="card-title" id="horz-layout-colored-controls">
                            National Energy Consumption Scenario
                        </h2>

                    </div>
                    


                        
                            
                                
                                


                                    
                                        
                                            
                                                
                                                
                                                
                                            
                                        
                                    

                                    
                                        
                                            
                                        
                                    
                                    
                                
                            
                        
                    
                </div>
            </div>

                <?php
                $province_name_final = (!empty($province_name->location_name))?$province_name->location_name:'';
                $district_name_final = (!empty($district_name->location_name))?$district_name->location_name:'';

                $province_name_final = ($district_name_final != '')?'':$province_name_final;
                ?>
            <?php
            $readonly = 'readonly';
            $disabled = 'disabled';
            ?>
            <div class="card-content collpase show">
                <div class="card-body">

                    <?php if(!empty($start) && $start != date('Y')): ?>

                        

                        <section id="horizontal-form-layouts">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card">
                                        <div class="card-header">
                                            <input type="hidden" id="this_name" value="Total Energy">
                                            <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                                            <div class="heading-elements">
                                                <ul class="list-inline mb-0">
                                                    <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                                    <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <?php
                                        $permalink = $url;
                                        ?>
                                        <div class="card-content collpase show">
                                            <div class="card-body row">
                                                <div class="col-md-12 form-body-listing">
                                                    <div style=" border: 2px solid #333; padding: 0; ">
                                                        <h4 class="card-title text-center" id="this_title" style="display:none;">National Energy <?php echo e($this_energy_type->energy_type_name); ?> By Fuel Types (<?php echo e($start); ?>)</h4>

                                                        <div id="container" style="height:650px;"></div>
                                                        <span id="total"></span>
                                                    </div>
                                                    
                                                    <div class="table-responsive">
                                                        <table class="table table-hover table-bordered">
                                                            <tr class="info">
                                                                <th colspan="2">Fuel Types</th>
                                                                <th>Total (PJ)</th>
                                                                <th>Total (In 000,ToE)</th>
                                                                <th>Total (In 000000,MWh)</th>
                                                            </tr>

                                                            <?php
                                                            $col = array();
                                                            $col_total_init = 0;
                                                            $count = 1;
                                                            $row_class= '';
                                                            $row_key= '';
                                                            $counter = 0;
                                                            $color_arr = array('table-primary', 'table-success', 'table-info', 'table-warning');
                                                            $total = 0;
                                                            $col_count = 0;

                                                            if(!empty($final_result)){
                                                            foreach($final_result as $key=>$value){

                                                                $this_key = (!empty($key))?explode('-', $key):array();

                                                                $this_first_key = (is_array($this_key) && (!empty($this_key[0])))?$this_key[0]:'';

//                                                                $col_count = 0;

                                                                $counter += ($this_first_key != $row_key)?1:0;

                                                                $counter = ($counter < count($color_arr))?$counter:0;

                                                                $row_class = (!empty($color_arr[$counter]))?$color_arr[$counter]:'';

                                                                $this_no = (((float)$value)/1000000);

                                                                $col[$col_count] = (!empty($col[$col_count]))?((float)$col[$col_count]):0;
                                                                $this_value = (((float)$value)/1000000);


                                                                $this_no = (((float)$value)/1000000);

//                                                                $col[$col_count] = (!empty($col[$col_count]))?((float)$col[$col_count]):0;
//                                                                $this_value = (((float)$value)/1000000);

                                                            if($this_value > 0){
                                                            ?>

                                                            <?php if($this_first_key != $row_key): ?>

                                                            <tr class="warning">

                                                                <th colspan="5">
                                                                    <?php echo ($this_first_key != $row_key)?$this_first_key:''; ?>
                                                                    <?php
                                                                    $row_key = ($this_first_key != $row_key)?$this_first_key:$row_key;
                                                                    $second_term = (is_array($this_key) && (!empty($this_key[1])))?ucwords(str_replace('_', ' ', $this_key[1])):'';
                                                                    $third_term = (is_array($this_key) && (!empty($this_key[2])))?ucwords(str_replace('_', ' ', $this_key[2])):'';
                                                                    ?>
                                                                </th>

                                                            </tr>

                                                            <?php endif; ?>

                                                            <tr class="top_row">
                                                                <th class="text-center">
                                                                    <?php echo $count; ?>
                                                                    <?php
                                                                    $row_key = ($this_first_key != $row_key)?$this_first_key:$row_key;
                                                                    $second_term = (is_array($this_key) && (!empty($this_key[1])))?ucwords(str_replace('_', ' ', $this_key[1])):'';

                                                                    $third_term = (is_array($this_key) && (!empty($this_key[2])))?ucwords(str_replace('_', ' ', $this_key[2])):'';

                                                                    ?>
                                                                </th>
                                                                <th>
                                                                    <?php echo $this_term_value = $second_term.' '.$third_term; ?>
                                                                    <?php // echo $second_term; ?>
                                                                    <?php
                                                                    echo '<input type="hidden" id="row'.$count.'" value="'.$this_term_value.'">';
                                                                    ?>
                                                                </th>

                                                                <?php
                                                                echo '<td><input type="hidden" class=" row'.$count.'" value="'.(((float)$value)/1000000).'">'.round((((float)$value)/1000000), 2).'</td>';
                                                                $this_total_td = (((float)$value)/1000000);
                                                                $total += (((float)$value)/1000000);
                                                                $col[$col_count] += (((float)$value)/1000000);
                                                                $col_count++;
                                                                $count++;
                                                                ?>
                                                                <td><?php echo e(round(($this_total_td*23.8845), 2)); ?></td>
                                                                <td><?php echo e(round(($this_total_td/3.6), 2)); ?></td>
                                                            </tr>


                                                            <?php
                                                                }
                                                            }
                                                            ?>

                                                            <tr class="active">
                                                                <th colspan="2">
                                                                    Total
                                                                    <?php
                                                                    echo '<input type="hidden" id="row'.$count.'" value="Total">';
                                                                    ?>
                                                                </th>
                                                                <th id="this_total"><?php echo e(round($total, 2)); ?></th>
                                                                <th><?php echo e(round(($total*23.8845), 2)); ?></th>
                                                                <th><?php echo e(round(($total/3.6), 2)); ?></th>
                                                            </tr>
                                                            <?php
                                                            }
                                                            ?>
                                                        </table>
                                                    </div>

                                                    <script>
                                                        var this_total = document.getElementById('this_total').innerHTML;
                                                        document.getElementById('total').innerHTML = this_total+' PJ';

                                                        function getRandomInt(max) {
                                                            return Math.floor(Math.random() * Math.floor(max));
                                                        }

                                                        var this_title = document.getElementById("this_title").innerHTML;

                                                        var this_name = document.getElementById("this_name").value;

                                                        // var categories_arr = new Array();

                                                        // var findit = document.getElementsByClassName('x-axis');
                                                        // for(var i = 0; i < findit.length; i++){
                                                        //     var this_key = findit[i].value;
                                                        //     categories_arr.push(this_key);
                                                        // }

                                                        var series_data = [];

                                                        var top_row = document.getElementsByClassName('top_row');

                                                        for(var j=0;j<top_row.length;j++){
                                                            var k = j+1;
                                                            var row = 'row'+k;

                                                            // console.log(row);

                                                            var y_value = 0;
                                                            var find_row = document.getElementsByClassName(row);

                                                            var y_value = find_row[0].value;

                                                            // for (var i = 0; i < find_row.length; i++) {
                                                            //     var this_key = find_row[i].value;
                                                            //     row_arr.push(parseInt(this_key));
                                                            // }
                                                            var find_id_row_value = document.getElementById(row).value;

                                                            // console.log(row);

                                                            // {
                                                            //     name: 'Chrome',
                                                            //         y: 61.41,
                                                            //     sliced: true,
                                                            //     selected: true
                                                            // }

                                                            if(k < 2)
                                                                var obj_row = {name: find_id_row_value, y: parseFloat(y_value), sliced: true, selected: true};
                                                            else
                                                                var obj_row = {name: find_id_row_value, y: parseFloat(y_value)};

                                                            series_data.push(obj_row);

                                                        }

                                                        // console.log(series_data);

                                                        // return false;

                                                        // var series_data = [obj_row1, obj_row2, obj_row3, obj_row4, obj_row5, obj_row6];

                                                        Highcharts.chart('container', {
                                                            chart: {
                                                                plotBackgroundColor: null,
                                                                plotBorderWidth: null,
                                                                plotShadow: false,
                                                                type: 'pie'
                                                            },
                                                            title: {
                                                                text: this_title
                                                            },
                                                            tooltip: {
                                                                pointFormat: '{series.name}: <b>{point.percentage:.2f}%</b>'
                                                            },
                                                            accessibility: {
                                                                point: {
                                                                    valueSuffix: '%'
                                                                }
                                                            },
                                                            plotOptions: {
                                                                pie: {
                                                                    size: '80%',
                                                                    allowPointSelect: true,
                                                                    cursor: 'pointer',
                                                                    dataLabels: {
                                                                        enabled: true,
                                                                        format: '<b>{point.name}</b>: {point.percentage:.2f} %',
                                                                        style: {
                                                                            textOverflow: 'ellipsis',
                                                                            fontSize: '1em'
                                                                        }
                                                                    }
                                                                }
                                                            },
                                                            series: [{
                                                                name: this_name,
                                                                colorByPoint: true,
                                                                data: series_data
                                                            }]
                                                        });
                                                    </script>
                                                </div>
                                            </div>


                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>

                    <?php endif; ?>

                </div>


            </div>
        </div>
    </div>
</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend_layouts.frontend_federal_chart_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>