<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <title>NEIS</title>
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/images/ico/favicon.ico">
    <link href="https://fonts.googleapis.com/css?family=Muli:400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="https://maxcdn.icons8.com/fonts/line-awesome/1.1/css/line-awesome-font-awesome.min.css" rel="stylesheet">
    <!-- BEGIN VENDOR CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/css/vendors.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/vendors/css/forms/toggle/switchery.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/css/plugins/forms/switch.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/css/core/colors/palette-switch.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/vendors/css/charts/chartist.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/vendors/css/charts/chartist-plugin-tooltip.css">
    <!-- END VENDOR CSS-->
    <!-- BEGIN CHAMELEON  CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/css/app.min.css">
    <!-- END CHAMELEON  CSS-->
    <!-- BEGIN Page Level CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/css/core/menu/menu-types/vertical-menu.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/css/core/colors/palette-gradient.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/css/core/colors/palette-gradient.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/css/pages/chat-application.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/css/pages/dashboard-analytics.min.css">
    <!-- END Page Level CSS-->
    <!-- BEGIN Custom CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/resources/assets/ppentry/assets/css/style.css">
    <!-- END Custom CSS-->
  </head>
  <body class="vertical-layout vertical-menu 2-columns menu-expanded fixed-navbar" data-open="click" data-menu="vertical-menu" data-color="bg-gradient-x-purple-blue" data-col="2-columns">

    <?php echo $__env->make("dashboard_layouts.inc.front_header", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
    <div class="main-menu menu-fixed menu-light menu-accordion menu-shadow " data-scroll-to-active="true" data-img="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/images/backgrounds/02.jpg">
      <div class="navbar-header">
          <img class="img-responsive brand-logo" alt="Logo" src="<?php echo e(url('/')); ?>/resources/assets/frontend/assets/images/logo.jpg"/>

      </div>
      <div class="main-menu-content">
        <?php echo $__env->make("dashboard_layouts.inc.front_sidebar", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>
      <div class="navigation-background"></div>
    </div>

    <div class="app-content content">
      <div class="content-wrapper">
        <div class="content-wrapper-before"></div>
        <div class="content-header row">
        </div>
        <div class="content-body"><!-- Revenue, Hit Rate & Deals -->
            <?php echo $__env->yieldContent('content'); ?>
<!--/ Revenue, Hit Rate & Deals -->
<!-- Emails Products & Avg Deals -->

<!--/ Emails Products & Avg Deals -->
<!--/ Total earning & Recent Sales  -->
        </div>
      </div>
    </div>
    <!-- ////////////////////////////////////////////////////////////////////////////-->

    <?php echo $__env->make("dashboard_layouts.inc.front_footer", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


    <!-- BEGIN VENDOR JS-->
    <script src="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/vendors/js/vendors.min.js" type="text/javascript"></script>
    <script src="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/vendors/js/forms/toggle/switchery.min.js" type="text/javascript"></script>
    <script src="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/js/scripts/forms/switch.min.js" type="text/javascript"></script>
    <!-- BEGIN VENDOR JS-->
    <!-- BEGIN PAGE VENDOR JS-->
    <script src="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/vendors/js/charts/chartist.min.js" type="text/javascript"></script>
    <script src="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/vendors/js/charts/chartist-plugin-tooltip.min.js" type="text/javascript"></script>
    <!-- END PAGE VENDOR JS-->
    <!-- BEGIN CHAMELEON  JS-->
    <script src="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/js/core/app-menu.min.js" type="text/javascript"></script>
    <script src="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/js/core/app.min.js" type="text/javascript"></script>
    <script src="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/js/scripts/customizer.min.js" type="text/javascript"></script>
    <script src="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/vendors/js/jquery.sharrre.js" type="text/javascript"></script>
    <!-- END CHAMELEON  JS-->
    <!-- BEGIN PAGE LEVEL JS-->
    <script src="<?php echo e(url('/')); ?>/resources/assets/ppentry/app-assets/js/scripts/pages/dashboard-analytics.min.js" type="text/javascript"></script>
    <!-- END PAGE LEVEL JS-->
    <script>
        $(document).ready(function(){
            // alert('adsfasd');

            $('.display_none').css("display", "none");
            $('.display_block').css("display", "block");

            $('#type-change').on('change', function(){
                // $('.child_of').removeAttr('selected');
                // $(".child_of:selected").remove();
                // $('.child_of:selected', this ).remove();

                $('.child_of:selected').removeAttr('selected');

                var this_id = $(this).val();
                $('.child_of').css("display", "none");
                $('.parent_'+this_id).css('display', 'block');

                var option_html = $('.form-group-child-of').html();

                $('.form-group-child-of').html('');
                $('.form-group-child-of').html(option_html);

                // $('.form-group-child-of').empty();
            });

            $('.natural_qty').on('keyup', function(){
                var indexed = $('.natural_qty').index($(this));
                var natural_qty_this = $(this).val();
                var natural_qty_this = parseFloat((natural_qty_this)?natural_qty_this:0);
                var natural_unit_this = $('.natural_unit:eq('+indexed+')').val();
                if(natural_unit_this.length > 0){
                    var scientific_unit_conversion_no = parseFloat($('.scientific_unit_conversion_standard[title="'+natural_unit_this+'"]').val());
                    var scientific_qty_no = natural_qty_this*scientific_unit_conversion_no;
                    $('.scientific_qty:eq('+indexed+')').attr("value", scientific_qty_no);
                }
            });

            $('.natural_unit').on('change', function(){
                var indexed = $('.natural_unit').index($(this));
                var natural_unit_this = $(this).val();
                var natural_qty_this = parseFloat($('.natural_qty:eq('+indexed+')').val());
                var natural_qty_this = parseFloat((natural_qty_this)?natural_qty_this:0);
                if(natural_qty_this > 0){
                    var scientific_unit_conversion_no = parseFloat($('.scientific_unit_conversion_standard[title="'+natural_unit_this+'"]').val());
                    var scientific_qty_no = natural_qty_this*scientific_unit_conversion_no;
                    $('.scientific_qty:eq('+indexed+')').attr("value", scientific_qty_no);
                }
            });

            // $('.natural_unit').on('change', function(){
            //     var indexed = $('.natural_unit').index($(this));
            //     var natural_unit_this = $(this).val();
            //     var natural_qty_this = parseFloat($('.natural_qty:eq('+indexed+')').val());
            //     var natural_qty_this = parseFloat((natural_qty_this)?natural_qty_this:0);
            //     if(natural_qty_this > 0){
            //         var scientific_unit_conversion_no = parseFloat($('.scientific_unit_conversion_standard[title="'+natural_unit_this+'"]').val());
            //         var scientific_qty_no = natural_qty_this*scientific_unit_conversion_no;
            //         $('.scientific_qty:eq('+indexed+')').attr("value", scientific_qty_no);
            //     }
            // });

            $('#starting').on('change', function(){
                var start_year = $(this).val();
                if(start_year != ''){
                    $('#ending').css("display", "block");
                    $('#ending option').css("display", "block");
                    for(var i = parseInt(start_year); i > (parseInt(start_year) - 40); i--){
                        $('#ending option[value='+i+']').css("display", "none");
                    }
                    var a_href = $('#go_id').attr('name');
                    $('#go_id').attr('title', a_href+'/trend/'+start_year);

                    var end_year = $('#ending').val();

                    $('#go_id').attr('href', a_href+'/trend/'+start_year+'/'+end_year);

                }else{
                    $('#ending').css("display", "none");
                    var a_href = $('#go_id').attr('name');
                    $('#go_id').attr('href', a_href);
                    $('#go_id').attr('title', a_href);
                }
            });

            $('#ending').on('change', function(){
                var end_year = $(this).val();
                if(end_year != ''){
                    $('#now_go').css("display", "block");
                    var b_href = $('#go_id').attr('title');
                    $('#go_id').attr('href', b_href+'/'+end_year);
                }else{
                    $('#ending').css("display", "none");
                    var b_href = $('#go_id').attr('name');
                    $('#go_id').attr('href', b_href);
                }
            });

            // alert('adsfasd');

            $('#province').on('change', function () {
                // alert($(this).val());
                var parent_id = parseInt($(this).val());

                $('#district option, #local_gov_id option').removeAttr("selected");
                var district_html = $('#district').html();
                var local_government_html = $('#local_gov_id').html();

                if(parent_id > 0){
                    $('#district option').css("display", "none");
                    $('#district option').removeAttr("selected");
                    $('#district option[class="parent_'+parent_id+'"]').css("display", "block");
                    district_html = $('#district').html();
                    $('#district').html(district_html);
                    $('#local_gov_id').html(local_government_html);
                }else{
                    $('#district option').css("display", "none");
                    $('#local_gov_id option').css("display", "none");
                    $('#district').html(district_html);
                    $('#local_gov_id').html(local_government_html);
                }
            });

            $('#district').on('change', function () {
                // alert($(this).val());
                var parent_id = parseInt($(this).val());

                // console.log(parent_id);

                $('#local_gov_id option').removeAttr("selected");
                var local_government_html = $('#local_gov_id').html();

                if(parent_id > 0){
                    $('#local_gov_id option').removeAttr("selected");
                    $('#local_gov_id option').css("display", "none");
                    $('#local_gov_id option[class="parent_'+parent_id+'"]').css("display", "block");
                    local_government_html = $('#local_gov_id').html();
                    $('#local_gov_id').html(local_government_html);
                }else{
                    $('#local_gov_id').html(local_government_html);
                }
            });

            $('.districtwise_natural_unit').on('change', function () {
                // alert($(this).val());
                var this_districtwise_natural_unit = $(this).val();

                var index_this = $(this).parent('.long-unit').attr('title');

                // console.log(index_this);

                // console.log(this_districtwise_natural_unit);

                // $('.long-unit-'+index_this+' option[value="'+this_districtwise_natural_unit+'"]').attr("selected");

                $('.long-unit-'+index_this+' option[value="'+this_districtwise_natural_unit+'"]').each(function(){

                    console.log(1);

                    $(this).attr("selected","selected");

                    // $(this).next('option[value="'+this_districtwise_natural_unit+'"]').attr("selected");

                    // if($(this).next('option').attr("value") == this_districtwise_natural_unit){
                    //     $(this).next('option').attr("selected");
                    // }

                });

            });

            $('.districtwise_natural_qty').on('keyup', function () {
                // alert($(this).val());
                var this_districtwise_natural_qty = parseFloat($(this).val());

                var index_this = $(this).parent('.long-qty').attr('title');

                // console.log(index_this);
                //
                // console.log(this_districtwise_natural_qty);

                // $('.long-unit-'+index_this+' option[value="'+this_districtwise_natural_unit+'"]').attr("selected");

                var sum_of = 0;

                $('.long-qty-'+index_this+' > .districtwise_natural_qty').each(function(){

                    if($(this).val() > 0){

                        var this_input_qty = parseFloat($(this).val());

                        console.log(this_input_qty);

                        sum_of += this_input_qty;

                        // console.log(1);

                    }

                });

                // console.log(sum_of);

                document.getElementById('overall_natural_qty_'+index_this).value = sum_of;

                // $('#overall_natural_qty').attr("value", sum_of);

            });

        });
    </script>
  </body>
</html>
            
