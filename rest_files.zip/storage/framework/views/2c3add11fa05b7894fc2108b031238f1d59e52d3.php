
<?php $__env->startSection('content'); ?>
<section id="horizontal-form-layouts">
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title" id="horz-layout-colored-controls">
                    District Wise Entry Form For <?php echo e($this_energy_type->energy_type_name); ?>

                    
                </h4>
                <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                <div class="heading-elements">
                    <ul class="list-inline mb-0">
                        <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                        <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                    </ul>
                </div>
            </div>
            <?php
            $readonly = ($route != 'edit')?'':'readonly';
            $disabled = ($route != 'edit')?'':'disabled';
            ?>
            <div class="card-content collpase show">
                <div class="card-body">
                    <div class="card-text">
                        <p>Please fill all the required inputs</p>
                    </div>

                    <div class="advance-filter">
                        <form action="<?php echo e(url('/')); ?>/dashboard/entryform-districtwise/<?php echo e($this_energy_type->energy_type_slug); ?>/" id="filterform" method="get">
                        <div class="row">

                            <?php if(!empty($energy_year[0])): ?>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <p>Year</p>
                                        <select name="year" id="year" class="form-control border-primary" onchange="document.getElementById('filterform').submit();" required>
                                            <option value="">-Select Year-</option>
                                            <?php $__currentLoopData = $energy_year; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $the_year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($the_year->energy_year_start); ?>" <?php echo e(($the_year->energy_year_start == $start)?'selected':''); ?>><?php echo e($the_year->energy_year_start.'/'.$the_year->energy_year_end); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>

                                        <input type="hidden" name="is_central" value="0" />
                                    </div>
                                </div>
                            <?php endif; ?>

                            <?php $is_central_get = (!empty($is_central))?$is_central:0; ?>

                            <div class="col-md-10" id="no_central" <?php echo ($start > 1)?'style="display:block;"':'style="display:none;"'; ?>>
                                <div class="row">

                                    <?php if(!empty($provinces)): ?>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <p>Province</p>
                                                <select name="province_id" id="province" class="form-control border-primary">
                                                    <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $the_location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($the_location->id); ?>" <?php echo e(($province_id == $the_location->id)?'selected':''); ?>><?php echo e($the_location->location_name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                    <?php endif; ?>

                                    <?php if(!empty($sectors)): ?>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <p>Sector</p>
                                                <select name="sector" id="sector" class="form-control border-primary" onchange="document.getElementById('filterform').submit();">
                                                    <?php $__currentLoopData = $sectors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $the_sector): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($the_sector->sector_slug); ?>" <?php echo e(($this_sector_id == $the_sector->id)?'selected':''); ?>><?php echo e($the_sector->sector_name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                    <?php endif; ?>

                                </div>

                            </div>
                            <div class="clearfix"></div>
                        </div>
                        </form>
                    </div>

                    <?php if(!empty($start) && $start != date('Y')): ?>

                        <form action="<?php echo e(url('/')); ?>/dashboard/entryform-districtwise/<?php echo e($this_energy_type->energy_type_slug); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="formdata[from_date]" value="<?php echo e($start); ?>">
                            <input type="hidden" name="formdata[to_date]" value="<?php echo e($end); ?>">
                            <input type="hidden" name="formdata[province_id]" value="<?php echo e($province_id); ?>">
                            <input type="hidden" name="formdata[sector_id]" value="<?php echo e($this_sector_id); ?>">


                            <div class="table-responsive table-static-col">

                                <table class="table table-bordered">
                                    <tr>
                                        <th class="headcol">District</th>

                                        <?php if(!empty($energy_listing)): ?>
                                            <?php $__currentLoopData = $energy_listing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $the_energy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <th class="long" colspan="2"><?php echo e($the_energy->energy_name); ?></th>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                         <?php endif; ?>
                                    </tr>
                                    <tr>
                                        <th class="headcol">&nbsp;</th>

                                        <?php if(!empty($energy_listing)): ?>
                                            <?php $__currentLoopData = $energy_listing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $the_energy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <th>Natural Qty</th>
                                                <th>Natural Unit</th>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>

                                    </tr>
                                    <?php if(!empty($districts)): ?>
                                        <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $the_location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th class="headcol"><?php echo e($the_location->location_name); ?></th>

                                                <?php
                                                $count = 0;
                                                ?>

                                                <?php if(!empty($energy_listing)): ?>
                                                    <?php $__currentLoopData = $energy_listing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $the_energy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <?php
                                                        $this_natural_qty = (!empty($data[$the_location->id][$the_energy->id]['natural_qty']))?$data[$the_location->id][$the_energy->id]['natural_qty']:'';
                                                        $this_natural_unit = (!empty($data[$the_location->id][$the_energy->id]['natural_unit']))?$data[$the_location->id][$the_energy->id]['natural_unit']:'';
                                                        ?>

                                                        <td class="long long-qty long-qty-<?php echo e($count); ?>" title="<?php echo e($count); ?>">
                                                            <input type="text" class="form-control districtwise_natural_qty" name="districtwise[<?php echo e($the_location->id); ?>][<?php echo e($the_energy->id); ?>][natural_qty]" value="<?php echo e($this_natural_qty); ?>">
                                                        </td>
                                                        <td class="long long-unit long-unit-<?php echo e($count); ?>" title="<?php echo e($count++); ?>">
                                                            <select name="districtwise[<?php echo e($the_location->id); ?>][<?php echo e($the_energy->id); ?>][natural_unit]" class="form-control districtwise_natural_unit">
                                                                <?php if($units): ?>
                                                                    <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $the_unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <option value="<?php echo e($the_unit->unit_slug); ?>" <?php echo e(($the_unit->unit_slug == $this_natural_unit)?'selected="selected"':''); ?>><?php echo e($the_unit->unit_name); ?></option>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php endif; ?>
                                                            </select>
                                                        </td>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    <tr>
                                        <th class="headcol">Overall</th>

                                        <?php if(!empty($energy_listing)): ?>
                                            <?php
                                            $count = 0;
                                            ?>
                                            <?php $__currentLoopData = $energy_listing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $the_energy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                $this_natural_qty = (!empty($data_overall[$the_energy->id]['natural_qty']))?$data_overall[$the_energy->id]['natural_qty']:'';
                                                $this_natural_unit = (!empty($data_overall[$the_energy->id]['natural_unit']))?$data_overall[$the_energy->id]['natural_unit']:'';
                                                ?>
                                                <td class="long">
                                                    <input type="text" id="overall_natural_qty_<?php echo e($count); ?>" class="natural_qty form-control" name="overall[<?php echo e($the_energy->id); ?>][natural_qty]" value="<?php echo e($this_natural_qty); ?>">
                                                </td>
                                                <td class="long long-unit-<?php echo e($count); ?>" title="<?php echo e($count++); ?>">
                                                    <select name="overall[<?php echo e($the_energy->id); ?>][natural_unit]" class="form-control districtwise_natural_unit">
                                                        <?php if($units): ?>
                                                            <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $the_unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($the_unit->unit_slug); ?>" <?php echo e(($the_unit->unit_slug == $this_natural_unit)?'selected="selected"':''); ?>><?php echo e($the_unit->unit_name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    </select>
                                                </td>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </tr>
                                </table>
                            </div>

                            <?php if($units): ?>
                                <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $the_unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="scientific_unit_conversion_standard[<?php echo e($the_unit->unit_slug); ?>]" value="<?php echo e($the_unit->scientific_qty); ?>" title="<?php echo e($the_unit->unit_slug); ?>">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                            <div class="col-md-12">
                                <div class="form-actions right">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="la la-check-square-o"></i>
                                        <?php
                                        if(!empty($user_level->user_group_slug) && $user_level->user_group_slug == 'data-entry'){
                                            echo 'Save For Entry';
                                        }elseif(!empty($user_level->user_group_slug) && $user_level->user_group_slug == 'supervisor'){
                                            echo 'Validate & Publish';
                                        }else{
                                            echo 'Save';
                                        }
                                        ?>

                                    </button>
                                </div>
                            </div>

                        </form>
                        

                    <?php endif; ?>

                </div>


            </div>
        </div>
    </div>
</div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard_layouts.user_dashboard_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>