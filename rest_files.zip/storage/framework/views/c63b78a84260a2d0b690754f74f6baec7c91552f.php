<?php $__env->startSection('content'); ?>
    <div class="col-md-12">

        <section class="no-padding-bottom">

            <article class="post-detail-01">

                <div class="content">

                    <h4>Energy Conversion Tools</h4>
                    <p>This tool converts available energy units into the standard unit (GJ, ToE and MWh) .</p>

                    <div class="row">
                        <div class="col-md-6">

                            <div class="energy_content">
                                <div class="row">
                                    <div class="col-md-2">

                                        <form action="" method="get" class="form-inline" id="energy_conversion_form">
                                            <?php echo csrf_field(); ?>

                                            <?php if(!empty($energy_list)): ?>
                                                <div class="form-group">
                                                    <label for="sel1">Fuel:</label>
                                                    <select name="energy" class="form-control" id="fuel_select" onchange="document.getElementById('energy_conversion_form').submit();">
                                                        <option value="">Select Fuel</option>
                                                        <?php $__currentLoopData = $energy_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $the_energy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($the_energy->energy_slug); ?>" <?php echo e((!empty($this_energy) && $this_energy == $the_energy->energy_slug )?'selected':''); ?>><?php echo e($the_energy->energy_name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            <?php endif; ?>
                                        </form>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">

                                        <?php if(!empty($energy_list_with)): ?>
                                            <?php $__currentLoopData = $energy_list_with; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <form action="" method="get" class="unit_select form-inline" id="energy_conversion_form_<?php echo e($key); ?>" style="display:<?php echo e(($this_energy == $key)?'block':'none'); ?>;">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="energy" value="<?php echo e($key); ?>">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="form-group" id="<?php echo e($key); ?>">
                                                                <label for="sel1">Quantity:</label>
                                                                <input type="text" class="form-control" name="qty" value="<?php echo e(($this_qty > 0)?$this_qty:1); ?>">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group" id="<?php echo e($key); ?>">
                                                                <label for="sel1">From Unit:</label>
                                                                <select name="unit" class="form-control" onchange="document.getElementById('energy_conversion_form_<?php echo e($key); ?>').submit();">
                                                                    <option value="">Choose Unit</option>
                                                                    <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $the_unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php if($the_unit->unit_slug != 'giga-joule'): ?>
                                                                            <option value="<?php echo e($the_unit->unit_slug); ?>" <?php echo e((!empty($this_unit) && $this_unit == $the_unit->unit_slug )?'selected':''); ?>><?php echo e($the_unit->unit_name); ?></option>
                                                                        <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>

                                    </div>
                                    <div class="col-md-6">

                                        <?php if(!empty($result->scientific_qty) && !empty($result->scientific_unit)): ?>
                                            <table class="table table-bordered">
                                                <tr class="info">
                                                    <th>Result In GJ</th>
                                                    <th>Result In (000) ToE</th>
                                                    <th>Result In (000000) MWh</th>
                                                </tr>
                                                <tr class="active">
                                                    <td>
                                                        <?php
                                                        echo $this_qty*$result->scientific_qty.' '.$result->scientific_unit;
                                                        ?>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        echo round(($this_qty*$result->scientific_qty*23.8845), 2).' ToE';
                                                        ?>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        echo round(($this_qty*$result->scientific_qty/3.6), 2).' MWh';
                                                        ?>
                                                    </td>
                                                </tr>
                                            </table>
                                        <?php endif; ?>

                                    </div>
                                </div>


                            </div>

                        </div>
                    </div>

                </div>

            </article>

        </section>

    </div>

<!--end site header-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend_layouts.frontend_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>