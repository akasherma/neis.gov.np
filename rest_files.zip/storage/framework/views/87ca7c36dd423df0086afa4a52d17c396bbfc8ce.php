<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <div class="content-wrapper">
            <div class="content-body"><!-- Zero configuration table -->
                <section id="configuration">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">User Lists <a href="<?php echo e(url('/')); ?>/dashboard/user/add" class="btn btn-primary btn-xs">Add</a></h4>
                                    <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                                    <div class="heading-elements">
                                        <ul class="list-inline mb-0">
                                            
                                            <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                            <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                                            
                                        </ul>
                                    </div>
                                </div>
                                <div class="card-content collapse show">
                                    <div class="table-responsive card-body card-dashboard">
                                        <table class="table table-striped table-bordered zero-configuration">
                                            <thead>
                                            <tr>
                                                <th>S.No.</th>
                                                <th>Name</th>
                                                <th>Designation</th>
                                                <th>Org. Name</th>
                                                <th>User Type</th>
                                                <th>Action</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $count = 1; ?>
                                            <?php if(!is_null($data)): ?>
                                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $the_result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($count++); ?></td>
                                                        <td><?php echo e($the_result->name); ?></td>
                                                        <td><?php echo e($the_result->designation); ?></td>
                                                        <td><?php echo e($the_result->organization_name); ?></td>
                                                        <td><?php echo e($the_result->user_group_name); ?></td>
                                                        <td><a href="<?php echo e(url('/')); ?>/dashboard/user/edit/<?php echo e($the_result->id); ?>" class="btn btn-primary btn-xs mb-1">Edit</a>
                                                            <a href="<?php echo e(url('/')); ?>/dashboard/user/delete/<?php echo e($the_result->id); ?>" class="btn btn-primary btn-xs mb-1">Remove</a></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                            </tbody>
                                            <tfoot>
                                            <tr>
                                                <th>S.No.</th>
                                                <th>Name</th>
                                                <th>Designation</th>
                                                <th>Org. Name</th>
                                                <th>User Type</th>
                                                <th>Action</th>
                                            </tr>
                                            </tfoot>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!--/ Zero configuration table -->

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard_layouts.datatables_list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>