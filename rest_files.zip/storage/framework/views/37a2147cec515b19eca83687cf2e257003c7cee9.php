

<?php $__env->startSection('content'); ?>

        <div class="content-body"><section class="flexbox-container">
                <div class="col-12 d-flex align-items-center justify-content-center">
                    <div class="col-md-4 col-10 box-shadow-2 p-0">
                        <div class="card border-grey border-lighten-3 px-1 py-1 m-0">

                            <img class="img-responsive" src="<?php echo e(url('/').'/resources/assets/images/wecs_logo.jpg'); ?>" alt="wecs logo" title="wecs logo">

                            <div class="card-header border-0">
                                <div class="font-large-1  text-center">
                                    <h2>Login</h2>
                                </div>



                            <?php if(Session::has('error')): ?>
                                    <p class="alert <?php echo e(Session::get('alert-class', 'alert-danger')); ?>"><?php echo e(Session::get('error')); ?></p>
                                <?php endif; ?>

                                <?php if(Session::has('success')): ?>
                                    <p class="alert alert-success"><?php echo e(Session::get('success')); ?></p>
                                <?php endif; ?>

                                <?php if(Session::has('warning')): ?>
                                    <p class="alert <?php echo e(Session::get('alert-class', 'alert-warning')); ?>"><?php echo e(Session::get('warning')); ?></p>
                                <?php endif; ?>

                                <?php if(Session::has('message')): ?>
                                    <p class="alert <?php echo e(Session::get('alert-class', 'alert-info')); ?>"><?php echo e(Session::get('message')); ?></p>
                                <?php endif; ?>

                            </div>
                            <div class="card-content">

                                <div class="card-body">

                                    <form method="POST" action="<?php echo e(route('login')); ?>" aria-label="<?php echo e(__('Login')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <fieldset class="form-group position-relative has-icon-left">
                                            <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required autofocus>

                                            <?php if($errors->has('email')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                            <div class="form-control-position">
                                                <i class="ft-user"></i>
                                            </div>
                                        </fieldset>
                                        <fieldset class="form-group position-relative has-icon-left">

                                            <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                                            <?php if($errors->has('password')): ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                            <div class="form-control-position">
                                                <i class="ft-lock"></i>
                                            </div>
                                        </fieldset>

                                        <div class="form-group row">
                                            <div class="col-md-6 offset-md-4">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                                    <label class="form-check-label" for="remember">
                                                        <?php echo e(__('Remember Me')); ?>

                                                    </label>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="form-group row mb-0">
                                            <div class="col-md-8 offset-md-4">
                                                <button type="submit" class="btn btn-primary">
                                                    <?php echo e(__('Login')); ?>

                                                </button>

                                                <a class="btn btn-link" href="<?php echo e(url('/')); ?>/forgot-password/">
                                                    <?php echo e(__('Forgot Your Password?')); ?>

                                                </a>
                                            </div>
                                        </div>
                                    </form>
                                </div>

                                <p class="card-subtitle text-muted text-right font-small-3 mx-2 my-1"><span>Don't have an account ? <a href="<?php echo e(url('/')); ?>/register/" class="card-link">Sign Up</a></span></p>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>