
<?php $__env->startSection('content'); ?>
    <section id="horizontal-form-layouts">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="horz-layout-colored-controls">Energy Types</h4>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <?php
                    $permalink = $url;
//                    $permalink = url('/').'/dashboard/entry-form';
//                    $permalink .= (!empty($this_province))?'/province/'.$this_province->location_slug:'';
//                    $permalink .= (!empty($this_district))?'/district/'.$this_district->location_slug:'';
//                    $permalink .= (!empty($this_local))?'/local/'.$this_local->location_slug:'';

//                    echo $permalink;

                    ?>
                    <div class="card-content collpase show">
                        <div class="card-body row">
                            <?php if(!empty($energy_types)): ?>
                            <div class="col-md-12 form-body-listing ">
                                <ul>
                                    <?php $__currentLoopData = $energy_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $energy_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <h4>
                                            <a class="btn btn-lg btn-outline-primary" href="<?php echo e($permalink.'/'.$energy_type->energy_type_slug); ?>"><?php echo e($energy_type->energy_type_name); ?></a>
                                        </h4>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard_layouts.user_dashboard_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>