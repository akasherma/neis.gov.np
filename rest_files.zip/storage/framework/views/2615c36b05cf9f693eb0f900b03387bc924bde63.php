
<?php $__env->startSection('content'); ?>
<section id="horizontal-form-layouts">
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-md-9">


                        <?php
                        $province_name_final = (!empty($province_name->location_name))?$province_name->location_name:'';
                        $district_name_final = (!empty($district_name->location_name))?$district_name->location_name:'';

                        $province_name_final = ($district_name_final != '')?'':$province_name_final;
                        ?>

                        <h2 class="card-title" id="horz-layout-colored-controls">
                            <?php echo e($province_name_final); ?> Energy <?php echo e($this_energy_type->energy_type_name); ?> By Fuel Types (<?php echo e($start); ?>)
                        </h2>

                    </div>
                    
                        
                            
                                
                                
                                    
                                        

                                            
                                                
                                                
                                                
                                                
                                                
                                            
                                        
                                        
                                    

                                    
                                        
                                            
                                        
                                    
                                    
                                
                            
                        
                    
                </div>
                <div class="clearfix"></div>
            </div>
            <?php
            $readonly = 'readonly';
            $disabled = 'disabled';
            ?>
            <div class="card-content collpase show">
                <div class="card-body">



                    <?php if(!empty($start) && $start != date('Y')): ?>
                        <section id="horizontal-form-layouts">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card">
                                        <div class="card-header">



                                            
                                                
                                            <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                                            <div class="heading-elements">
                                                <ul class="list-inline mb-0">
                                                    <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                                    <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="card-content collpase show">
                                            <div class="card-body row">
                                                <div class="col-md-12 form-body-listing">

                                                    <div style=" border: 2px solid #333; padding: 30px 30px 60px; ">
                                                        <h4 class="card-title text-center" id="this_title" style="display:none;">
                                                            <?php echo e($province_name_final); ?> Energy <?php echo e($this_energy_type->energy_type_name); ?> By Fuel Types (<?php echo e($start); ?>)
                                                        </h4>
                                                        <div id="container" style="height:500px;"></div>
                                                        <span id="total"></span>
                                                    </div>

                                                    
                                                    <div class="table-responsive">


                                                        <table class="table table-striped table-bordered">
                                                            <?php
                                                            $col = array();
                                                            $col_total_init = 0;
                                                            $count = 1;
                                                            $row_class= '';
                                                            $row_key= '';
                                                            $counter = 0;
                                                            $color_arr = array('table-primary', 'table-success', 'table-info', 'table-warning');
                                                            $total = 0;
                                                            $col_count = 0;

                                                            ?>
                                                            <tr class="info">
                                                                <th colspan="2">Fuel Type</th>
                                                                <th>Total (PJ)</th>
                                                                <th>Total (000, ToE)</th>
                                                                <th>Total (000, GWh)</th>
                                                                <?php
                                                                if(!empty($final_result)){
                                                                    foreach($final_result as $key=>$value){

                                                                        $this_key = (!empty($key))?explode('-', $key):array();

                                                                        $this_first_key = (is_array($this_key) && (!empty($this_key[0])))?$this_key[0]:'';

                                                                        $col_count = 0;

                                                                        $counter += ($this_first_key != $row_key)?1:0;

                                                                        $counter = ($counter < count($color_arr))?$counter:0;

                                                                        $row_class = $color_arr[$counter];

                                                                        $col[$col_count] = (!empty($col[$col_count]))?((float)$col[$col_count]):0;
                                                                        $this_value = (((float)$value)/1000000);


                                                                        $this_no = (((float)$value)/1000000);

                                                                        if($this_no > 0){

                                                                            $this_key = (!empty($key))?explode('-', $key):array();

                                                                            $this_second_key = (is_array($this_key) && (!empty($this_key[1])))?$this_key[1]:$key;

                                                                            echo '<input type="hidden" class="x-axis" value="'.$this_second_key.'">';
                                                                            echo '<input type="hidden" class="y-axis" value="'.$this_no.'">';
                                                                            $col[$col_total_init] = 0;
                                                                            $col_total_init++;

                                                                        }
                                                                    }
                                                                    $col[$col_total_init] = 0;
                                                                }
                                                                ?>
                                                            </tr>
                                                            <tbody class="">
                                                            <?php
                                                            $count = 1;
                                                            $row_class= '';
                                                            $row_key= '';
                                                            $counter = 0;

                                                            $total = 0;
                                                            $color_arr = array('table-primary', 'table-success', 'table-info', 'table-warning');
                                                            if(!empty($final_result)){
                                                            foreach($final_result as $key=>$value){

                                                            $this_key = (!empty($key))?explode('-', $key):array();

                                                            $this_first_key = (is_array($this_key) && (!empty($this_key[0])))?$this_key[0]:'';

                                                            $col_count = 0;

                                                            $counter += ($this_first_key != $row_key)?1:0;

                                                            $counter = ($counter < count($color_arr))?$counter:0;

                                                            $row_class = (!empty($color_arr[$counter]))?$color_arr[$counter]:'';

                                                            $this_no = (((float)$value)/1000000);

                                                            if($this_no > 0){

                                                                ?>

                                                                <?php if($this_first_key != $row_key): ?>

                                                                    <tr class="warning">
                                                                        <th colspan="5">
                                                                            <?php echo e(($this_first_key != $row_key)?$this_first_key:''); ?>

                                                                        </th>
                                                                    </tr>

                                                                <?php endif; ?>

                                                                
                                                                <tr class="top_row " title="Key: ">
                                                                    <th>
                                                                        <?php echo e($count); ?>

                                                                        <?php // echo ($this_first_key != $row_key)?$this_first_key:''; ?>
                                                                        <?php
                                                                        $row_key = ($this_first_key != $row_key)?$this_first_key:$row_key;
                                                                        $second_term = (is_array($this_key) && (!empty($this_key[1])))?ucwords(str_replace('_', ' ', $this_key[1])):'';
                                                                        $third_term = (is_array($this_key) && (!empty($this_key[2])))?ucwords(str_replace('_', ' ', $this_key[2])):'';
                                                                        ?>
                                                                    </th>
                                                                    <td>
                                                                        <?php echo $second_term.' '.$third_term; ?>
                                                                        <?php
                                                                        echo '<input type="hidden" id="row'.$count.'" value="'.$second_term.' '.$third_term.'">';
                                                                        ?>
                                                                    </td>


                                                                    <?php
    //                                                                $col[$col_count] = (!empty($col[$col_count]))?(((float)$col[$col_count])/1000):0;
                                                                            echo '<td><input type="hidden" class="row'.$count.'" value="'.$this_no.'">'.(round($this_no,2)).'</td>';
                                                                            $total += abs($this_no);
                                                                            $col[$col_count] += abs($this_no);
                                                                            $col_count++;

                                                                    //                                                        $col[$col_count] = (!empty($col[$col_count]))?(((float)$col[$col_count])/1000):0;

                                                                    $col[$col_count] += $total;
                                                                    //                                                        $col_count++;
                                                                    ?>
                                                                    <td><?php echo e(round(($this_no*23.8845), 2)); ?></td>
                                                                    <td><?php echo e(round(($this_no/3.6), 2)); ?></td>
                                                                </tr>

                                                                <?php
                                                                $count++;
                                                                }
                                                            }
                                                            ?>

                                                            <tr class="active">
                                                                <th colspan="2">
                                                                    Grand Total
                                                                    <?php
                                                                    // echo '<input type="hidden" id="row'.$count.'" value="">';
                                                                    ?>
                                                                </th>
                                                                <th id="this_total"><?php echo round($total, 2); ?></th>
                                                                <th><?php echo e(round(($total*23.8845), 2)); ?></th>
                                                                <th><?php echo e(round(($total/3.6), 2)); ?></th>
                                                            </tr>
                                                            <?php
                                                            }
                                                            ?>
                                                            </tbody>
                                                        </table>
                                                    </div>

                                                    <script>
                                                        var this_total = document.getElementById('this_total').innerHTML;
                                                        document.getElementById('total').innerHTML = this_total+' PJ';

                                                        // function getRandomInt(max) {
                                                        //     return Math.floor(Math.random() * Math.floor(max));
                                                        // }

                                                        var this_title = document.getElementById("this_title").innerHTML;

                                                        var categories_arr = new Array();

                                                        var findit = document.getElementsByClassName('x-axis');
                                                        for(var i = 0; i < findit.length; i++){
                                                            var this_key = findit[i].value;
                                                            categories_arr.push(this_key);
                                                            console.log(this_key);
                                                        }

                                                        var series_data = new Array();

                                                        var finditnext = document.getElementsByClassName('y-axis');
                                                        for(var i = 0; i < finditnext.length; i++){
                                                            var this_key = parseFloat(finditnext[i].value);
                                                            series_data.push(this_key);
                                                            console.log(this_key);
                                                        }

                                                        // console.log(categories_arr);
                                                        //
                                                        // var series_data = [];
                                                        //
                                                        // var top_row = document.getElementsByClassName('y-axis');
                                                        //
                                                        // // console.log(top_row);
                                                        //
                                                        // for(var j=0;j<categories_arr.length;j++){
                                                        //     var k = j+1;
                                                        //     var row = 'row'+k;
                                                        //
                                                        //     // console.log(row);
                                                        //
                                                        //     var row_arr = new Array();
                                                        //     var find_row = document.getElementsByClassName(row);
                                                        //
                                                        //     for (var i = 0; i < find_row.length; i++) {
                                                        //         var this_key = find_row[i].value;
                                                        //         row_arr.push(parseInt(this_key));
                                                        //     }
                                                        //     var find_id_row_value = document.getElementById(row).value;
                                                        //     var obj_row = {name: find_id_row_value, data: row_arr};
                                                        //     series_data.push(obj_row);
                                                        //
                                                        // }

                                                        console.log(series_data);

                                                        // Highcharts.chart('container', {
                                                        //     chart: {
                                                        //         type: 'column'
                                                        //     },
                                                        //     title: {
                                                        //         text: this_title
                                                        //     },
                                                        //     subtitle: {
                                                        //         text: ''
                                                        //     },
                                                        //     xAxis: {
                                                        //         // categories: categories_arr,
                                                        //         categories: ['a', 'b'],
                                                        //         crosshair: true
                                                        //     },
                                                        //     yAxis: {
                                                        //         min: 0,
                                                        //         title: {
                                                        //             text: 'Energy Consumption (In PJ)'
                                                        //         }
                                                        //     },
                                                        //     tooltip: {
                                                        //         headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                                                        //         pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                                                        //             '<td style="padding:0"><b>{point.y:.2f} PJ</b></td></tr>',
                                                        //         footerFormat: '</table>',
                                                        //         shared: true,
                                                        //         useHTML: true
                                                        //     },
                                                        //     plotOptions: {
                                                        //         column: {
                                                        //             pointPadding: 0.2,
                                                        //             borderWidth: 0
                                                        //         }
                                                        //     },
                                                        //     series: series_data
                                                        // });

                                                        Highcharts.chart('container', {
                                                            chart: {
                                                                type: 'column'
                                                            },
                                                            title: {
                                                                text: this_title
                                                            },
                                                            subtitle: {
                                                                text: 'Source: wecs'
                                                            },
                                                            xAxis: {
                                                                categories: categories_arr,
                                                                crosshair: true
                                                            },
                                                            yAxis: {
                                                                min: 0,
                                                                title: {
                                                                    text: 'Energy (PJ)'
                                                                }
                                                            },
                                                            tooltip: {
                                                                headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                                                                pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                                                                    '<td style="padding:0"><b>{point.y:.2f} PJ</b></td></tr>',
                                                                footerFormat: '</table>',
                                                                shared: true,
                                                                useHTML: true
                                                            },
                                                            plotOptions: {
                                                                column: {
                                                                    pointPadding: 0.2,
                                                                    borderWidth: 0
                                                                }
                                                            },
                                                            series: [{
                                                                name: 'PJ',
                                                                data: series_data

                                                            }]
                                                        });

                                                    </script>
                                                </div>
                                            </div>


                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>

                    <?php endif; ?>

                </div>


            </div>
        </div>
    </div>
</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend_layouts.frontend_province_chart_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>