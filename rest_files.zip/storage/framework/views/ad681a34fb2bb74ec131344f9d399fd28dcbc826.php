<?php $__env->startSection('content'); ?>


<div class="container-fluid">
    <div class="row">
        <div class="col-md-8">
            <div id="myCarousel" class="carousel slide" data-ride="carousel">
                <!-- Indicators -->
                
                
                    
                    
                    
                    
                

                <!-- Wrapper for slides -->
                <div class="carousel-inner">
                    <div class="item active">
                        <img src="<?php echo e(url('/')); ?>/public/images/slider-final-presentation3.jpg" class="img-responsive" alt="Training Program on Gandaki Province, Pokhara" title="Training Program on Gandaki Province, Pokhara">
                        <h2>Training Program on Gandaki Province, Pokhara</h2>
                    </div>
                    <!--<div class="item ">-->
                    <!--    <img src="public/images/slider-final-presentation.jpg" class="img-responsive" alt="Presentation Program of neis.gov.np" title="Presentation Program of neis.gov.np">-->
                    <!--    <h2>Presentation Program on WECS Hall, Kathmandu</h2>-->
                    <!--</div>-->

                    <div class="item">
                        <img src="<?php echo e(url('/')); ?>/public/images/slider-koshi-pradesh1.jpg" class="img-responsive" alt="Training at Koshi Province" title="Training at Koshi Province">
                        <h2>Training at Koshi Province, Biratnagar</h2>
                    </div>

                    <div class="item">
                        <img src="<?php echo e(url('/')); ?>/public/images/slider-madhesh-pradesh.jpg" class="img-responsive" alt="Training at Madhesh Province, Janakpur" title="Training at Madhesh Province, Janakpur">
                        <h2>Training at Madhesh Province, Janakpur</h2>
                    </div>

                    <!--<div class="item">-->
                    <!--    <img src="public/images/slider-final-presentation2.jpg" class="img-responsive" alt="Presentation Program of neis.gov.np" title="Presentation Program of neis.gov.np">-->
                    <!--    <h2>Presentation Program of neis.gov.np</h2>-->
                    <!--</div>-->
                </div>



                <!-- Left and right controls -->
                <a class="left carousel-control" href="#myCarousel" data-slide="prev">
                    <span class="glyphicon glyphicon-chevron-left"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="right carousel-control" href="#myCarousel" data-slide="next">
                    <span class="glyphicon glyphicon-chevron-right"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="widget team-section-01">

                <!--h5>SECRETARY</h5-->

                <div class="team-style-01 text-center section-block-p main-person">

                    <h5 class="name"><a href="<?php echo e(url('/')); ?>/report/energy-consumption-share-by-fueltypes">Federal Energy Data</a></h5>

                    <p class="job"><a href="<?php echo e(url('/')); ?>/report/energy-consumption-share-by-fueltypes">View Details</a></p>

                </div>

                <div class="team-style-01 text-center section-block-p main-person">

                    <h5 class="name"><a href="<?php echo e(url('/')); ?>/report/province/province-3">Province Level Energy Data</a></h5>

                    <p class="job"><a href="<?php echo e(url('/')); ?>/report/province/province-3">View Details</a></p>

                </div>

            </div>
        </div>
    </div>
</div>

<div class="clearfix"></div>

<div class="about-container pt-15">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-9">
                <h2>
                    Introduction
                </h2>
                
                <?php echo (!empty($welcome->page_desc))?$welcome->page_desc:''; ?>

                
                <?php /*
                <p>
                    Energy is the backbone of any economy of the country. Information on available energy resources and its consumption provide the sound basis for appropriate policy formulation and planning of the energy sector towards sustainable development. For this reliable and timely data availability is the key for better action.
                </p>
                <p>
                    Water and Energy Commission Secretariat (WECS) is the apex body which is responsible for collecting the data related to energy and water resources. Since its establishment, it has been collecting, analysing and publishing the energy related data. Every year WECS collects national level fuel wise energy data from different energy related organizations like Nepal Electricity Authority (NEA), Alternative Energy Promotion Centre (AEPC), Department of Mines and Geology, Ministry of Forest and Environment, Ministry of Agriculture and Livestock Development, Nepal Oil Corporation, Department of Customs etc.
                </p>
                <p>
                    Based on these primary surveys of energy demand supply situation, WECS publishes Energy Sector synopsis report and energy data sheet in regular basis. It routinely conducts such primary surveys and prepares reports related to the development of the energy sector in Nepal, for example, estimation of resource potential, energy consumption and conversion technologies appropriate for Nepal's future economic growth, modernization, socio-economic development, policy researches and demonstration studies. Such information obtained from surveys and studies provide a scientific basis which would be a value-added tool for conducting various energy policy analysis and energy modelling exercises.
                </p>
                */ ?>
                
            </div>
            <div class="col-md-3 text-center">

                <img src="<?php echo e(url('/')); ?>/public/images/energy-pyramid.png" class="img-responsive" alt="energy" title="energy">
                <h5>Energy Pyramid</h5>
            </div>
        </div>
        <div class="row mission_vision mt-30">
            <div class="col-md-6">
                <div class="panel panel-info pl-15 pr-15">
                    <div class="panel-heading">
                        <h2>Mission</h2>
                    </div>
                    <div class="panel-body">
                        <p>
                            National Energy Information System (NEIS) is believed to be useful for all involved in national energy planning as well as academic research and studies of the energy sector. It further gives the ideas about the interrelationship between indigenous energy resources availability and consumption scenario which will enable to understand the intervention needed to meet the challenges and opportunities for sustainable energy development in the country.
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="panel panel-info pl-15 pr-15">
                    <div class="panel-heading">
                        <h2>Vision</h2>
                    </div>
                    <div class="panel-body">
                        <ul class="nav nav-tabs">
                            <li>
                            To provide assistance to the concerned ministries in formulation policies and objectives to be included in the perspective/periodic plan.
                            </li>
                            <li>
                            To provide suggestion, recommendations and guidance with regard to the multipurpose (mega and medium scale only) projects' development relating to all sectors.
                            </li>
                            <li>
                                To formulate policies and strategies for the water resources and energy sector.
                            </li>
                            <li>
                                To render opinion, advice and recommendation on the bilateral and multilateral issue relating to water resources and energy.
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="about pt-15">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <h2>
                    Major Stakeholders/Agencies for Energy Data Sources
                </h2>
            </div>
            <div class="col-md-3">
                <div class="panel-logo">
                    <a href="https://moewri.gov.np/" target="_blank">
                        <img class="img-responsive" src="<?php echo e(url('/')); ?>/public/images/moewri.jpg" alt="moewri-logo" />
                        <span>Ministry of Energy, Water Resources and Irrigation</span>
                    </a>
                </div>
            </div>
            <div class="col-md-3">
                <div class="panel-logo">
                    <a href="https://www.mofe.gov.np/" target="_blank">
                        <img class="img-responsive" src="<?php echo e(url('/')); ?>/public/images/mofe.jpg" alt="mofe-logo" />
                        <span>Ministry of Forests and Environment</span>
                    </a>
                </div>
            </div>
            <div class="col-md-3">
                <div class="panel-logo">
                    <a href="https://www.customs.gov.np/" target="_blank">
                        <img class="img-responsive" src="<?php echo e(url('/')); ?>/public/images/doc.png" alt="doc" />
                        <span>Department of Customs</span>
                    </a>
                </div>
            </div>
            <div class="col-md-3">
                <div class="panel-logo">
                    <a href="https://www.dmgnepal.gov.np/" target="_blank">
                        <img class="img-responsive" src="<?php echo e(url('/')); ?>/public/images/dmgnepal.jpg" alt="dmgnepal" />
                        <span>Department of Mines and Geology</span>
                    </a>
                </div>
            </div>
            <div class="clearfix"></div>
            <div class="col-md-3">
                <div class="panel-logo">
                    <a href="https://www.doed.gov.np/" target="_blank">
                        <img class="img-responsive" src="<?php echo e(url('/')); ?>/public/images/doed.jpg" alt="doed" />
                        <span>Department of Electricity Development</span>
                    </a>
                </div>
            </div>
            <div class="col-md-3">
                <div class="panel-logo">
                    <a href="https://www.aepc.gov.np/" target="_blank">
                        <img class="img-responsive" src="<?php echo e(url('/')); ?>/public/images/aepc.jpg" alt="aepc" />
                        <span>Alternative Energy Promotion Centre</span>
                    </a>
                </div>
            </div>
            <div class="col-md-3">
                <div class="panel-logo">
                    <a href="https://www.nea.org.np/" target="_blank">
                    <img class="img-responsive" src="<?php echo e(url('/')); ?>/public/images/nea-logo.png" alt="nea-logo" />
                    <span>Nepal Electricity Authority</span>
                    </a>
                </div>
            </div>
            <div class="col-md-3">
                <div class="panel-logo">
                    <a href="https://noc.org.np/" target="_blank">
                        <img class="img-responsive" src="<?php echo e(url('/')); ?>/public/images/noc.jpeg" alt="noc" />
                        <span>Nepal Oil Corporation</span>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php /*
<div class="about-container pt-15">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-7">

                <section class="">

                    <article class="post-detail-01 skyblue_bg">

                        <div class="content">
                            <h2>Three Levels of Natural Energy Data Sources</h2>
                            <div class="col-md-12 info">
                                <div class="col-md-12 panel with-nav-tabs panel-info">
                                    <div class="panel-heading">
                                        <ul class="nav nav-tabs">

                                            <?php
                                            $active = 'active';
                                            if(!empty($welcome->id)){
                                            ?>
                                            <li class="active"><a href="#introduction" data-toggle="tab">Federal </a></li>
                                            <?php
                                            $active = '';
                                            }
                                            ?>

                                            <?php
                                            if(!empty($mission->id)){
                                            ?>
                                            <li class="{{ $active }}"><a href="#mission" data-toggle="tab">Provincial </a></li>
                                            <?php
                                            $active = '';
                                            }
                                            ?>

                                            <?php
                                            if(!empty($vision->id)){
                                            ?>
                                            <li class="{{ $active }}"><a href="#vision" data-toggle="tab">Local Government </a></li>
                                            <?php
                                            $active = '';
                                            }
                                            ?>
                                        </ul>
                                    </div>
                                    <div class="panel-body">
                                        <div class="tab-content">

                                            <?php
                                            $active = 'in active';
                                            if(!empty($welcome->id)){
                                            ?>
                                            <div class="tab-pane fade in active" id="introduction">
                                                {!! $welcome->page_desc !!}
                                            </div>
                                            <?php
                                            $active = '';
                                            }
                                            ?>

                                            <?php
                                            if(!empty($mission->id)){
                                            ?>
                                            <div class="tab-pane fade {{ $active }}" id="mission">
                                                {!! $mission->page_desc !!}
                                            </div>
                                            <?php
                                            $active = '';
                                            }
                                            ?>
                                            <?php
                                            if(!empty($vision->id)){
                                            ?>
                                            <div class="tab-pane fade {{ $active }}" id="vision">
                                                {!! $vision->page_desc !!}
                                            </div>
                                            <?php
                                            }
                                            ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </article>

                </section>

            </div>
            <div class="col-md-4 text-center"><img src="{{ url('/') }}/public/images/power-nepal.png" class="img-responsive" alt="energy" title="energy">
            </div>
        </div>
    </div>
</div>

    */ ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend_layouts.frontend_layout_homepage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>