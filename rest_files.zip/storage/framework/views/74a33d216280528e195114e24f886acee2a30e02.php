<?php $__env->startSection('content'); ?>
    <div class="col-md-12">

        <section class="no-padding-bottom">

            <article class="post-detail-01">

                <div class="content">

                    <h4><?php echo e((!empty($this_page->page_name))?$this_page->page_name:''); ?></h4>
                    <?php echo (!empty($this_page->page_desc))?$this_page->page_desc:''; ?>

                </div>

            </article>

        </section>

    </div>

<!--end site header-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend_layouts.frontend_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>