
<section class="no-padding-bottom right-design">
    <div class="widget team-section-01">

        <h2 class="card-title">
            Filter
        </h2>
        <form action="<?php echo e($url); ?>" method="get">
            <?php echo csrf_field(); ?>
            <?php
            $start = (!empty($_GET['start']))?$_GET['start']:2005;
            
            $end = 2023;
            
            ?>

            <div class="p-15">
                <div class="row">
                    <div class="col-md-6">

                        <h4>From Year</h4>

                        <select name="start" class="form-control">
                            <option value="">Select Start Year</option>
                            <?php for($i = 2000; $i < $end; $i++): ?>
                                <option value="<?php echo e($i); ?>" <?php echo e(($i == $start)?'selected':''); ?>><?php echo e($i); ?></option>
                            <?php endfor; ?>

                        </select>

                    </div>
                    <div class="col-md-6">

                        <h4>To Year</h4>

                        <select name="end" class="form-control">
                            <option value="">Select End Year</option>
                            <?php for($i = 2000; $i <= $end; $i++): ?>
                                <option value="<?php echo e($i); ?>" <?php echo e(($i == $end)?'selected':''); ?>><?php echo e($i); ?></option>
                            <?php endfor; ?>

                        </select>

                    </div>
                </div>

                <input type="submit" class="btn btn-primary btn-xs " value="Submit">

            </div>

        </form>

        <hr>

        <h2 class="card-title">
            National Energy Data
        </h2>

        <ul class="mt-15">
            <li>
                <a href="<?php echo e(url('/')); ?>/report/energy-consumption-share-by-fueltypes" class="<?php echo e(($url == url('/').'/report/energy-consumption-share-by-fueltypes')?'active':''); ?>">By Fuel Types [ Pie Chart ] <span class="pull-right pr-10"><i class="fa fa-pie-chart"></i></span></a>
            </li>
            <li>
                <a href="<?php echo e(url('/')); ?>/report/energy-consumption-share-by-sectors" class="<?php echo e(($url == url('/').'/report/energy-consumption-share-by-sectors')?'active':''); ?>" > By Sectors [ Pie Chart ] <span class="pull-right pr-10"><i class="fa fa-pie-chart"></i></span></a>
            </li>
            <li>
                <a href="<?php echo e(url('/')); ?>/report/energy-consumption-by-sectors" class="<?php echo e(($url == url('/').'/report/energy-consumption-by-sectors')?'active':''); ?>">By Sectors [ Bar Diagram ] <span class="pull-right pr-10"><i class="fa fa-bar-chart"></i></span></a>
            </li>
            <li>
                <a href="<?php echo e(url('/')); ?>/report/consumption-energy-topic-energy-line-graph" class="<?php echo e(($url == url('/').'/report/consumption-energy-topic-energy-line-graph')?'active':''); ?>">By Line Graph [ Bar Diagram ] <span class="pull-right pr-10"><i class="fa fa-bar-chart"></i></span></a>
            </li>
            <li>
                <a href="<?php echo e(url('/')); ?>/report/energy-consumption-by-trend-bar-graph" class="<?php echo e(($url == url('/').'/report/energy-consumption-by-trend-bar-graph')?'active':''); ?>">By Year [ Bar Diagram ] <span class="pull-right pr-10"><i class="fa fa-bar-chart"></i></span></a>
            </li>
            <li>
                <a href="<?php echo e(url('/')); ?>/report/energy-supply-demand-balance" class="<?php echo e(($url == url('/').'/report/energy-supply-demand-balance')?'active':''); ?>">Energy Balance[ Tabular Data ] <span class="pull-right pr-10"><i class="fa fa-th"></i></span></a>
            </li>
        </ul>

        <hr>

        <h2 class="card-title">
            Provincial Energy Data
        </h2>

        <ul class="mt-15">
            <li>
                <a href="<?php echo e(url('/')); ?>/report/province/province-1" class="<?php echo e(($url == url('/').'/report/province/province-1')?'active':''); ?>">Koshi Pradesh <span class="pull-right pr-10"><i class="fa fa-external-link"></i></span></a>
            </li>
            <li>
                <a href="<?php echo e(url('/')); ?>/report/province/province-2" class="<?php echo e(($url == url('/').'/report/province/province-2')?'active':''); ?>">Madhesh Pradesh <span class="pull-right pr-10"><i class="fa fa-external-link"></i></span></a>
            </li>
            <li>
                <a href="<?php echo e(url('/')); ?>/report/province/province-3" class="<?php echo e(($url == url('/').'/report/province/province-3')?'active':''); ?>">Bagmati Pradesh <span class="pull-right pr-10"><i class="fa fa-external-link"></i></span></a>
            </li>
            <li>
                <a href="<?php echo e(url('/')); ?>/report/province/province-4" class="<?php echo e(($url == url('/').'/report/province/province-4')?'active':''); ?>">Gandaki Pradesh <span class="pull-right pr-10"><i class="fa fa-external-link"></i></span></a>
            </li>
            <li>
                <a href="<?php echo e(url('/')); ?>/report/province/province-5" class="<?php echo e(($url == url('/').'/report/province/province-5')?'active':''); ?>">Lumbini Pradesh <span class="pull-right pr-10"><i class="fa fa-external-link"></i></span></a>
            </li>
            <li>
                <a href="<?php echo e(url('/')); ?>/report/province/province-6" class="<?php echo e(($url == url('/').'/report/province/province-6')?'active':''); ?>">Karnali Pradesh <span class="pull-right pr-10"><i class="fa fa-external-link"></i></span></a>
            </li>
            <li>
                <a href="<?php echo e(url('/')); ?>/report/province/province-7" class="<?php echo e(($url == url('/').'/report/province/province-7')?'active':''); ?>">Sudur Paschim Pradesh <span class="pull-right pr-10"><i class="fa fa-external-link"></i></span></a>
            </li>
        </ul>

        <hr>



    </div>
</section>
