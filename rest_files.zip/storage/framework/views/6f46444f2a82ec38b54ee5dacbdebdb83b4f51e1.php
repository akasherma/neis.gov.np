
<section class="no-padding-bottom right-design">
    <div class="widget team-section-01">

        <h2 class="card-title">
            Filter
        </h2>
        <form action="<?php echo e($url); ?>" method="get">
            <?php echo csrf_field(); ?>
            <?php
            $start = (!empty($_GET['start']))?$_GET['start']:'2023';
            ?>

            <div class="p-15">

                <h4>By Fiscal Year</h4>

                <ul class="nav navbar-nav">
                    <li>
                        <input type="radio" name="start" value="2019" <?php echo e(($start == '2019')?'checked':''); ?>> 2019/2020
                    </li>
                    <li>
                        <input type="radio" name="start" value="2023" <?php echo e(($start == '2023')?'checked':''); ?>> 2023/2024
                    </li>
                </ul>

                

            </div>

        </form>

        <hr>

        <h2 class="card-title">
            National Energy Data
        </h2>

        <ul class="mt-15">
            <li>
                <a href="<?php echo e(url('/')); ?>/report/energy-consumption-share-by-fueltypes" class="<?php echo e(($url == url('/').'/report/energy-consumption-share-by-fueltypes')?'active':''); ?>">By Fuel Types [ Pie Chart ] <span class="pull-right pr-10"><i class="fa fa-pie-chart"></i></span></a>
            </li>
            <li>
                <a href="<?php echo e(url('/')); ?>/report/energy-consumption-share-by-sectors" class="<?php echo e(($url == url('/').'/report/energy-consumption-share-by-sectors')?'active':''); ?>" > By Sectors [ Pie Chart ] <span class="pull-right pr-10"><i class="fa fa-pie-chart"></i></span></a>
            </li>
            <li>
                <a href="<?php echo e(url('/')); ?>/report/energy-consumption-by-sectors" class="<?php echo e(($url == url('/').'/report/energy-consumption-by-sectors')?'active':''); ?>">By Sectors [ Bar Diagram ] <span class="pull-right pr-10"><i class="fa fa-bar-chart"></i></span></a>
            </li>
            <li>
                <a href="<?php echo e(url('/')); ?>/report/consumption-energy-topic-energy-line-graph" class="<?php echo e(($url == url('/').'/report/consumption-energy-topic-energy-line-graph')?'active':''); ?>">By Line Graph [ Bar Diagram ] <span class="pull-right pr-10"><i class="fa fa-bar-chart"></i></span></a>
            </li>
            <li>
                <a href="<?php echo e(url('/')); ?>/report/energy-consumption-by-trend-bar-graph" class="<?php echo e(($url == url('/').'/report/energy-consumption-by-trend-bar-graph')?'active':''); ?>">By Year [ Bar Diagram ] <span class="pull-right pr-10"><i class="fa fa-bar-chart"></i></span></a>
            </li>
            <li>
                <a href="<?php echo e(url('/')); ?>/report/energy-supply-demand-balance" class="<?php echo e(($url == url('/').'/report/energy-supply-demand-balance')?'active':''); ?>">Energy Balance[ Tabular Data ] <span class="pull-right pr-10"><i class="fa fa-th"></i></span></a>
            </li>
        </ul>

        <hr>

        <h2 class="card-title">
            Provincial Energy Data
        </h2>

        <ul class="mt-15">
            <li>
                <a href="<?php echo e(url('/')); ?>/report/province/province-1" class="<?php echo e(($url == url('/').'/report/province/province-1')?'active':''); ?>">Koshi Pradesh <span class="pull-right pr-10"><i class="fa fa-external-link"></i></span></a>
            </li>
            <li>
                <a href="<?php echo e(url('/')); ?>/report/province/province-2" class="<?php echo e(($url == url('/').'/report/province/province-2')?'active':''); ?>">Madhesh Pradesh <span class="pull-right pr-10"><i class="fa fa-external-link"></i></span></a>
            </li>
            <li>
                <a href="<?php echo e(url('/')); ?>/report/province/province-3" class="<?php echo e(($url == url('/').'/report/province/province-3')?'active':''); ?>">Bagmati Pradesh <span class="pull-right pr-10"><i class="fa fa-external-link"></i></span></a>
            </li>
            <li>
                <a href="<?php echo e(url('/')); ?>/report/province/province-4" class="<?php echo e(($url == url('/').'/report/province/province-4')?'active':''); ?>">Gandaki Pradesh <span class="pull-right pr-10"><i class="fa fa-external-link"></i></span></a>
            </li>
            <li>
                <a href="<?php echo e(url('/')); ?>/report/province/province-5" class="<?php echo e(($url == url('/').'/report/province/province-5')?'active':''); ?>">Lumbini Pradesh <span class="pull-right pr-10"><i class="fa fa-external-link"></i></span></a>
            </li>
            <li>
                <a href="<?php echo e(url('/')); ?>/report/province/province-6" class="<?php echo e(($url == url('/').'/report/province/province-6')?'active':''); ?>">Karnali Pradesh <span class="pull-right pr-10"><i class="fa fa-external-link"></i></span></a>
            </li>
            <li>
                <a href="<?php echo e(url('/')); ?>/report/province/province-7" class="<?php echo e(($url == url('/').'/report/province/province-7')?'active':''); ?>">Sudur Paschim Pradesh <span class="pull-right pr-10"><i class="fa fa-external-link"></i></span></a>
            </li>
        </ul>

        <hr>



    </div>
</section>
