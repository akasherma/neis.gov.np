<!DOCTYPE html>
<html class="no-js">
<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>National Energy Information System :: Government of Nepal</title>

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/resources/assets/frontend/vendors/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/resources/assets/frontend/vendors/animate/animate.min.css">
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/resources/assets/frontend/assets/fonts/wolverine/styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;400;700&display=swap" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css2?family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/resources/assets/frontend/vendors/slick/slick.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('/')); ?>/resources/assets/frontend/vendors/full-page/jquery.fullPage.css">
    <!--Main stylesheet-->
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/resources/assets/frontend/assets/css/main.css">
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/resources/assets/frontend/assets/css/fontawesome.css">
    <link rel="stylesheet" href="<?php echo e(url('/')); ?>/resources/assets/frontend/assets/css/caMenu.css">
    <!--Modernizr js-->
    <script src="<?php echo e(url('/')); ?>/resources/assets/frontend/vendors/modernizr/modernizr-2.8.3-respond-1.4.2.min.js"></script>
    <style> .nav-main-menu > li > ul{display:none;}</style>

</head>

<body class="creative-page">

<?php echo $__env->make('frontend_layouts.inc.front_header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!-- site header -->

<header class="site-header">

    <div class="container-fluid">
        <div class="row">

            <?php echo $__env->yieldContent('content'); ?>

            <div class="clearfix"></div>
        </div>
    </div>
</header>

<?php echo $__env->make('frontend_layouts.inc.front_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<!--end site footer-->

</main>

<script src="<?php echo e(url('/')); ?>/resources/assets/frontend/vendors/jquery/jquery-1.11.2.min.js"></script>
<script src="<?php echo e(url('/')); ?>/resources/assets/frontend/vendors/stellar/jquery.stellar.min.js"></script>
<script src="<?php echo e(url('/')); ?>/resources/assets/frontend/vendors/waypoints/lib/jquery.waypoints.min.js"></script>
<script src="<?php echo e(url('/')); ?>/resources/assets/frontend/vendors/smooth-scroll/SmoothScroll.js"></script>
<script src="<?php echo e(url('/')); ?>/resources/assets/frontend/vendors/bootstrap/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo e(url('/')); ?>/resources/assets/frontend/vendors/slick/slick.js"></script>
<script type="text/javascript" src="<?php echo e(url('/')); ?>/resources/assets/frontend/vendors/magnific-popup/jquery.magnific-popup.js"></script>
<script src="<?php echo e(url('/')); ?>/resources/assets/frontend/vendors/isotope/isotope.pkgd.min.js"></script>
<script src="<?php echo e(url('/')); ?>/resources/assets/frontend/vendors/isotope/packery-mode.pkgd.min.js"></script>
<script type="text/javascript" src="<?php echo e(url('/')); ?>/resources/assets/frontend/vendors/img-loaded/imagesloaded.pkgd.min.js"></script>
<script src="<?php echo e(url('/')); ?>/resources/assets/frontend/assets/js/main.js"></script>
<script>
    $(document).ready(function(){
        // alert('asdf');
        var output = $('#output').val();

        if(output != 'trend'){
            $('#fiscal_year').css("display", "block");
            $('#year_range').css("display", "none");
        }else {
            $('#year_range').css("display", "block")
            $('#fiscal_year').css("display", "none");
        }

        $('#output').on('change', function(){
            output = $(this).val();

            // alert(output);

            if(output != 'trend'){
                $('#fiscal_year').css("display", "block");
                $('#year_range').css("display", "none");
            }else {
                $('#year_range').css("display", "block")
                $('#fiscal_year').css("display", "none");
            }

        });

    });
</script>
</body>
</html>
