<?php $__env->startSection('content'); ?>
    <section id="horizontal-form-layouts">

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="horz-layout-colored-controls"><?php echo e(ucfirst($route)); ?> User</h4>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="card-content collpase show">
                        <div class="card-body">
                            <div class="card-text">
                                <p>Please fill all the required inputs</p>
                            </div>
                            <form action="<?php echo e(url('/')); ?>/dashboard/user/<?php echo e($route); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="form-body">
                                    <h4 class="form-section"><i class="la la-eye"></i> User Details</h4>
                                    <?php echo csrf_field(); ?>
                                    <h5 class="form-section">Personal Information</h5>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <input type="hidden" name="formdata[id]" value="<?php echo e($data->id); ?>">
                                            <div class="form-group">
                                                <p>Name</p>
                                                <input type="text" class="form-control border-primary" name="formdata[name]" placeholder="Enter Your Name" value="<?php echo e($data->name); ?>" required />
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <p>Email</p>
                                                <input type="email" class="form-control border-primary" name="formdata[email]" placeholder="Enter Your Email" value="<?php echo e($data->email); ?>" required />
                                            </div>
                                        </div>
                                        <?php if($data->password == ''): ?>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <p>Password</p>
                                                <input type="password" class="form-control border-primary" name="formdata[password]" placeholder="Enter Your Password" value="" required />
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <p>Phone No</p>
                                                <input type="text" class="form-control border-primary" name="formdata[phone]" placeholder="Enter Your Phone No" value="<?php echo e($data->phone); ?>" required />
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <p>Address</p>
                                                <input type="text" class="form-control border-primary" name="formdata[address]" placeholder="Enter Your Address" value="<?php echo e($data->address); ?>" required />
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <p>Designation</p>
                                                <input type="text" class="form-control border-primary" name="formdata[designation]" placeholder="Enter Your Designation" value="<?php echo e($data->designation); ?>" required />
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <p>Organization Name</p>
                                                <input type="text" class="form-control border-primary" name="formdata[organization_name]" placeholder="Enter Your organization name" value="<?php echo e($data->organization_name); ?>" required />
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <h5 class="form-section">User Privilege</h5>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <p>User Group</p>

                                                <select name="formdata[user_group_id]" id="" class="form-control border-primary">
                                                    <?php if($user_group): ?>
                                                        <?php $__currentLoopData = $user_group; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $the_user_group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($the_user_group->id); ?>" <?php echo e(($data->user_group_id == $the_user_group->id)?'selected':''); ?>><?php echo e($the_user_group->user_group_name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <p>Are You from Central Office</p>
                                                <select name="formdata[is_central]" id="" class="form-control border-primary" onchange="changePrivilege(this.value);">
                                                    <option value="0" <?php echo e((!empty($data->is_central) && $data->is_central == '0')?'selected':''); ?>>No</option>
                                                    <option value="1" <?php echo e((!empty($data->is_central) && $data->is_central == '1')?'selected':''); ?>>Yes</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="privilege">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <p>Province</p>
                                                    <select name="formdata[province_id]" id="" class="form-control border-primary">
                                                        <option value="0">Select Province</option>
                                                        <?php if($provinces): ?>
                                                            <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $the_location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($the_location->id); ?>" <?php echo e((!empty($data->province_id) && $data->province_id == $the_location->id)?'selected':''); ?>><?php echo e($the_location->location_name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <p>District</p>
                                                    <select name="formdata[district_id]" id="" class="form-control border-primary">
                                                        <option value="0">Select District</option>
                                                        <?php if($districts): ?>
                                                            <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $the_location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($the_location->id); ?>" <?php echo e((!empty($data->district_id) && $data->district_id == $the_location->id)?'selected':''); ?>><?php echo e($the_location->location_name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <p>Local Government</p>
                                                    <select name="formdata[local_govt_id]" id="" class="form-control border-primary">
                                                        <option value="0">Select Local Government</option>
                                                        <?php if($local_governments): ?>
                                                            <?php $__currentLoopData = $local_governments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $the_location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($the_location->id); ?>" <?php echo e((!empty($data->local_govt_id) && $data->local_govt_id == $the_location->id)?'selected':''); ?>><?php echo e($the_location->location_name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-actions right">
                                        <button type="button" class="btn btn-danger mr-1">
                                            <i class="ft-x"></i> Cancel
                                        </button>
                                        <button type="submit" class="btn btn-primary">
                                            <i class="la la-check-square-o"></i> Save
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>
<script>
function changePrivilege(val){
    if(val == '0'){
        document.getElementById('privilege').style.display="block";
    }else{
        document.getElementById('privilege').style.display="none";
    }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard_layouts.user_dashboard_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>