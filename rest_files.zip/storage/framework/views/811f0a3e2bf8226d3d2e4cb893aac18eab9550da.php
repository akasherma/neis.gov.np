<nav class="header-navbar navbar-expand-md navbar navbar-with-menu navbar-without-dd-arrow fixed-top navbar-semi-light">
      <div class="navbar-wrapper">
        <div class="navbar-container content">
          <div class="collapse navbar-collapse show" id="navbar-mobile">
            <ul class="nav navbar-nav float-left">
              <li class="nav-item mobile-menu d-md-none mr-auto"><a class="nav-link nav-menu-main menu-toggle hidden-xs" href="#"><i class="ft-menu font-large-1"></i></a></li>
              <li class="nav-item d-none d-md-block"><a class="nav-link nav-menu-main menu-toggle hidden-xs" href="#"><i class="ft-menu"></i></a></li>
              <li class="nav-item d-none d-md-block">
                  <a class="nav-link nav-menu-main" href="#"></a>
              </li>
            </ul>

              <h4 class="brand-text">National Energy Information System
                  <span class="message">

                      <?php
                      $user_status = App\User::getUserStatus(Auth::user()->id);
                      ?>
                      <mark>
                      Welcome To <?php echo e($user_status); ?> Section
                      </mark>
                      <?php if(session()->has('success')): ?>
                          <span class="btn btn-xs alert alert-success">
                              <?php echo e(session()->get('success')); ?>

                          </span>
                      <?php endif; ?>
                      <?php if(session()->has('error')): ?>
                          <span class="btn btn-xs alert alert-danger">
                              <?php echo e(session()->get('error')); ?>

                          </span>
                      <?php endif; ?>
                      <?php if(session()->has('warning')): ?>
                          <span class="btn btn-xs alert alert-warning">
                              <?php echo e(session()->get('warning')); ?>

                          </span>
                      <?php endif; ?>
                  </span>
              </h4>

            <div class="float-left mr-auto">
            </div>

            <ul class="nav navbar-nav float-right">
                  <li class="dropdown dropdown-user nav-item">
                      <a class="dropdown-toggle nav-link dropdown-user-link" href="#" data-toggle="dropdown">
                          <span class="avatar avatar-online">
                            <span class="badge badge-pill badge-primary float-right" style="border: 4px solid #615fdc;">
                                Account</span>
                          </span></a>
                    <div class="dropdown-menu dropdown-menu-right">
                      <div class="arrow_box_right"><a class="dropdown-item" href="#">
                          <span class="avatar avatar-online">
                            <span class="user-name text-bold-700 ml-1">
                                Account
                            </span></span></a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="<?php echo e(url('/')); ?>/dashboard/viewprofile">
                          <i class="ft-user"></i> View Profile</a>
                        <div class="dropdown-divider"></div>
                          <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                             onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                              <?php echo e(__('Logout')); ?>

                          </a>

                          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                              <?php echo csrf_field(); ?>
                          </form>
                      </div>
                    </div>
                  </li>
            </ul>
          </div>
        </div>
      </div>
    </nav>
