
<?php $__env->startSection('content'); ?>
<section id="horizontal-form-layouts">
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-md-9">
                        <h2 class="card-title" id="horz-layout-colored-controls">
                            National Energy Consumption Scenario
                        </h2>

                    </div>
                    
                        
                            
                                
                                


                                    
                                        
                                            
                                                
                                                
                                                
                                            
                                        
                                    

                                    
                                        
                                            
                                        
                                    
                                    
                                
                            
                        
                    
                    <div class="clearfix"></div>
                </div>

            </div>
            <?php
            $readonly = 'readonly';
            $disabled = 'disabled';
            ?>
            <div class="card-content collpase show">
                <div class="card-body">



                    <?php if(!empty($start) && $start != date('Y')): ?>

                        <section id="horizontal-form-layouts">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card">
                                        <div class="card-header">



                                            
                                                
                                            <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                                            <div class="heading-elements">
                                                <ul class="list-inline mb-0">
                                                    <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                                    <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="card-content collpase show">
                                            <div class="card-body row">
                                                <div class="col-md-12 form-body-listing">


                                                        <div style=" border: 2px solid #333; padding: 30px 30px 60px; ">
                                                            <h4 class="card-title text-center" id="this_title" style="display:none;">National Energy <?php echo e($this_energy_type->energy_type_name); ?> By Sectors (<?php echo e($start); ?>)</h4>
                                                            <div id="container" style="height:650px;"></div>
                                                            <span id="total"></span>
                                                        </div>
                                                    
                                                    <div class="table-responsive">
                                                        <table class="table table-striped table-bordered">
                                                            <?php
                                                            $col = array();
                                                            $col_total_init = 0;
                                                            ?>
                                                            <tr class="info">
                                                                <th colspan="2">Fuel Type</th>
                                                                <?php
                                                                if(!empty($col_send)){
                                                                    foreach($col_send as $the_col){
                                                                        echo '<th><input type="hidden" class="x-axis" value="'.$the_col.'">'.$the_col.'</th>';
                                                                        $col[$col_total_init] = 0;
                                                                        $col_total_init++;
                                                                    }
                                                                    $col[$col_total_init] = 0;
                                                                }
                                                                ?>
                                                                <th>
                                                                    
                                                                    Total (PJ)
                                                                </th>
                                                                <th>Total (In 000, ToE)</th>
                                                                <th>Total (In 000000, MWh)</th>
                                                            </tr>
                                                            <?php
                                                            $count = 1;
                                                            $row_class= '';
                                                            $row_key= '';
                                                            $counter = 0;
                                                            $color_arr = array('table-primary', 'table-success', 'table-info', 'table-warning');
                                                            if(!empty($final_result)){
                                                            foreach($final_result as $key=>$value){

                                                            $this_key = (!empty($key))?explode('-', $key):array();

                                                            $this_first_key = (is_array($this_key) && (!empty($this_key[0])))?$this_key[0]:'';

                                                            $total = 0;
                                                            $col_count = 0;

                                                            $counter += ($this_first_key != $row_key)?1:0;

                                                            $counter = ($counter < count($color_arr))?$counter:0;

                                                            $row_class = $color_arr[$counter];

                                                            ?>

                                                            <?php if($this_first_key != $row_key): ?>

                                                                <tr class="warning" title="Key: <?php echo e($row_key); ?> & Counter: <?php echo e($counter); ?>">
                                                                    <th colspan="11">
                                                                        <?php echo e(($this_first_key != $row_key)?$this_first_key:''); ?>

                                                                    </th>
                                                                </tr>

                                                            <?php endif; ?>

                                                            <tr class="top_row <?php echo e($row_class); ?>" title="Key: <?php echo e($row_key); ?> & Counter: <?php echo e($counter); ?>">
                                                                <th>
                                                                    <?php echo e($count); ?>


                                                                    <?php $row_key = ($this_first_key != $row_key)?$this_first_key:$row_key;
                                                                    $second_term = (is_array($this_key) && (!empty($this_key[1])))?ucwords(str_replace('_', ' ', $this_key[1])):'';
                                                                    $third_term = (is_array($this_key) && (!empty($this_key[2])))?ucwords(str_replace('_', ' ', $this_key[2])):'';
                                                                    ?>
                                                                </th>
                                                                <td>
                                                                    
                                                                    <?php echo $this_term_value = $second_term.' '.$third_term; ?>
                                                                    <?php
                                                                    echo '<input type="hidden" id="row'.$count.'" value="'.$this_term_value.'">';
                                                                    ?>
                                                                </td>
                                                                <?php
                                                                if(is_array($value)){
                                                                    foreach($value as $the_value){
//                                                                $col[$col_count] = (!empty($col[$col_count]))?(((float)$col[$col_count])/1000):0;
                                                                        $this_no = (((float)$the_value))/1000000;
//                                                                echo '<td><input type="hidden" class=" row'.$count.'" value="'.$this_no.'">'.(round($this_no,2)).'</td>';
                                                                        echo '<td><input type="hidden" class=" row'.$count.'" value="'.$this_no.'">'.(round($this_no,2)).'</td>';
                                                                        $total += abs($this_no);
                                                                        $col[$col_count] += abs($this_no);
                                                                        $col_count++;
                                                                    }
                                                                }

                                                                //                                                        $col[$col_count] = (!empty($col[$col_count]))?(((float)$col[$col_count])/1000):0;

                                                                $col[$col_count] += $total;
                                                                //                                                        $col_count++;
                                                                ?>
                                                                <th>
                                                                    <?php

                                                                    //                                                        echo '<pre>';
                                                                    //                                                        print_r($col);

                                                                    ?>
                                                                    <?php echo e(round($total, 2)); ?></th>
                                                                <th><?php echo e(round(($total*23.8845), 2)); ?></th>
                                                                <th><?php echo e(round(($total/3.6), 2)); ?></th>
                                                            </tr>

                                                            <?php
                                                            $count++;
                                                            }
                                                            ?>

                                                            <tr class="active top_row table-active">
                                                                <th colspan="2">
                                                                    Grand Total
                                                                    <?php
                                                                    echo '<input type="hidden" id="row'.$count.'" value="">';
                                                                    ?>
                                                                </th>
                                                                <?php
                                                                $this_no = 0;
                                                                $col_total = 0;
                                                                if(is_array($col)){
                                                                    foreach($col as $the_value){
                                                                        $this_no = ((float)$the_value);
//                                                            echo '<td><input type="hidden" class=" row'.$count.'" value="'.$this_no.'">'.(round($this_no,2)).'</td>';;
                                                                        echo '<th>'.(round($this_no,2)).'</th>';
                                                                        $col_total += (float)$the_value;
                                                                    }
                                                                }
                                                                $count++;
                                                                ?>
                                                                <th><?php echo e(round(($this_no*23.8845), 2)); ?></th>
                                                                <th><?php echo e(round(($this_no/3.6), 2)); ?></th>
                                                                
                                                            </tr>
                                                            <?php
                                                            }
                                                            ?>
                                                        </table>
                                                    </div><script>

                                                        function getRandomInt(max) {
                                                            return Math.floor(Math.random() * Math.floor(max));
                                                        }

                                                        var this_title = document.getElementById("this_title").innerHTML;



                                                        var categories_arr = new Array();

                                                        var findit = document.getElementsByClassName('x-axis');
                                                        for(var i = 0; i < findit.length; i++){
                                                            var this_key = findit[i].value;
                                                            categories_arr.push(this_key);
                                                        }

                                                        var series_data = [];

                                                        var top_row = document.getElementsByClassName('top_row');

                                                        for(var j=0;j<top_row.length;j++){
                                                            var k = j+1;
                                                            var row = 'row'+k;

                                                            // console.log(row);

                                                            var row_arr = new Array();
                                                            var find_row = document.getElementsByClassName(row);

                                                            for (var i = 0; i < find_row.length; i++) {
                                                                var this_key = find_row[i].value;
                                                                row_arr.push(parseInt(this_key));
                                                            }
                                                            var find_id_row_value = document.getElementById(row).value;
                                                            var obj_row = {name: find_id_row_value, data: row_arr};
                                                            series_data.push(obj_row);

                                                        }

                                                        console.log(series_data);

                                                        Highcharts.chart('container', {
                                                            chart: {
                                                                type: 'column'
                                                            },
                                                            title: {
                                                                text: this_title
                                                            },
                                                            xAxis: {
                                                                categories: categories_arr
                                                                // categories: ['Apples', 'Oranges', 'Pears', 'Grapes', 'Bananas']
                                                            },
                                                            yAxis: {
                                                                min: 0,
                                                                title: {
                                                                    text: "Energy (PJ)"
                                                                },
                                                                stackLabels: {
                                                                    enabled: true,
                                                                    style: {
                                                                        fontWeight: 'bold',
                                                                        fontSize: '1em',
                                                                        // color: ( // theme
                                                                        //     Highcharts.defaultOptions.title.style &&
                                                                        //     Highcharts.defaultOptions.title.style.color
                                                                        // ) || 'gray'
                                                                    }
                                                                }
                                                            },
                                                            legend: {
                                                                align: 'right',
                                                                x: -30,
                                                                verticalAlign: 'top',
                                                                y: 20,
                                                                floating: true,
                                                                backgroundColor:
                                                                    Highcharts.defaultOptions.legend.backgroundColor || 'white',
                                                                borderColor: '#CCC',
                                                                borderWidth: 1,
                                                                shadow: false
                                                            },
                                                            tooltip: {
                                                                headerFormat: '<b>{point.x}</b><br/>',
                                                                pointFormat: '{series.name}: {point.y}<br/>Total: {point.stackTotal}'
                                                            },
                                                            plotOptions: {
                                                                column: {
                                                                    stacking: 'normal',
                                                                    dataLabels: {
                                                                        enabled: false,
                                                                        style: {
                                                                            textOverflow: 'ellipsis',
                                                                            fontSize: '1em'
                                                                        }
                                                                    }
                                                                }
                                                            },
                                                            series: series_data
                                                            // series: [{
                                                            //     name: 'John',
                                                            //     data: [5, 3, 4, 7, 2]
                                                            // }, {
                                                            //     name: 'Jane',
                                                            //     data: [2, 2, 3, 2, 1]
                                                            // }, {
                                                            //     name: 'Joe',
                                                            //     data: [3, 4, 4, 2, 5]
                                                            // }]
                                                        });

                                                    </script>

                                                    <?php /* ?>
                                                    <script>

                                                        function getRandomInt(max) {
                                                            return Math.floor(Math.random() * Math.floor(max));
                                                        }

                                                        var this_title = document.getElementById("this_title").innerHTML;



                                                        var categories_arr = new Array();

                                                        var findit = document.getElementsByClassName('x-axis');
                                                        for(var i = 0; i < findit.length; i++){
                                                            var this_key = findit[i].value;
                                                            categories_arr.push(this_key);
                                                        }

                                                        var series_data = [];

                                                        var top_row = document.getElementsByClassName('top_row');

                                                        for(var j=0;j<top_row.length;j++){
                                                            var k = j+1;
                                                            var row = 'row'+k;

                                                            console.log(row);

                                                            var row_arr = new Array();
                                                            var find_row = document.getElementsByClassName(row);

                                                            for (var i = 0; i < find_row.length; i++) {
                                                                var this_key = find_row[i].value;
                                                                row_arr.push(parseInt(this_key));
                                                            }
                                                            var find_id_row_value = document.getElementById(row).value;
                                                            var obj_row = {name: find_id_row_value, data: row_arr};
                                                            series_data.push(obj_row);

                                                        }

                                                        Highcharts.chart('container', {
                                                            chart: {
                                                                type: 'column'
                                                            },
                                                            title: {
                                                                text: this_title
                                                            },
                                                            subtitle: {
                                                                text: ''
                                                            },
                                                            xAxis: {
                                                                categories: categories_arr,
                                                                crosshair: true
                                                            },
                                                            yAxis: {
                                                                min: 0,
                                                                title: {
                                                                    text: 'Energy Unit (In GJ)'
                                                                }
                                                            },
                                                            tooltip: {
                                                                headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                                                                pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                                                                    '<td style="padding:0"><b>{point.y:.1f} GJ</b></td></tr>',
                                                                footerFormat: '</table>',
                                                                shared: true,
                                                                useHTML: true
                                                            },
                                                            plotOptions: {
                                                                column: {
                                                                    pointPadding: 0.2,
                                                                    borderWidth: 0
                                                                }
                                                            },
                                                            series: series_data
                                                        });
                                                    </script>

                                                    <?php */ ?>
                                                </div>
                                            </div>


                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>

                    <?php endif; ?>

                </div>


            </div>
        </div>
    </div>
</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend_layouts.frontend_federal_chart_layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>