@extends('frontend_layouts.user_dashboard_layout')
@section('content')
    <section id="horizontal-form-layouts">

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="horz-layout-colored-controls">Add Qualification Type</h4>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="card-content collpase show">
                        <div class="card-body">
                            <div class="card-text">
                                <p>Please fill all the required inputs</p>
                            </div>

                            <form action="{{url('/')}}/user/dashboard/qualificationtype/add" method="post" enctype="multipart/form-data">
                                <div class="form-body">
                                    <h4 class="form-section"><i class="la la-eye"></i> Qualification Type Details</h4>
                                @csrf
                                <div class="form-group">
                                    <p>Qualification Type Name</p>
                                    <input type="text" class="form-control border-primary" name="qualification_type_name" placeholder="Enter Qualification Type Name" required />
                                </div>
                                <div class="form-group">
                                    <p>Qualification Status</p>
                                    <input type="radio" name="status" value="Y"  /> Yes<br/>
                                    <input type="radio" name="status" value="N" checked/> No
                                </div>
                                <div class="form-actions right">
                                    <button type="button" class="btn btn-danger mr-1">
                                        <i class="ft-x"></i> Cancel
                                    </button>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="la la-check-square-o"></i> Save
                                    </button>
                                </div>
                                </div>
                            </form>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection