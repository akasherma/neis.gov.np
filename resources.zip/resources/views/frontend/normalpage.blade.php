@extends('frontend_layouts.frontend_layout')

@section('content')
    <div class="col-md-12">

        <section class="no-padding-bottom">

            <article class="post-detail-01">

                <div class="content">

                    <h4>{{ (!empty($this_page->page_name))?$this_page->page_name:'' }}</h4>
                    {!! (!empty($this_page->page_desc))?$this_page->page_desc:'' !!}
                </div>

            </article>

        </section>

    </div>

<!--end site header-->

@endsection