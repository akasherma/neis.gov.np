@extends('frontend_layouts.report_layout')
@section('content')
    <section id="horizontal-form-layouts">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="this_title">Historical Trend of Energy {{ $this_energy_type->energy_type_name }} [{{ $start }}/{{ $end }}]</h4>
                        <p>Energy Unit In Kilo GJ</p>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <?php
                    $permalink = $url;
                    ?>
                    <div class="card-content collpase show">
                        <div class="card-body row">
                            <div class="col-md-12 form-body-listing">
                                <div id="container" style="height:600px;"></div>

                                <div class="table-responsive">
                                    <table border="1" cellspacing="3" cellpadding="3">
                                        <tr>
                                            <th colspan="2">Fuel Type</th>
                                            <?php
                                            $col = array();
                                            $col_counter = 0;
                                            if(!empty($start)){
                                                for ($year = $start; $year < $end; $year++){
                                                    echo '<th><input type="hidden" class="x-axis" value="'.$year.'">'.$year.'</th>';
                                                    $col[$col_counter] = 0;
                                                    $col_counter++;
                                                }
                                                $col[$col_counter] = 0;


//                                                foreach($provinces as $the_province){
//                                                    echo '<th><input type="hidden" class="x-axis" value="'.$the_province->location_name.'">'.$the_province->location_name.'</th>';
//                                                }
                                            }
                                            ?>
                                            <th><input type="hidden" class="x-axis" value="Total">Total</th>
                                            <input type="hidden" id="start" value="{{$start}}">
                                        </tr>
                                        <?php
                                        $count = 1;
                                        $total = 0;
                                        if(!empty($final_result)){
                                        foreach($final_result as $key=>$value){
                                        $col_count = 0;
                                        ?>

                                        <tr class="top_row">
                                            <?php
                                            $this_key = (!empty($key))?explode('-', $key):array();
                                            ?>
                                            <td>
                                                {{ (is_array($this_key) && (!empty($this_key[0])))?$this_key[0]:'' }}
                                            </td>
                                            <td>
                                                {{ (is_array($this_key) && (!empty($this_key[1])))?ucwords(str_replace('_', ' ', $this_key[1])):'' }}
                                                <?php
                                                echo '<input type="hidden" id="row'.$count.'" value="'.((is_array($this_key) && (!empty($this_key[1])))?ucwords(str_replace('_', ' ', $this_key[1])):'').'">';
                                                ?>
                                            </td>
                                            <?php
                                            if(is_array($value)){
                                                foreach($value as $the_value){
                                                    $the_value_qty = (!empty($the_value))?(((float)$the_value)/1000):0;
//                                                    $col[$col_count] = (!empty($col[$col_count]))?((float)$col[$col_count]):0;

                                                    echo '<td><input type="hidden" class=" row'.$count.'" value="'.$the_value_qty.'">'.$the_value_qty.'</td>';
                                                    $total += $the_value_qty;
                                                    $col[$col_count] += $the_value_qty;
                                                    $col_count++;
                                                }
                                            }
                                            $count++;
                                            ?>
                                            <td>{{ $total }}</td>
                                        </tr>


                                        <?php
                                        }
                                        ?>

                                        <tr class="top_row">
                                            <td colspan="2">
                                                Total
                                                <?php
                                                echo '<input type="hidden" id="row'.$count.'" value="Total">';
                                                ?>
                                            </td>
                                            <?php
                                            $col_total = 0;
                                            $the_value_qty = 0;
                                            if(is_array($col)){
                                                foreach($col as $the_value){
                                                    $the_value_qty = (!empty($the_value))?$the_value:$the_value_qty;
                                                    echo '<td><input type="hidden" class=" row'.$count.'" value="'.$the_value_qty.'">'.$the_value_qty.'</td>';
                                                    $col_total += $the_value_qty;
                                                }
                                            }
                                            ?>
{{--                                            <td>{{ $col_total }}</td>--}}
                                        </tr>
                                        <?php
                                        }
                                        ?>
                                    </table>
                                </div>

                                <script>

                                    function getRandomInt(max) {
                                        return Math.floor(Math.random() * Math.floor(max));
                                    }

                                    var this_title = document.getElementById("this_title").innerHTML;



                                    var categories_arr = new Array();

                                    var findit = document.getElementsByClassName('x-axis');
                                    for(var i = 0; i < findit.length; i++){
                                        var this_key = findit[i].value;
                                        categories_arr.push(this_key);
                                    }

                                    var series_data = [];

                                    var top_row = document.getElementsByClassName('top_row');

                                    for(var j=0;j<top_row.length;j++){
                                        var k = j+1;
                                        var row = 'row'+k;

                                        var row_arr = new Array();
                                        var find_row = document.getElementsByClassName(row);

                                        for (var i = 0; i < find_row.length; i++) {
                                            var this_key = find_row[i].value;
                                            row_arr.push(parseInt(this_key));
                                        }
                                        var find_id_row_value = document.getElementById(row).value;
                                        var obj_row = {name: find_id_row_value, data: row_arr};
                                        series_data.push(obj_row);

                                    }

                                    var this_start = parseInt(document.getElementById('start').value);

                                    // console.log(this_start);

                                    // var series_data = [obj_row1, obj_row2, obj_row3, obj_row4, obj_row5, obj_row6];

                                    Highcharts.chart('container', {

                                        title: {
                                            text: this_title
                                        },

                                        subtitle: {
                                            text: ''
                                        },

                                        yAxis: {
                                            title: {
                                                text: 'Energy Unit (In Kilo GJ)'
                                            }
                                        },
                                        legend: {
                                            layout: 'vertical',
                                            align: 'right',
                                            verticalAlign: 'middle'
                                        },

                                        plotOptions: {
                                            series: {
                                                label: {
                                                    connectorAllowed: false
                                                },
                                                pointStart: this_start
                                            }
                                        },

                                        series: series_data,

                                        // series: [{
                                        //     name: 'Installation',
                                        //     data: [43934, 52503, 57177, 69658, 97031, 119931, 137133, 154175]
                                        // }, {
                                        //     name: 'Manufacturing',
                                        //     data: [24916, 24064, 29742, 29851, 32490, 30282, 38121, 40434]
                                        // }, {
                                        //     name: 'Sales & Distribution',
                                        //     data: [11744, 17722, 16005, 19771, 20185, 24377, 32147, 39387]
                                        // }, {
                                        //     name: 'Project Development',
                                        //     data: [null, null, 7988, 12169, 15112, 22452, 34400, 34227]
                                        // }, {
                                        //     name: 'Other',
                                        //     data: [12908, 5948, 8105, 11248, 8989, 11816, 18274, 18111]
                                        // }],

                                        responsive: {
                                            rules: [{
                                                condition: {
                                                    maxWidth: 500
                                                },
                                                chartOptions: {
                                                    legend: {
                                                        layout: 'horizontal',
                                                        align: 'center',
                                                        verticalAlign: 'bottom'
                                                    }
                                                }
                                            }]
                                        }

                                    });

                                </script>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection