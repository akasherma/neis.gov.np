@extends('frontend_layouts.report_layout')
@section('content')
    <section id="horizontal-form-layouts">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="horz-layout-colored-controls">Energy {{ $this_energy_type->energy_type_name }} Report For Fiscal Year [{{ $start }}/{{$end}}]</h4>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <?php

                    $in_array = array(
                        'production' => array('land_type', 'geographic_region', 'river' ),
                        'consumption' => array('sector', 'geographic_region', 'river' ),
                        'resources' => array('land_type', 'geographic_region', 'river' ),
                        'import' => array('' ),
                        'export' => array('' )
                    );

                    $this_in_array = (!empty($in_array[$this_energy_type->energy_type_slug]))?$in_array[$this_energy_type->energy_type_slug]:array();

//                    echo '<hr><pre>';
//                    print_r($this_in_array);
//                    echo '</pre><hr>';


                    $permalink = $url;
//                    $permalink = url('/').'/dashboard/entry-form';
//                    $permalink .= (!empty($this_province))?'/province/'.$this_province->location_slug:'';
//                    $permalink .= (!empty($this_district))?'/district/'.$this_district->location_slug:'';
//                    $permalink .= (!empty($this_local))?'/local/'.$this_local->location_slug:'';
//                    $permalink .= (!empty($start) && !empty($end))?'/fiscal-year/'.$start.'/'.$end:'';



                    ?>
                    <?php if(strpos($permalink, 'trend') === false && ($this_energy_type->energy_type_slug == 'import' || $this_energy_type->energy_type_slug == 'export')){
                        $new_permalink = str_replace('fiscal-year', 'trend', $permalink);
                        ?>
                    <div class="card-content collpase show">
                        <div class="card-body row">
                            <div class="col-md-12 col-sm-12 form-body-listing ">
                                <div>
                                    <h4>
                                        <a class="btn btn-md btn-outline-primary round" href="{{ $new_permalink.'/direct' }}">
                                            Trend of Energy {{ $this_energy_type->energy_type_name }}
                                            <br>
                                        </a>
                                    </h4>
                                </div>
                                <br>                                        &nbsp;
                            </div>

                        </div>
                    </div>
                    <hr>
                    <?php } ?>

                    <?php if(strpos($permalink, 'trend') === false) { ?>
                    <div class="card-content collpase show">
                        <div class="card-body row">
                            @if(!empty($energy_topics))
                                @foreach($energy_topics as $energy_list)
                                    @if(is_array($this_in_array) && in_array($energy_list, $this_in_array))
                                        <div class="col-md-12 col-sm-12 form-body-listing ">
                                            <div>
                                                <h4>
                                                    <a class="btn btn-md btn-outline-primary round" href="{{ $permalink.'/energy-topic/'.$energy_list }}/tabular">
                                                        Energy {{ $this_energy_type->energy_type_name }} By {{ ucwords(str_replace("_", " ",$energy_list)) }}
                                                        <br>
                                                    </a>
                                                </h4>
                                            </div>
                                            <br>                                        &nbsp;
                                        </div>
                                    @endif
                                @endforeach
                            @endif
                        </div>
                    </div>
                    <hr>
                    <?php } ?>
                    <div class="card-content collpase show">
                        <div class="card-body row">
                            @if(!empty($energy_topics))
                                @foreach($energy_topics as $energy_list)
                                    @if(is_array($this_in_array) && in_array($energy_list, $this_in_array))
                                    <div class="col-md-12 col-sm-12 form-body-listing ">
                                        <div>
                                            <h4>
                                                <a class="btn btn-md btn-outline-primary round" href="{{ $permalink.'/energy-topic/'.$energy_list }}/direct">
                                                    Total Energy {{ $this_energy_type->energy_type_name }} By {{ ucwords(str_replace("_", " ",$energy_list)) }}
                                                    <br>
                                                </a>
                                            </h4>
                                        </div>
                                        <br>                                        &nbsp;
                                    </div>
                                    @endif
                                @endforeach
                            @endif
                        </div>
                    </div>
                    <hr>
                    <?php if(strpos($permalink, 'trend') === false) { ?>
                    <div class="card-content collpase show">
                        <div class="card-body row">
                            @if(!empty($energy_topics))
                                @foreach($energy_topics as $energy_list)
                                    @if(is_array($this_in_array) && in_array($energy_list, $this_in_array))
                                    <div class="col-md-12 col-sm-12 form-body-listing ">
                                        <div>
                                            <h4>
                                                <a class="btn btn-md btn-outline-primary round" href="{{ $permalink.'/energy-topic/'.$energy_list }}">
                                                    Provincewise Energy {{ $this_energy_type->energy_type_name }} By {{ ucwords(str_replace("_", " ",$energy_list)) }}
                                                    <br>
                                                </a>
                                            </h4>
                                        </div>
                                        <br>                                        &nbsp;
                                    </div>
                                    @endif
                                @endforeach
                            @endif
                        </div>
                    </div>
                    <?php }else{
                    ?>
                        <div class="card-content collpase show">
                            <div class="card-body row">
                                <div class="col-md-12 col-sm-12 form-body-listing ">
                                    <div>
                                        <h4>
                                            <a class="btn btn-md btn-outline-primary round" href="{{ $permalink.'/direct' }}">
                                                Historical Trend of Energy {{ $this_energy_type->energy_type_name }} 
                                                <br>
                                                <br>
                                            </a>
                                        </h4>
                                    </div>
                                    <br>                                        &nbsp;
                                </div>
                            </div>
                        </div>

                    <?php
                    } ?>
                </div>
            </div>
        </div>
    </section>
@endsection