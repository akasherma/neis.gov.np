@extends('frontend_layouts.report_layout')
@section('content')
    <section id="horizontal-form-layouts">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="this_title">Total Energy {{ $this_energy_type->energy_type_name }} By {{ ucwords(str_replace("_", " ", $energy_topic)) }}s of Fiscal Year [{{ $start }}/{{ $end }}]</h4>
                        <input type="hidden" id="this_name" value="{{ ucwords(str_replace("_", " ", $energy_topic)) }}">
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <?php
                    $permalink = $url;
                    ?>
                    <div class="card-content collpase show">
                        <div class="card-body row">
                            <div class="col-md-12 form-body-listing">

                                <div id="container" style="height:500px;"></div>

                                <div class="table-responsive">
                                    <table border="1" cellspacing="3" cellpadding="3">
                                        <tr>
                                            <th>{{ ucwords(str_replace("_", " ", $energy_topic)) }}</th>
                                            <th>Energy Unit (In Kilo GJ)</th>
                                        </tr>

                                        <?php
                                        $count = 1;
                                        $col = array();
                                        if(!empty($final_result)){
                                            $total = 0;
                                            $col_count = 0;
                                            foreach($final_result as $key=>$value){
                                                ?>

                                                <tr class="top_row">
                                                    <th>
                                                        <a class="btn btn-primary" href="{{ url('/').'/report/'.$this_energy_type->energy_type_slug.'/'.$energy_topic.'/direct/'.$start.'/'.$end.'/'.$key }}">{{ ucwords(str_replace('_', ' ', $key)) }}</a>

                                                        <?php
                                                        $col[$col_count] = (!empty($col[$col_count]))?((float)$col[$col_count]):0;
                                                        echo '<input type="hidden" id="row'.$count.'" value="'.$key.'-'.(((float)$value->qty)/1000).'">';
                                                        ?>
                                                    </th>
                                                    <?php
                                                        echo '<td><input type="hidden" class=" row'.$count.'" value="'.(((float)$value->qty)/1000).'">'.(((float)$value->qty)/1000).'</td>';
                                                                $total += (((float)$value->qty)/1000);
                                                                $col[$col_count] += (((float)$value->qty)/1000);
                                                                $col_count++;


                                                        $count++;
                                                    ?>
                                                </tr>


                                        <?php
                                            }
                                        ?>

                                            <tr class="">
                                                <th>
                                                    Total
                                                    <?php
                                                    echo '<input type="hidden" id="row'.$count.'" value="Total">';
                                                    ?>
                                                </th>
                                                <td>{{ $total }}</td>
                                            </tr>
                                        <?php
                                        }
                                        ?>
                                    </table>
                                </div>

                                <script>

                                    function getRandomInt(max) {
                                        return Math.floor(Math.random() * Math.floor(max));
                                    }

                                    var this_title = document.getElementById("this_title").innerHTML;

                                    var this_name = document.getElementById("this_name").value;

                                    // var categories_arr = new Array();

                                    // var findit = document.getElementsByClassName('x-axis');
                                    // for(var i = 0; i < findit.length; i++){
                                    //     var this_key = findit[i].value;
                                    //     categories_arr.push(this_key);
                                    // }

                                    var series_data = [];

                                    var top_row = document.getElementsByClassName('top_row');

                                    for(var j=0;j<top_row.length;j++){
                                        var k = j+1;
                                        var row = 'row'+k;

                                        // console.log(row);

                                        var y_value = 0;
                                        var find_row = document.getElementsByClassName(row);

                                        var y_value = find_row[0].value;

                                        // for (var i = 0; i < find_row.length; i++) {
                                        //     var this_key = find_row[i].value;
                                        //     row_arr.push(parseInt(this_key));
                                        // }
                                        var find_id_row_value = document.getElementById(row).value;

                                        // console.log(row);

                                        // {
                                        //     name: 'Chrome',
                                        //         y: 61.41,
                                        //     sliced: true,
                                        //     selected: true
                                        // }

                                        if(k < 2)
                                            var obj_row = {name: find_id_row_value, y: parseFloat(y_value), sliced: true, selected: true};
                                        else
                                            var obj_row = {name: find_id_row_value, y: parseFloat(y_value)};

                                        series_data.push(obj_row);

                                    }

                                    // console.log(series_data);

                                    // return false;

                                    // var series_data = [obj_row1, obj_row2, obj_row3, obj_row4, obj_row5, obj_row6];

                                    Highcharts.chart('container', {
                                        chart: {
                                            plotBackgroundColor: null,
                                            plotBorderWidth: null,
                                            plotShadow: false,
                                            type: 'pie'
                                        },
                                        title: {
                                            text: this_title
                                        },
                                        tooltip: {
                                            pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
                                        },
                                        plotOptions: {
                                            pie: {
                                                allowPointSelect: true,
                                                cursor: 'pointer',
                                                dataLabels: {
                                                    enabled: true,
                                                    format: '<b>{point.name}</b>: {point.percentage:.1f} %'
                                                }
                                            }
                                        },
                                        series: [{
                                            name: this_name,
                                            colorByPoint: true,
                                            data: series_data
                                        }]
                                    });
                                </script>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection