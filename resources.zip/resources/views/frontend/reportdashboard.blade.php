@extends('frontend_layouts.user_dashboard_layout')

@section('content')

<div class="content-header row">
    <div class="content-header-left col-md-12 col-12">
        <h3 class="content-header-title">Report !!!</h3>
    </div>
</div>

<div class="row">

    <div class="clearfix"></div>
    @if(!empty($demand_entries))
        @foreach($demand_entries as $the_demand_entry)
        <div class="col-lg-4 col-md-12">
            <div class="row report">
                <div class="col-12">
                    <div class="card pull-up">
                        <div class="card-header">
                            <h4>
                                <a href="{{ url('/').'/user/dashboard/report/'.$the_demand_entry->entry_status_slug }}">
                                    {{ strtoupper($the_demand_entry->entry_status_name) }}
                                    <span class="badge badge-pill badge-info float-right m-0"><i class="fa fa-total"></i>{{ $the_demand_entry->status_cnt }}</span>
                                </a>
                            </h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @endforeach
    @endif
    <div class="col-lg-4 col-md-12">
        <div class="row report">
            <div class="col-12">
                <div class="card pull-up">
                    <div class="card-header">
                        <h4>
                            <a href="{{ url('/').'/user/dashboard/demandreport/' }}">Demand Report
                            </a>
                        </h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="clearfix"></div>
    @if(!empty($companies))
        <div class="col-lg-4 col-md-12">
            <div class="row">
                <div class="col-12">
                    <div class="card pull-up bg-gradient-directional-danger">
                        <div class="card-header bg-hexagons-danger">
                            <h4 class="card-title white">Analytics</h4>
                            <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                            <div class="heading-elements">
                                <ul class="list-inline mb-0">
                                    <li>
                                        <a class="btn btn-sm btn-white danger box-shadow-1 round btn-min-width pull-right" href="#" target="_blank">Report <i class="ft-bar-chart pl-1"></i></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="card-content collapse show bg-hexagons-danger">
                            <div class="card-body">
                                <div class="media d-flex">
                                    <div class="align-self-center width-100">
                                        <div id="Analytics-donut-chart" class="height-100 donutShadow"></div>
                                    </div>
                                    <div class="media-body text-right mt-1">
                                        <h3 class="font-large-2 white">###</h3>
                                        {{--<h6 class="mt-1"><span class="text-muted white">Analytics in the <a href="#" class="darken-2 white">last year.</a></span></h6>--}}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @endif
</div>
@endsection