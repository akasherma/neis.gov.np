@extends('frontend_layouts.datatables_list')
@section('content')
    <div class="app-content content">
      <div class="content-wrapper">
        <div class="content-body"><!-- Zero configuration table -->
<section id="configuration">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Candidate Lists <a href="{{url('/')}}/user/dashboard/candidate/add" class="btn btn-primary btn-xs">Add</a></h4>
                    <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                    <div class="heading-elements">
                        <ul class="list-inline mb-0">
                            {{--<li><a data-action="collapse"><i class="ft-minus"></i></a></li>--}}
                            <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                            <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            {{--<li><a data-action="close"><i class="ft-x"></i></a></li>--}}
                        </ul>
                    </div>
                </div>
                <div class="card-content collapse show">
                    <div class="table-responsive card-body card-dashboard">
                        <table class="table table-striped table-bordered zero-configuration">
                            <thead>
                                <tr>
                                    <th>Entry No</th>
                                    <th>Name</th>
                                    <th>PP No</th>
                                    <th>Company</th>
                                    <th>Job Applied For</th>
                                    <th>Status</th>
                                    <th>Reference</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @if(!is_null($candidates))
                                @foreach($candidates as $the_candidate)
                                <tr>
                                    <td>{{ $the_candidate->entry_reg_no }}</td>
                                    <td>{{ $the_candidate->first_name.' '.$the_candidate->middle_name.' '.$the_candidate->last_name }}</td>
                                    <td>{{ $the_candidate->passport_no }}</td>
                                    <td>{{ $the_candidate->company_applied_for_name }}</td>
                                    <td>{{ $the_candidate->position_name }}</td>

                                    <td>{{ (!empty($the_candidate->entry_status_name))?$the_candidate->entry_status_name:'Fresh Candidate' }}</td>
                                    <td>{{ $the_candidate->reference_name }}</td>
                                    <td>
                                        <a class="btn btn-primary" href="{{ url('/').'/user/dashboard/candidate/view/'.$the_candidate->id }}">View</a>
                                        <a class="btn btn-primary" href="{{ url('/').'/user/dashboard/candidate/edit/'.$the_candidate->id }}">Edit</a>
                                    </td>
                                </tr>
                                @endforeach
                                @endif
                            </tbody>
                            {{--<tfoot>--}}
                                {{--<tr>--}}
                                    {{--<th>Name</th>--}}
                                    {{--<th>Pre Approval Date</th>--}}
                                    {{--<th>Country</th>--}}
                                    {{--<th>Company</th>--}}
                                    {{--<th>Entry Status</th>--}}
                                    {{--<th>Action</th>--}}
                                {{--</tr>--}}
                            {{--</tfoot>--}}
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--/ Zero configuration table -->



        </div>
      </div>
    </div>
@endsection