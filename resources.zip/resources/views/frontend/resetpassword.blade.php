@extends('frontend_layouts.loginlayout')

@section('content')
<section class="flexbox-container">
    <div class="col-12 d-flex align-items-center justify-content-center">
        <div class="col-md-4 col-10 box-shadow-2 p-0">
            <div class="card border-grey border-lighten-3 px-2 py-2 m-0">               
                <div class="card-header border-0">
                    <div class="font-large-1  text-center">
                        Reset Password
                    </div>
                    <h6 class="card-subtitle line-on-side text-muted text-center font-small-3 pt-2">
                        <span>Please enter the New Password</span>
                    </h6>
                </div>
                
                @if(Session::has('error'))
                    <p class="alert {{ Session::get('alert-class', 'alert-danger') }}">{{ Session::get('error') }}</p>
                @endif

                @if(Session::has('success'))
                    <p class="alert alert-success">{{ Session::get('success') }}</p>
                @endif

                @if(Session::has('warning'))
                    <p class="alert {{ Session::get('alert-class', 'alert-warning') }}">{{ Session::get('warning') }}</p>
                @endif

                @if(Session::has('message'))
                    <p class="alert {{ Session::get('alert-class', 'alert-info') }}">{{ Session::get('message') }}</p>
                @endif

                <div class="card-content">
                    <div class="card-body">
                        <form class="form-horizontal" method="post" action="{{ url('/') }}/resetpwd" novalidate>
                            {{ csrf_field() }}
                            <input name="email" type="hidden" class="form-control" placeholder="Email Address" value="<?php echo $email; ?>">
                            <fieldset class="form-group position-relative has-icon-left">
                                <input type="password" name="password" class="form-control round" id="user-email" placeholder="Your New Password" required>
                                <div class="form-control-position">
                                    <i class="ft-mail"></i>
                                </div>
                            </fieldset>                            
                            <div class="form-group text-center">
                                    <button type="submit" class="btn round btn-block btn-glow btn-bg-gradient-x-purple-blue col-12 mr-1 mb-1">Submit</button>
                                </div>
                        </form>
                    </div>
                </div>
                <div class="card-footer border-0 p-0">
                    <p class="float-sm-center text-center">Not a member ?
                        <a href="{{ url('/') }}/signup" class="card-link">Sign Up</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection