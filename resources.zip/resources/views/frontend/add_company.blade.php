@extends('frontend_layouts.add_edit_form_layout')

@section('content')

	<div class="row">
            <div class="col-md-12">
	        <div class="card">
	            <div class="card-header">
	                <h4 class="card-title" id="horz-layout-colored-controls">Add Company</h4>
	                <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
        			<div class="heading-elements">
	                    <ul class="list-inline mb-0">
	                        <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
	                        <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
	                    </ul>
	                </div>
	            </div>
	            <div class="card-content collpase show">
	                <div class="card-body">
                            <div class="card-text">
                                    <p>Please fill all the required fields</p>
                            </div>
	                    <form class="form form-horizontal" method="post" action="{{ url('/')}}/user/dashboard/company/add">
	                    	@csrf
				

                                <input type="hidden" name="status" value="Y">
                                <div class="form-body">
                                    <h4 class="form-section"><i class="la la-eye"></i> Company Details</h4>
                                    <div class="row">
                                            <div class="col-md-8">
                                                <div class="form-group row">
                                                    <div class="col-md-12">
                                                        <p>Company Name</p>
                                                        <input type="text" class="form-control border-primary" placeholder="Company Name" name="company_applied_for_name" required>
                                                    </div>
                                                </div>
                                            </div>
											<div class="col-md-8">
												<div class="form-group row">
													<div class="col-md-12">
														<p>Company Description</p>
														<textarea class="form-control border-primary" placeholder="Company Description" name="company_applied_for_desc"></textarea>
													</div>
												</div>
											</div>
											<div class="col-md-8">
												<div class="form-group row">
													<div class="col-md-12">
														<p>Country</p>
														@if(!is_null($country_applied_for))
															<fieldset class="form-group">
																<select class="form-control" id="country_applied_for" name="country_id" required>
																	<option value="">Select Option</option>
																	@foreach($country_applied_for as $the_country)
                                                                        <?php $sel = ($the_country->id == $data->country_id)?'selected':''; ?>
																		<option value="{{$the_country->id}}" {{ $sel }}>{{$the_country->country_applied_for_name}}</option>
																	@endforeach
																</select>
															</fieldset>
														@endif
													</div>
												</div>
											</div>
                                    </div>
	                    		                                            
				</div>

	                        <div class="form-actions right">
	                            <button type="button" class="btn btn-danger mr-1">
	                            	<i class="ft-x"></i> Cancel
	                            </button>
	                            <button type="submit" class="btn btn-primary">
	                                <i class="la la-check-square-o"></i> Save
	                            </button>
	                        </div>
	                    </form>

	                </div>
	            </div>
	        </div>
	    </div>
	</div>

@endsection