@extends('frontend_layouts.record_layout')

@section('content')

    <section class="whatwer slider-container">

        <div class="rs-blog-details sec-spacer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-9">

                        <div class="sec-title">
                            <h3>Power Plant Station :: {{ ucwords(str_replace('-', ' ', $topic)) }}</h3>
                        </div>

                        {{--<img class="img-fluid img-responsive" src="{{ url('/').'/public/images/nepal-map.jpg' }}" alt="nepal-map.jpg">--}}

                        @if(!empty($data_map))
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped">
                                    <tr>
                                        <th>{{ ucwords(str_replace('-', ' ', $topic)) }} Name</th>
                                        <th>Description</th>
                                        <th>Address</th>
                                        <th>Installed Capacity</th>
                                        <th>Lat, Long</th>
                                    </tr>
                                    @foreach($data_map as $the_data)
                                        <tr>
                                            <td>{{$the_data->record_name}}</td>
                                            <td>{{$the_data->record_desc}}</td>
                                            <td>{{$the_data->address}}</td>
                                            <td>{{$the_data->capacity}}</td>
                                            <td>{{$the_data->lat.', '.$the_data->lang}}</td>
                                        </tr>
                                    @endforeach
                                </table>
                            </div>
                        @endif

                    </div>
                    <div class="col-md-3">

                        <div class="sec-title">
                            <h4 class="h-widget-title">Power Plant / Storage List</h4>
                        </div>

                        <div class="service-sidebar h-sidebar">
                            <div class="service-button">
                                <div class="block-service-style-05">
                                    @if(!empty($recordlist))
                                        <ul class="">
                                            @foreach($recordlist as $the_data)
                                                <li>
                                                    <a href="{{ url('/') }}/power-plant-storage?topic={{ $the_data->menu_slug}}">{{ $the_data->menu_name}}</a>
                                                </li>
                                            @endforeach
                                        </ul>
                                    @endif
                                    @if(!empty($data_map))
                                        @foreach($data_map as $the_data)
                                            <input type="hidden" class="producer_id" value="{{ $the_data->id}}">
                                            <input type="hidden" class="lat" value="{{ $the_data->lat}}">
                                            <input type="hidden" class="lng" value="{{ $the_data->lang}}">
                                            <?php
                                            $link_url = '';
//                                                $capacity = $the_data->capacity;
//                                                $unit = $the_data->unit;
//                                                $record_name = $the_data->record_name;
//                                                $record_desc = $the_data->record_desc;
//                                                $content = ($the_data->image != '')?'<img title="" alt="" src="'.url("/").'/public/images/'.$the_data->image.'" /><br />':'';
                                            $content = '<h4>'.$the_data->record_name.'</h4>';
                                            $content .= '<ul class="clearfix">';
                                            $content .= '<li><strong>Location: </strong>'.$the_data->address.'</li>';
                                            $content .= '<li><strong>Capacity: </strong>'.$the_data->capacity.' '.$the_data->unit.'</li>';
                                            $content .= '<li>'.$the_data->record_desc.'</li>';
                                            $content .= '</ul>';

                                            ?>
                                            <input type="hidden" class="content" value="{{ $content }}">
                                            <input type="hidden" class="link" value="{{ url('/') }}/power-plant-storage">
                                        @endforeach
                                    @endif

                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="clearfix"></div>
                </div>
            </div>
        </div>

        <div class="clearfix"></div>
    </section>

    <input type="hidden" id="color" value="">
    <script type="text/javascript" src="http://code.jquery.com/jquery-2.1.0.min.js"></script>
    {{--<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>--}}
    <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false&key=AIzaSyDEvOkk5CnZnx4h7eFW5Gd6aE15g5EwqCI"></script>
    <script type="text/javascript">
        var contentstring = [];
        var regionlocation = [];
        var markers = [];
        var iterator = 0;
        var areaiterator = 0;
        var map;
        var infowindow = [];

        geocoder = new google.maps.Geocoder();

        $(document).ready(function () {
            setTimeout(function() { initialize(); }, 400);
        });

        function initialize() {
            infowindow = [];
            markers = [];
            GetValues();
            iterator = 0;
            areaiterator = 0;
            region = new google.maps.LatLng(28.208497,84.3527265);
            map = new google.maps.Map(document.getElementById("map"), {
                zoom: 7,
                mapTypeId: google.maps.MapTypeId.ROADMAP,
                center: region,
            });
            drop();
        }


        // mapTypeId: google.maps.MapTypeId.ROADMAP,

        function GetValues() {
            //Get the Latitude and Longitude of a Point site : http://itouchmap.com/latlong.html

            // var contentstring = new Array();
            // var regionlocation = new Array();

            $('.producer_id').each(function(){
                var this_index = $('.producer_id').index($(this));
                var this_lat = $('.lat:eq('+this_index+')').attr("value");
                var this_lng = $('.lng:eq('+this_index+')').attr("value");
                var this_content = $('.content:eq('+this_index+')').attr("value");

                contentstring[this_index] = this_content;
                regionlocation[this_index] = this_lat + ", " + this_lng;

            });

        }

        function drop() {
            for (var i = 0; i < contentstring.length; i++) {
                setTimeout(function() {
                    addMarker();
                }, 800);
            }
        }

        function addMarker() {
            var color = document.getElementById('color').value;

            color = (color != 'green')?color:'green';

            var address = contentstring[areaiterator];
            // var icons = 'http://maps.google.com/mapfiles/ms/icons/'+color+'-dot.png';

            var icons = 'http://maps.google.com/mapfiles/arrow.png';

            var templat = regionlocation[areaiterator].split(',')[0];
            var templong = regionlocation[areaiterator].split(',')[1];
            var temp_latLng = new google.maps.LatLng(templat, templong);
            markers.push(new google.maps.Marker(
                {
                    position: temp_latLng,
                    map: map,
                    icon: icons,
                    draggable: true,
                    animation: google.maps.Animation.DROP,
                }));
            iterator++;
            info(iterator);
            areaiterator++;
        }

        function info(i) {
            infowindow[i] = new google.maps.InfoWindow({
                content: contentstring[i - 1]
            });
            infowindow[i].content = contentstring[i - 1];

            // infowindow[1].open(map, markers[0]);

            google.maps.event.addListener(markers[i - 1], 'mouseover', function() {
                for (var j = 1; j < contentstring.length + 1; j++) {
                    infowindow[j].close();
                }
                infowindow[i].open(map, markers[i - 1]);
            });
        }
    </script>

@endsection