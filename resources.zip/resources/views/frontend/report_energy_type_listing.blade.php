@extends('frontend_layouts.report_layout')
@section('content')
    <section id="horizontal-form-layouts">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="horz-layout-colored-controls">Energy Report</h4>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <?php
                    $permalink = $url;
//                    $permalink = url('/').'/dashboard/entry-form';
//                    $permalink .= (!empty($this_province))?'/province/'.$this_province->location_slug:'';
//                    $permalink .= (!empty($this_district))?'/district/'.$this_district->location_slug:'';
//                    $permalink .= (!empty($this_local))?'/local/'.$this_local->location_slug:'';

//                    echo $permalink;

                    ?>
                    <div class="card-content collpase show">
                        <div class="card-body row">
                            @if(!empty($energy_types))
                                @foreach($energy_types as $energy_type)
                                    <div class="col-md-4 col-sm-6 form-body-listing ">
                                        <div>
                                            <h4>
                                                <a class="btn btn-md btn-outline-primary round" href="{{ $permalink.'/'.$energy_type->energy_type_slug }}"> Energy {{ $energy_type->energy_type_name }}</a>
                                            </h4>
                                        </div>
                                        <br>
                                    </div>
                                @endforeach
                            @endif
                            <?php if(strpos($permalink, 'trend') === false) { ?>
                            <div class="col-md-6 col-sm-6 form-body-listing ">
                                <div>
                                    <h4>
                                        <a class="btn btn-md btn-outline-primary round" href="{{ $permalink.'/energy-supply-demand-balance' }}"> Nepal Energy Supply Demand Balance</a>
                                    </h4>
                                </div>
                                <br>
                            </div>
                            <?php } ?>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection