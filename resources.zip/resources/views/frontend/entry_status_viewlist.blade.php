@extends('frontend_layouts.datatables_list')
@section('content')
    <div class="app-content content">
      <div class="content-wrapper">
        <div class="content-body"><!-- Zero configuration table -->
<section id="configuration">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Report Lists For {{ $entry_status_name }}</h4>
                    <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                    <div class="heading-elements">
                        <ul class="list-inline mb-0">
                            <li><a href="{{ url('/').'/user/dashboard/report' }}">Export to Excel</a></li>
                            {{--<li><a data-action="collapse"><i class="ft-minus"></i></a></li>--}}
                            <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                            <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            {{--<li><a data-action="close"><i class="ft-x"></i></a></li>--}}
                        </ul>
                    </div>
                </div>
                <div class="clearfix"></div>
                <div class="row search_list" style="margin: 0;">
                    <div class="col-12 ">
                        <div class="card-content collapse show">
                            <div class="table-responsive card-body card-dashboard">
                                <table class="table table-striped table-bordered zero-configuration">
                                    <thead>
                                        <tr>
                                            <th>&nbsp;</th>
                                            <th>Name</th>
                                            <th>PP No.</th>
                                            @if(!empty($table_fields))
                                                @foreach($table_fields as $table_field)
                                                    <th>{{ $table_field->entry_status_label }}</th>
                                                @endforeach
                                            @endif
                                            <th>Company</th>
                                            <th>Demand Ref.</th>
                                            <th>Position</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @if(!is_null($candidates))
                                        @foreach($candidates as $the_candidate)
                                        <tr>
                                            <td><input type="checkbox" name="candidate_id" value="{{ $the_candidate['id'] }}" title="{{ $the_candidate["first_name"].' '.$the_candidate["middle_name"].' '.$the_candidate["last_name"] }}" class="candidate_id_click" ></td>
                                            <td>{{ $the_candidate["first_name"].' '.$the_candidate["middle_name"].' '.$the_candidate["last_name"] }}</td>
                                            <td>{{ $the_candidate["passport_no"] }}</td>
                                            @if(!empty($table_fields))
                                                @foreach($table_fields as $table_field)
                                                    <?php
//                                                    echo '<pre>';
//                                                    print_r($table_field);
//                                                    echo '</pre>';
                                                    ?>
                                                    <td>{{ (!empty($the_candidate[$table_field->entry_status_key]))?$the_candidate[$table_field->entry_status_key]:'' }}</td>
                                                @endforeach
                                            @endif
                                            <td>{{ $the_candidate["company_applied_for_name"] }}</td>
                                            <td>{{ $the_candidate["demand_no"] }}</td>
                                            <td>{{ $the_candidate["position_name"] }}</td>
                                            <td><a class="btn btn-primary" href="{{ url('/').'/user/dashboard/candidate/edit/'.$the_candidate["id"] }}">Edit</a></td>
                                        </tr>
                                        @endforeach
                                        @endif
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div> {{-- col-10--}}
                </div>
            </div>
        </div>
    </div>
</section>
<!--/ Zero configuration table -->
        </div>
      </div>
    </div>

    <script>
        $(document).ready(function(){

            $('.candidate_id_click').on('click', function(){
                var value_candidate_id = $(this).val();
                var candidate_name = $(this).attr('title');
                if($(this).prop('checked') != false){

                    // data-toggle="modal" disabled="disabled"

                    $('.entry_status_modal form').append('<input type="hidden" name="candidate_ids[]" value="'+value_candidate_id+'">');

                    $('.entry_status_btn').each(function(){
                        $(this).attr("data-toggle", "modal").removeClass("disabled");
                        $(this).removeAttr("onclick");
                    });

                    $('#visa_entry_tr').after('<tr id="candidate_id_'+value_candidate_id+'">' + '<td><input type="hidden" name="visa_status[candidate_id][]" value="'+value_candidate_id+'">'+candidate_name+'</td>' + '<td><input type="text" name="visa_status[entry_permit_no][]" value=""></td>' + '<td><input type="date" name="visa_status[date_of_issue][]" value=""></td>\n' +
'<td><input type="date" name="visa_status[valid_upto][]" value=""></td>' + '<td><input type="text" name="visa_status[uid_no][]" value=""></td>' + '<td><textarea name="visa_status[remarks][]"></textarea></td>' + '</tr>');

                }else{
                    $('.entry_status_modal form input[value="'+value_candidate_id+'"]').remove();
                    $('#candidate_id_'+value_candidate_id).remove();

                    var checked_no = $('.sorting_1 input:checked');
                    // alert(checked_no.length);
                    if(checked_no.length < 1){
                        $('.entry_status_btn').each(function(){
                            $(this).removeAttr("data-toggle").addClass("disabled");
                            $(this).attr("onclick", "alert('Please tick the checkbox of appropriate candidate first! ');");
                            // onclick="alert('Please tick the checkbox of appropriate candidate first! ');"
                        });
                    }
                    // return false;
                }

                // alert('two');
                // alert('<input type="hidden" name="candidate_ids[]" value="'+$(this).val()+'">');
                // alert($(this).prop('checked'));
                // alert($(this).val());
                // return false;

            });

            // $("button.disabled").on('click', function(){
            //     alert('Please tick the checkbox of appropriate candidate first! ');
            // });

            $('.modal-dialog button[type="submit"]').on('click', function(ev){
                var find_this = $('.entry_status_modal input[type="hidden"]');
                if(find_this.length > 0){
                    return true;
                }else{
                    alert('Choose atleast one candidate!');
                    ev.preventDefault();
                    return false;
                }
            });

            $('#entry_status_btn_visa').on('click', function(){
                var len = $('.candidate_id_click:checked').length;
                if(len > 0){
                    $('#visa_for').toggle();
                }else{
                    alert('Please tick the checkbox of appropriate candidate first! ');
                }
                // alert('asdfsa'+len);
            });

        });
    </script>

@endsection