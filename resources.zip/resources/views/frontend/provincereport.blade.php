﻿@extends('frontend_layouts.frontend_layout')

@section('content')

    <div class="col-md-9">

        <section class="no-padding-bottom">

            <article class="post-detail-01">

                <div class="content">


                    <h4>This report is under testing.</h4>

                    <p style="text-align: justify;">All the data needs to be validated. Final version of the data with appropriate charts will be ready within this fiscal year 078/079</p>

                    <p>Please <a href="{{ url('/') }}/dashboard/reportnew/">login</a> for more details.</p>

                </div>

            </article>

        </section>

    </div>
    <div class="col-md-3">

        @include('frontend_layouts.inc.front_sidebar')
    </div>

@endsection