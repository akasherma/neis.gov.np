@extends('frontend_layouts.add_edit_form_layout')

@section('content')

	<div class="row">
		<div class="col-md-12">
	        <div class="card">
	            <div class="card-header">
	                <h4 class="card-title" id="horz-layout-colored-controls">Add Entry Status</h4>
	                <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
        			<div class="heading-elements">
	                    <ul class="list-inline mb-0">
	                        <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
	                        <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
	                    </ul>
	                </div>
	            </div>
	            <div class="card-content collpase show">
	                <div class="card-body">
                            <div class="card-text">
                                    <p>Please fill all the required fields</p>
                            </div>
	                    <form class="form form-horizontal" method="post" action="{{ url('/')}}/user/dashboard/entry_status/{{$route}}">
	                    	@csrf

							<input type="hidden" class="form-control border-primary" value="{{$data->id}}" name="formdata[id]">

							<div class="form-body">
								<h4 class="form-section"><i class="la la-eye"></i> Status Update Details</h4>
								<div class="row">
										<div class="col-md-8">
											<div class="form-group row">
												<div class="col-md-12">
													<p>Entry Status  Name</p>
													<input type="text" class="form-control border-primary" placeholder="Entry Status Name" value="{{$data->entry_status_name}}" name="formdata[entry_status_name]" required>
												</div>
											</div>
										</div>
										<div class="col-md-8">
											<div class="form-group row">
												<div class="col-md-12">
													<p>Entry Status Description</p>
													<textarea class="form-control border-primary" placeholder="entry_status Description" name="formdata[entry_status_desc]">{{$data->entry_status_desc}}</textarea>
												</div>
											</div>
										</div>
										<div class="col-md-8">
											<div class="form-group row">
												<div class="col-md-12">
													<p>Entry Status Order</p>
													<input type="number" class="form-control border-primary" placeholder="1" value="{{$data->entry_status_order}}" name="formdata[entry_status_order]" />
												</div>
											</div>
										</div>
								</div>

							</div>

	                        <div class="form-actions right">
	                            <button type="button" class="btn btn-danger mr-1">
	                            	<i class="ft-x"></i> Cancel
	                            </button>
	                            <button type="submit" class="btn btn-primary">
	                                <i class="la la-check-square-o"></i> Save
	                            </button>
	                        </div>
	                    </form>

	                </div>
	            </div>
	        </div>
	    </div>
	</div>

@endsection