@extends('frontend_layouts.add_edit_form_layout')

@section('content')

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title" id="horz-layout-colored-controls"><a href="{{ url('/') }}/user/dashboard/candidate/add">Add Another Candidate</a></h4>
                <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                    <ul class="list-inline mb-0">
                        <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                        <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="card-content collpase show">
                <div class="card-body">
                    <div class="card-text">
                            <p>Please fill all the required inputs</p>
                    </div>
                    <form action="{{url('/')}}/user/dashboard/candidate/update" method="post" class="form form-horizontal" enctype="multipart/form-data">
                        @csrf
                        <input type="hidden" name="formdata[id]" value="{{ $candidate_entry->id }}">
                        <div class="form-body">
                                <h4 class="form-section"><i class="la la-eye"></i> Candidate Details</h4>
                                <?php if($candidate_entry->entry_reg_no != ''): ?>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group row">
                                            <div class="col-md-12">
                                                <p>Entry Register Number</p>
                                                <input type="text" id="entry_reg_no" class="form-control border-primary" placeholder="" name="formdata[entry_reg_no]" value="{{ $candidate_entry->entry_reg_no }}" required>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endif; ?>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group row">
                                            <div class="col-md-12">
                                                <p>Passport Number <span id="checkppno" style="color: red;"></span></p>
                                                <input type="text" id="ppno" class="form-control border-primary" placeholder="" name="formdata[passport_no]" value="{{ $candidate_entry->passport_no }}" required>
                                            </div>
                                        </div>
                                    </div>
                                    <?php /*
                                    <div class="col-md-4">
                                        <div class="form-group row">
                                            <div class="col-md-12">
                                                <p>Demand</p>
                                                @if(!empty($demands))
                                                    <fieldset class="form-group">
                                                        <select class="form-control" id="demand_id" name="formdata[demand_id]">
                                                            <option value="">Select Demand No</option>
                                                            @foreach($demands as $the_demand)
                                                                <?php $sel = ($candidate_entry->demand_id == $the_demand->id)?'selected':''; ?>
                                                                <option value="{{$the_demand->id}}" {{ $sel }}>{{$the_demand->demand_no}} </option>
                                                            @endforeach
                                                        </select>
                                                    </fieldset>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    */ ?>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group row">
                                            <div class="col-md-12">
                                                <p>Last Name</p>
                                                <input type="text" id="" class="form-control border-primary" placeholder="Last Name" name="formdata[last_name]" value="{{ $candidate_entry->last_name }}"  required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group row">
                                            <div class="col-md-12">
                                                <p>First Name</p>
                                                <input type="text" id="" class="form-control border-primary" placeholder="First Name" name="formdata[first_name]" value="{{ $candidate_entry->first_name }}" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group row">
                                            <div class="col-md-12">
                                                <p>Middle Name</p>
                                                <input type="text" id="" class="form-control border-primary" placeholder="Middle Name" name="formdata[middle_name]" value="{{ $candidate_entry->middle_name }}">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group row">
                                            <div class="col-md-12 date_field">
                                                <p>Date of Birth</p>
                                                <?php
                                                $dob = (!empty($candidate_entry->dob))?explode('-', $candidate_entry->dob):array();
                                                $dob_y = (!empty($dob[0]))?$dob[0]:'';
                                                $dob_m = (!empty($dob[1]))?$dob[1]:'';
                                                $dob_d = (!empty($dob[2]))?$dob[2]:'';
                                                ?>
                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <input type="number" id="" maxlength="2" min="1" max="31" class="form-control border-primary" placeholder="dd" name="formdata[dob_d]" value="{{ $dob_d }}" required>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <input type="number" id="" maxlength="2" min="1" max="12" class="form-control border-primary" placeholder="mm" name="formdata[dob_m]" value="{{ $dob_m }}" required>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <input type="number" id="" maxlength="4" min="1" max="<?php echo ((int)date('Y') - 18 ); ?>" class="form-control border-primary" placeholder="yyyy" name="formdata[dob_y]" value="{{ $dob_y }}" required>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group row">
                                            <div class="col-md-12">
                                                <p>Gender</p>
                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <input type="radio" id="" class="form-control" placeholder="" name="formdata[gender]" value="Male" <?php echo ($candidate_entry->gender == 'Male')?'checked':''; ?>> Male
                                                    </div>
                                                    <div class="col-md-8">
                                                        <input type="radio" id="" class="form-control" placeholder="" name="formdata[gender]" value="Female" <?php echo ($candidate_entry->gender == 'Female')?'checked':''; ?>> Female
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                        <div class="col-md-4">
                                            <div class="form-group row">
                                                <div class="col-md-12">
                                                    <p>Place of Birth</p>
                                                    <?php
                                                    $districts = array('Achham','Arghakhanchi','Baglung','Baitadi','Bajhang','Bajura','Banke','Bara','Bardiya','Bhaktapur','Bhojpur','Chitwan','Dadeldhura','Dailekh','Dang','Darchula','Dhading','Dhankutta','Dhanusa','Dolkha','Dolpa','Doti','Gorkha','Gulmi','Humla','Ilam','Jajarkot','Jhapa','Jumla','Kailali','Kalikot','Kanchanpur','Kapilvastu','Kaski','Kathmandu','Kavreplanchauk','Khotang','Lalitpur','Lamjung','Mahottari','Makwanpur','Manag','Morang','Mugu','Mustang','Myagdi','Nawalpur','Nuwakot','Okhaldunga','Palpa','Panchthar','Parasi','Parsa','Parwat','Pyuthan','Ramechhap','Rasuwa','Rauthat','Rolpa','Rukum Paschim','Rukum Purba','Rupandehi','Salyan','Sankhuwasabha','Saptari','Sarlahi','Sindhuli','Sindhupalchauk','Siraha','Solukhumbu','Sunsari','Surkhet','Syangja','Tanahun','Taplejung','Terhathum','Udaypur');
                                                    ?>
                                                    <select name="formdata[place_of_issue]" id="" class="form-control border-primary"  required>
                                                        @for($i=0; $i< 77; $i++)
                                                            <?php $sel = ($candidate_entry->place_of_issue == $districts[$i])?'selected':''; ?>
                                                            <option value="{{$districts[$i]}}" {{ $sel }}>{{$districts[$i]}}</option>
                                                        @endfor
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    <input type="hidden" name="issuing_authority" value="MOFA, DEPARTMENT OF PASSPORT" />
                                        <div class="col-md-4">
                                            <div class="form-group row">
                                                <div class="col-md-12 date_field">
                                                    <p>Passport Issue Date</p>
                                                    <?php
                                                    $passport_issue_date = (!empty($candidate_entry->passport_issue_date))?explode('-', $candidate_entry->passport_issue_date):array();
                                                    $passport_issue_date_y = (!empty($passport_issue_date[0]))?$passport_issue_date[0]:'';
                                                    $passport_issue_date_m = (!empty($passport_issue_date[1]))?$passport_issue_date[1]:'';
                                                    $passport_issue_date_d = (!empty($passport_issue_date[2]))?$passport_issue_date[2]:'';
                                                    ?>
                                                    <div class="row">
                                                        <div class="col-md-4">
                                                            <input type="number" title="passport_expiry_date_d" id="passport_issue_date_d" min="1" max="31" maxlength="2" class="form-control border-primary" placeholder="dd" name="formdata[passport_issue_date_d]" value="{{ $passport_issue_date_d }}" required>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <input type="number" title="passport_expiry_date_m" id="passport_issue_date_m" min="1" max="12" maxlength="2" class="form-control border-primary" placeholder="mm" name="formdata[passport_issue_date_m]" value="{{ $passport_issue_date_m }}" required>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <input type="number" title="passport_expiry_date_y" id="passport_issue_date_y" min="1" max="<?php echo ((int)date('Y')); ?>" maxlength="4" class="form-control border-primary" placeholder="yyyy" name="formdata[passport_issue_date_y]" value="{{ $passport_issue_date_y }}" required>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group row">
                                                    <div class="col-md-12">
                                                        <p>Passport Expiry Date</p>
                                                        <?php
                                                        $passport_expiry_date = (!empty($candidate_entry->passport_expiry_date))?explode('-', $candidate_entry->passport_expiry_date):array();
                                                        $passport_expiry_date_y = (!empty($passport_expiry_date[0]))?$passport_expiry_date[0]:'';
                                                        $passport_expiry_date_m = (!empty($passport_expiry_date[1]))?$passport_expiry_date[1]:'';
                                                        $passport_expiry_date_d = (!empty($passport_expiry_date[2]))?$passport_expiry_date[2]:'';
                                                        ?>
                                                        <div class="row">
                                                            <div class="col-md-4">
                                                                <input type="number" id="passport_expiry_date_d" maxlength="2" class="form-control border-primary" placeholder="dd" name="formdata[passport_expiry_date_d]" value="{{ $passport_expiry_date_d }}" required>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <input type="number" id="passport_expiry_date_m" maxlength="2" class="form-control border-primary" placeholder="mm" name="formdata[passport_expiry_date_m]" value="{{ $passport_expiry_date_m }}" required>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <input type="number" id="passport_expiry_date_y" maxlength="4" class="form-control border-primary" placeholder="yyyy" name="formdata[passport_expiry_date_y]" value="{{ $passport_expiry_date_y }}" required>
                                                            </div>
                                                        </div>
                                                    </div>
                                            </div>
                                        </div>
                                </div>
                                    <hr>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group row">
                                                <div class="col-md-12">
                                                <p>Next of Keen</p>
                                                <input type="text" id="userinput1" class="form-control border-primary" placeholder="Next of Keen" name="formdata[next_to_kin]" value="{{ $candidate_entry->next_to_kin }}" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group row">
                                                <div class="col-md-12">
                                                <p>Relation to Next of keen</p>
                                                <input type="text" id="userinput2" class="form-control border-primary" placeholder="Relation to Next of keen" name="formdata[relation_with_kin]" value="{{ $candidate_entry->relation_with_kin }}" required>
                                                </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group row">
                                            <div class="col-md-12">
                                                <p>Permanent Address</p>
                                                <input type="text" id="userinput2" class="form-control border-primary" placeholder="Permanent Address" name="formdata[address]" value="{{ $candidate_entry->address }}">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group row">
                                            <div class="col-md-12">
                                                <p>Contact Number</p>
                                                <input type="text" id="userinput2" class="form-control border-primary" placeholder="Contact Number" name="formdata[contact_no]" value="{{ $candidate_entry->contact_no }}">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group row">
                                            <div class="col-md-12">
                                                <p>Email</p>
                                                <input type="email" id="userinput2" class="form-control border-primary" placeholder="Email" name="formdata[email]" value="{{ $candidate_entry->email }}">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                    <hr>
                                <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group row">
                                                    <div class="col-md-12">
                                                    <p>Country Applied For</p>
                                                    @if(!is_null($country_applied_for))
                                                    <fieldset class="form-group">
                                                        <select class="form-control" id="country_applied_for" name="formdata[country_applied_for]" value="{{ $candidate_entry->country_applied_for }}" required>
                                                          <option value="">Select Option</option>
                                                          @foreach($country_applied_for as $the_country)
                                                            <?php $sel = ($candidate_entry->country_applied_for == $the_country->id)?'selected':''; ?>
                                                            <option value="{{$the_country->id}}" {{ $sel }}>{{$the_country->country_applied_for_name}}</option>
                                                          @endforeach
                                                        </select>
                                                    </fieldset>
                                                    @endif
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group row">
                                                <div class="col-md-12">
                                                    <p>Company Applied For</p>
                                                    @if(!is_null($country_applied_for))
                                                    <fieldset class="form-group">
                                                        <select class="form-control select_one" title="company_applied_for" id="company_applied_for" name="formdata[company_applied_for]" required>
                                                              <option value="">Select Option</option>
                                                              @foreach($company_applied_for as $the_company)
                                                                <?php $sel = ($candidate_entry->company_applied_for == $the_company->id)?'selected':''; ?>
                                                                <option value="{{$the_company->id}}" {{ $sel }}>{{$the_company->company_applied_for_name}}</option>
                                                              @endforeach
                                                              <option value="0">Enter New</option>
                                                        </select>
                                                    </fieldset>
                                                    @endif
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group row">
                                                <div class="col-md-12">
                                                <p>Position/Job Category</p>
                                                @if(!empty($position))
                                                <fieldset class="form-group ">
                                                    <select class="form-control select_one" title="position" id="position_applied_for" name="formdata[position_applied_for]" required>
                                                          <option value="">Select Option</option>
                                                          @foreach($position as $the_position)
                                                                <?php $sel = ($candidate_entry->position_applied_for == $the_position->id)?'selected':''; ?>
                                                             <option value="{{$the_position->id}}" {{ $sel }}>{{$the_position->position_name}}</option>
                                                          @endforeach
                                                          <option value="0">Enter New</option>
                                                    </select>
                                                </fieldset>
                                                @endif
                                                </div>
                                            </div>
                                        </div>
                                </div>
                                <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group row">
                                                    <div class="col-md-12">
                                                    <p>Referred By</p>
                                                    @if(!empty($reference_list))
                                                    <fieldset class="form-group">
                                                        <select class="form-control select_one" title="reference" id="reference" name="formdata[reference_by]" required>
                                                            <option value="">Select Option</option>
                                                            @foreach($reference_list as $the_reference)
                                                                <?php $sel = ($candidate_entry->reference_by == $the_reference->id)?'selected':''; ?>
                                                                <option value="{{$the_reference->id}}" {{ $sel }}>{{$the_reference->reference_name}}</option>
                                                            @endforeach
                                                            <option value="0">Enter New</option>
                                                        </select>
                                                    </fieldset>
                                                    @endif
                                                    </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group row">
                                                    <div class="col-md-12">
                                                    <p>Entry Status</p>
                                                    <fieldset class="form-group">
                                                        <select class="form-control" id="entry_status" name="formdata[entry_status]">
                                                            <option value="">Fresh Candidate</option>
                                                            @foreach($entry_status as $the_status)
                                                                <?php $sel = ($candidate_entry->entry_status == $the_status->id)?'selected':'style="display:none;"'; ?>
                                                                <option value="{{$the_status->id}}" <?php echo $sel?>>{{$the_status->entry_status_name}}</option>
                                                            @endforeach
                                                        </select>
                                                    </fieldset>
                                                    </div>
                                            </div>
                                        </div>
                                </div>
                                    <hr>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">

                                            {{--accordians--}}
                                            <div class="panel-group" id="accordion">
                                                <div class="panel panel-default">
                                                    <div class="panel-heading">
                                                        <h4 class="panel-title">
                                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse1" class="" aria-expanded="true">
                                                                Educational Qualification</a>
                                                        </h4>
                                                    </div>
                                                    <div id="collapse1" class="panel-collapse collapse in show">
                                                        <div class="panel-body">
                                                            <div class="row">
                                                                <div class="col-md-12">
                                                                    <div class="form-group row">
                                                                        <div class="col-md-12">
                                                                            <div class="form-group col-12 file-repeater">
                                                                                <div data-repeater-list="repeater-list">
                                                                                    <div data-repeater-item="">
                                                                                        <div class="row ">
                                                                                            <?php
                                                                                                $count = 1;
                                                                                            if(!empty($qualifications)){
                                                                                                foreach($qualifications as $the_qualification){

                                                                                            ?>
                                                                                            <div class="col-md-10 repeater-block3" id="{{ 'qualification_'.$count }}">
                                                                                                <div class="row">
                                                                                                    <div class="col-md-3">
                                                                                                        @if(!empty($qualification_type))
                                                                                                            <select class="form-control border-primary" name="qualification[qualification_type_id][]" id="">
                                                                                                                <option value="">Select Option</option>
                                                                                                                @foreach($qualification_type as $the_qualification_type)
                                                                                                                    <?php $sel = ($the_qualification->qualification_type_id == $the_qualification_type->id)?'selected':''; ?>
                                                                                                                    <option value="{{$the_qualification_type->id}}" {{ $sel }}>{{$the_qualification_type->qualification_type_name}}</option>
                                                                                                                @endforeach
                                                                                                            </select>
                                                                                                        @endif
                                                                                                    </div>
                                                                                                    <div class="col-md-3">
                                                                                                        <input type="text" id="" class="form-control border-primary" placeholder="Board" name="qualification[board][]" value="{{ $the_qualification->board }}">
                                                                                                    </div>
                                                                                                    <div class="col-md-2">
                                                                                                        <input type="text" id="" class="form-control border-primary" placeholder="Year" name="qualification[year][]" value="{{ $the_qualification->year }}">
                                                                                                    </div>
                                                                                                    <div class="col-md-2">
                                                                                                        <input type="text" id="" class="form-control border-primary" placeholder="Division" name="qualification[division][]" value="{{ $the_qualification->division }}">
                                                                                                    </div>
                                                                                                    <div class="col-md-2">
                                                                                                        <button type="button" data-repeater-create="" name="{{ 'qualification_'.$count }}" id="" class="minus_btn_this btn btn-danger">
                                                                                                            <i class="ft-plus"></i> Remove This
                                                                                                        </button>
                                                                                                    </div>
                                                                                                </div>
                                                                                                <br>
                                                                                            </div>
                                                                                                <?php
                                                                                                    $count++;
                                                                                                }
                                                                                                    }
                                                                                                ?>
                                                                                            <div class="col-md-10 repeater-block3">
                                                                                                <div class="row">
                                                                                                    <div class="col-md-3">
                                                                                                        @if(!empty($qualification_type))
                                                                                                            <select class="form-control border-primary" name="qualification[qualification_type_id][]" id="">
                                                                                                                <option value="">Select Option</option>
                                                                                                                @foreach($qualification_type as $the_qualification_type)
                                                                                                                    <option value="{{$the_qualification_type->id}}">{{$the_qualification_type->qualification_type_name}}</option>
                                                                                                                @endforeach
                                                                                                            </select>
                                                                                                        @endif
                                                                                                    </div>
                                                                                                    <div class="col-md-3">
                                                                                                        <input type="text" id="" class="form-control border-primary" placeholder="Board" name="qualification[board][]">
                                                                                                    </div>
                                                                                                    <div class="col-md-3">
                                                                                                        <input type="text" id="" class="form-control border-primary" placeholder="Year" name="qualification[year][]">
                                                                                                    </div>
                                                                                                    <div class="col-md-3">
                                                                                                        <input type="text" id="" class="form-control border-primary" placeholder="Division" name="qualification[division][]">
                                                                                                    </div>
                                                                                                </div>
                                                                                                <br>
                                                                                            </div>
                                                                                            <div class="col-md-2">
                                                                                                <button type="button" data-repeater-create="" name="repeater-block3" id="" class="minus_btn btn btn-danger">
                                                                                                    <i class="ft-plus"></i> Remove This
                                                                                                </button>
                                                                                            </div>

                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>

                                                                            <button type="button" data-repeater-create="" id="" name="repeater-block3" class="add_more btn btn-primary">
                                                                                <i class="ft-plus"></i> Add More Qualification
                                                                            </button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <hr>
                                                <div class="panel panel-default">
                                                    <div class="panel-heading">
                                                        <h4 class="panel-title">
                                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse2" aria-expanded="true">
                                                                Working Experience</a>
                                                        </h4>
                                                    </div>
                                                    <div id="collapse2" class="panel-collapse collapse show">
                                                        <div class="panel-body">
                                                            <div class="row">
                                                                <div class="col-md-12">
                                                                    <div class="form-group row">
                                                                        <div class="col-md-12">
                                                                            <p>Working Experience</p>
                                                                            <div class="form-group col-12 file-repeater">

                                                                                <div class="row ">
                                                                                    <div class="col-md-2">
                                                                                        <p>GCC Experience</p>
                                                                                    </div>
                                                                                    <div class="col-md-10">
                                                                                        <select class="form-control border-primary" name="experience[gcc_exp]">
                                                                                            <option value="N" {{ (!empty($experiences[0]['gcc_exp']) && $experiences[0]['gcc_exp'] == 'N')?'selected':'' }}>No</option>
                                                                                            <option value="Y" {{ (!empty($experiences[0]['gcc_exp']) && $experiences[0]['gcc_exp'] == 'Y')?'selected':'' }}>Yes</option>
                                                                                        </select>
                                                                                    </div>
                                                                                </div>
                                                                                <hr>
                                                                                <div data-repeater-list="repeater-list">
                                                                                    <div data-repeater-item="">
                                                                                        <div class="row ">
                                                                                            <?php
                                                                                                $count = 1;
                                                                                            if(!empty($experiences)){
                                                                                                foreach($experiences as $the_experience){

                                                                                            ?>
                                                                                            <div class="col-md-10 repeater-block5" id="experience_{{ $count }}">
                                                                                                <div class="row">
                                                                                                    <div class="col-md-3">
                                                                                                        <p>Experience From</p>
                                                                                                        <input type="date" id="" class="form-control border-primary" placeholder="From" name="experience[exp_from][]" value="{{ $the_experience->exp_from }}">
                                                                                                    </div>
                                                                                                    <div class="col-md-3">
                                                                                                        <p>Experience To</p>
                                                                                                        <input type="date" id="" class="form-control border-primary" placeholder="To" name="experience[exp_to][]" value="{{ $the_experience->exp_to }}">
                                                                                                    </div>
                                                                                                    <div class="col-md-4">
                                                                                                        <p>Or, No of Experience (in months)</p>
                                                                                                        <input type="number" id="" class="form-control border-primary" placeholder="To" name="experience[no_of_exp_in_years][]" value="{{ $the_experience->no_of_exp_in_years }}">
                                                                                                    </div>
                                                                                                    <div class="col-md-2">
                                                                                                        <button type="button" data-repeater-create="" name="{{ 'experience_'.$count }}" id="" class="minus_btn_this btn btn-danger">
                                                                                                            <i class="ft-plus"></i> Remove This
                                                                                                        </button>
                                                                                                    </div>
                                                                                                    <div class="clearfix"></div>
                                                                                                    <div class="col-md-3">
                                                                                                        <p>From which country</p>
                                                                                                        <input type="text" id="" class="form-control border-primary" placeholder="Country" name="experience[country][]" value="{{ $the_experience->country }}">
                                                                                                    </div>
                                                                                                    <div class="col-md-3">
                                                                                                        <p>From which company</p>
                                                                                                        <input type="text" id="" class="form-control border-primary" placeholder="Company" name="experience[company][]" value="{{ $the_experience->company }}">
                                                                                                    </div>
                                                                                                    <div class="col-md-3">
                                                                                                        <p>On which designation</p>
                                                                                                        <input type="text" id="" class="form-control border-primary" placeholder="Designation" name="experience[designation][]" value="{{ $the_experience->designation }}">
                                                                                                    </div>
                                                                                                    <div class="col-md-3">
                                                                                                        <p>Enter Job Details</p>
                                                                                                        <textarea id="" class="form-control border-primary" placeholder="Job Details" name="experience[job_details][]">{{ $the_experience->job_details }}</textarea>
                                                                                                    </div>
                                                                                                </div>
                                                                                                <hr>
                                                                                            </div>
                                                                                            <?php
                                                                                                $count++;
                                                                                                    }
                                                                                            }
                                                                                                ?>

                                                                                                <div class="col-md-10 repeater-block5">
                                                                                                    <div class="row">
                                                                                                        <div class="col-md-3">
                                                                                                            <p>Experience From</p>
                                                                                                            <input type="date" id="" class="form-control border-primary" placeholder="From" name="experience[exp_from][]">
                                                                                                        </div>
                                                                                                        <div class="col-md-3">
                                                                                                            <p>Experience To</p>
                                                                                                            <input type="date" id="" class="form-control border-primary" placeholder="To" name="experience[exp_to][]">
                                                                                                        </div>
                                                                                                        <div class="col-md-6">
                                                                                                            <p>Or, No of Experience (in months)</p>
                                                                                                            <input type="number" id="" class="form-control border-primary" placeholder="To" name="experience[no_of_exp_in_years][]">
                                                                                                        </div>
                                                                                                        <div class="clearfix"></div>
                                                                                                        <div class="col-md-3">
                                                                                                            <p>From which country</p>
                                                                                                            <input type="text" id="" class="form-control border-primary" placeholder="Country" name="experience[country][]">
                                                                                                        </div>
                                                                                                        <div class="col-md-3">
                                                                                                            <p>From which company</p>
                                                                                                            <input type="text" id="" class="form-control border-primary" placeholder="Company" name="experience[company][]">
                                                                                                        </div>
                                                                                                        <div class="col-md-3">
                                                                                                            <p>On which designation</p>
                                                                                                            <input type="text" id="" class="form-control border-primary" placeholder="Designation" name="experience[designation][]">
                                                                                                        </div>
                                                                                                        <div class="col-md-3">
                                                                                                            <p>Enter Job Details</p>
                                                                                                            <textarea id="" class="form-control border-primary" placeholder="Job Details" name="experience[job_details][]"></textarea>
                                                                                                        </div>
                                                                                                    </div>
                                                                                                    <hr>
                                                                                                </div>
                                                                                            <div class="col-md-2 remove_this">
                                                                                                <button type="button" data-repeater-create="" name="repeater-block5" id="" class="minus_btn btn btn-danger">
                                                                                                    <i class="ft-plus"></i> Remove This
                                                                                                </button>
                                                                                            </div>

                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>

                                                                            <button type="button" data-repeater-create="" id="" name="repeater-block5" class="add_more btn btn-primary">
                                                                                <i class="ft-plus"></i> Add More Experience
                                                                            </button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <hr>
                                                <div class="panel panel-default">
                                                    <div class="panel-heading">
                                                        <h4 class="panel-title">
                                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse8" aria-expanded="true">
                                                                Additional Information</a>
                                                        </h4>
                                                    </div>
                                                    <div id="collapse8" class="panel-collapse collapse show">
                                                        <div class="panel-body">
                                                            <div class="row">
                                                                <div class="col-md-12">
                                                                    <div class="form-group row">
                                                                        <div class="col-md-12">
                                                                            <div class="form-group col-12 file-repeater">
                                                                                <div data-repeater-list="repeater-list">
                                                                                    <div data-repeater-item="">
                                                                                        <div class="row ">
                                                                                            <div class="col-md-10 repeater-block8">
                                                                                                <div class="row">
                                                                                                    <div class="col-md-3">
                                                                                                        <p>Father's Name</p>
                                                                                                        <input type="text" id="" class="form-control border-primary" placeholder="Father's name" name="additional[father_name]">
                                                                                                    </div>
                                                                                                    <div class="col-md-3">
                                                                                                        <p>Mother's Name</p>
                                                                                                        <input type="text" id="" class="form-control border-primary" placeholder="Mother's name" name="additional[mother_name]">
                                                                                                    </div>
                                                                                                    <div class="col-md-3">
                                                                                                        <p>Marital Status</p>
                                                                                                        <select class="form-control border-primary" name="additional[marital_status]">
                                                                                                            <option value="Y" {{ (!empty($additionals['marital_status']) && $additionals['marital_status'] == 'Y')?'selected':'' }}>Married</option>
                                                                                                            <option value="N" {{ (!empty($additionals['marital_status']) && $additionals['marital_status'] == 'N')?'selected':'' }}>Unmarried</option>
                                                                                                        </select>
                                                                                                    </div>
                                                                                                    <div class="col-md-3">
                                                                                                        <p>Spouse Name</p>
                                                                                                        <input type="text" id="" class="form-control border-primary" placeholder="Spouse's name" name="additional[spouse_name]" value="{{ (!empty($additionals['spouse_name'])?$additionals['spouse_name']:'') }}">
                                                                                                    </div>
                                                                                                    <div class="clearfix"></div>
                                                                                                    <div class="col-md-3">
                                                                                                        <p>No. of children (If any)</p>
                                                                                                        <input type="number" id="" class="form-control border-primary" placeholder="No. of children (In number)" name="additional[no_of_children]" value="{{ (!empty($additionals['no_of_children'])?$additionals['no_of_children']:'') }}">
                                                                                                    </div>
                                                                                                    <div class="col-md-3">
                                                                                                        <p>Religion</p>
                                                                                                        <input type="text" id="" class="form-control border-primary" placeholder="Company" name="additional[religion]" value="{{ (!empty($additionals['religion'])?$additionals['religion']:'') }}">
                                                                                                    </div>
                                                                                                    <div class="col-md-3">
                                                                                                        <p>Height</p>
                                                                                                        <input type="text" id="" class="form-control border-primary" placeholder="Designation" name="additional[height]" value="{{ (!empty($additionals['height'])?$additionals['height']:'') }}">
                                                                                                    </div>
                                                                                                    <div class="col-md-3">
                                                                                                        <p>Weight</p>
                                                                                                        <input type="text" id="" class="form-control border-primary" placeholder="Designation" name="additional[weight]" value="{{ (!empty($additionals['weight'])?$additionals['weight']:'') }}">
                                                                                                    </div>
                                                                                                </div>
                                                                                                <hr>
                                                                                            </div>

                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <hr>
                                                <div class="panel panel-default">
                                                    <div class="panel-heading">
                                                        <h4 class="panel-title">
                                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse3">
                                                                Attachments</a>
                                                        </h4>
                                                    </div>
                                                    <div id="collapse3" class="panel-collapse collapse show">
                                                        <div class="panel-body">
                                                            <div class="row">
                                                                <div class="col-md-8">
                                                                    <div class="form-group row">
                                                                        <div class="col-md-12">
                                                                            <p>Attachments [Uplaod either jpg, jpeg, png or gif images only]</p>
                                                                            <div class="form-group col-12 file-repeater">
                                                                                <div data-repeater-list="repeater-list">
                                                                                    <div data-repeater-item="">
                                                                                        <div class="row ">
                                                                                            <?php
                                                                                                $count = 1;
                                                                                            if(!empty($attachments)){
                                                                                                foreach($attachments as $key=>$value){
                                                                                                    ?>
                                                                                                    <div class="col-md-10 repeater-block2" id="{{ 'attachment_'.$count }}">
                                                                                                        <div class="row">
                                                                                                            <div class="col-md-3">
                                                                                                                <p>File Title</p>
                                                                                                                <input type="text" id="" class="form-control border-primary" placeholder="File Title" name="attachment[title_txt][]" value="{{ $key }}">
                                                                                                            </div>
                                                                                                            <div class="col-md-6">
                                                                                                                <p>&nbsp;</p>
                                                                                                                @if($value != '')
                                                                                                                    <img src="{{ url('/').'/public/images/'.$value }}" style="width: 100px; float: right; " title="" alt="">
                                                                                                                    <input type="hidden" name="attachment[file_txt][]" value="{{ $value }}">
                                                                                                                @endif
                                                                                                            </div>
                                                                                                            <div class="col-md-3">
                                                                                                                <button type="button" data-repeater-create="" name="{{ 'attachment_'.$count }}" id="" class="minus_btn_this btn btn-danger">
                                                                                                                    <i class="ft-plus"></i> Remove This
                                                                                                                </button>
                                                                                                            </div>
                                                                                                        </div>
                                                                                                        <br>
                                                                                                    </div>

                                                                                                    <?php

                                                                                                    $count++;

                                                                                                }
                                                                                            }

                                                                                            ?>

                                                                                            <div class="col-md-10 repeater-block2">
                                                                                                <div class="row">
                                                                                                    <div class="col-md-3">
                                                                                                        <p>File Title</p>
                                                                                                        <input type="text" id="" class="form-control border-primary" placeholder="File Title" name="attachment[title][]">
                                                                                                    </div>
                                                                                                    <div class="col-md-9">
                                                                                                        <p>File</p>
                                                                                                        <input type="file" class="form-control" placeholder="Attachments" name="attachment[file][]">
                                                                                                    </div>
                                                                                                </div>
                                                                                                <br>
                                                                                            </div>
                                                                                            <div class="col-md-2">
                                                                                                <button type="button" data-repeater-create="" name="repeater-block2" id="" class="minus_btn btn btn-danger">
                                                                                                    <i class="ft-plus"></i> Remove This
                                                                                                </button>
                                                                                            </div>

                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>

                                                                            <button type="button" data-repeater-create="" name="repeater-block2" id="" class="add_more btn btn-primary">
                                                                                <i class="ft-plus"></i> Add More Attachment
                                                                            </button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            {{--accordians--}}
                                        </div>
                                    </div>
                                </div>
                            <hr>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <p>Remarks</p>
                                        <textarea id="" class="form-control border-primary" placeholder="Remarks" name="formdata[remarks]">{{ $candidate_entry->remarks }}</textarea>
                                    </div>
                                </div>
                            </div>

                            <div class="form-actions left">
                                <button type="button" class="btn btn-danger mr-1">
                                    <i class="ft-x"></i> Cancel
                                </button>
                                <button type="submit" class="btn btn-primary">
                                    <i class="la la-check-square-o"></i> Save
                                </button>
                            </div>

                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
<input type="hidden" id="url" value="{{ url('/') }}">
<input type="hidden" id="current_date" value="{{ date('Y-m-d') }}">
<script>
$(document).ready(function(){

    $('.select_one').on('change', function(){

        var option_value = $(this).val();
        var url_this = $('#url').attr("value");

        if(parseInt(option_value) < 1) {
            var this_title = $(this).attr('title');
            var this_id = '#'+$(this).attr('id');
            var new_option = prompt('Please Enter new ' + this_title + '?');
            var new_option_arr = new_option.split(' ');
            var new_option_value = '';
            var dashed = '';
            for(var i = 0; i < new_option_arr.length; i++){
                new_option_value += dashed+new_option_arr[i];
                dashed = '-';
            }
            var url_post = url_this+'/user/dashboard/candidate/'+this_title+'/'+new_option_value;
            // alert(url_post);
            // return false;
            if (parseInt(new_option_value.length) > 0) {
                $.ajax({
                    method: "GET",
                    url: url_post,
                    data: { }
                }).done(function( msg ) {
                    // alert( "Data Saved: " + msg );
                    $(this_id).append(msg);
                    return false;
                });
                // alert('Good');
            } else {
                alert('Try Again!');
            }
        }
        return false;
    });

    function pp_issue_date_with(passport_issue_date_y, passport_issue_date_m, passport_issue_date_d, current_date_value){

        if(passport_issue_date_y > 1000 && passport_issue_date_m >= 0 && passport_issue_date_d > 0 ){

            // alert(passport_issue_date_y+''+passport_issue_date_m+''+passport_issue_date_d);
            //
            // return false;

            var pp_issue_date = new Date(passport_issue_date_y, passport_issue_date_m, passport_issue_date_d);

            // alert(pp_issue_date.getFullYear()+''+pp_issue_date.getMonth()+''+pp_issue_date.getDate());
            //
            // return false;

            var current_date = new Date(current_date_value);

            current_date.setFullYear(current_date.getFullYear());

            pp_issue_date.setDate( pp_issue_date.getDate() - 1 );

            pp_issue_date.setFullYear(pp_issue_date.getFullYear() + 10);

            // pp_issue_date.setTime( pp_issue_date.getTime() - 24*60*60*1000 );

            // alert(pp_issue_date.getFullYear()+''+(pp_issue_date.getMonth()+1)+''+pp_issue_date.getDate());
            //
            // return false;

            var newDate = (pp_issue_date.getDate() < 10)?'0'+pp_issue_date.getDate():pp_issue_date.getDate();
            //
            var thisMonth = pp_issue_date.getMonth()+1;
            //
            var thisYear = pp_issue_date.getFullYear();
            //
            var newMonth = (thisMonth < 10)?'0'+thisMonth:thisMonth;
            //
            // alert(thisYear+' '+thisMonth+' '+newDate);
            //
            // return false;

            if(current_date.getFullYear() > pp_issue_date.getFullYear()){

                $('#passport_issue_date_y').attr("value", "");

                $('#passport_expiry_date_d').attr("value", "");

                $('#passport_expiry_date_m').attr("value", "");

                $('#passport_expiry_date_y').attr("value", "");

                alert("Passport has been expired!");

                return false;
            }

            $('#passport_expiry_date_d').attr("value", newDate);

            $('#passport_expiry_date_m').attr("value", newMonth);

            $('#passport_expiry_date_y').attr("value", thisYear);

            // alert(thisYear+' '+newMonth+' '+newDate);

            // return false;

        }

    }

    $('.date_field input').on('keyup', function(){
        var max_length_no = $(this).attr('maxlength');
        var max = $(this).attr('max');
        var this_no = $(this).val();
        var index_no = $('.form-control').index($(this)) + 1;

        var passport_issue_date_d = ($('#passport_issue_date_d').val().length < 1)?0:(parseInt($('#passport_issue_date_d').val()));
        var passport_issue_date_m = ($('#passport_issue_date_m').val().length < 1)?0:(parseInt($('#passport_issue_date_m').val()) - 1);
        var passport_issue_date_y = ($('#passport_issue_date_y').val().length < 1)?0:(parseInt($('#passport_issue_date_y').val()));

        // alert(max_length_no+this_no);

        var current_date_value = $('#current_date').val();

        // alert(current_date.getFullYear());
        // return false;

        if(this_no.length < max_length_no){

            // $(this).next('input').focus();
            // $(this).next().focus();

            var this_title = $(this).attr("title");
            if(this_title == 'passport_expiry_date_d'){

                pp_issue_date_with(passport_issue_date_y, passport_issue_date_m, passport_issue_date_d, current_date_value);
                // $('#passport_expiry_date_d').attr("value", (parseInt(this_no) - 1));
            }else if(this_title == 'passport_expiry_date_m'){
                pp_issue_date_with(passport_issue_date_y, passport_issue_date_m, passport_issue_date_d, current_date_value);
                // $('#passport_expiry_date_m').attr("value", this_no);
            }else if(this_title == 'passport_expiry_date_y'){
                // var this_no_next = parseInt(this_no) + 10;



                // alert(passport_issue_date_y+''+passport_issue_date_m+''+passport_issue_date_d);
                //
                // return false;

                pp_issue_date_with(passport_issue_date_y, passport_issue_date_m, passport_issue_date_d, current_date_value);
                // $('#passport_expiry_date_y').attr("value", this_no_next);
            }

        }else{

            if(parseInt(this_no) > parseInt(max)){
                // alert(parseInt(this_no) + parseInt(max));
                $(this).val(parseInt(max));
                this_no = max;

                // alert('Age must be 18+ years');
                // return false;
                // return false;
            }

            var this_title = $(this).attr("title");
            if(this_title == 'passport_expiry_date_d'){
                pp_issue_date_with(passport_issue_date_y, passport_issue_date_m, passport_issue_date_d, current_date_value);
                // $('#passport_expiry_date_d').attr("value", (parseInt(this_no) - 1));
            }else if(this_title == 'passport_expiry_date_m'){
                pp_issue_date_with(passport_issue_date_y, passport_issue_date_m, passport_issue_date_d, current_date_value);
                // $('#passport_expiry_date_m').attr("value", this_no);
            }else if(this_title == 'passport_expiry_date_y'){

                // alert(passport_issue_date_y+''+passport_issue_date_m+''+passport_issue_date_d);
                //
                // return false;

                pp_issue_date_with(passport_issue_date_y, passport_issue_date_m, passport_issue_date_d, current_date_value);
                // var this_no_next = parseInt(this_no) + 10;
                // $('#passport_expiry_date_y').attr("value", this_no_next);
            }

            $(this).val(this_no.substring(0, max_length_no));
            $('.form-control:eq('+index_no+')').focus();
        }

    });

    $('#ppno').on('blur', function(){

        var ppno = $(this).val();

        // alert(ppno);

        // return false;

        $('#checkppno').html("[ Checking... please wait! ]");

        var url = $('#url').val();

        if(ppno != ''){

            $.ajax({
                method: "GET",
                url: url+"/user/dashboard/check_passport_no/"+ppno,
                data: { }
            }).done(function( msg ) {

                if(msg > 0) {
                    $('#checkppno').html("[ Duplicate Passport No: " + ppno + " ]").css("font-size", "11px");
                    $('#ppno').val("");
                }else{
                    $('#checkppno').html("");
                }
            });

        }else{
            $('#checkppno').html('');
        }

        // var pp_arr = ($(this).val()).split('-');
        // if(Array.isArray(pp_arr)){
        //     $('#pp_expiry_date').attr("value", pp_arr[2]+'-'+pp_arr[1]+'-'+(parseInt(pp_arr[0])+10));
        // }

    });

    $('#pp_issue_date').on('blur', function(){
        // var pp_issue_date = alert($(this).val());
//        var pp_issue_date_obj = new Date($(this).val());
        var pp_arr = ($(this).val()).split('-');
//        console.log(pp_arr);
        if(Array.isArray(pp_arr)){
//            alert(pp_arr[2]+'-'+pp_arr[1]+'-'+(parseInt(pp_arr[0])+5));
            $('#pp_expiry_date').attr("value", pp_arr[1]+'/'+pp_arr[2]+'/'+(parseInt(pp_arr[0])+10));
//             $('#pp_expiry_date').attr("value", (parseInt(pp_arr[0])+10)+'/'+pp_arr[1]+'/'+pp_arr[2]);

        }
//        var pp_issue_date_obj_new = new Date(pp_issue_date_obj.getTime() + 5*365*24*60*60)
//        alert(pp_issue_date_obj.getDay() + '-' + pp_issue_date_obj.getMonth() + '-' + (pp_issue_date_obj.getFullYear() + 5 ));

    });
    
    $('.add_more').on('click', function(){
        var classname = '.'+$(this).attr('name');
        // alert(classname);
        var repeater_block_html = $(classname).html();
        $(classname+':last').after('<div class="col-md-10 '+$(this).attr("name")+'">'+repeater_block_html+'</div>');
    });
    
    $('.minus_btn').on('click', function(){
        var classname = '.'+$(this).attr('name');
        // alert(classname);
        var length_this = $(classname).length;
        // alert(length_this);
//        alert(length_this);
//        var repeater_block_html = $('.repeater-block').html();
        if(length_this > 1)
        $(classname+':last').remove();
    });

    $('.minus_btn_this').on('click', function(){
        var this_btn = $(this).attr('name');
        // alert(this_btn);
        var indexing = $('#'+this_btn).remove();
        // alert(indexing);
    });
    
});
</script>
@endsection