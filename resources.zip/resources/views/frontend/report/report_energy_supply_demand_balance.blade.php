@extends('frontend_layouts.new_report_layout')
@section('content')

    <form class="" action="{{ $url }}" method="get" id="thisform">
        @csrf
        <div class="row">
            <div class="col-md-2">
                <div id="fiscal_year" class="form-group direct tabular">
                    <label for="">Fiscal Year</label>
                    <select name="start" class="form-control" onchange="document.getElementById('end_date').value=(parseInt(this.value) + 1); document.getElementById('thisform').submit();">
                        @for($i = 1995; $i < date('Y'); $i++)
                            <option value="{{ $i }}" {{ ($start == $i)?'selected':'' }}>{{ $i }}/{{ ($i+1) }}</option>
                        @endfor
                    </select>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    <label for="">&nbsp;</label>
                    <button type="submit" class="btn btn-primary">Search</button>
                </div>
            </div>
        </div>

    </form>
    <section id="horizontal-form-layouts">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="this_title">Nepal Energy Supply Demand Balance of Fiscal Year [{{ $start }}/{{ $end }}]</h4>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="card-content collpase show">
                        <div class="card-body row">
                            <div class="col-md-12 form-body-listing">
                                <p>Energy Unit In PJ</p>
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered">
                                        <?php
                                        $col = array();
                                        $col_total_init = 0;
                                        ?>
                                        <tr>
                                            <th colspan="2">Fuel Type</th>
                                            <?php
                                            if(!empty($col_send)){
                                                foreach($col_send as $the_col){
                                                    echo '<th><input type="hidden" class="x-axis" value="'.$the_col.'">'.$the_col.'</th>';
                                                    $col[$col_total_init] = 0;
                                                    $col_total_init++;
                                                }
                                                $col[$col_total_init] = 0;
                                            }
                                            ?>
                                            <th><input type="hidden" class="x-axis" value="Total">Grand Total</th>
                                        </tr>
                                        <?php
                                        $count = 1;
                                        if(!empty($final_result)){
                                            $first_col = '';
                                            foreach($final_result as $key=>$value){
                                                $total = 0;
                                                $col_count = 0;
                                                ?>

                                                <tr class="top_row">
                                                    <?php
                                                        $this_key = (!empty($key))?explode('-', $key):array();
                                                        $this_first_col = (is_array($this_key) && (!empty($this_key[0])))?$this_key[0]:'';
                                                    ?>
                                                    <th>
                                                        {{ ($this_first_col != $first_col)?$this_first_col:'' }}
                                                    </th>
                                                    <th>
                                                        {{ (is_array($this_key) && (!empty($this_key[1])))?ucwords(str_replace('_', ' ', $this_key[1])):'' }}
                                                    <?php
                                                    echo '<input type="hidden" id="row'.$count.'" value="'.$key.'">';
                                                    ?>
                                                    </th>
                                                    <?php

                                                        $first_col = $this_first_col;

                                                        if(is_array($value)){
                                                            foreach($value as $the_value){

//                                                                $col[$col_count] = (!empty($col[$col_count]))?(((float)$col[$col_count])/1000):0;

                                                                echo '<td><input type="hidden" class=" row'.$count.'" value="'.round((((float)$the_value)/1000000),2).'">'.round((((float)$the_value)/1000000),2).'</td>';
                                                                $total += (((float)$the_value)/1000000);
                                                                $col[$col_count] += (((float)$the_value)/1000000);
                                                                $col_count++;
                                                            }
                                                        }

                                                        $col[$col_count] += $total;
                                                        $count++;
                                                    ?>
                                                    <th>{{ round($total, 2) }}</th>
                                                </tr>

                                        <?php
                                            }
                                        ?>

                                            <tr class="top_row">
                                                <th>
                                                    Total
                                                    <?php
                                                    echo '<input type="hidden" id="row'.$count.'" value="Total">';
                                                    ?>
                                                </th>
                                                <td></td>
                                            <?php
                                                $col_total = 0;
                                            if(is_array($col)){
                                                foreach($col as $the_value){
                                                    $this_value = round((((float)$the_value)),2);
                                                    // $this_value = $the_value;
                                                    echo '<th><input type="hidden" class=" row'.$count.'" value="'.$this_value.'">'.$this_value.'</th>';
                                                    $col_total += $this_value;
                                                }
                                            }
                                            ?>
                                                {{--<td>{{ $col_total }}</td>--}}
                                            </tr>
                                        <?php
                                        }
                                        ?>
                                    </table>
                                </div>

                                <script>

                                    /*

                                    function getRandomInt(max) {
                                        return Math.floor(Math.random() * Math.floor(max));
                                    }

                                    var this_title = document.getElementById("this_title").innerHTML;



                                    var categories_arr = new Array();

                                    var findit = document.getElementsByClassName('x-axis');
                                    for(var i = 0; i < findit.length; i++){
                                        var this_key = findit[i].value;
                                        categories_arr.push(this_key);
                                    }

                                    var series_data = [];

                                    var top_row = document.getElementsByClassName('top_row');

                                    for(var j=0;j<top_row.length;j++){
                                        var k = j+1;
                                        var row = 'row'+k;

                                        console.log(row);

                                        var row_arr = new Array();
                                        var find_row = document.getElementsByClassName(row);

                                        for (var i = 0; i < find_row.length; i++) {
                                            var this_key = find_row[i].value;
                                            row_arr.push(parseInt(this_key));
                                        }
                                        var find_id_row_value = document.getElementById(row).value;
                                        var obj_row = {name: find_id_row_value, data: row_arr};
                                        series_data.push(obj_row);

                                    }

                                    Highcharts.chart('container', {
                                        chart: {
                                            type: 'column'
                                        },
                                        title: {
                                            text: this_title
                                        },
                                        subtitle: {
                                            text: ''
                                        },
                                        xAxis: {
                                            categories: categories_arr,
                                            crosshair: true
                                        },
                                        yAxis: {
                                            min: 0,
                                            title: {
                                                text: 'Energy Unit (In Kilo GJ)'
                                            }
                                        },
                                        tooltip: {
                                            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                                            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                                                '<td style="padding:0"><b>{point.y:.1f} GJ</b></td></tr>',
                                            footerFormat: '</table>',
                                            shared: true,
                                            useHTML: true
                                        },
                                        plotOptions: {
                                            column: {
                                                pointPadding: 0.2,
                                                borderWidth: 0
                                            }
                                        },
                                        series: series_data
                                    });
                                    */
                                </script>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection