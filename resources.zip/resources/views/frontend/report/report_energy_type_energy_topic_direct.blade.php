@extends('frontend_layouts.new_report_layout')
@section('content')

    <form class="" action="{{ $url }}" method="get" id="thisform">
        @csrf
        <?php

        $start = (!empty($_GET['start']) && is_numeric($_GET['start']) && $_GET['start'] > 1990 && $_GET['start'] <= (date('Y') - 1) )?$_GET['start']:(date('Y') - 1);

        $end = (!empty($_GET['end']) && is_numeric($_GET['end']) && $_GET['end'] > 1990 && $_GET['end'] <= date('Y') )?$_GET['end']:date('Y');

        $energy_topic = (!empty($_GET['energy_topic']) && in_array($_GET['energy_topic'], ['sector', 'land_type', 'geographic_region', 'river']))?$_GET['energy_topic']:'sector';

        ?>
        <div class="row">
            <div class="col-md-2">
                <div id="fiscal_year" class="form-group direct tabular">
                    <label for="">Fiscal Year</label>
                    <select name="start" class="form-control" onchange="document.getElementById('end_date').value=(parseInt(this.value) + 1); document.getElementById('thisform').submit();">
                        @for($i = (date('Y') -1); $i >= 2019; $i--)
                            <?php $j = $i + 1; ?>
                            <option value="{{ $i }}" {{ ($start == $i)?'selected':'' }}>{{ $i }}/{{ $j }}</option>
                        @endfor
                    </select>
                    <input type="hidden" value="{{$end}}" id="end_date" name="end" readonly>
                </div>
            </div>
            {{--<div class="col-md-4">--}}
                {{--<div class="form-group">--}}
                    {{--<label for="">Energy Topic</label>--}}
                    {{--<select name="energy_topic" id="" class="form-control" onchange="document.getElementById('thisform').submit();">--}}
                        {{--<option value="sector" {{ ($energy_topic == 'sector')?'selected':'' }}>Sector</option>--}}
                        {{--<option value="land_type" {{ ($energy_topic == 'land_type')?'selected':'' }}>Land Type</option>--}}
                        {{--<option value="geographic_region" {{ ($energy_topic == 'geographic_region')?'selected':'' }}>Geographic Region</option>--}}
                        {{--<option value="river" {{ ($energy_topic == 'river')?'selected':'' }}>River</option>--}}
                    {{--</select>--}}
                {{--</div>--}}
            {{--</div>--}}
            <div class="col-md-2">
                <div class="form-group">
                    <label for="">&nbsp;</label>
                    <button type="submit" class="btn btn-primary">Search</button>
                </div>
            </div>
        </div>

    </form>

    <section id="horizontal-form-layouts">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="this_title">Province wise Total Energy Consumption of Fiscal Year [{{ $start }}/{{ $end }}]</h4>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <?php
                    $permalink = $url;
                    ?>
                    <div class="card-content collpase show">
                        <div class="card-body row">
                            @if(!empty($energy_topics))
                                @foreach($energy_topics as $energy_list)
                                    <div class="col-md-12 form-body-listing ">
                                        <div class="btn btn-sm btn-outline-primary round">
                                            <h4>
                                                <a class="" href="{{ $permalink.'/energy-topic/'.$energy_list }}">{{ ucwords(str_replace("_", " ",$energy_list)) }} Verses Energy</a>
                                            </h4>
                                        </div>
                                        <br>                                        &nbsp;
                                    </div>
                                @endforeach

                                @endif
                            <div class="col-md-12 form-body-listing">
                                <div id="container" style="height:500px;"></div>
				<p>Energy Unit In (000000) GJ</p>
                                <div class="table-responsive">
                                    <table border="1" cellspacing="3" cellpadding="3">
                                        <?php
                                        $col = array();
                                        $col_total_init = 0;
                                        ?>
                                        <tr>
                                            <th>&nbsp;</th>
                                            <?php
                                            if(!empty($provinces)){
                                                foreach($provinces as $the_province){
                                                    echo '<th><input type="hidden" class="x-axis" value="'.$the_province->location_name.'">'.$the_province->location_name.'</th>';
                                                    $col[$col_total_init] = 0;
                                                    $col_total_init++;
                                                }
                                                $col[$col_total_init] = 0;
                                            }
                                            ?>
                                            <th><input type="hidden" class="x-axis" value="Total">Total</th>
                                        </tr>
                                        <?php
                                        $count = 1;
                                        if(!empty($final_result)){
                                            foreach($final_result as $key=>$value){
                                                $total = 0;
                                                $col_count = 0;
                                                ?>

                                                <tr class="top_row">
                                                    <th>
                                                        {{ ucwords(str_replace('_', ' ', $key)) }}
                                                        <?php
                                                        echo '<input type="hidden" id="row'.$count.'" value="'.$key.'">';
                                                        ?>
                                                    </th>
                                                    <?php
                                                        if(is_array($value)){
                                                            foreach($value as $the_value){

                                                                $qty = (!empty($the_value->qty) && $the_value->qty > 0)?(float)$the_value->qty:0;

//                                                                $col[$col_count] = (!empty($col[$col_count]))?(((float)$col[$col_count])/1000):0;

                                                                echo '<td><input type="hidden" class=" row'.$count.'" value="'.($qty/1000000).'">'.($qty/1000000).'</td>';
                                                                $total += ($qty/1000000);
                                                                $col[$col_count] += ($qty/1000000);
                                                                $col_count++;
                                                            }
                                                        }

                                                        $col[$col_count] += $total;
                                                        $count++;
                                                    ?>
                                                    <td>{{ $total }}</td>
                                                </tr>


                                        <?php
                                            }
                                        ?>

                                            <tr class="top_row">
                                                <th>
                                                    Total
                                                    <?php
                                                    echo '<input type="hidden" id="row'.$count.'" value="Total">';
                                                    ?>
                                                </th>
                                            <?php
                                                $col_total = 0;
                                            if(is_array($col)){
                                                foreach($col as $the_value){
//                                                    echo '<td><input type="hidden" class=" row'.$count.'" value="'.((float)$the_value).'">'.((float)$the_value).'</td>';
                                                    echo '<th>'.((float)$the_value).'</th>';
                                                    $col_total += (float)$the_value;
                                                }
                                            }
                                            ?>
                                                {{--<td>{{ $col_total }}</td>--}}
                                            </tr>
                                        <?php
                                        }
                                        ?>
                                    </table>
                                </div>

                                <script>

                                    function getRandomInt(max) {
                                        return Math.floor(Math.random() * Math.floor(max));
                                    }

                                    var this_title = document.getElementById("this_title").innerHTML;

                                    var categories_arr = new Array();

                                    var findit = document.getElementsByClassName('x-axis');
                                    for(var i = 0; i < findit.length; i++){
                                        var this_key = findit[i].value;
                                        categories_arr.push(this_key);
                                    }

                                    var series_data = [];

                                    var top_row = document.getElementsByClassName('top_row');

                                    for(var j=0;j<top_row.length;j++){
                                        var k = j+1;
                                        var row = 'row'+k;

                                        console.log(row);

                                        var row_arr = new Array();
                                        var find_row = document.getElementsByClassName(row);

                                        for (var i = 0; i < find_row.length; i++) {
                                            var this_key = find_row[i].value;
                                            row_arr.push(parseInt(this_key));
                                        }
                                        var find_id_row_value = document.getElementById(row).value;
                                        var obj_row = {name: find_id_row_value, data: row_arr};
                                        series_data.push(obj_row);

                                    }

                                    Highcharts.chart('container', {
                                        chart: {
                                            type: 'column'
                                        },
                                        title: {
                                            text: this_title
                                        },
                                        subtitle: {
                                            text: ''
                                        },
                                        credits: {
                                            enabled: false
                                        },
                                        xAxis: {
                                            categories: categories_arr,
                                            crosshair: true
                                        },
                                        yAxis: {
                                            min: 0,
                                            title: {
                                                text: 'Energy Unit In (000000) GJ'
                                            }
                                        },
                                        tooltip: {
                                            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                                            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                                                '<td style="padding:0"><b>{point.y:.1f} GJ</b></td></tr>',
                                            footerFormat: '</table>',
                                            shared: true,
                                            useHTML: true
                                        },
                                        plotOptions: {
                                            column: {
                                                pointPadding: 0.2,
                                                borderWidth: 0
                                            }
                                        },
                                        series: series_data
                                    });
                                </script>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection