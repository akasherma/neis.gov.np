@extends('frontend_layouts.new_report_layout')
@section('content')

    <form class="" action="{{ $url }}" method="get" id="thisform">
        @csrf
        <?php

        $energy_topic = (!empty($_GET['energy_topic']) && in_array($_GET['energy_topic'], ['sector', 'land_type', 'geographic_region', 'river']))?$_GET['energy_topic']:'sector';

        ?>
        <div class="row">
            <div class="col-md-2">
                <div id="fiscal_year" class="form-group direct tabular">
                    <label for="">Fiscal Year From</label>
                    <select name="start" class="form-control" onchange="document.getElementById('end_date').value=(parseInt(this.value) + 1); document.getElementById('thisform').submit();">
                        @for($i = 1995; $i <= date('Y'); $i++)
                            <option value="{{ $i }}" {{ ($start == $i)?'selected':'' }}>{{ $i }}</option>
                        @endfor
                    </select>
                </div>
            </div>
            <div class="col-md-2">
                <div id="fiscal_year" class="form-group direct tabular">
                    <label for="">Fiscal Year To</label>
                    <select name="end" class="form-control" onchange="document.getElementById('end_date').value=(parseInt(this.value) + 1); document.getElementById('thisform').submit();">
                        @for($i = 1995; $i <= date('Y'); $i++)
                            <option value="{{ $i }}" {{ ($end == $i)?'selected':'' }}>{{ $i }}</option>
                        @endfor
                    </select>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    <label for="">&nbsp;</label>
                    <button type="submit" class="btn btn-primary">Search</button>
                </div>
            </div>
        </div>

    </form>

    <section id="horizontal-form-layouts">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="this_title">Total Energy Consumption  By Fuel type ({{ $start }} - {{ $end }})</h4>
                        <p>Energy Unit In PJ</p>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <?php
                    $permalink = $url;
                    ?>
                    <div class="card-content collpase show">
                        <div class="card-body row">
                            @if(!empty($energy_topics))
                                @foreach($energy_topics as $energy_list)
                                    <div class="col-md-12 form-body-listing ">
                                        <div class="btn btn-sm btn-outline-primary round">
                                            <h4>
                                                <a class="" href="{{ $permalink.'/energy-topic/'.$energy_list }}">{{ ucwords(str_replace("_", " ",$energy_list)) }} Verses Energy</a>
                                            </h4>
                                        </div>
                                        <br>                                        &nbsp;
                                    </div>
                                @endforeach

                            @endif
                            <div class="col-md-12 form-body-listing">
                                <div id="container" style="height:600px;"></div>
                                <p>Energy Unit In PJ</p>

                                <div class="table-responsive">
                                    <table class="table table-bordered table-striped">
                                        <tr>
                                            <th colspan="2">Energy</th>
                                            <input type="hidden" class="x-axis" value="">
                                            <?php
                                            $col = array();
                                            $col_counter = 0;
                                            if(!empty($start)){
                                                for ($year = $start; $year <= $end; $year++){
                                                    echo '<th><input type="hidden" class="x-axis" value="'.$year.'">'.$year.'</th>';
                                                    $col[$col_counter] = 0;
                                                    $col_counter++;
                                                }

                                                $col[$col_counter] = 0;

                                            }
                                            ?>
                                            <th>
                                                {{--<input type="hidden" class="x-axis" value="Total">--}}
                                                Total
                                            </th>
                                            <input type="hidden" id="start" value="{{$start}}">
                                        </tr>
                                        <?php
                                        $count = 1;
                                        $total = 0;
                                        $row_key= '';
                                        if(!empty($final_result)){
                                            foreach($final_result as $key=>$value){
                                            $col_count = 0;

                                            $this_key = explode("#", $key);

                                            $this_first_key = (is_array($this_key) && (!empty($this_key[0])))?$this_key[0]:'';

                                            ?>

                                            <tr class="">

                                                <th>
                                                    {{ ($this_first_key != $row_key)?$this_first_key:'' }}
                                                    <?php $row_key = ($this_first_key != $row_key)?$this_first_key:$row_key; ?>
                                                </th>
                                                <td>
                                                    {{ (is_array($this_key) && (!empty($this_key[1])))?ucwords(str_replace('_', ' ', $this_key[1])):'' }}
                                                </td>
                                                <?php

                                                    $total = 0;

//                                                    print_r($topic_arr);

//                                                    if(count($topic_arr) > 0 && count($topic_arr) <= 2){
//                                                        echo '<td>'.$topic_arr[0].'</td><td>'.$topic_arr[1].'</td>';
//                                                    }else{
//                                                        echo '<td colspan="2">'.ucwords(str_replace('_', ' ', $key)).'</td>';
//                                                    }

//                                                    echo '<input type="hidden" id="row'.$count.'" value="'.((!empty($this_key[1]))?$this_key[1]:ucwords(str_replace('#', ' ', $key))).'" title="N">';

                                                    ?>
                                                <?php
                                                if(is_array($value)){
                                                    foreach($value as $the_value){
                                                        $the_value_qty = (!empty($the_value->qty))?(((float)$the_value->qty)/1000000):0;
                                                        $col[$col_count] = (!empty($col[$col_count]))?((float)$col[$col_count]):0;

                                                        echo '<td><input type="hidden" title="N" class=" arow'.$count.'" value="'.$the_value_qty.'">'.round($the_value_qty, 2).'</td>';

    //                                                    echo '<td>'.$the_value_qty.'</td>';

                                                        $total += $the_value_qty;
                                                        $col[$col_count] += $the_value_qty;
                                                        $col_count++;
                                                    }
                                                }
//                                                $count++;
                                                ?>
                                                <td>{{ $total }}</td>
                                            </tr>


                                            <?php
                                            }
                                            ?>

                                            <tr class="top_row">
                                                <th colspan="2">
                                                    Total
                                                    <?php
                                                     echo '<input type="hidden" id="row'.$count.'" value="Total">';
                                                    ?>
                                                </th>
                                                <input type="hidden" title="N" class=" row{{$count}}" value="0">
                                                <?php
                                                $col_total = 0;
                                                $the_value_qty = 0;
                                                $req_row = 1;
                                                if(is_array($col)){
                                                    foreach($col as $the_value){
                                                        $the_value_qty = (!empty($the_value))?$the_value:$the_value_qty;

                                                        if(count($col) == $req_row){
                                                            echo '<th><input type="hidden" title="Y" class=" arow'.$count.'" value="'.$the_value_qty.'">'.round($the_value_qty, 2).'</th>';
                                                        }else{
                                                            echo '<th><input type="hidden" title="N" class=" row'.$count.'" value="'.$the_value_qty.'">'.round($the_value_qty, 2).'</th>';
                                                        }

//                                                        echo '<td><input type="hidden" title="N" class=" row'.$count.'" value="'.$the_value_qty.'">'.$the_value_qty.'</td>';

                                                        $col_total += $the_value_qty;
                                                        $req_row++;
                                                    }
                                                }
                                                $req_row++;
                                                ?>
    {{--                                            <td>{{ $col_total }}</td>--}}
                                            </tr>
                                        <?php
                                        }
                                        ?>
                                    </table>
                                </div>

                                <script>

                                    function getRandomInt(max) {
                                        return Math.floor(Math.random() * Math.floor(max));
                                    }

                                    var this_title = document.getElementById("this_title").innerHTML;



                                    var categories_arr = new Array();

                                    var findit = document.getElementsByClassName('x-axis');
                                    for(var i = 0; i < findit.length; i++){
                                        var this_key = findit[i].value;
                                        categories_arr.push(this_key);
                                    }

                                    // console.log(categories_arr);

                                    var series_data = [];

                                    var top_row = document.getElementsByClassName('top_row');

                                    for(var j=0;j<top_row.length;j++){
                                        var k = j+1;
                                        var row = 'row'+k;

                                        var row_arr = new Array();
                                        var find_row = document.getElementsByClassName(row);

                                        for (var i = 0; i < find_row.length; i++) {
                                            var this_key = find_row[i].value;
                                            row_arr.push(parseInt(this_key));
                                        }
                                        // var find_id_row_value = document.getElementById(row).value;
                                        // var obj_row = {name: find_id_row_value, data: row_arr};
                                        // series_data.push(obj_row);

                                    }

                                    series_data = row_arr;

                                    // console.log(series_data);

                                    // return false;

                                    var this_start = parseInt(document.getElementById('start').value);

                                    // console.log(this_start);

                                    // var series_data = [obj_row1, obj_row2, obj_row3, obj_row4, obj_row5, obj_row6];

                                    Highcharts.chart('container', {
                                        chart: {
                                            zoomType: 'xy'
                                        },
                                        title: {
                                            text: 'Total Energy Consumption By Fuel Type'
                                        },
                                        subtitle: {
                                            text: 'Source: NEIS'
                                        },
                                        credits: {
                                            enabled: false
                                        },
                                        xAxis: [{
                                            // categories: ['Jan1', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
                                            categories: categories_arr,
                                            crosshair: false
                                        }],
                                        yAxis: [{ // Primary yAxis
                                            labels: {
                                                format: '{value} PJ',
                                                style: {
                                                    color: Highcharts.getOptions().colors[1]
                                                }
                                            },
                                            title: {
                                                text: 'Energy',
                                                style: {
                                                    color: Highcharts.getOptions().colors[1]
                                                }
                                            }
                                        }, { // Secondary yAxis
                                            title: {
                                                text: 'Energy',
                                                style: {
                                                    color: Highcharts.getOptions().colors[1]
                                                }
                                            },
                                            labels: {
                                                format: '{value} PJ',
                                                style: {
                                                    color: Highcharts.getOptions().colors[1]
                                                }
                                            },
                                            opposite: true
                                        }],
                                        tooltip: {
                                            shared: true
                                        },
                                        legend: {
                                            layout: 'vertical',
                                            align: 'left',
                                            x: 200,
                                            verticalAlign: 'top',
                                            y: 100,
                                            floating: true,
                                            backgroundColor:
                                                Highcharts.defaultOptions.legend.backgroundColor || // theme
                                                'rgba(255,255,255,0.25)'
                                        },
                                        series: [{
                                            name: 'Energy',
                                            type: 'column',
                                            yAxis: 1,
                                            data: series_data,
                                            tooltip: {
                                                valueSuffix: ' PJ'
                                            }

                                        }, {
                                            name: 'Energy',
                                            type: 'spline',
                                            // data: [49.9, 71.5, 106.4, 129.2, 144.0, 176.0],
                                            data: series_data,
                                            tooltip: {
                                                valueSuffix: ' PJ'
                                            }
                                        }]
                                    });


                                    // Highcharts.chart('container', {
                                    //
                                    //     title: {
                                    //         text: this_title
                                    //     },
                                    //
                                    //     subtitle: {
                                    //         text: ''
                                    //     },
                                    //
                                    //     yAxis: {
                                    //         title: {
                                    //             text: 'Energy Unit In (000) GJ'
                                    //         }
                                    //     },
                                    //     legend: {
                                    //         layout: 'vertical',
                                    //         align: 'right',
                                    //         verticalAlign: 'middle'
                                    //     },
                                    //
                                    //     plotOptions: {
                                    //         series: {
                                    //             label: {
                                    //                 connectorAllowed: false
                                    //             },
                                    //             pointStart: this_start
                                    //         }
                                    //     },
                                    //
                                    //     series: series_data,
                                    //
                                    //     // series: [{
                                    //     //     name: 'Installation',
                                    //     //     data: [43934, 52503, 57177, 69658, 97031, 119931, 137133, 154175]
                                    //     // }, {
                                    //     //     name: 'Manufacturing',
                                    //     //     data: [24916, 24064, 29742, 29851, 32490, 30282, 38121, 40434]
                                    //     // }, {
                                    //     //     name: 'Sales & Distribution',
                                    //     //     data: [11744, 17722, 16005, 19771, 20185, 24377, 32147, 39387]
                                    //     // }, {
                                    //     //     name: 'Project Development',
                                    //     //     data: [null, null, 7988, 12169, 15112, 22452, 34400, 34227]
                                    //     // }, {
                                    //     //     name: 'Other',
                                    //     //     data: [12908, 5948, 8105, 11248, 8989, 11816, 18274, 18111]
                                    //     // }],
                                    //
                                    //     responsive: {
                                    //         rules: [{
                                    //             condition: {
                                    //                 maxWidth: 500
                                    //             },
                                    //             chartOptions: {
                                    //                 legend: {
                                    //                     layout: 'horizontal',
                                    //                     align: 'center',
                                    //                     verticalAlign: 'bottom'
                                    //                 }
                                    //             }
                                    //         }]
                                    //     }
                                    //
                                    // });

                                </script>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection