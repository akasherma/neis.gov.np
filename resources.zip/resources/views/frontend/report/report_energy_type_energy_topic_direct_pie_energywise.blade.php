@extends('frontend_layouts.new_report_layout')
@section('content')

    <form class="" action="{{ $url }}" method="get" id="thisform">
        @csrf
        <?php

        $start = (!empty($_GET['start']) && is_numeric($_GET['start']) && $_GET['start'] > 1990 && $_GET['start'] <= (date('Y') - 1) )?$_GET['start']:(date('Y') - 1);

        $end = (!empty($_GET['end']) && is_numeric($_GET['end']) && $_GET['end'] > 1990 && $_GET['end'] <= date('Y') )?$_GET['end']:date('Y');

        $energy_topic = (!empty($_GET['energy_topic']) && in_array($_GET['energy_topic'], ['sector', 'land_type', 'geographic_region', 'river']))?$_GET['energy_topic']:'sector';

        $province_slugs = array();

        if(!empty($province_list)){
            foreach($province_list as $the_province){
                array_push( $province_slugs, $the_province->location_slug);
            }
        }

        $province = (!empty($_GET['province']) && in_array($_GET['province'], $province_slugs))?$_GET['province']:'province-2';

        $selected_province = '';

        ?>
        <div class="row">
            <div class="col-md-2">
                <div id="fiscal_year" class="form-group direct tabular">
                    <label for="">Province</label>
                    <select name="province" class="form-control" onchange="document.getElementById('thisform').submit();">
                        @if(!is_null($province_list))
                            @foreach($province_list as $the_province)
                                <option value="{{ $the_province->location_slug }}" {{ ($the_province->location_slug == $province)?'selected':'' }}>{{ $the_province->location_name }}</option>
                                <?php $selected_province = ($the_province->location_slug == $province)?$the_province->location_name:$selected_province; ?>
                            @endforeach
                        @endif
                    </select>
                </div>
            </div>
            <div class="col-md-2">
                <div id="fiscal_year" class="form-group direct tabular">
                    <label for="">Fiscal Year</label>
                    <select name="start" class="form-control" onchange="document.getElementById('end_date').value=(parseInt(this.value) + 1); document.getElementById('thisform').submit();">
                        @for($i = (date('Y') -1); $i >= 1990; $i--)
                            <?php $j = $i + 1; ?>
                            <option value="{{ $i }}" {{ ($start == $i)?'selected':'' }}>{{ $i }}/{{ $j }}</option>
                        @endfor
                    </select>
                    <input type="hidden" value="{{$end}}" id="end_date" name="end" readonly>
                </div>
            </div>
            <div class="col-md-4">
                <div class="form-group">
                    <label for="">Energy Topic</label>
                    <select name="energy_topic" id="" class="form-control" onchange="document.getElementById('thisform').submit();">
                        <option value="sector" {{ ($energy_topic == 'sector')?'selected':'' }}>Sector</option>
                        <option value="land_type" {{ ($energy_topic == 'land_type')?'selected':'' }}>Land Type</option>
                        <option value="geographic_region" {{ ($energy_topic == 'geographic_region')?'selected':'' }}>Geographic Region</option>
                        <option value="river" {{ ($energy_topic == 'river')?'selected':'' }}>River</option>
                    </select>
                </div>
            </div>
            <div class="col-md-2">
                <div class="form-group">
                    <label for="">&nbsp;</label>
                    <button type="submit" class="btn btn-primary">Search</button>
                </div>
            </div>
        </div>

    </form>

    <section id="horizontal-form-layouts">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="this_title">Total Energy {{ $this_energy_type->energy_type_name }} By {{ ucwords(str_replace("_", " ", $energy_topic)) }}s of Fiscal Year [{{ $start }}/{{ $end }}]</h4>
                        <input type="hidden" id="this_name" value="{{ ucwords(str_replace("_", " ", $energy_topic)) }}">
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <?php
                    $permalink = $url;
                    ?>
                    <div class="card-content collpase show">
                        <div class="card-body row">
                            <div class="col-md-12 form-body-listing">

                                <div id="container" style="height:500px;"></div>
                                <p>Energy Unit In (000) GJ</p>
                                <div class="table-responsive">
                                    <table border="1" cellspacing="3" cellpadding="3">
                                        <tr>
                                            <th>{{ ucwords(str_replace("_", " ", $energy_topic)) }}</th>
                                            <th>Energy Unit In (000) GJ</th>
                                        </tr>

                                        <?php
                                        $count = 1;
                                        $col = array();
                                        if(!empty($final_result)){
                                            $total = 0;
                                            $col_count = 0;
                                            foreach($final_result as $key=>$value){
                                                ?>

                                                <tr class="top_row">
                                                    <th>
                                                        {{ ucwords(str_replace('_', ' ', $key)) }}
                                                        <?php
                                                        $col[$col_count] = (!empty($col[$col_count]))?((float)$col[$col_count]):0;
                                                        echo '<input type="hidden" id="row'.$count.'" value="'.$key.'-'.(((float)$value->qty)/1000).'">';
                                                        ?>
                                                    </th>
                                                    <?php
                                                        echo '<td><input type="hidden" class=" row'.$count.'" value="'.(((float)$value->qty)/1000).'">'.(((float)$value->qty)/1000).'</td>';
                                                                $total += (((float)$value->qty)/1000);
                                                                $col[$col_count] += (((float)$value->qty)/1000);
                                                                $col_count++;


                                                        $count++;
                                                    ?>
                                                </tr>


                                        <?php
                                            }
                                        ?>

                                            <tr class="">
                                                <th>
                                                    Total
                                                    <?php
                                                    echo '<input type="hidden" id="row'.$count.'" value="Total">';
                                                    ?>
                                                </th>
                                                <td>{{ $total }}</td>
                                            </tr>
                                        <?php
                                        }
                                        ?>
                                    </table>
                                </div>

                                <script>

                                    function getRandomInt(max) {
                                        return Math.floor(Math.random() * Math.floor(max));
                                    }

                                    var this_title = document.getElementById("this_title").innerHTML;

                                    var this_name = document.getElementById("this_name").value;

                                    // var categories_arr = new Array();

                                    // var findit = document.getElementsByClassName('x-axis');
                                    // for(var i = 0; i < findit.length; i++){
                                    //     var this_key = findit[i].value;
                                    //     categories_arr.push(this_key);
                                    // }

                                    var series_data = [];

                                    var top_row = document.getElementsByClassName('top_row');

                                    for(var j=0;j<top_row.length;j++){
                                        var k = j+1;
                                        var row = 'row'+k;

                                        // console.log(row);

                                        var y_value = 0;
                                        var find_row = document.getElementsByClassName(row);

                                        var y_value = find_row[0].value;

                                        // for (var i = 0; i < find_row.length; i++) {
                                        //     var this_key = find_row[i].value;
                                        //     row_arr.push(parseInt(this_key));
                                        // }
                                        var find_id_row_value = document.getElementById(row).value;

                                        // console.log(row);

                                        // {
                                        //     name: 'Chrome',
                                        //         y: 61.41,
                                        //     sliced: true,
                                        //     selected: true
                                        // }

                                        if(k < 2)
                                            var obj_row = {name: find_id_row_value, y: parseFloat(y_value), sliced: true, selected: true};
                                        else
                                            var obj_row = {name: find_id_row_value, y: parseFloat(y_value)};

                                        series_data.push(obj_row);

                                    }

                                    // console.log(series_data);

                                    // return false;

                                    // var series_data = [obj_row1, obj_row2, obj_row3, obj_row4, obj_row5, obj_row6];

                                    Highcharts.chart('container', {
                                        chart: {
                                            plotBackgroundColor: null,
                                            plotBorderWidth: null,
                                            plotShadow: false,
                                            type: 'pie'
                                        },
                                        title: {
                                            text: this_title
                                        },
                                        credits: {
                                            enabled: false
                                        },
                                        tooltip: {
                                            pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
                                        },
                                        plotOptions: {
                                            pie: {
                                                allowPointSelect: true,
                                                cursor: 'pointer',
                                                dataLabels: {
                                                    enabled: true,
                                                    format: '<b>{point.name}</b>: {point.percentage:.1f} %'
                                                }
                                            }
                                        },
                                        series: [{
                                            name: this_name,
                                            colorByPoint: true,
                                            data: series_data
                                        }]
                                    });
                                </script>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection