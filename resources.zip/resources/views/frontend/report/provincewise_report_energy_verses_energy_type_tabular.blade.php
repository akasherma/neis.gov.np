@extends('frontend_layouts.new_report_layout')
@section('content')

    <form class="" action="{{ $url }}" method="get" id="thisform">
        @csrf
        <?php

        $start = (!empty($_GET['start']) && is_numeric($_GET['start']) && $_GET['start'] > 1990 && $_GET['start'] <= (date('Y') - 1) )?$_GET['start']:(date('Y') - 1);

        $end = (!empty($_GET['end']) && is_numeric($_GET['end']) && $_GET['end'] > 1990 && $_GET['end'] <= date('Y') )?$_GET['end']:date('Y');

        $energy_topic = (!empty($_GET['energy_topic']) && in_array($_GET['energy_topic'], ['sector', 'land_type', 'geographic_region', 'river']))?$_GET['energy_topic']:'sector';

        $province_slugs = array();

        if(!empty($province_list)){
            foreach($province_list as $the_province){
                array_push( $province_slugs, $the_province->location_slug);
            }
        }

        $province = (!empty($_GET['province']) && in_array($_GET['province'], $province_slugs))?$_GET['province']:'province-2';

        $selected_province = '';

        ?>
        <div class="row">
            <div class="col-md-2">
                <div id="fiscal_year" class="form-group direct tabular">
                    <label for="">Province</label>
                    <select name="province" class="form-control" onchange="document.getElementById('thisform').submit();">
                        @if(!is_null($province_list))
                            @foreach($province_list as $the_province)
                                <option value="{{ $the_province->location_slug }}" {{ ($the_province->location_slug == $province)?'selected':'' }}>{{ $the_province->location_name }}</option>
                                <?php $selected_province = ($the_province->location_slug == $province)?$the_province->location_name:$selected_province; ?>
                            @endforeach
                        @endif
                    </select>
                </div>
            </div>
            <div class="col-md-2">
                <div id="fiscal_year" class="form-group direct tabular">
                    <label for="">Fiscal Year</label>
                    <select name="start" class="form-control" onchange="document.getElementById('end_date').value=(parseInt(this.value) + 1); document.getElementById('thisform').submit();">
                        @for($i = (date('Y') -1); $i >= 2019; $i--)
                            <?php $j = $i + 1; ?>
                            <option value="{{ $i }}" {{ ($start == $i)?'selected':'' }}>{{ $i }}/{{ $j }}</option>
                        @endfor
                    </select>
                    <input type="hidden" value="{{$end}}" id="end_date" name="end" readonly>
                </div>
            </div>
            {{--<div class="col-md-4">--}}
                {{--<div class="form-group">--}}
                    {{--<label for="">Energy Topic</label>--}}
                    {{--<select name="energy_topic" id="" class="form-control" onchange="document.getElementById('thisform').submit();">--}}
                        {{--<option value="sector" {{ ($energy_topic == 'sector')?'selected':'' }}>Sector</option>--}}
                        {{--<option value="land_type" {{ ($energy_topic == 'land_type')?'selected':'' }}>Land Type</option>--}}
                        {{--<option value="geographic_region" {{ ($energy_topic == 'geographic_region')?'selected':'' }}>Geographic Region</option>--}}
                        {{--<option value="river" {{ ($energy_topic == 'river')?'selected':'' }}>River</option>--}}
                    {{--</select>--}}
                {{--</div>--}}
            {{--</div>--}}
            <div class="col-md-2">
                <div class="form-group">
                    <label for="">&nbsp;</label>
                    <button type="submit" class="btn btn-primary">Search</button>
                </div>
            </div>
        </div>

    </form>

    <section id="horizontal-form-layouts">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="this_title">
                            {{ ($selected_province != '')?'Province "'.$selected_province.'"':''}} :: Energy Consumption By Sector of Fiscal Year {{ $start }}/{{ $end }}
                        </h4>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="card-content collpase show">
                        <div class="card-body row">
                            <div class="col-md-12 form-body-listing">
                                <div id="container" style="height:500px;"></div>
                                <p>Energy Unit In (000000) GJ</p>
                                <div class="table-responsive">
                                    <table class="table table-striped table-bordered">
                                        <?php
                                        $col = array();
                                        $col_total_init = 0;
                                        ?>
                                        <tr>
                                            <th colspan="2">Fuel Type</th>
                                            <?php
                                            if(!empty($col_send)){
                                                foreach($col_send as $the_col){
                                                    echo '<th><input type="hidden" class="x-axis" value="'.$the_col.'">'.$the_col.'</th>';
                                                    $col[$col_total_init] = 0;
                                                    $col_total_init++;
                                                }
                                                $col[$col_total_init] = 0;
                                            }
                                            ?>
                                            <th>
                                                {{--<input type="hidden" class="x-axis" value="Total2">--}}
                                                Grand Total
                                            </th>
                                        </tr>
                                        <?php
                                        $count = 1;
                                        $row_class= '';
                                        $row_key= '';
                                        $counter = 0;
                                        $color_arr = array('table-primary', 'table-success', 'table-info', 'table-warning');
                                        if(!empty($final_result)){
                                            foreach($final_result as $key=>$value){

                                                $this_key = (!empty($key))?explode('-', $key):array();

                                                $this_first_key = (is_array($this_key) && (!empty($this_key[0])))?$this_key[0]:'';

                                                $total = 0;
                                                $col_count = 0;

                                                $counter += ($this_first_key != $row_key)?1:0;

                                                $counter = ($counter < count($color_arr))?$counter:0;

                                                $row_class = $color_arr[$counter];

                                                ?>

                                                <tr class="top_row {{ $row_class }}" title="Key: {{ $row_key }} & Counter: {{ $counter }}">
                                                    <th>
                                                        {{ ($this_first_key != $row_key)?$this_first_key:'' }}
                                                        <?php $row_key = ($this_first_key != $row_key)?$this_first_key:$row_key; ?>
                                                    </th>
                                                    <td>
                                                        {{ (is_array($this_key) && (!empty($this_key[1])))?ucwords(str_replace('_', ' ', $this_key[1])):'' }}
                                                    <?php
                                                    echo '<input type="hidden" id="row'.$count.'" value="'.$key.'">';
                                                    ?>
                                                    </td>
                                                    <?php
                                                        if(is_array($value)){
                                                            foreach($value as $the_value){
//                                                                $col[$col_count] = (!empty($col[$col_count]))?(((float)$col[$col_count])/1000000):0;
                                                                $this_no = (((float)$the_value)/1000000);
//                                                                echo '<td><input type="hidden" class=" row'.$count.'" value="'.$this_no.'">'.(round($this_no,2)).'</td>';
                                                                echo '<td><input type="hidden" class=" row'.$count.'" value="'.$this_no.'">'.(round($this_no,2)).'</td>';
                                                                $total += abs($this_no);
                                                                $col[$col_count] += abs($this_no);
                                                                $col_count++;
                                                            }
                                                        }

//                                                        $col[$col_count] = (!empty($col[$col_count]))?(((float)$col[$col_count])/1000000):0;

                                                        $col[$col_count] += $total;
//                                                        $col_count++;
                                                    ?>
                                                    <td>
                                                        <?php

//                                                        echo '<pre>';
//                                                        print_r($col);

                                                        ?>
                                                        {{ round($total, 2) }}</td>
                                                </tr>

                                        <?php
                                                $count++;
                                            }
                                        ?>

                                            <tr class="top_row table-active">
                                                <th colspan="2">
                                                    Grand Total
                                                    <?php
                                                    echo '<input type="hidden" id="row'.$count.'" value="">';
                                                    ?>
                                                </th>
                                                <?php
                                                    $col_total = 0;
                                                    if(is_array($col)){
                                                        foreach($col as $the_value){
                                                            $this_no = ((float)$the_value);
//                                                            echo '<td><input type="hidden" class=" row'.$count.'" value="'.$this_no.'">'.(round($this_no,2)).'</td>';;
                                                            echo '<th>'.(round($this_no,2)).'</th>';
                                                            $col_total += (float)$the_value;
                                                        }
                                                    }
                                                    $count++;
                                                ?>
                                                {{--<td>{{ $col_total }}</td>--}}
                                            </tr>
                                        <?php
                                        }
                                        ?>
                                    </table>
                                </div>

                                <script>

                                    function getRandomInt(max) {
                                        return Math.floor(Math.random() * Math.floor(max));
                                    }

                                    var this_title = document.getElementById("this_title").innerHTML;



                                    var categories_arr = new Array();

                                    var findit = document.getElementsByClassName('x-axis');
                                    for(var i = 0; i < findit.length; i++){
                                        var this_key = findit[i].value;
                                        categories_arr.push(this_key);
                                    }

                                    var series_data = [];

                                    var top_row = document.getElementsByClassName('top_row');

                                    for(var j=0;j<top_row.length;j++){
                                        var k = j+1;
                                        var row = 'row'+k;

                                        console.log(row);

                                        var row_arr = new Array();
                                        var find_row = document.getElementsByClassName(row);

                                        for (var i = 0; i < find_row.length; i++) {
                                            var this_key = find_row[i].value;
                                            row_arr.push(parseInt(this_key));
                                        }
                                        var find_id_row_value = document.getElementById(row).value;
                                        var obj_row = {name: find_id_row_value, data: row_arr};
                                        series_data.push(obj_row);

                                    }

                                    Highcharts.chart('container', {
                                        chart: {
                                            type: 'column'
                                        },
                                        title: {
                                            text: this_title
                                        },
                                        subtitle: {
                                            text: ''
                                        },
                                        credits: {
                                            enabled: false
                                        },
                                        xAxis: {
                                            categories: categories_arr,
                                            crosshair: true
                                        },
                                        yAxis: {
                                            min: 0,
                                            title: {
                                                text: 'Energy Unit In (000000) GJ'
                                            }
                                        },
                                        tooltip: {
                                            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                                            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                                                '<td style="padding:0"><b>{point.y:.1f} GJ</b></td></tr>',
                                            footerFormat: '</table>',
                                            shared: true,
                                            useHTML: true
                                        },
                                        plotOptions: {
                                            column: {
                                                pointPadding: 0.2,
                                                borderWidth: 0
                                            }
                                        },
                                        series: series_data
                                    });
                                </script>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection