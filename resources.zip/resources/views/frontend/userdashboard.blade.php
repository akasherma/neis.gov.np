@extends('frontend_layouts.user_dashboard_layout')

@section('content')

<div class="content-header row">
    <div class="content-header-left col-md-12 col-12">
        <h3 class="content-header-title">Welcome To Passport Entry Dashboard !!!</h3>
    </div>
</div>

<div class="row">

    <div class="clearfix"></div>
    @if(!empty($companies))
        @foreach($companies as $the_company)
        <div class="col-lg-4 col-md-12">
            <div class="row">
                <div class="col-12">
                    <div class="card pull-up">
                        <div class="card-header">
                            <h4>
                                <a href="{{ url('/').'/user/dashboard/company/edit/'.$the_company->id }}">
                                    {{ strtoupper($the_company->company_applied_for_name) }}
                                </a>
                            </h4>
                        </div>
                        <div class="card-content collapse show row">
                            <div class="card-body pt-0 pb-1 col-lg-6">
                                <div class="media d-flex">
                                    <div class="align-self-center align-center">
                                        <h6 class="text-bold-600 mt-2"> Total Demands </h6>
                                        <h6 class="text-bold-600 mt-1"><span class="blue-grey">1</span></h6>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body pt-0 pb-1 col-lg-6">
                                <div class="media d-flex">
                                    <div class="align-self-center align-center">
                                        <h6 class="text-bold-600 mt-2"> Applied Candidate </h6>
                                        <h6 class="text-bold-600 mt-1"><span class="blue-grey">0</span></h6>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @endforeach
    @endif
</div>
<div class="row">
    <div class="clearfix"></div>
    @if(!empty($companies))
        <div class="col-lg-4 col-md-12">
            <div class="row">
                <div class="col-12">
                    <div class="card pull-up bg-gradient-directional-danger">
                        <div class="card-header bg-hexagons-danger">
                            <h4 class="card-title white">Analytics</h4>
                            <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                            <div class="heading-elements">
                                <ul class="list-inline mb-0">
                                    <li>
                                        <a class="btn btn-sm btn-white danger box-shadow-1 round btn-min-width pull-right" href="#" target="_blank">Report <i class="ft-bar-chart pl-1"></i></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="card-content collapse show bg-hexagons-danger">
                            <div class="card-body">
                                <div class="media d-flex">
                                    <div class="align-self-center width-100">
                                        <div id="Analytics-donut-chart" class="height-100 donutShadow"></div>
                                    </div>
                                    <div class="media-body text-right mt-1">
                                        <h3 class="font-large-2 white">###</h3>
                                        {{--<h6 class="mt-1"><span class="text-muted white">Analytics in the <a href="#" class="darken-2 white">last year.</a></span></h6>--}}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    @endif
</div>
@endsection