@extends('frontend_layouts.datatables_list')

@section('content')

    <div class="app-content content">
      <div class="content-wrapper">
        <div class="content-body"><!-- Zero configuration table -->
<section id="configuration">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Demand Lists <a href="{{url('/')}}/user/dashboard/demand/add" class="btn btn-primary btn-xs">Add</a></h4>
                    <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                    <div class="heading-elements">
                        <ul class="list-inline mb-0">
                            {{--<li><a data-action="collapse"><i class="ft-minus"></i></a></li>--}}
                            <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                            <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            {{--<li><a data-action="close"><i class="ft-x"></i></a></li>--}}
                        </ul>
                    </div>
                </div>
                <div class="card-content collapse show">
                    <div class="table-responsive card-body card-dashboard">
                        <table class="table table-striped table-bordered zero-configuration">
                            <thead>
                                <tr>
                                    <th>Company</th>
                                    <th>Demand Ref No.</th>
                                    <th>Pre Approval</th>
                                    <th>Job Category</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @if(!is_null($demands))
                                @foreach($demands as $the_demand)
                                <tr>
                                    <td>{{ $the_demand->company_applied_for_name }}</td>
                                    <td>{{ $the_demand->demand_no }}</td>
                                    <td>{{ (!empty($the_demand->pre_approval_date))?'Yes':'No' }}</td>
                                    <td>{{ $the_demand->job_position }}</td>
                                    <td>{{ (!empty($the_demand->status) && $the_demand->status == 'Y')?"Running":"Closed" }}</td>
                                    <td><a class="btn btn-primary" href="{{ url('/').'/user/dashboard/demand/edit/'.$the_demand->id }}">Edit</a>
                                        @if($parent_id == $user_id)
                                            <a class="btn btn-danger" href="{{ url('/').'/user/dashboard/demand/delete/'.$the_demand->id }}" onclick="return confirm('Are you sure you want to close this demand?');">Close</a>
                                        @endif
                                    </td>

                                </tr>
                                @endforeach
                                @endif
                            </tbody>
                            {{--<tfoot>--}}
                                {{--<tr>--}}
                                    {{--<th>Pre Approval Date</th>--}}
                                    {{--<th>Lot No.</th>--}}
                                    {{--<th>Chalani No.</th>--}}
                                    {{--<th>Demand No.</th>--}}
                                    {{--<th>Country</th>--}}
                                    {{--<th>Company</th>--}}
                                    {{--<th>Action</th>--}}
                                {{--</tr>--}}
                            {{--</tfoot>--}}
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--/ Zero configuration table -->



        </div>
      </div>
    </div>
@endsection