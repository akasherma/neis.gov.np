@extends('frontend_layouts.frontend_federal_chart_layout')
@section('content')
<section id="horizontal-form-layouts">
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <row>
                    <div class="col-md-9">

                        <h2 class="card-title" id="horz-layout-colored-controls">
                            National Energy Consumption Scenario
                        </h2>

                    </div>
                    {{--<div class="col-md-3">--}}
                        {{--<div class="advance-filter">--}}
                            {{--<form action="{{$url}}/" id="filterform" method="get">--}}
                                {{--@csrf--}}
                                {{--<div class="row">--}}


                                    {{--<div class="col-md-8">--}}
                                        {{--<div class="form-group">--}}
                                            {{--<select name="start" id="output" class="form-control border-primary">--}}
                                                {{--<option value="2019" {{ (!empty($start) && $start == 2019)?'selected="selected"':'' }}>2019/2020</option>--}}
                                                {{--<option value="2020" {{ (!empty($start) && $start == 2020)?'selected="selected"':'' }}>2020/2021</option>--}}
                                                {{--<option value="2021" {{ (!empty($start) && $start == 2021)?'selected="selected"':'' }}>2021/2022</option>--}}
                                            {{--</select>--}}
                                        {{--</div>--}}
                                        {{--<input type="hidden" name="status" value="Y" />--}}
                                    {{--</div>--}}

                                    {{--<div class="col-md-4">--}}
                                        {{--<div class="form-group">--}}
                                            {{--<button class="form-control bg bg-warning" style="width: auto;">Go</button>--}}
                                        {{--</div>--}}
                                    {{--</div>--}}
                                    {{--<div class="clearfix"></div>--}}
                                {{--</div>--}}
                            {{--</form>--}}
                        {{--</div>--}}
                    {{--</div>--}}
                </row>
                <div class="clearfix"></div>
            </div>
            <?php
            $readonly = 'readonly';
            $disabled = 'disabled';
            ?>
            <div class="card-content collpase show">
                <div class="card-body">



                    @if(!empty($start) && $start != date('Y'))

                        {{--http://localhost/wecs/public_html/dashboard/entryform/import/store--}}

                        <section id="horizontal-form-layouts">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card">
                                        <div class="card-header">
                                            {{--<h4 class="card-title" id="this_title">Total Energy {{ $this_energy_type->energy_type_name }} Total Energy of Fiscal Year [{{ $start }}/{{ $end }}]</h4>--}}
                                            <input type="hidden" id="this_name" value="Total Energy">
                                            <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                                            <div class="heading-elements">
                                                <ul class="list-inline mb-0">
                                                    <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                                    <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <?php
                                        $permalink = $url;
                                        ?>
                                        <div class="card-content collpase show">
                                            <div class="card-body row">
                                                <div class="col-md-12 form-body-listing">



                                                    <div style=" border: 2px solid #333; padding: 30px 30px 60px; ">
                                                        <h4 class="card-title text-center" id="this_title" style="display: none;">National Energy {{ $this_energy_type->energy_type_name }} By Sectors ({{ $start }})</h4>

                                                        <div id="container" style="height:650px;"></div>
                                                        <span id="total"></span>
                                                    </div>
                                                    {{--<p class="text-right">Unit: PJ</p>--}}
                                                    <div class="table-responsive">
                                                        <table class="table table-hover table-bordered">
                                                            <tr class="info">
                                                                <th>Sectors</th>
                                                                <th>Grand Total (PJ)</th>
                                                                <th>Total (In 000,ToE)</th>
                                                                <th>Total (In 000000,MWh)</th>
                                                            </tr>

                                                            <?php
                                                            $count = 1;
                                                            $col = array();
                                                            if(!empty($final_result)){
                                                            $total = 0;
                                                            $col_count = 0;
                                                            foreach($final_result as $key=>$value){
                                                            $col[$col_count] = (!empty($col[$col_count]))?((float)$col[$col_count]):0;
                                                            $this_value = (((float)$value)/1000000);
                                                            if($this_value > 0){
                                                            ?>

                                                            <tr class="top_row">
                                                                <th>
                                                                    <?php
//                                                                    echo '<pre>';
//                                                                    print_r($value);
//                                                                    echo '</pre>';
                                                                    ?>
                                                                    {{ ucwords(str_replace('_', ' ', $key)) }}
                                                                    <?php
                                                                    echo '<input type="hidden" id="row'.$count.'" value="'.$key.'">';
                                                                    ?>
                                                                </th>
                                                                <?php
                                                                $this_total_td = (((float)$value)/1000000);
                                                                echo '<td><input type="hidden" class=" row'.$count.'" value="'.$this_total_td.'">'.round($this_total_td, 2).'</td>';

//                                                                $total += (((float)$value)/1000000);
//                                                                $col[$col_count] += (((float)$value)/1000000);
                                                                $total += $this_total_td;
                                                                $col[$col_count] += $this_total_td;
                                                                $col_count++;
                                                                $count++;
                                                                ?>
                                                                <td>{{ round(($this_total_td*23.8845), 2) }}</td>
                                                                <td>{{ round(($this_total_td/3.6), 2) }}</td>
                                                            </tr>


                                                            <?php
                                                                }
                                                            }
                                                            ?>

                                                            <tr class="">
                                                                <th>
                                                                    Total
                                                                    <?php
                                                                    echo '<input type="hidden" id="row'.$count.'" value="Total">';
                                                                    ?>
                                                                </th>
                                                                <td id="this_total">{{ round($total, 2) }}</td>
                                                                <td>{{ round(($total*23.8845), 2) }}</td>
                                                                <td>{{ round(($total/3.6), 2) }}</td>
                                                            </tr>
                                                            <?php
                                                            }
                                                            ?>
                                                        </table>
                                                    </div>

                                                    <script>
                                                        var this_total = document.getElementById('this_total').innerHTML;
                                                        document.getElementById('total').innerHTML = this_total+' PJ';

                                                        function getRandomInt(max) {
                                                            return Math.floor(Math.random() * Math.floor(max));
                                                        }

                                                        var this_title = document.getElementById("this_title").innerHTML;

                                                        var this_name = document.getElementById("this_name").value;

                                                        // var categories_arr = new Array();

                                                        // var findit = document.getElementsByClassName('x-axis');
                                                        // for(var i = 0; i < findit.length; i++){
                                                        //     var this_key = findit[i].value;
                                                        //     categories_arr.push(this_key);
                                                        // }

                                                        var series_data = [];

                                                        var top_row = document.getElementsByClassName('top_row');

                                                        for(var j=0;j<top_row.length;j++){
                                                            var k = j+1;
                                                            var row = 'row'+k;

                                                            // console.log(row);

                                                            var y_value = 0;
                                                            var find_row = document.getElementsByClassName(row);

                                                            var y_value = find_row[0].value;

                                                            // for (var i = 0; i < find_row.length; i++) {
                                                            //     var this_key = find_row[i].value;
                                                            //     row_arr.push(parseInt(this_key));
                                                            // }
                                                            var find_id_row_value = document.getElementById(row).value;

                                                            // console.log(row);

                                                            // {
                                                            //     name: 'Chrome',
                                                            //         y: 61.41,
                                                            //     sliced: true,
                                                            //     selected: true
                                                            // }

                                                            if(k < 2)
                                                                var obj_row = {name: find_id_row_value, y: parseFloat(y_value), sliced: true, selected: true};
                                                            else
                                                                var obj_row = {name: find_id_row_value, y: parseFloat(y_value)};

                                                            series_data.push(obj_row);

                                                        }

                                                        // console.log(series_data);

                                                        // return false;

                                                        // var series_data = [obj_row1, obj_row2, obj_row3, obj_row4, obj_row5, obj_row6];

                                                        Highcharts.chart('container', {
                                                            chart: {
                                                                plotBackgroundColor: null,
                                                                plotBorderWidth: null,
                                                                plotShadow: false,
                                                                type: 'pie'
                                                            },
                                                            title: {
                                                                text: this_title
                                                            },
                                                            tooltip: {
                                                                pointFormat: '{series.name}: <b>{point.percentage:.2f}%</b>'
                                                            },
                                                            plotOptions: {
                                                                pie: {
                                                                    size: '80%',
                                                                    allowPointSelect: true,
                                                                    cursor: 'pointer',
                                                                    dataLabels: {
                                                                        enabled: true,
                                                                        format: '<b>{point.name}</b>: {point.percentage:.2f} %',
                                                                        style: {
                                                                            textOverflow: 'ellipsis',
                                                                            fontSize: '1em'
                                                                        }
                                                                    }
                                                                }
                                                            },
                                                            series: [{
                                                                name: this_name,
                                                                colorByPoint: true,
                                                                data: series_data
                                                            }]
                                                        });
                                                    </script>
                                                </div>
                                            </div>


                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>

                    @endif

                </div>


            </div>
        </div>
    </div>
</div>
</section>
@endsection