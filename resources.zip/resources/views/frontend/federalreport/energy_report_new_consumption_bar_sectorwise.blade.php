@extends('frontend_layouts.frontend_federal_chart_layout')
@section('content')
<section id="horizontal-form-layouts">
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-md-9">

                        <h2 class="card-title" id="horz-layout-colored-controls">
                            National Energy Consumption Scenario
                        </h2>
                    </div>
                    {{--<div class="col-md-3">--}}
                        {{--<div class="advance-filter">--}}
                            {{--<form action="{{$url}}/" id="filterform" method="get">--}}
                                {{--@csrf--}}
                                {{--<div class="row">--}}


                                    {{--<div class="col-md-6">--}}
                                        {{--<div class="form-group">--}}
                                            {{--<select name="start" id="output" class="form-control border-primary">--}}
                                                {{--<option value="2019" {{ (!empty($start) && $start == 2019)?'selected="selected"':'' }}>2019/2020</option>--}}
                                                {{--<option value="2020" {{ (!empty($start) && $start == 2020)?'selected="selected"':'' }}>2020/2021</option>--}}
                                                {{--<option value="2021" {{ (!empty($start) && $start == 2021)?'selected="selected"':'' }}>2021/2022</option>--}}
                                            {{--</select>--}}
                                        {{--</div>--}}
                                    {{--</div>--}}

                                    {{--<div class="col-md-2">--}}
                                        {{--<div class="form-group">--}}
                                            {{--<button class="form-control bg bg-warning" style="width: auto;">Go</button>--}}
                                        {{--</div>--}}
                                    {{--</div>--}}
                                    {{--<div class="clearfix"></div>--}}
                                {{--</div>--}}
                            {{--</form>--}}
                        {{--</div>--}}
                    {{--</div>--}}
                    <div class="clearfix"></div>
                </div>
            </div>
            <?php
            $readonly = 'readonly';
            $disabled = 'disabled';
            ?>
            <div class="card-content collpase show">
                <div class="card-body">



                    @if(!empty($start) && $start != date('Y'))

                        <section id="horizontal-form-layouts">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card">
                                        <div class="card-header">

                                            <h4 class="card-title" id="this_title" style="display:none;">National Energy {{ $this_energy_type->energy_type_name }} By Sectors ({{ $start }})</h4>

                                            {{--<h4 class="card-title" id="this_title">Energy {{ ucwords(str_replace("_", " ", $energy_type_slug)) }}--}}
                                                {{--For  {{ ucwords(str_replace("_", " ", 'Total Energy')) }} of Fiscal Year [{{ $start }}/{{ $end }}]</h4>--}}
                                            <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                                            <div class="heading-elements">
                                                <ul class="list-inline mb-0">
                                                    <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                                    <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="card-content collpase show">
                                            <div class="card-body row">
                                                <div class="col-md-12 form-body-listing">


                                                    <div style=" border: 2px solid #333; padding: 30px 30px 60px; ">
                                                        <div id="container" style="height:650px;"></div>
                                                        <span id="total"></span>
                                                    </div>
                                                    {{--<p class="text-right">Unit: PJ</p>--}}
                                                    <div class="table-responsive">
                                                        <table class="table table-striped table-bordered">
                                                            <?php
                                                            $col = array();
                                                            $col_total_init = 0;
                                                            ?>
                                                            <tr>
                                                                <th colspan="2">Fuel Type</th>
                                                                <?php
                                                                if(!empty($col_send)){
                                                                    foreach($col_send as $the_col){
                                                                        echo '<th><input type="hidden" class="x-axis" value="'.$the_col.'">'.$the_col.'</th>';
                                                                        $col[$col_total_init] = 0;
                                                                        $col_total_init++;
                                                                    }
                                                                    $col[$col_total_init] = 0;
                                                                }
                                                                ?>
                                                                <th>
                                                                    {{--<input type="hidden" class="x-axis" value="Total2">--}}
                                                                    Grand Total (PJ)
                                                                </th>
                                                            </tr>
                                                                <?php
                                                                $count = 1;
                                                                $row_class= '';
                                                                $row_key= '';
                                                                $counter = 0;
                                                                $color_arr = array('table-primary', 'table-success', 'table-info', 'table-warning');
                                                                if(!empty($final_result)){
                                                                foreach($final_result as $key=>$value){

                                                                $this_key = (!empty($key))?explode('-', $key):array();

                                                                $this_first_key = (is_array($this_key) && (!empty($this_key[0])))?$this_key[0]:'';

                                                                $total = 0;
                                                                $col_count = 0;

                                                                $counter += ($this_first_key != $row_key)?1:0;

                                                                $counter = ($counter < count($color_arr))?$counter:0;

                                                                $row_class = $color_arr[$counter];

                                                                ?>

                                                                <tr class="top_row {{ $row_class }}" title="Key: {{ $row_key }} & Counter: {{ $counter }}">
                                                                    <th colspan="{{ $col_total_init }}">
                                                                        {{ ($this_first_key != $row_key)?$this_first_key:'' }}
                                                                    </th>
                                                                </tr>

                                                                <tr class="top_row {{ $row_class }}" title="Key: {{ $row_key }} & Counter: {{ $counter }}">
                                                                    <th>
                                                                        {{ ($this_first_key != $row_key)?$this_first_key:'' }}
                                                                        <?php $row_key = ($this_first_key != $row_key)?$this_first_key:$row_key;
                                                                        $second_term = ((!empty($this_key[1])))?ucwords(str_replace('_', ' ', $this_key[1])):'';
                                                                        $third_term = (is_array($this_key) && (!empty($this_key[2])))?ucwords(str_replace('_', ' ', $this_key[2])):'';
                                                                        ?>
                                                                    </th>
                                                                    <td>
                                                                        {{--{{ $second_term }}--}}
                                                                        <?php echo $this_term_value = $second_term.' '.$third_term; ?>
                                                                        <?php
                                                                        echo '<input type="hidden" id="row'.$count.'" value="'.$this_term_value.'">';
                                                                        ?>
                                                                    </td>
                                                                    <?php
                                                                    if(!empty($value[0])){
                                                                        foreach($value as $the_value){

                                                                            if(empty($col[$col_count])){
                                                                                $col[$col_count] = 0;
                                                                            }

//                                                                $col[$col_count] = (!empty($col[$col_count]))?(((float)$col[$col_count])/1000):0;
                                                                            $this_no = (((float)$the_value));
//                                                                echo '<td><input type="hidden" class=" row'.$count.'" value="'.$this_no.'">'.(round($this_no,2)).'</td>';
                                                                            echo '<td><input type="hidden" class=" row'.$count.'" value="'.$this_no.'">'.(round($this_no,2)).'</td>';
                                                                            $total += abs($this_no);

                                                                            $col[$col_count] += abs($this_no);
                                                                            $col_count++;
                                                                        }
                                                                    }

                                                                    //                                                        $col[$col_count] = (!empty($col[$col_count]))?(((float)$col[$col_count])/1000):0;

                                                                    $col[$col_count] += $total;
                                                                    //                                                        $col_count++;
                                                                    ?>
                                                                    <td>
                                                                        <?php

                                                                        //                                                        echo '<pre>';
                                                                        //                                                        print_r($col);

                                                                        ?>
                                                                        {{ round($total, 2) }}</td>
                                                                </tr>

                                                                <?php
                                                                $count++;
                                                                }
                                                                ?>

                                                                <tr class="top_row table-active">
                                                                    <td colspan="2">
                                                                        Grand Total
                                                                        <?php
                                                                        echo '<input type="hidden" id="row'.$count.'" value="">';
                                                                        ?>
                                                                    </td>
                                                                    <?php
                                                                    $col_total = 0;
                                                                    if(!empty($col) && is_array($col)){
                                                                        foreach($col as $the_value){
                                                                            $this_no = ((float)$the_value) * 1000;
//                                                            echo '<td><input type="hidden" class=" row'.$count.'" value="'.$this_no.'">'.(round($this_no,2)).'</td>';;
                                                                            echo '<td>'.(round($this_no,2)).'</td>';
                                                                            $col_total += (float)$the_value;
                                                                        }
                                                                    }
                                                                    $count++;
                                                                    ?>
                                                                    {{--<td>{{ $col_total }}</td>--}}
                                                                </tr>
                                                                <?php
                                                                }
                                                                ?>

                                                        </table>
                                                    </div>

                                                    <script>

                                                        function getRandomInt(max) {
                                                            return Math.floor(Math.random() * Math.floor(max));
                                                        }

                                                        var this_title = document.getElementById("this_title").innerHTML;



                                                        var categories_arr = new Array();

                                                        var findit = document.getElementsByClassName('x-axis');
                                                        for(var i = 0; i < findit.length; i++){
                                                            var this_key = findit[i].value;
                                                            categories_arr.push(this_key);
                                                        }

                                                        var series_data = [];

                                                        var top_row = document.getElementsByClassName('top_row');

                                                        for(var j=0;j<top_row.length;j++){
                                                            var k = j+1;
                                                            var row = 'row'+k;

                                                            console.log(row);

                                                            var row_arr = new Array();
                                                            var find_row = document.getElementsByClassName(row);

                                                            for (var i = 0; i < find_row.length; i++) {
                                                                var this_key = find_row[i].value;
                                                                row_arr.push(parseInt(this_key));
                                                            }
                                                            var find_id_row_value = document.getElementById(row).value;
                                                            var obj_row = {name: find_id_row_value, data: row_arr};
                                                            series_data.push(obj_row);

                                                        }

                                                        Highcharts.chart('container', {
                                                            chart: {
                                                                type: 'column'
                                                            },
                                                            title: {
                                                                text: this_title
                                                            },
                                                            subtitle: {
                                                                text: ''
                                                            },
                                                            xAxis: {
                                                                categories: categories_arr,
                                                                crosshair: true
                                                            },
                                                            yAxis: {
                                                                min: 0,
                                                                title: {
                                                                    text: 'Energy Consumption (In PJ)'
                                                                }
                                                            },
                                                            tooltip: {
                                                                headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                                                                pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                                                                    '<td style="padding:0"><b>{point.y:.2f} PJ</b></td></tr>',
                                                                footerFormat: '</table>',
                                                                shared: true,
                                                                useHTML: true
                                                            },
                                                            plotOptions: {
                                                                column: {
                                                                    pointPadding: 0.2,
                                                                    borderWidth: 0
                                                                }
                                                            },
                                                            series: series_data
                                                        });
                                                    </script>
                                                </div>
                                            </div>


                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>

                    @endif

                </div>


            </div>
        </div>
    </div>
</div>
</section>
@endsection