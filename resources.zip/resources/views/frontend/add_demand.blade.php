@extends('frontend_layouts.add_edit_form_layout')

@section('content')

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title" id="horz-layout-colored-controls">Add Demand Entry</h4>
                <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                    <ul class="list-inline mb-0">
                        <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                        <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="card-content collpase show">
                <div class="card-body">
                    <div class="card-text">
                            <p>Please fill all the required inputs</p>
                    </div>
                    <form action="{{url('/')}}/user/dashboard/demand/add" method="post" class="form form-horizontal">
                        @csrf
                        <div class="form-body">
                            <h4 class="form-section"><i class="la la-eye"></i> Demand Details</h4>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group row">
                                        <div class="col-md-12">
                                            <p>Country</p>
                                            @if(!empty($country_applied_for))
                                                <select name="demand[country_applied_for]" class="form-control border-primary" id="">
                                                    <option value="">Select Country</option>
                                                    @foreach($country_applied_for as $country)
                                                        <option value="{{$country->id}}">{{$country->country_applied_for_name}}</option>
                                                    @endforeach
                                                </select>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group row">
                                        <div class="col-md-12">
                                            <p>Company</p>
                                            @if(!empty($company_applied_for))
                                                <select name="demand[company_applied_for]" id="company_list" class="form-control border-primary" id="">
                                                    <option value="">Select Company</option>
                                                    @foreach($company_applied_for as $company)
                                                        <option value="{{$company->id}}">{{$company->company_applied_for_name}}</option>
                                                    @endforeach
                                                </select>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group row">
                                        <div class="col-md-12">
                                            <p>Demand Number</p>
                                            <input type="text" id="demnad_no" class="form-control border-primary" placeholder="" name="demand[demand_no]">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <hr>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        {{--accordians--}}
                                        <div class="panel-group" id="accordion">
                                            <div class="panel panel-default">
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">
                                                        <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">
                                                            Demand Entry</a>
                                                    </h4>
                                                </div>
                                                <div id="collapse2" class="panel-collapse collapse show">
                                                    <div class="panel-body">
                                                        <div class="row">
                                                            <div class="col-md-12">
                                                                <div class="form-group row">
                                                                    <div class="col-md-12">
                                                                        <div class="form-group col-12 file-repeater">
                                                                            <div data-repeater-list="repeater-list">
                                                                                <div data-repeater-item="">
                                                                                    <div class="row ">
                                                                                        <div class="col-md-10 repeater-block5">
                                                                                            <div class="row">
                                                                                                <div class="col-md-4">
                                                                                                    <label>Job Category</label>
                                                                                                    @if(!empty($positions))
                                                                                                    <select name="demandentry[position_id][]" class="form-control border-primary" id="">
                                                                                                        <option value="">Select Job Category</option>
                                                                                                        @foreach($positions as $the_position)
                                                                                                        <option value="{{$the_position->id}}">{{$the_position->position_name}}</option>
                                                                                                        @endforeach
                                                                                                    </select>
                                                                                                    @endif
                                                                                                </div>
                                                                                                <div class="col-md-4">
                                                                                                    <label>Required Quantity</label>
                                                                                                    <input type="number" id="" class="form-control border-primary" placeholder="" name="demandentry[required_qty][]">
                                                                                                </div>
                                                                                                <div class="col-md-4">
                                                                                                    <label>Basic Salary</label>
                                                                                                    <input type="text" id="" class="form-control border-primary" placeholder="" name="demandentry[basic_salary][]">
                                                                                                </div>
                                                                                            </div>
                                                                                            <div class="row">
                                                                                                <div class="col-md-4">
                                                                                                    <label>Duty Hour</label>
                                                                                                    <input type="text" id="" class="form-control border-primary" placeholder="Company" value="8 hrs" name="demandentry[duty_hours][]">
                                                                                                </div>
                                                                                                <div class="col-md-4">
                                                                                                    <label>Lodging</label>
                                                                                                    <select name="demandentry[lodging][]" class="form-control border-primary" id="">
                                                                                                        <option value="Y" selected="selected">Yes</option>
                                                                                                        <option value="N">No</option>
                                                                                                    </select>
                                                                                                </div>
                                                                                                <div class="col-md-4">
                                                                                                    <label>Fooding</label>
                                                                                                    <select name="demandentry[fooding][]" class="form-control border-primary" id="">
                                                                                                        <option value="Y" selected="selected">Yes</option>
                                                                                                        <option value="N">No</option>
                                                                                                    </select>
                                                                                                </div>
                                                                                            </div>
                                                                                            <div class="row">
                                                                                                <div class="col-md-4">
                                                                                                    <label>Overtime</label>
                                                                                                    <input type="text" id="" class="form-control border-primary" value="As per company rule" name="demandentry[overtime][]">
                                                                                                </div>
                                                                                                <div class="col-md-4">
                                                                                                    <label>Air Ticket</label>
                                                                                                    <input type="text" id="" class="form-control border-primary" value="Provided by the company" name="demandentry[air_ticket][]">
                                                                                                </div>
                                                                                                <div class="col-md-4">
                                                                                                    <label>Required Qualification</label>
                                                                                                    <textarea name="demandentry[qualification][]" class="form-control border-primary" id=""></textarea>
                                                                                                </div>
                                                                                            </div>
                                                                                            <div class="row">
                                                                                                <div class="col-md-4">
                                                                                                    <label>Actual Job if different from Job Category In Demand Letter</label>
                                                                                                    @if(!empty($positions))
                                                                                                        <select name="demandentry[position_id_actual][]" class="form-control border-primary" id="">
                                                                                                            <option value="">Select Actual Job Category</option>
                                                                                                            @foreach($positions as $the_position)
                                                                                                                <option value="{{$the_position->id}}">{{$the_position->position_name}}</option>
                                                                                                            @endforeach
                                                                                                        </select>
                                                                                                    @endif
                                                                                                </div>
                                                                                            </div>

                                                                                            <br />
                                                                                            <hr />
                                                                                        </div>
                                                                                        <div class="col-md-2">
                                                                                            <button type="button" data-repeater-create="" name="repeater-block5" id="" class="minus_btn btn btn-danger">
                                                                                                <i class="ft-plus"></i> Remove This
                                                                                            </button>
                                                                                        </div>

                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>

                                                                        <button type="button" data-repeater-create="" id="" name="repeater-block5" class="add_more btn btn-primary">
                                                                            <i class="ft-plus"></i> Add More
                                                                        </button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        {{--accordians--}}
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group row">
                                        <div class="col-md-12">
                                            <p>Pre Approval Date</p>
                                            <input type="date" id="" class="form-control border-primary" placeholder="" name="demand[pre_approval_date]">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group row">
                                        <div class="col-md-12">
                                            <p>Lot Number</p>
                                            <input type="text" id="" class="form-control border-primary" placeholder="" name="demand[lot_number]">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group row">
                                        <div class="col-md-12">
                                            <p>Chalani No</p>
                                            <input type="text" id="" class="form-control border-primary" placeholder="" name="demand[chalani_no]">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <hr>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <p>Remarks</p>
                                        <textarea id="" class="form-control border-primary" placeholder="Remarks" name="demand[remarks]"></textarea>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <div class="form-actions right">
                            <button type="button" class="btn btn-danger mr-1">
                                <i class="ft-x"></i> Cancel
                            </button>
                            <button type="submit" class="btn btn-primary">
                                <i class="la la-check-square-o"></i> Save
                            </button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
<input type="hidden" id="url" value="{{ url('/') }}">
<script>
$(document).ready(function(){
//    alert('asdfasdf');
    $('#pp_issue_date').on('blur', function(){
        // var pp_issue_date = alert($(this).val());
//        var pp_issue_date_obj = new Date($(this).val());
        var pp_arr = ($(this).val()).split('-');
//        console.log(pp_arr);
        if(Array.isArray(pp_arr)){
//            alert(pp_arr[2]+'-'+pp_arr[1]+'-'+(parseInt(pp_arr[0])+5));
            $('#pp_expiry_date').attr("value", pp_arr[2]+'-'+pp_arr[1]+'-'+(parseInt(pp_arr[0])+5));
        }       
//        var pp_issue_date_obj_new = new Date(pp_issue_date_obj.getTime() + 5*365*24*60*60)
//        alert(pp_issue_date_obj.getDay() + '-' + pp_issue_date_obj.getMonth() + '-' + (pp_issue_date_obj.getFullYear() + 5 ));
        
    });
    
    $('.add_more').on('click', function(){
        var classname = '.'+$(this).attr('name');
        // alert(classname);
        var repeater_block_html = $(classname).html();
        $(classname+':last').after('<div class="col-md-10 '+$(this).attr("name")+'">'+repeater_block_html+'</div>');
    });
    
    $('.minus_btn').on('click', function(){
        var classname = '.'+$(this).attr('name');
        // alert(classname);
        var length_this = $(classname).length;
        // alert(length_this);
//        alert(length_this);
//        var repeater_block_html = $('.repeater-block').html();
        if(length_this > 1)
        $(classname+':last').remove();
    });

    $('#company_list').on('change', function(){
        var company_id = $(this).val();
        var url = $('#url').val();
        if(company_id != ''){

            $.ajax({
                method: "GET",
                url: url+"/user/dashboard/demand/getcompany/"+company_id,
                data: { }
            })
            .done(function( msg ) {
                $('#demnad_no').val(msg);
                // alert( "Data Saved: " + msg );
            });

        }else{
            $('#demnad_no').val('');
        }
    });
    
});
</script>
@endsection