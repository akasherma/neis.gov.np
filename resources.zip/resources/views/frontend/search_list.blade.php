@extends('frontend_layouts.datatables_list')
@section('content')
    <div class="app-content content">
      <div class="content-wrapper">
        <div class="content-body"><!-- Zero configuration table -->
<section id="configuration">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <form action="{{url('/')}}/user/dashboard/search" method="get">
                    @csrf
                    <div class="card-header">
                        <h4 class="card-title">Search Lists</h4>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                {{--<li><a data-action="collapse"><i class="ft-minus"></i></a></li>--}}
                                <li>
                                    <button type="reset" name="reset"><i class="ft-rotate-cw"></i></button>
                                </li>
                                <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                                {{--<li><a data-action="close"><i class="ft-x"></i></a></li>--}}
                            </ul>
                        </div>
                    </div>
                    <div class="card-content show">
                        <div class="table-responsive search_filter">
                            <table class="table table-bordered">
                                <tr>

                                    <td>
                                        <label>Company</label>
                                        @if(!empty($company_applied_for))
                                            <select class="form-control" id="company" name="company">
                                                <option value="">Select Company</option>
                                                @foreach($company_applied_for as $the_company)
                                                    <?php $sel = ($the_company->company_applied_for_name == $search_for_company)?'selected':''; ?>
                                                    <option value="{{ $the_company->company_applied_for_name }}" {{ $sel }}>
                                                        {{$the_company->company_applied_for_name}}
                                                    </option>
                                                @endforeach
                                            </select>
                                        @endif
                                    </td>

                                    <td>
                                        <label>Demand Reference</label>
                                        @if(!empty($demand_list))
                                            <select class="form-control" id="demand_ref" name="demand_ref">
                                                <option value="">Select Demand</option>
                                                @foreach($demand_list as $the_demand)
                                                    <?php $sel = ($the_demand->demand_no == $search_for_demand_ref)?'selected':''; ?>
                                                    <option value="{{$the_demand->demand_no}}" {{ $sel }}>{{$the_demand->demand_no}}</option>
                                                @endforeach
                                            </select>
                                        @endif
                                    </td>
                                    <td>
                                        <label>Candidate Name</label>
                                        <input type="text" class="form-control" name="candidate" value="{{ $search_for_candidate }}" />
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <label>Passport No.</label>
                                        <input type="text" class="form-control" name="passport_no" value="{{ $search_for_passport_no }}" />
                                    </td>
                                    <td>
                                        <label>Job Category</label>
                                        @if(!empty($position))
                                            <select class="form-control" id="position_applied_for" name="position">
                                                <option value="">Select Job Category</option>
                                                @foreach($position as $the_position)
                                                    <?php $sel = ($the_position->position_name == $search_for_position)?'selected':''; ?>
                                                    <option value="{{$the_position->position_name}}" {{ $sel }}>{{$the_position->position_name}}</option>
                                                @endforeach
                                            </select>
                                        @endif
                                    </td>
                                    <td>
                                        <label>Referred By</label>
                                        @if(!empty($reference_list))
                                            <select class="form-control" id="referred_by" name="referred_by">
                                                <option value="">Select Option</option>
                                                @foreach($reference_list as $the_reference)
                                                    <?php $sel = (strtolower($the_reference->reference_name) == $search_for_referred_by)?'selected':''; ?>
                                                    <option value="{{ strtolower($the_reference->reference_name) }}" {{ $sel }}>{{$the_reference->reference_name}}</option>
                                                @endforeach
                                            </select>
                                        @endif
                                    </td>
                                </tr>
                            </table>
                            <div class="pl-30">
                                <input type="submit" class="btn btn-info" value="Search" />
                            </div>
                        </div>
                    </div>
                </form>
                <div class="clearfix"></div>
                <div class="row search_list" style="margin: 0;">
                    <div class="col-10 ">
                        <div class="card-content collapse show">
                            <div class="table-responsive card-body card-dashboard">
                                <table class="table table-striped table-bordered zero-configuration">
                                    <thead>
                                        <tr>
                                            <th>&nbsp;</th>
                                            <th>Name</th>
                                            <th>PP No.</th>
                                            <th>Company</th>
                                            <th>Demand No.</th>
                                            <th>Position</th>
                                            <th>Referred By</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @if(!is_null($candidates))
                                        @foreach($candidates as $the_candidate)
                                        <tr>
                                            <td><input type="checkbox" name="candidate_id" value="{{ $the_candidate->id }}" title="{{ $the_candidate->first_name.' '.$the_candidate->middle_name.' '.$the_candidate->last_name }}" class="candidate_id_click" ></td>
                                            <td>{{ $the_candidate->first_name.' '.$the_candidate->middle_name.' '.$the_candidate->last_name }}</td>
                                            <td>{{ $the_candidate->passport_no }}</td>
                                            <td>{{ $the_candidate->company_applied_for_name }}</td>
                                            <td>{{ $the_candidate->demand_no }}</td>
                                            <td>{{ $the_candidate->position_name }}</td>
                                            <td>{{ $the_candidate->reference_name }}</td>
                                            <td><a class="btn btn-primary" href="{{ url('/').'/user/dashboard/candidate/edit/'.$the_candidate->id }}">Edit</a></td>
                                        </tr>
                                        @endforeach
                                        @endif
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div> {{-- col-10--}}
                    <div class="col-2">
                        @if(!empty($entry_status_lists))
                            <ul class="entry_status_list">
                            @foreach($entry_status_lists as $entry_status)
                                <li>
                                    <button type="button" class="entry_status_btn btn btn-info btn-lg" onclick="alert('Please tick the checkbox of appropriate candidate first! ');" data-target="#myModal_{{$entry_status->id}}">{{$entry_status->entry_status_name}}</button>
                                </li>
                            @endforeach
                                <li>
                                    <button type="button" id="entry_status_btn_visa" class="btn btn-info btn-lg">Visa</button>
                                </li>
                                <li>
                                    <button type="button" id="entry_status_btn_set_demand" class="btn btn-info btn-lg">Set Demand</button>
                                </li>
                                <li>
                                    <button type="button" id="entry_status_btn_set_company_position" class="btn btn-info btn-lg">Change Company Position</button>
                                </li>
                            </ul>

                            @if(!empty($entry_status_meta))
                                @foreach($entry_status_lists as $entry_status)
                                    <div id="myModal_{{$entry_status->id}}" class="modal fade entry_status_modal" role="dialog">
                                        <form action="{{ url('/') }}/user/dashboard/entry_status_post" method="post">
                                            @csrf
                                            <input type="hidden" value="{{ $entry_status->id }}" name="entry_status_id">
                                            {{--<form action="{{ url('/') }}/user/dashboard/{{ strtolower($entry_status->entry_status_name) }}_entry" method="post">--}}

                                            <div class="modal-dialog">

                                                <!-- Modal content-->
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title">{{$entry_status->entry_status_desc}}</h4>
                                                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                    </div>
                                                    <div class="modal-body">
                                                         <?php
                                                            $id = (int)$entry_status->id;
                                                            $entry_status_meta_field = (!empty($entry_status_meta[$id]))?$entry_status_meta[$id]:'';
                                                            if(is_array($entry_status_meta_field) && count($entry_status_meta_field) > 0){
                                                                for($i = 0; $i < count($entry_status_meta_field); $i++){
                                                                    $this_field = $entry_status_meta_field[$i];
        //                                                            echo '<pre>';
        //                                                            print_r($this_field);
        //                                                            echo '</pre>';
                                                                ?>

                                                                <div class="form-label">
                                                                    <label>{{ (!empty($this_field->entry_status_label))?$this_field->entry_status_label:'' }}</label>
                                                                </div>
                                                                <div class="form-input">
                                                                    @if(!empty($this_field->entry_status_type) && $this_field->entry_status_type == 'radio')
                                                                        <div class="form-group">
                                                                            <input class="form-control" type="{{ (!empty($this_field->entry_status_type))?$this_field->entry_status_type:'' }}" value="Y" name="formdata[{{ (!empty($this_field->entry_status_key))?$this_field->entry_status_key:'' }}]"> <span>Pass</span>
                                                                            <input class="form-control" type="{{ (!empty($this_field->entry_status_type))?$this_field->entry_status_type:'' }}" value="N" name="formdata[{{ (!empty($this_field->entry_status_key))?$this_field->entry_status_key:'' }}]"> <span>Fail</span>
                                                                        </div>
                                                                    @elseif(!empty($this_field->entry_status_type) && $this_field->entry_status_type == 'checkbox')
                                                                        <input class="form-control" type="{{ (!empty($this_field->entry_status_type))?$this_field->entry_status_type:'' }}" value="{{ (!empty($this_field->entry_status_value))?$this_field->entry_status_value:'' }}" name="formdata[{{ (!empty($this_field->entry_status_key))?$this_field->entry_status_key:'' }}]"> {{ (!empty($this_field->entry_status_key))?ucfirst($this_field->entry_status_key):'' }}
                                                                    @elseif(!empty($this_field->entry_status_type) && $this_field->entry_status_type == 'date')
                                                                        <input class="form-control" type="{{ (!empty($this_field->entry_status_type))?$this_field->entry_status_type:'' }}" value="{{ (!empty($this_field->entry_status_value))?$this_field->entry_status_value:'' }}" name="formdata[{{ (!empty($this_field->entry_status_key))?$this_field->entry_status_key:'' }}]">
                                                                    @else
                                                                        <input class="form-control" type="{{ (!empty($this_field->entry_status_type))?$this_field->entry_status_type:'' }}" value="{{ (!empty($this_field->entry_status_value))?$this_field->entry_status_value:'' }}" name="formdata[{{ (!empty($this_field->entry_status_key))?$this_field->entry_status_key:'' }}]">
                                                                    @endif
                                                                </div>
                                                                <div class="clearfix"></div>

                                                            <?php
                                                                }
                                                            }
                                                            ?>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="submit" class="btn btn-default">Submit</button>
                                                    </div>
                                                </div>

                                            </div>
                                        </form>
                                    </div>
                                @endforeach
                            @endif
                        @endif
                    </div>
                </div>
                <div class="row search_list" id="visa_for" style="display: none; margin: 0;">
                    <div class="col-12">
                        <form action="{{ url('/') }}/user/dashboard/visa_status_post" method="post">
                            @csrf
                            <h4>Visa Entry</h4>
                            <table class="table table-striped table-bordered zero-configuration dataTable">
                                <tr id="visa_entry_tr">
                                    <th>Candidate Name</th>
                                    <th>Entry Permit No</th>
                                    <th>Date Of Issue</th>
                                    <th>Valid Upto</th>
                                    <th>UID No</th>
                                    <th>Remarks</th>
                                </tr>
                                <tr id="visa_entry_tr_last">
                                    <td colspan="6">
                                        <button type="submit">Save Changes</button>
                                    </td>
                                </tr>
                            </table>
                        </form>
                    </div>
                </div>
                <div class="row search_list" id="set_demand" style="display: none; margin: 0;">
                    <div class="col-12">
                        <form action="{{ url('/') }}/user/dashboard/set_demand_post" method="post">
                            @csrf
                            <h4>Set Demand</h4>
                            <table class="table table-striped table-bordered zero-configuration dataTable">
                                <tr id="visa_entry_tr">
                                    <td>
                                        <label>Company Name</label>
                                        @if(!empty($company_applied_for))
                                            <select class="form-control" id="company_applied_for" name="demand[company_applied_for]">
                                                <option value="">Select Company</option>
                                                @foreach($company_applied_for as $the_company)
                                                    <option value="{{$the_company->id}}">{{$the_company->company_applied_for_name}}</option>
                                                @endforeach
                                            </select>
                                        @endif
                                    </td>
                                    <td>
                                        <label>Demand Reference</label>
                                        @if(!empty($demand_list))
                                            <select class="form-control" id="demand_id" name="demand[demand_id]">
                                                <option value="">Select Demand</option>
                                                @foreach($demand_list as $the_demand)
                                                    <option value="{{$the_demand->id}}">{{$the_demand->demand_no}}</option>
                                                @endforeach
                                            </select>
                                        @endif
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="2">
                                        <button type="submit" id="" class="btn btn-info btn-lg">Save</button>
                                    </td>
                                </tr>
                            </table>
                        </form>
                    </div>
                </div>
                <div class="row search_list" id="set_company_position" style="display: none; margin: 0;">
                    <div class="col-12">
                        <form action="{{ url('/') }}/user/dashboard/set_company_position_post" method="post">
                            @csrf
                            <h4>Set Demand</h4>
                            <table class="table table-striped table-bordered zero-configuration dataTable">
                                <tr id="visa_entry_tr">
                                    <td>
                                        <label>Country</label>
                                        @if(!empty($country_applied_for))
                                            <select class="form-control" id="country_applied_for" name="demand[country_applied_for]">
                                                <option value="">Select Country</option>
                                                @foreach($country_applied_for as $the_country)
                                                    <option value="{{$the_country->id}}">{{$the_country->country_applied_for_name}}</option>
                                                @endforeach
                                            </select>
                                        @endif
                                    </td>
                                    <td>
                                        <label>Company Name</label>
                                        @if(!empty($company_applied_for))
                                            <select class="form-control" id="company_applied_for" name="demand[company_applied_for]">
                                                <option value="">Select Company</option>
                                                @foreach($company_applied_for as $the_company)
                                                    <option value="{{$the_company->id}}">{{$the_company->company_applied_for_name}}</option>
                                                @endforeach
                                            </select>
                                        @endif
                                    </td>
                                    <td>
                                        <label>Positions</label>
                                        @if(!empty($position))
                                            <select class="form-control" id="demand_id" name="demand[position_applied_for]">
                                                <option value="">Select Position</option>
                                                @foreach($position as $the_position)
                                                    <option value="{{$the_position->id}}">{{$the_position->position_name}}</option>
                                                @endforeach
                                            </select>
                                        @endif
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="2">
                                        <button type="submit" id="" class="btn btn-info btn-lg">Save</button>
                                    </td>
                                </tr>
                            </table>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--/ Zero configuration table -->
        </div>
      </div>
    </div>

    <script>
        $(document).ready(function(){

            $('.candidate_id_click').on('click', function(){
                var value_candidate_id = $(this).val();
                var candidate_name = $(this).attr('title');
                if($(this).prop('checked') != false){

                    // data-toggle="modal" disabled="disabled"

                    $('.entry_status_modal form').append('<input type="hidden" name="candidate_ids[]" value="'+value_candidate_id+'">');

                    $('.entry_status_btn').each(function(){
                        $(this).attr("data-toggle", "modal").removeClass("disabled");
                        $(this).removeAttr("onclick");
                    });

                    $('#set_demand form').append('<input type="hidden" name="demand[candidate_ids][]" value="'+value_candidate_id+'">');

                    // #set_demand

                    $('#set_company_position form').append('<input type="hidden" name="demand[candidate_ids][]" value="'+value_candidate_id+'">');

                    // #company_position

                    $('#visa_entry_tr_last').before('<tr id="candidate_id_'+value_candidate_id+'">' + '<td><input type="hidden" name="visa_status[candidate_id][]" value="'+value_candidate_id+'">'+candidate_name+'</td>' + '<td><input type="text" name="visa_status[entry_permit_no][]" value=""></td>' + '<td><input type="text" placeholder="dd/mm/yyyy" class="date_of_issue" name="visa_status[date_of_issue][]" value=""></td>\n' +
'<td><input type="text" placeholder="dd/mm/yyyy" class="valid_upto" name="visa_status[valid_upto][]" value=""></td>' + '<td><input type="text" name="visa_status[uid_no][]" value=""></td>' + '<td><textarea name="visa_status[remarks][]"></textarea></td>' + '</tr>');

                    // $('.valid_upto')

                }else{
                    $('.entry_status_modal form input[value="'+value_candidate_id+'"]').remove();
                    $('#candidate_id_'+value_candidate_id).remove();

                    $('#set_demand form input[value="'+value_candidate_id+'"]').remove();

                    $('#set_company_position form input[value="'+value_candidate_id+'"]').remove();

                    // $('#set_demand').append('<input type="hidden" name="candidate_ids[]" value="'+value_candidate_id+'">');

                    var checked_no = $('.sorting_1 input:checked');
                    // alert(checked_no.length);
                    if(checked_no.length < 1){
                        $('.entry_status_btn').each(function(){
                            $(this).removeAttr("data-toggle").addClass("disabled");
                            $(this).attr("onclick", "alert('Please tick the checkbox of appropriate candidate first! ');");
                            // onclick="alert('Please tick the checkbox of appropriate candidate first! ');"
                        });
                    }
                    // return false;
                }

                $('.date_of_issue:first').on('blur',function(){
                    var this_value = $(this).val();
                    var re = /^([0]?[1-9]|[1|2][0-9]|[3][0|1])[./-]([0]?[1-9]|[1][0-2])[./-]([0-9]{4}|[0-9]{2})$/ ;
                    if(re.test(this_value) !== false ){
                        $('.date_of_issue').each(function(){
                            if($(this).attr("value").length < 1)
                                $(this).attr("value", this_value);
                        });
                    }else{
                        $(this).attr("placeholder", "dd/mm/yyyy");
                        $(this).val("");
                    }
                    return false;
                });

                $('.valid_upto:first').on('blur',function(){
                    var this_value = $(this).val();
                    var re2 = /^([0]?[1-9]|[1|2][0-9]|[3][0|1])[./-]([0]?[1-9]|[1][0-2])[./-]([0-9]{4}|[0-9]{2})$/ ;
                    if(re2.test(this_value) !== false ){
                        $('.valid_upto').each(function(){
                            if($(this).attr("value").length < 1)
                                $(this).attr("value", this_value);
                        });
                    }else{
                        alert("Invalid Date Format");
                        $(this).attr("placeholder", "dd/mm/yyyy");
                        $(this).val("");
                    }
                    return false;
                });

                // alert('two');
                // alert('<input type="hidden" name="candidate_ids[]" value="'+$(this).val()+'">');
                // alert($(this).prop('checked'));
                // alert($(this).val());
                // return false;

            });

            // $("button.disabled").on('click', function(){
            //     alert('Please tick the checkbox of appropriate candidate first! ');
            // });

            $('.modal-dialog button[type="submit"]').on('click', function(ev){
                var find_this = $('.entry_status_modal input[type="hidden"]');
                if(find_this.length > 0){
                    return true;
                }else{
                    alert('Choose atleast one candidate!');
                    ev.preventDefault();
                    return false;
                }
            });

            $('#entry_status_btn_visa').on('click', function(){
                var len = $('.candidate_id_click:checked').length;
                if(len > 0){
                    $('#visa_for').toggle();
                    var n = $('body').height();
                    $('html, body').animate({ scrollTop: n }, 50);
                }else{
                    alert('Please tick the checkbox of appropriate candidate first! ');
                }
            });

            $('#entry_status_btn_set_demand').on('click', function(){
                var len = $('.candidate_id_click:checked').length;
                if(len > 0){
                    $('#set_demand').toggle();
                    // console.log($('body').height());

                    var n = $('body').height();
                    $('html, body').animate({ scrollTop: n }, 50);
                }else{
                    alert('Please tick the checkbox of appropriate candidate first! ');
                }
            });

            $('#entry_status_btn_set_company_position').on('click', function(){
                var len = $('.candidate_id_click:checked').length;
                if(len > 0){
                    $('#set_company_position').toggle();
                    // console.log($('body').height());

                    var n = $('body').height();
                    $('html, body').animate({ scrollTop: n }, 50);

                }else{
                    alert('Please tick the checkbox of appropriate candidate first! ');
                }
            });

            $('button[type="reset"]').on('click', function () {
                // alert('dfasd');
                $('select option[value=""]').each(function(){
                    $(this).next('option[value=""]').attr("selected", "selected");
                });
                // $('select option[value=""]')
            });

        });
    </script>

@endsection