@extends('frontend_layouts.frontend_layout')

@section('content')
    <div class="col-md-12">

        <section class="no-padding-bottom">

            <article class="post-detail-01">

                <div class="content">

                    <h4>Energy Conversion Tools</h4>
                    <p>This tool converts available energy units into the standard unit (GJ, ToE and MWh) .</p>

                    <div class="row">
                        <div class="col-md-6">

                            <div class="energy_content">
                                <div class="row">
                                    <div class="col-md-2">

                                        <form action="" method="get" class="form-inline" id="energy_conversion_form">
                                            @csrf

                                            @if(!empty($energy_list))
                                                <div class="form-group">
                                                    <label for="sel1">Fuel:</label>
                                                    <select name="energy" class="form-control" id="fuel_select" onchange="document.getElementById('energy_conversion_form').submit();">
                                                        <option value="">Select Fuel</option>
                                                        @foreach($energy_list as $the_energy)
                                                            <option value="{{ $the_energy->energy_slug }}" {{ (!empty($this_energy) && $this_energy == $the_energy->energy_slug )?'selected':'' }}>{{ $the_energy->energy_name }}</option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                            @endif
                                        </form>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">

                                        @if(!empty($energy_list_with))
                                            @foreach($energy_list_with as $key=>$value)
                                                <form action="" method="get" class="unit_select form-inline" id="energy_conversion_form_{{$key}}" style="display:{{ ($this_energy == $key)?'block':'none' }};">
                                                    @csrf
                                                    <input type="hidden" name="energy" value="{{ $key }}">
                                                    <div class="row">
                                                        <div class="col-md-6">
                                                            <div class="form-group" id="{{ $key }}">
                                                                <label for="sel1">Quantity:</label>
                                                                <input type="text" class="form-control" name="qty" value="{{ ($this_qty > 0)?$this_qty:1 }}">
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group" id="{{ $key }}">
                                                                <label for="sel1">From Unit:</label>
                                                                <select name="unit" class="form-control" onchange="document.getElementById('energy_conversion_form_{{$key}}').submit();">
                                                                    <option value="">Choose Unit</option>
                                                                    @foreach($value as $the_unit)
                                                                        @if($the_unit->unit_slug != 'giga-joule')
                                                                            <option value="{{ $the_unit->unit_slug }}" {{ (!empty($this_unit) && $this_unit == $the_unit->unit_slug )?'selected':'' }}>{{ $the_unit->unit_name }}</option>
                                                                        @endif
                                                                    @endforeach
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            @endforeach
                                        @endif

                                    </div>
                                    <div class="col-md-6">

                                        @if(!empty($result->scientific_qty) && !empty($result->scientific_unit))
                                            <table class="table table-bordered">
                                                <tr class="info">
                                                    <th>Result In GJ</th>
                                                    <th>Result In (000) ToE</th>
                                                    <th>Result In (000000) MWh</th>
                                                </tr>
                                                <tr class="active">
                                                    <td>
                                                        <?php
                                                        echo $this_qty*$result->scientific_qty.' '.$result->scientific_unit;
                                                        ?>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        echo round(($this_qty*$result->scientific_qty*23.8845), 2).' ToE';
                                                        ?>
                                                    </td>
                                                    <td>
                                                        <?php
                                                        echo round(($this_qty*$result->scientific_qty/3.6), 2).' MWh';
                                                        ?>
                                                    </td>
                                                </tr>
                                            </table>
                                        @endif

                                    </div>
                                </div>


                            </div>

                        </div>
                    </div>

                </div>

            </article>

        </section>

    </div>

<!--end site header-->

@endsection