@extends('frontend_layouts.add_edit_form_layout')

@section('content')

<div class="row">
        <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title" id="horz-layout-colored-controls">Add Candidate</h4>
                <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                    <ul class="list-inline mb-0">
                        <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                        <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                    </ul>
                </div>
            </div>
            <div class="card-content collpase show">
                <div class="card-body">
                    <div class="card-text">
                            <p>Please fill all the required inputs</p>
                    </div>
                    <form action="{{url('/')}}/user/dashboard/candidate/add" method="post" class="form form-horizontal" enctype="multipart/form-data">
                        @csrf
                        <div class="form-body">
                                <h4 class="form-section"><i class="la la-eye"></i> Candidate Details</h4>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group row">
                                            <div class="col-md-12">
                                                <p>Passport Number</p>
                                                <input type="text" id="ppno" class="form-control border-primary" placeholder="" name="formdata[passport_no]" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group row">
                                            <div class="col-md-12">
                                                <p>Entry Registration Number</p>
                                                <input type="text" id="entry_reg_no" class="form-control border-primary" placeholder="" name="formdata[entry_reg_no]" value="{{ $entry_reg_no }}" required>
                                            </div>
                                        </div>
                                    </div>
                                    <?php /*
                                    <div class="col-md-4">
                                        <div class="form-group row">
                                            <div class="col-md-12">
                                                <p>Demand</p>
                                                @if(!empty($demands))
                                                    <fieldset class="form-group">
                                                        <select class="form-control" id="demand_id" name="formdata[demand_id]">
                                                            <option value="">Select [Pre Approval No (Chalani No)]</option>
                                                            @foreach($demands as $the_demand)
                                                                <option value="{{$the_demand->id}}">{{$the_demand->pre_approval_date}} ( {{ $the_demand->chalani_no }} )</option>
                                                            @endforeach
                                                        </select>
                                                    </fieldset>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                    */ ?>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group row">
                                            <div class="col-md-12">
                                                <p>Last Name</p>
                                                <input type="text" id="userinput1" class="form-control border-primary" placeholder="Last Name" name="formdata[last_name]" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group row">
                                            <div class="col-md-12">
                                                <p>First Name</p>
                                                <input type="text" id="userinput2" class="form-control border-primary" placeholder="First Name" name="formdata[first_name]" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group row">
                                            <div class="col-md-12">
                                                <p>Middle Name</p>
                                                <input type="text" id="userinput2" class="form-control border-primary" placeholder="Middle Name" name="formdata[middle_name]">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group row">
                                            <div class="col-md-12">
                                                <p>Date of Birth</p>
                                                <input type="date" id="userinput1" class="form-control border-primary" placeholder="Date of Birth" name="formdata[dob]" required>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group row">
                                            <div class="col-md-12">
                                                <p>Gender</p>
                                                <input type="radio" id="" class="" placeholder="" name="formdata[gender]" value="Male" checked> Male
                                                <input type="radio" id="" class="" placeholder="" name="formdata[gender]" value="Female"> Female
                                            </div>
                                        </div>
                                    </div>
                                        <div class="col-md-4">
                                            <div class="form-group row">
                                                <div class="col-md-12">
                                                    <p>Place of Birth</p>
                                                    <?php
                                                    $districts = array('Achham','Arghakhanchi','Baglung','Baitadi','Bajhang','Bajura','Banke','Bara','Bardiya','Bhaktapur','Bhojpur','Chitwan','Dadeldhura','Dailekh','Dang','Darchula','Dhading','Dhankutta','Dhanusa','Dolkha','Dolpa','Doti','Gorkha','Gulmi','Humla','Ilam','Jajarkot','Jhapa','Jumla','Kailali','Kalikot','Kanchanpur','Kapilvastu','Kaski','Kathmandu','Kavreplanchauk','Khotang','Lalitpur','Lamjung','Mahottari','Makwanpur','Manag','Morang','Mugu','Mustang','Myagdi','Nawalpur','Nuwakot','Okhaldunga','Palpa','Panchthar','Parasi','Parsa','Parwat','Pyuthan','Ramechhap','Rasuwa','Rauthat','Rolpa','Rukum Paschim','Rukum Purba','Rupandehi','Salyan','Sankhuwasabha','Saptari','Sarlahi','Sindhuli','Sindhupalchauk','Siraha','Solukhumbu','Sunsari','Surkhet','Syangja','Tanahun','Taplejung','Terhathum','Udaypur');
                                                    ?>
                                                    <select name="formdata[place_of_issue]" id="" class="form-control border-primary" >
                                                        @for($i=0; $i< 77; $i++)
                                                            <option value="{{$districts[$i]}}">{{$districts[$i]}}</option>
                                                        @endfor
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    <input type="hidden" name="issuing_authority" value="MOFA, DEPARTMENT OF PASSPORT" />
                                        <div class="col-md-4">
                                            <div class="form-group row">
                                                <div class="col-md-12">
                                                    <p>Passport Issue Date</p>
                                                    <input type="date" id="pp_issue_date" class="form-control border-primary" placeholder="PP Issue Date" name="formdata[passport_issue_date]" required>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group row">
                                                    <div class="col-md-12">
                                                    <p>Passport Expiry Date</p>
                                                        <input type="text" id="pp_expiry_date" class="form-control border-primary" placeholder="PP Expiry Date" name="formdata[passport_expiry_date]" value="" readonly="readonly">
                                                    </div>
                                            </div>
                                        </div>
                                </div>
                                    <hr>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="form-group row">
                                                <div class="col-md-12">
                                                <p>Next of Keen</p>
                                                <input type="text" id="userinput1" class="form-control border-primary" placeholder="Next of Keen" name="formdata[next_to_kin]">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group row">
                                                <div class="col-md-12">
                                                <p>Relation to Next of keen</p>
                                                <input type="text" id="userinput2" class="form-control border-primary" placeholder="Relation to Next of keen" name="formdata[relation_with_kin]">
                                                </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group row">
                                            <div class="col-md-12">
                                                <p>Permanent Address</p>
                                                <input type="text" id="userinput2" class="form-control border-primary" placeholder="Permanent Address" name="formdata[address]">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group row">
                                            <div class="col-md-12">
                                                <p>Contact Number</p>
                                                <input type="text" id="userinput2" class="form-control border-primary" placeholder="Contact Number" name="formdata[contact_no]">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="form-group row">
                                            <div class="col-md-12">
                                                <p>Email</p>
                                                <input type="email" id="userinput2" class="form-control border-primary" placeholder="Email" name="formdata[email]">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                    <hr>
                                <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group row">
                                                    <div class="col-md-12">
                                                    <p>Country</p>
                                                    @if(!is_null($country_applied_for))
                                                    <fieldset class="form-group">
                                                        <select class="form-control" id="country_applied_for" name="formdata[country_applied_for]" required>
                                                          <option value="">Select Option</option>
                                                          @foreach($country_applied_for as $the_country)
                                                          <option value="{{$the_country->id}}">{{$the_country->country_applied_for_name}}</option>
                                                          @endforeach
                                                        </select>
                                                    </fieldset>
                                                    @endif
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group row">
                                                <div class="col-md-12">
                                                    <p>Company Applied For</p>
                                                    @if(!is_null($country_applied_for))
                                                    <fieldset class="form-group">
                                                        <select class="form-control select_one" title="company_applied_for" id="company_applied_for" name="formdata[company_applied_for]">
                                                          <option value="">Select Option</option>
                                                          @foreach($company_applied_for as $the_company)
                                                          <option value="{{$the_company->id}}">{{$the_company->company_applied_for_name}}</option>
                                                          @endforeach
                                                          <option value="0">Enter New</option>
                                                        </select>
                                                    </fieldset>
                                                    @endif
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group row">
                                                <div class="col-md-12">
                                                <p>Position/Job Category</p>
                                                @if(!empty($position))
                                                <fieldset class="form-group">
                                                    <select class="form-control select_one" title="position" id="position_applied_for" name="formdata[position_applied_for]">
                                                      <option value="">Select Option</option>
                                                      @foreach($position as $the_position)
                                                      <option value="{{$the_position->id}}">{{$the_position->position_name}}</option>
                                                      @endforeach
                                                      <option value="0">Enter New</option>
                                                    </select>
                                                </fieldset>
                                                @endif
                                                </div>
                                            </div>
                                        </div>
                                </div>
                                <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group row">
                                                    <div class="col-md-12">
                                                    <p>Referred By</p>
                                                    @if(!empty($reference_list))
                                                    <fieldset class="form-group">
                                                        <select class="form-control select_one" title="reference" id="reference" name="formdata[reference_by]">
                                                              <option value="">Select Option</option>
                                                              @foreach($reference_list as $the_reference)
                                                              <option value="{{$the_reference->id}}">{{$the_reference->reference_name}}</option>
                                                              @endforeach
                                                            <option value="0">Enter New</option>
                                                        </select>
                                                    </fieldset>
                                                    @endif
                                                    </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group row">
                                                    <div class="col-md-12">
                                                    <p>Entry Status</p>
                                                    <fieldset class="form-group">
                                                        <select class="form-control" id="entry_status" name="formdata[entry_status]">
                                                            <option value="">Fresh Candidate</option>
                                                        </select>
                                                    </fieldset>
                                                    </div>
                                            </div>
                                        </div>
                                </div>
                                    <hr>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">

                                            {{--accordians--}}
                                            <div class="panel-group" id="accordion">
                                                <div class="panel panel-default">
                                                    <div class="panel-heading">
                                                        <h4 class="panel-title">
                                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">
                                                                Educational Qualification</a>
                                                        </h4>
                                                    </div>
                                                    <div id="collapse1" class="panel-collapse collapse in">
                                                        <div class="panel-body">
                                                            <div class="row">
                                                                <div class="col-md-12">
                                                                    <div class="form-group row">
                                                                        <div class="col-md-12">
                                                                            <div class="form-group col-12 file-repeater">
                                                                                <div data-repeater-list="repeater-list">
                                                                                    <div data-repeater-item="">
                                                                                        <div class="row ">
                                                                                            <div class="col-md-10 repeater-block3">
                                                                                                <div class="row">
                                                                                                    <div class="col-md-3">
                                                                                                        @if(!empty($qualification_type))
                                                                                                            <select class="form-control border-primary" name="qualification[qualification_type_id][]" id="">
                                                                                                                <option value="">Select Option</option>
                                                                                                                @foreach($qualification_type as $the_qualification_type)
                                                                                                                    <option value="{{$the_qualification_type->id}}">{{$the_qualification_type->qualification_type_name}}</option>
                                                                                                                @endforeach
                                                                                                            </select>
                                                                                                        @endif
                                                                                                    </div>
                                                                                                    <div class="col-md-3">
                                                                                                        <input type="text" id="" class="form-control border-primary" placeholder="Board" name="qualification[board][]">
                                                                                                    </div>
                                                                                                    <div class="col-md-3">
                                                                                                        <input type="text" id="" class="form-control border-primary" placeholder="Year" name="qualification[year][]">
                                                                                                    </div>
                                                                                                    <div class="col-md-3">
                                                                                                        <input type="text" id="" class="form-control border-primary" placeholder="Division" name="qualification[division][]">
                                                                                                    </div>
                                                                                                </div>
                                                                                                <br>
                                                                                            </div>
                                                                                            <div class="col-md-2">
                                                                                                <button type="button" data-repeater-create="" name="repeater-block3" id="" class="minus_btn btn btn-danger">
                                                                                                    <i class="ft-plus"></i> Remove This
                                                                                                </button>
                                                                                            </div>

                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>

                                                                            <button type="button" data-repeater-create="" id="" name="repeater-block3" class="add_more btn btn-primary">
                                                                                <i class="ft-plus"></i> Add More Qualification
                                                                            </button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="panel panel-default">
                                                    <div class="panel-heading">
                                                        <h4 class="panel-title">
                                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">
                                                                Working Experience</a>
                                                        </h4>
                                                    </div>
                                                    <div id="collapse2" class="panel-collapse collapse">
                                                        <div class="panel-body">
                                                            <div class="row">
                                                                <div class="col-md-12">
                                                                    <div class="form-group row">
                                                                        <div class="col-md-12">
                                                                            <p>Working Experience</p>
                                                                            <div class="form-group col-12 file-repeater">

                                                                                <div class="row ">
                                                                                    <div class="col-md-2">
                                                                                        <p>GCC Experience</p>
                                                                                    </div>
                                                                                    <div class="col-md-10">
                                                                                        <select class="form-control border-primary" name="experience[gcc_exp]">
                                                                                            <option value="Y">Yes</option>
                                                                                            <option value="N" selected="selected">No</option>
                                                                                        </select>
                                                                                    </div>
                                                                                </div>
                                                                                <hr>
                                                                                <div data-repeater-list="repeater-list">
                                                                                    <div data-repeater-item="">
                                                                                        <div class="row ">
                                                                                            <div class="col-md-10 repeater-block5">
                                                                                                <div class="row">
                                                                                                    <div class="col-md-4">
                                                                                                        <p>Experience From</p>
                                                                                                        <input type="date" id="" class="form-control border-primary" placeholder="From" name="experience[exp_from][]">
                                                                                                    </div>
                                                                                                    <div class="col-md-4">
                                                                                                        <p>Experience To</p>
                                                                                                        <input type="date" id="" class="form-control border-primary" placeholder="To" name="experience[exp_to][]">
                                                                                                    </div>
                                                                                                    <div class="col-md-4">
                                                                                                        <p>Or, No of Experience (in months)</p>
                                                                                                        <input type="number" id="" class="form-control border-primary" placeholder="To" name="experience[no_of_exp_in_years][]">
                                                                                                    </div>
                                                                                                    <div class="clearfix"></div>
                                                                                                    <div class="col-md-3">
                                                                                                        <p>From which country</p>
                                                                                                        <input type="text" id="" class="form-control border-primary" placeholder="Country" name="experience[country][]">
                                                                                                    </div>
                                                                                                    <div class="col-md-3">
                                                                                                        <p>From which company</p>
                                                                                                        <input type="text" id="" class="form-control border-primary" placeholder="Company" name="experience[company][]">
                                                                                                    </div>
                                                                                                    <div class="col-md-3">
                                                                                                        <p>On which designation</p>
                                                                                                        <input type="text" id="" class="form-control border-primary" placeholder="Designation" name="experience[designation][]">
                                                                                                    </div>
                                                                                                    <div class="col-md-3">
                                                                                                        <p>Enter Job Details</p>
                                                                                                        <textarea id="" class="form-control border-primary" placeholder="Job Details" name="experience[job_details][]"></textarea>
                                                                                                    </div>
                                                                                                </div>
                                                                                                <hr>
                                                                                            </div>
                                                                                            <div class="col-md-2 remove_this">
                                                                                                <button type="button" data-repeater-create="" name="repeater-block5" id="" class="minus_btn btn btn-danger">
                                                                                                    <i class="ft-plus"></i> Remove This
                                                                                                </button>
                                                                                            </div>

                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>

                                                                            <button type="button" data-repeater-create="" id="" name="repeater-block5" class="add_more btn btn-primary">
                                                                                <i class="ft-plus"></i> Add More Experience
                                                                            </button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="panel panel-default">
                                                    <div class="panel-heading">
                                                        <h4 class="panel-title">
                                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse8">
                                                                Additional Information</a>
                                                        </h4>
                                                    </div>
                                                    <div id="collapse8" class="panel-collapse collapse">
                                                        <div class="panel-body">
                                                            <div class="row">
                                                                <div class="col-md-12">
                                                                    <div class="form-group row">
                                                                        <div class="col-md-12">
                                                                            <div class="form-group col-12 file-repeater">
                                                                                <div data-repeater-list="repeater-list">
                                                                                    <div data-repeater-item="">
                                                                                        <div class="row ">
                                                                                            <div class="col-md-10 repeater-block8">
                                                                                                <div class="row">
                                                                                                    <div class="col-md-3">
                                                                                                        <p>Father's Name</p>
                                                                                                        <input type="text" id="" class="form-control border-primary" placeholder="Father's name" name="additional[father_name]">
                                                                                                    </div>
                                                                                                    <div class="col-md-3">
                                                                                                        <p>Mother's Name</p>
                                                                                                        <input type="text" id="" class="form-control border-primary" placeholder="Mother's name" name="additional[mother_name]">
                                                                                                    </div>
                                                                                                    <div class="col-md-3">
                                                                                                        <p>Marital Status</p>
                                                                                                        <select class="form-control border-primary" name="additional[marital_status]">
                                                                                                            <option value="Y">Married</option>
                                                                                                            <option value="N" selected="selected">Unmarried</option>
                                                                                                        </select>
                                                                                                    </div>
                                                                                                    <div class="col-md-3">
                                                                                                        <p>Spouse Name</p>
                                                                                                        <input type="text" id="" class="form-control border-primary" placeholder="Spouse's name" name="additional[spouse_name]">
                                                                                                    </div>
                                                                                                    <div class="clearfix"></div>
                                                                                                    <div class="col-md-3">
                                                                                                        <p>No. of children (If any)</p>
                                                                                                        <input type="number" id="" class="form-control border-primary" placeholder="No. of children (In number)" name="additional[no_of_children]">
                                                                                                    </div>
                                                                                                    <div class="col-md-3">
                                                                                                        <p>Religion</p>
                                                                                                        <input type="text" id="" class="form-control border-primary" placeholder="Company" name="additional[religion]">
                                                                                                    </div>
                                                                                                    <div class="col-md-3">
                                                                                                        <p>Height</p>
                                                                                                        <input type="text" id="" class="form-control border-primary" placeholder="Designation" name="additional[height]">
                                                                                                    </div>
                                                                                                    <div class="col-md-3">
                                                                                                        <p>Weight</p>
                                                                                                        <input type="text" id="" class="form-control border-primary" placeholder="Designation" name="additional[weight]">
                                                                                                    </div>
                                                                                                </div>
                                                                                                <hr>
                                                                                            </div>

                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="panel panel-default">
                                                    <div class="panel-heading">
                                                        <h4 class="panel-title">
                                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse3">
                                                                Attachments</a>
                                                        </h4>
                                                    </div>
                                                    <div id="collapse3" class="panel-collapse collapse">
                                                        <div class="panel-body">
                                                            <div class="row">
                                                                <div class="col-md-8">
                                                                    <div class="form-group row">
                                                                        <div class="col-md-12">
                                                                            <p>Attachments [Uplaod either jpg, jpeg, png or gif images only]</p>
                                                                            <div class="form-group col-12 file-repeater">
                                                                                <div data-repeater-list="repeater-list">
                                                                                    <div data-repeater-item="">
                                                                                        <div class="row ">
                                                                                            <div class="col-md-10">
                                                                                                <div class="row">
                                                                                                    <div class="col-md-12">
                                                                                                        <p>Photograph</p>
                                                                                                        <input type="hidden" id="" class="form-control border-primary" name="attachment[title][]" value="photograph" readonly>
                                                                                                        <input type="file" class="form-control" placeholder="Attachments" name="attachment[file][]">
                                                                                                    </div>
                                                                                                </div>
                                                                                                <br>
                                                                                            </div>

                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>

                                                                            <div class="form-group col-12 file-repeater">
                                                                                <div data-repeater-list="repeater-list">
                                                                                    <div data-repeater-item="">
                                                                                        <div class="row ">
                                                                                            <div class="col-md-10 repeater-block2">
                                                                                                <div class="row">
                                                                                                    <div class="col-md-3">
                                                                                                        <p>File Title</p>
                                                                                                        <input type="text" id="" class="form-control border-primary" placeholder="File Title" name="attachment[title][]">
                                                                                                    </div>
                                                                                                    <div class="col-md-9">
                                                                                                        <p>File</p>
                                                                                                        <input type="file" class="form-control" placeholder="Attachments" name="attachment[file][]">
                                                                                                    </div>
                                                                                                </div>
                                                                                                <br>
                                                                                            </div>
                                                                                            <div class="col-md-2">
                                                                                                <button type="button" data-repeater-create="" name="repeater-block2" id="" class="minus_btn btn btn-danger">
                                                                                                    <i class="ft-plus"></i> Remove This
                                                                                                </button>
                                                                                            </div>

                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>

                                                                            <button type="button" data-repeater-create="" name="repeater-block2" id="" class="add_more btn btn-primary">
                                                                                <i class="ft-plus"></i> Add More Attachment
                                                                            </button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            {{--accordians--}}
                                        </div>
                                    </div>
                                </div>
                            <hr>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <p>Remarks</p>
                                        <textarea id="" class="form-control border-primary" placeholder="Remarks" name="formdata[remarks]"></textarea>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <div class="form-actions right">
                            <button type="button" class="btn btn-danger mr-1">
                                <i class="ft-x"></i> Cancel
                            </button>
                            <button type="submit" class="btn btn-primary">
                                <i class="la la-check-square-o"></i> Save
                            </button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>
<input type="hidden" id="url" value="{{ url('/') }}">
<script>
$(document).ready(function(){

    $('.select_one').on('change', function(){
        var option_value = $(this).val();
        var url_this = $('#url').attr("value");
        // alert(this_title+' hi! '+option_value);
        if(parseInt(option_value) == 0) {
            var this_title = $(this).attr('title');
            var this_id = '#'+$(this).attr('id');
            var new_option = prompt('Please Enter new ' + this_title + '?');
            var new_option_arr = new_option.split(' ');
            var new_option_value = '';
            var dashed = '';
            for(var i = 0; i < new_option_arr.length; i++){
                new_option_value += dashed+new_option_arr[i];
                dashed = '-';
            }
            var url_post = url_this+'/user/dashboard/candidate/'+this_title+'/'+new_option_value;
            // alert(url_post);
            // return false;
            if (parseInt(new_option_value.length) > 0) {
                $.ajax({
                    method: "GET",
                    url: url_post,
                    data: { }
                }).done(function( msg ) {
                    // alert( "Data Saved: " + msg );
                    $(this_id).append(msg);
                    return false;
                });
                // alert('Good');
            } else {
                alert('Try Again!');
            }
        }
        return false;
    });

//    alert('asdfasdf');
    $('#pp_issue_date').on('blur', function(){
        // var pp_issue_date = alert($(this).val());
//        var pp_issue_date_obj = new Date($(this).val());
        var pp_arr = ($(this).val()).split('-');
//        console.log(pp_arr);
        if(Array.isArray(pp_arr)){
//            alert(pp_arr[2]+'-'+pp_arr[1]+'-'+(parseInt(pp_arr[0])+5));
            $('#pp_expiry_date').attr("value", pp_arr[2]+'-'+pp_arr[1]+'-'+(parseInt(pp_arr[0])+10));
        }       
//        var pp_issue_date_obj_new = new Date(pp_issue_date_obj.getTime() + 5*365*24*60*60)
//        alert(pp_issue_date_obj.getDay() + '-' + pp_issue_date_obj.getMonth() + '-' + (pp_issue_date_obj.getFullYear() + 5 ));
        
    });
    
    $('.add_more').on('click', function(){
        var classname = '.'+$(this).attr('name');
        // alert(classname);
        var repeater_block_html = $(classname).html();
        $(classname+':last').after('<div class="col-md-10 '+$(this).attr("name")+'">'+repeater_block_html+'</div>');
    });
    
    $('.minus_btn').on('click', function(){
        var classname = '.'+$(this).attr('name');
        // alert(classname);
        var length_this = $(classname).length;
        // alert(length_this);
//        alert(length_this);
//        var repeater_block_html = $('.repeater-block').html();
        if(length_this > 1)
        $(classname+':last').remove();
    });
    
});
</script>
@endsection