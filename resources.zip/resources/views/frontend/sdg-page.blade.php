@extends('frontend_layouts.frontend_layout')

@section('content')
    <div class="col-md-3">


        <section class="no-padding-bottom right-design">
            <div class="widget team-section-01">

                <h2 class="card-title">
                    SDG 7
                </h2>
                <p>Ensuring Access to Affordable, Reliable, Sustainable and Modern Energy for All</p>

                <h4>Targets:</h4>

                <ul class="nav nav-tabs">
                    <li class="active"><a data-toggle="tab" href="#overview">Overview</a></li>
                    <li><a data-toggle="tab" href="#sdg_7">SDG 7</a></li>
                    <li><a data-toggle="tab" href="#sdg_7_1_1">SDG 7.1.1</a></li>
                    <li><a data-toggle="tab" href="#sdg_7_1_2">SDG 7.1.2</a></li>
                    <li><a data-toggle="tab" href="#sdg_7_2_1">SDG 7.2.1</a></li>
                    <li><a data-toggle="tab" href="#sdg_7_3">SDG 7.3</a></li>
                </ul>

                <hr>



            </div>
        </section>



    </div>

    <div class="col-md-9 sdg_content">


        <div class="tab-content">
            <div id="overview" class="tab-pane fade in active">
                <img src="{{ url('/') }}/public/images/sdg-17-goals.png" alt="sdg-17-goals" style="width: 40%; float: right; margin-left: 10px; margin-bottom: 15px;">

                <h3> THE 17 GOALS</h3>
                <p>Nepal signed the 2030 Sustainable Development Agenda agreed by the Members of the United Nations. The Agenda sets out 17 goals that define global sustainable development priorities and aspirations to achieve by 2030 and seek to mobilize global efforts around a common set of goals and targets. Nepal, as a member of the UN, is committed to the SDGs.</p>
                <table class="table text-center">
                    <tr>
                        <td>
                            <span>SDG Targets</span>
                            <h4>169</h4>
                        </td>
                        <td>
                            <span>SDG Indicators</span>
                            <h4>494</h4>

                        </td>
                        <td>
                            <span>Tier I Indicators</span>
                            <h4>174</h4>

                        </td>
                        <td>
                            <span>Tier II Indicators</span>
                            <h4>269</h4>

                        </td>
                        <td>
                            <span>Tier III Indicators</span>
                            <h4>51</h4>

                        </td>
                    </tr>
                </table>
                <table class="table text-center table-bordered">
                    <tr>
                        <td colspan="2">
                            <h3>Overview of SGD status of Nepal according to Sustainable Development Report (SDR) 2022</h3>
                        </td>
                    </tr>
                    <tr>
                        <td style="width: 50%;">
                            <h5>SDG Index Rank</h5>
                            <h5>98/163</h5>
                            <h5>SDG Index Core</h5>
                            <h5>66.2/100</h5>
                        </td>
                        <td style="width: 50%;">
                            <h5>Spillover score: 98.55/100</h5>
                            <h5>Spillover rank: 33/163</h5>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <p>The overall score measures the total progress towards achieving all 17 SDGs. The score can be interpreted as a percentage of SDG achievement. A score of 100 indicates that all SDGs have been achieved.</p>
                        </td>
                        <td>
                            <p>Each country's actions can have positive or negative effects on other countries' abilities to achieve the SDGs. The Spillover Index assesses such spillovers along three dimensions: environmental & social impacts embodied into trade, economy & finance, and security. A higher score means that a country causes more positive and fewer negative spillover effects.</p>
                        </td>
                    </tr>
                </table>

            </div>
            <div id="sdg_7" class="tab-pane fade">
                <h3>SDG 7</h3>
                <h5>Ensure access to affordable, reliable, sustainable and modern energy for all.</h5>
                <p>The UN explains: "Energy is central to nearly every major challenge and opportunity the world faces today. Be it for jobs, security, climate change, food production or increasing incomes, access to energy for all is essential."</p>
                <p>Transitioning the global economy towards clean and sustainable sources of energy is one of our greatest challenges in the coming decades. Sustainable energy is an opportunity – it transforms lives, economies and the planet.</p>
                <p>The UN has defined 5 Targets and 6 Indicators for SDG 7. Targets specify the goals and Indicators represent the metrics by which the world aims to track whether these Targets are achieved.</p>
            </div>
            <div id="sdg_7_1_1" class="tab-pane fade">
                <h3>Target 7.1</h3>
                <h5>UN definition: By 2030, ensure universal access to affordable, reliable and modern energy services.</h5>
                <p><strong>SDG INDICATOR 7.1.1: Access to electricity</strong></p>
                <p>Definition: The proportion of population with access to electricity.</p>
                <p>This is measured as the share of people with electricity access at the household level. It comprises electricity sold commercially, both on-grid and off-grid.</p>
                <p>Goal: By 2030 ensure universal access to affordable, reliable and modern energy services.</p>
                <p>This requires universal access to electricity by 2030.</p>
                <div class="text-center">
                    <table class="table text-center table-bordered">
                        <tr>
                            <td rowspan="2">Figure</td>
                            <td rowspan="2">Description</td>
                            <td colspan="5">Years</td>
                        </tr>
                        <tr>
                            <td>2015</td>
                            <td>2019</td>
                            <td>2022</td>
                            <td>2025</td>
                            <td>2030</td>
                        </tr>
                        <tr>
                            <td>1</td>
                            <td>Proportion of population with access to electricity</td>
                            <td>74</td>
                            <td>80.7</td>
                            <td>85.7</td>
                            <td>90.7</td>
                            <td>99</td>
                        </tr>
                        <tr>
                            <td>2</td>
                            <td>Per capita energy (final) consumption (in gigajoules)</td>
                            <td>16</td>
                            <td>18.1</td>
                            <td>19.7</td>
                            <td>21.3</td>
                            <td>24</td>
                        </tr>
                    </table>
                    <div class="text-center row">
                        <div class="col-md-6">

                            <div class="panel">
                                <div class="panel-body">
                                    <img src="{{ url('/') }}/public/images/sdg.7.1.1a.png" alt="Figure 1" class="img-responsive">
                                    <span>Figure 1</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">

                            <div class="panel">
                                <div class="panel-body">
                                    <img src="{{ url('/') }}/public/images/sdg.7.1.1b.png" alt="Figure 1" class="img-responsive">
                                    <span>Figure 2</span>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <div id="sdg_7_1_2" class="tab-pane fade">
                <h3>Target 7.1</h3>
                <h5>UN definition: Ensure universal access to affordable, reliable and modern energy services By 2030.</h5>
                <p><strong>SDG INDICATOR 7.1.2: Access to clean fuels for cooking</strong></p>
                <p>Definition: The proportion of population with primary reliance on clean fuels and technology.</p>
                <p>This is measured as the share of the total population with access to clean fuels and technologies for cooking. Access to clean fuels or technologies such as clean cookstoves reduce exposure to indoor air pollutants, a leading cause of death in low-income households.</p>
                <p>Goal: Ensure universal access to affordable, reliable and modern energy services by 2030.</p>
                <p>This requires universal access to clean fuels and technologies for cooking by 2030.</p>
                <table class="table text-center table-bordered">
                    <tr>
                        <td rowspan="2">Figure</td>
                        <td rowspan="2">Description</td>
                        <td colspan="5">Years</td>
                    </tr>
                    <tr>
                        <td>2015</td>
                        <td>2019</td>
                        <td>2022</td>
                        <td>2025</td>
                        <td>2030</td>
                    </tr>
                    <tr>
                        <td>1</td>
                        <td>Households using solid fuel as primary source of energy for cooking (%)</td>
                        <td>74.7</td>
                        <td>65</td>
                        <td>55</td>
                        <td>45</td>
                        <td>30</td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>People using liquid petroleum gas (LPG) for cooking and heating (%)</td>
                        <td>18</td>
                        <td>23.6</td>
                        <td>27.8</td>
                        <td>32</td>
                        <td>39</td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td>Electricity consumption (k Wh per capita)</td>
                        <td>80</td>
                        <td>230</td>
                        <td>542</td>
                        <td>1027</td>
                        <td>15000</td>
                    </tr>
                </table>
                <div class="text-center row">
                    <div class="col-md-4">

                        <div class="panel">
                            <div class="panel-body">
                                <img src="{{ url('/') }}/public/images/sdg.7.1.2a.png" alt="Figure 1" class="img-responsive">
                                <span>Figure 1</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">

                        <div class="panel">
                            <div class="panel-body">
                                <img src="{{ url('/') }}/public/images/sdg.7.1.2b.png" alt="Figure 1" class="img-responsive">
                                <span>Figure 2</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">

                        <div class="panel">
                            <div class="panel-body">
                                <img src="{{ url('/') }}/public/images/sdg.7.1.2c.png" alt="Figure 1" class="img-responsive">
                                <span>Figure 3</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="sdg_7_2_1" class="tab-pane fade">
                <h3>Target 7.2</h3>
                <h5>Increase global percentage of renewable energy</h5>
                <p><strong>SDG INDICATOR 7.1.2: Renewable energy</strong></p>
                <p>Definition: Rrenewable energy share in the total final energy consumption.</p>
                <p>This is measured as renewable energy (inclusive of solar, wind, geothermal, hydropower, bioenergy and marine sources) as a share of final (not primary) energy consumption. Energy mix includes electricity, transportation and cooking/heating fuels.</p>
                <p>Goal: By 2030, increase substantially the share of renewable energy in the global energy mix.</p>
                <table class="table text-center table-bordered">
                    <tr>
                        <td rowspan="2">Figure</td>
                        <td rowspan="2">Description</td>
                        <td colspan="5">Years</td>
                    </tr>
                    <tr>
                        <td>2015</td>
                        <td>2019</td>
                        <td>2022</td>
                        <td>2025</td>
                        <td>2030</td>
                    </tr>
                    <tr>
                        <td>1</td>
                        <td> Renewable energy share in the total final energy consumption</td>
                        <td>11.9</td>
                        <td>22.1</td>
                        <td>29.7</td>
                        <td>37.3</td>
                        <td>50</td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>Installed capacity of hydropower (MW)</td>
                        <td>782</td>
                        <td>2301</td>
                        <td>5417</td>
                        <td>10260</td>
                        <td>15000</td>
                    </tr>
                </table>
                <div class="text-center row">
                    <div class="col-md-6">

                        <div class="panel">
                            <div class="panel-body">
                                <img src="{{ url('/') }}/public/images/sdg.7.2.1a.png" alt="Figure 1" class="img-responsive">
                                <span>Figure 1</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">

                        <div class="panel">
                            <div class="panel-body">
                                <img src="{{ url('/') }}/public/images/sdg.7.2.1b.png" alt="Figure 1" class="img-responsive">
                                <span>Figure 2</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="sdg_7_3" class="tab-pane fade">
                <h3>Target 7.3: Double the improvement in energy efficiency</h3>
                <h5>UN definition: By 2030, double the global rate of improvement in energy efficiency.</h5>
                <p><strong>SDG INDICATOR 7.3.1: Energy efficiency</strong></p>
                <p>Definition: Energy intensity measured in terms of primary energy and GDP.</p>
                <p>This is measured as the energy intensity of economies (collectively across all sectors). Energy intensity is measured as the quantity of kilowatt-hours produced per 2011 international-$ of gross domestic product (kWh per 2011 int-$).</p>
                <p>Goal: By 2030, double the global rate of improvement in energy efficiency..</p>
                <table class="table text-center table-bordered">
                    <tr>
                        <td rowspan="2">Figure</td>
                        <td rowspan="2">Description</td>
                        <td colspan="5">Years</td>
                    </tr>
                    <tr>
                        <td>2015</td>
                        <td>2019</td>
                        <td>2022</td>
                        <td>2025</td>
                        <td>2030</td>
                    </tr>
                    <tr>
                        <td>1</td>
                        <td>Commercial energy use per unit of GDP (ToE/mRs)</td>
                        <td>3.2	</td>
                        <td>3.28</td>
                        <td>3.17</td>
                        <td>3.15</td>
                        <td>3.14</td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>Energy efficiency in Industry ( MJ per  1000 rupees of product)</td>
                        <td>47.2</td>
                        <td>45.3</td>
                        <td>43.8</td>
                        <td>42.4</td>
                        <td>40</td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td>Higher efficiency appliances (in residential & commercial) (%)</td>
                        <td>10</td>
                        <td>15</td>
                        <td>30</td>
                        <td>40</td>
                        <td>60</td>
                    </tr>
                    <tr>
                        <td>4</td>
                        <td>Electric vehicles in public transport systems (%)</td>
                        <td>1	</td>
                        <td>5	</td>
                        <td>20	</td>
                        <td>35	</td>
                        <td>50</td>
                    </tr>
                </table>
                <div class="text-center row">
                    <div class="col-md-6">

                        <div class="panel">
                            <div class="panel-body">
                                <img src="{{ url('/') }}/public/images/sdg.7.3.1a.png" alt="Figure 1" class="img-responsive">
                                <span>Figure 1</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">

                        <div class="panel">
                            <div class="panel-body">
                                <img src="{{ url('/') }}/public/images/sdg.7.3.1b.png" alt="Figure 1" class="img-responsive">
                                <span>Figure 2</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="text-center row">
                    <div class="col-md-6">

                        <div class="panel">
                            <div class="panel-body">
                                <img src="{{ url('/') }}/public/images/sdg.7.3.1c.png" alt="Figure 1" class="img-responsive">
                                <span>Figure 3</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">

                        <div class="panel">
                            <div class="panel-body">
                                <img src="{{ url('/') }}/public/images/sdg.7.3.1d.png" alt="Figure 1" class="img-responsive">
                                <span>Figure 4</span>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

    </div>

    <!--end site header-->

@endsection