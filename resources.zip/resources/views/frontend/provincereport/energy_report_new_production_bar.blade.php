@extends('frontend_layouts.frontend_province_chart_layout')
@section('content')
<section id="horizontal-form-layouts">
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">

                <?php
                $province_name_final = (!empty($province_name->location_name))?$province_name->location_name:'';
                $district_name_final = (!empty($district_name->location_name))?$district_name->location_name:'';

                $province_name_final = ($district_name_final != '')?'':$province_name_final;
                ?>

                <h4 class="card-title" id="horz-layout-colored-controls">
                    Report For {{ $this_energy_type->energy_type_name }} in {{ $province_name_final }}{{ ($district_name_final != '')?' '.$district_name_final.' district':'' }}
                </h4>

                <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                <div class="heading-elements">
                    <ul class="list-inline mb-0">
                        <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                        <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="col-md-12">
        <div class="card">
            <?php
            $readonly = 'readonly';
            $disabled = 'disabled';
            ?>
            <div class="card-content collpase show">
                <div class="card-body">
                    <div class="card-text">
                        <p>Please fill all the required inputs</p>
                    </div>

                    <div class="advance-filter">
                        <form action="{{$url}}/" id="filterform" method="get">
                        <div class="row">


                            <div class="col-md-6">
                                <div class="form-group">
                                    <p>Output</p>
                                    <select name="output" id="output" class="form-control border-primary">
                                        <option value="overall" {{ (!empty($output) && $output == 'overall')?'selected':'' }}>Total Energy {{ $this_energy_type->energy_type_name }} Share By Fuel Types [ Pie-Chart ]</option>
                                        <option value="fueltype" {{ (!empty($output) && $output == 'fueltype')?'selected':'' }}>Energy {{ $this_energy_type->energy_type_name }} By Fuel Types [ Bar Diagram ]</option>
                                        <option value="districtwise" {{ (!empty($output) && $output == 'districtwise')?'selected':'' }}>Energy {{ $this_energy_type->energy_type_name }} In Districts By Fuel Types [ Bar Diagram ]</option>
                                    </select>
                                </div>
                                <input type="hidden" name="status" value="Y" />
                            </div>

                            <div class="col-md-2">
                                <div class="form-group">
                                    <p>&nbsp;</p>
                                    <button class="form-control bg bg-warning" style="width: auto;">Go</button>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                        </form>
                    </div>

                    @if(!empty($start) && $start != date('Y'))
                        <section id="horizontal-form-layouts">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card">
                                        <div class="card-header">

                                            <h4 class="card-title" id="this_title" style="display: none;">Energy {{ $this_energy_type->energy_type_name }} in {{ $province_name_final }}{{ ($district_name_final != '')?' '.$district_name_final.' district':'' }} By Fuel Types ({{ $start }})</h4>

                                            {{--<h4 class="card-title" id="this_title">Energy {{ ucwords(str_replace("_", " ", $this_energy_type->energy_type_slug)) }}--}}
                                                For  {{ ucwords(str_replace("_", " ", 'Total Energy')) }} of Fiscal Year [{{ $start }}/{{ $end }}]</h4>
                                            <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                                            <div class="heading-elements">
                                                <ul class="list-inline mb-0">
                                                    <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                                    <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="card-content collpase show">
                                            <div class="card-body row">
                                                <div class="col-md-12 form-body-listing">
                                                    <div id="container" style="height:500px; border: 2px solid #333; padding: 30px;"></div>
                                                    <p>In GJ</p>
                                                    <div class="table-responsive">


                                                        <table class="table table-striped table-bordered">
                                                            <?php
                                                            $col = array();
                                                            $col_total_init = 0;
                                                            ?>
                                                            <tr>
                                                                <th>Fuel Type</th>
                                                                <th>Quantity</th>
                                                                <?php
                                                                if(!empty($final_result)){
                                                                    foreach($final_result as $key=>$value){
                                                                        if($value > 0){
                                                                            echo '<input type="hidden" class="x-axis" value="'.$key.'">';
                                                                            echo '<input type="hidden" class="y-axis" value="'.$value.'">';
                                                                            $col[$col_total_init] = 0;
                                                                             $col_total_init++;
                                                                         }
                                                                    }
                                                                    $col[$col_total_init] = 0;
                                                                }
                                                                ?>
                                                            </tr>
                                                            <tbody class="">
                                                            <?php
                                                            $count = 1;
                                                            $row_class= '';
                                                            $row_key= '';
                                                            $counter = 0;

                                                            $total = 0;
                                                            $color_arr = array('table-primary', 'table-success', 'table-info', 'table-warning');
                                                            if(!empty($final_result)){
                                                            foreach($final_result as $key=>$value){

                                                            $this_key = (!empty($key))?$key:'';

                                                            $this_first_key = (!empty($this_key))?$this_key:'';

                                                            $col_count = 0;

                                                            $counter += ($this_first_key != $row_key)?1:0;

                                                            $counter = ($counter < count($color_arr))?$counter:0;

                                                            $row_class = $color_arr[$counter];

                                                            if($value > 0){

                                                            ?>

                                                            <tr class="top_row {{ $row_class }}" title="Key: {{ $row_key }} & Counter: {{ $counter }}">

                                                                    {{ ($this_first_key != $row_key)?$this_first_key:'' }}
                                                                    <?php $row_key = ($this_first_key != $row_key)?$this_first_key:$row_key; ?>

                                                                <td>
                                                                    {{ $this_first_key }}
                                                                    <?php
                                                                    echo '<input type="hidden" id="row'.$count.'" value="'.$this_first_key.'">';
                                                                    ?>
                                                                </td>
                                                                <?php
//                                                                $col[$col_count] = (!empty($col[$col_count]))?(((float)$col[$col_count])/1000):0;
                                                                        $this_no = (((float)$value));
                                                                        echo '<td><input type="hidden" class="row'.$count.'" value="'.$this_no.'">'.(round($this_no,2)).'</td>';
                                                                        $total += abs($this_no);
                                                                        $col[$col_count] += abs($this_no);
                                                                        $col_count++;

                                                                //                                                        $col[$col_count] = (!empty($col[$col_count]))?(((float)$col[$col_count])/1000):0;

                                                                $col[$col_count] += $total;
                                                                //                                                        $col_count++;
                                                                ?>
                                                            </tr>

                                                            <?php
                                                            $count++;
                                                            }
                                                            }
                                                            ?>

                                                            <tr class="table-active">
                                                                <td>
                                                                    Grand Total
                                                                    <?php
                                                                    // echo '<input type="hidden" id="row'.$count.'" value="">';
                                                                    ?>
                                                                </td>
                                                                <td><?php echo round($total, 2); ?></td>
                                                                {{--<td>{{ $col_total }}</td>--}}
                                                            </tr>
                                                            </tbody>
                                                            <?php
                                                            }
                                                            ?>
                                                        </table>
                                                    </div>

                                                    <script>

                                                        function getRandomInt(max) {
                                                            return Math.floor(Math.random() * Math.floor(max));
                                                        }

                                                        var this_title = document.getElementById("this_title").innerHTML;

                                                        var categories_arr = new Array();

                                                        var findit = document.getElementsByClassName('x-axis');
                                                        for(var i = 0; i < findit.length; i++){
                                                            var this_key = findit[i].value;
                                                            categories_arr.push(this_key);
                                                        }

                                                        console.log(categories_arr);

                                                        var series_data = [];

                                                        var top_row = document.getElementsByClassName('y-axis');

                                                        console.log(top_row);

                                                        for(var j=0;j<categories_arr.length;j++){
                                                            var k = j+1;
                                                            var row = 'row'+k;

                                                            // console.log(row);

                                                            var row_arr = new Array();
                                                            var find_row = document.getElementsByClassName(row);

                                                            for (var i = 0; i < find_row.length; i++) {
                                                                var this_key = find_row[i].value;
                                                                row_arr.push(parseInt(this_key));
                                                            }
                                                            var find_id_row_value = document.getElementById(row).value;
                                                            var obj_row = {name: find_id_row_value, data: row_arr};
                                                            series_data.push(obj_row);

                                                        }

                                                        Highcharts.chart('container', {
                                                            chart: {
                                                                type: 'column'
                                                            },
                                                            title: {
                                                                text: this_title
                                                            },
                                                            subtitle: {
                                                                text: ''
                                                            },
                                                            xAxis: {
                                                                categories: categories_arr,
                                                                crosshair: true
                                                            },
                                                            yAxis: {
                                                                min: 0,
                                                                title: {
                                                                    text: 'Energy Unit (In GJ)'
                                                                }
                                                            },
                                                            tooltip: {
                                                                headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                                                                pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                                                                    '<td style="padding:0"><b>{point.y:.1f} GJ</b></td></tr>',
                                                                footerFormat: '</table>',
                                                                shared: true,
                                                                useHTML: true
                                                            },
                                                            plotOptions: {
                                                                column: {
                                                                    pointPadding: 0.2,
                                                                    borderWidth: 0
                                                                }
                                                            },
                                                            series: series_data
                                                        });
                                                    </script>
                                                </div>
                                            </div>


                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>

                    @endif

                </div>


            </div>
        </div>
    </div>
</div>
</section>
@endsection