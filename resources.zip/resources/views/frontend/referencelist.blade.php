@extends('frontend_layouts.datatables_list')

@section('content')

    <div class="app-content content">
      <div class="content-wrapper">
        <div class="content-body"><!-- Zero configuration table -->
<section id="configuration">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Reference List <a href="{{url('/')}}/user/dashboard/reference/add" class="btn btn-primary btn-xs">Add</a></h4>
                    <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                    <div class="heading-elements">
                        <ul class="list-inline mb-0">
                            {{--<li><a data-action="collapse"><i class="ft-minus"></i></a></li>--}}
                            <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                            <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            {{--<li><a data-action="close"><i class="ft-x"></i></a></li>--}}
                        </ul>
                    </div>
                </div>
                <div class="card-content collapse show">
                    <div class="table-responsive card-body card-dashboard">
                        
                        <table class="table table-striped table-bordered zero-configuration">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Address</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @if(!is_null($datas))
                                @foreach($datas as $the_data)
                                <tr>
                                    <td>{{ $the_data->reference_name }}</td>
                                    <td>{{ $the_data->reference_email }}</td>
                                    <td>{{ $the_data->reference_phone }}</td>
                                    <td>{{ $the_data->reference_desc }}</td>
                                    <td>
                                        <a href="{{ url('/') }}/user/dashboard/reference/edit/{{ $the_data->id }}" class="btn btn-primary">Edit</a>
                                    </td>
                                </tr>
                                @endforeach
                                @endif
                            </tbody>
                            {{--<tfoot>--}}
                                {{--<tr>--}}
                                    {{--<th>Name</th>--}}
                                    {{--<th>Email</th>--}}
                                    {{--<th>Phone</th>--}}
                                    {{--<th>Address</th>--}}
                                    {{--<th>Action</th>--}}
                                {{--</tr>--}}
                            {{--</tfoot>--}}
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--/ Zero configuration table -->



        </div>
      </div>
    </div>
@endsection