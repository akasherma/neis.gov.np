@extends('frontend_layouts.add_edit_form_layout')

@section('content')
    <input type="hidden" id="current_email" value="{{$userinfo->email}}">
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-content collpase show ">
                <div class="card-header">
                    <div class="heading-elements">
                        <ul class="list-inline mb-0">
                            <li><a href="#" onclick="return printDoc();"><i class="fa fa-print fa-2x"></i></a></li>
                        </ul>
                    </div>
                </div>
                <div class="card-body">
                    <div class="form-body" id="print_container">
                        <?php
                        $gulf_return = 'No';
                        if($experiences){
                            foreach($experiences as $experience){
                                $gulf_return = (isset($experience->gcc_exp) && $experience->gcc_exp != 'Y')?'Yes':'No';
                            }
                        }
                        ?>
                        <table class="" style="width: 100%;">
                            <tr>
                                <td><?php echo (isset($company_info->company_logo) && $company_info->company_logo != '')?'<img style="width: 150px;" src="'.url("/").'/public/images/'.$company_info->company_logo.'" class="img-fluid" title="Company Logo" alt="Company Logo">':''; ?></td>
                                <td colspan="2" style="text-align: center; "><?php echo (isset($company_info->company_name) && $company_info->company_name != '')?'<h2 class="company-title">'.$company_info->company_name.'</h2>':''; ?></td>
                                <td><?php echo (isset($company_info->other_logo) && $company_info->other_logo != '')?'<img style="width: 150px; float: right;" src="'.url("/").'/public/images/'.$company_info->other_logo.'" class="img-fluid" title="Company Logo" alt="Company Logo">':''; ?></td>
                            </tr>
                            <tr>
                                <td colspan="4"><h3 style="text-align: center; font-size: 2rem;">Job Application Form</h3></td>
                            </tr>
                            <tr>
                                <td colspan="3">
                                    <?php echo (isset($candidate_entry->position_name) && $candidate_entry->position_name != '')?'<h4>Job Applied For: '.$candidate_entry->position_name.'</h4>':''; ?>
                                </td>
                                <td rowspan="3">
                                    <?php echo (isset($attachments['photograph']) && $attachments['photograph'] != '')?'<img style="width: 150px;" src="'.url("/").'/public/images/'.$attachments["photograph"].'" class="img-thumbnail" title="Photograph" alt="Photograph">':''; ?>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="3">
                                    <?php echo (isset($candidate_entry->company_applied_for_name) && $candidate_entry->company_applied_for_name != '')?'<h4>Company: '.$candidate_entry->company_applied_for_name.'</h4>':''; ?>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="3">
                                    <?php echo (isset($candidate_entry->first_name) && $candidate_entry->first_name != '')?'<h4>Name: '.$candidate_entry->first_name.' '.$candidate_entry->middle_name.' '.$candidate_entry->last_name.'</h4>':''; ?>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="4">&nbsp;</td>
                            </tr>
                            <tr>
                                <td colspan="4">&nbsp;</td>
                            </tr>
                            <tr>
                                <td>
                                    <?php echo (isset($candidate_entry->passport_no) && $candidate_entry->passport_no != '')?'<h4>PP No: '.$candidate_entry->passport_no.'</h4>':''; ?>
                                </td>
                                <td colspan="2" style="text-align: center;">
                                    <?php echo (isset($candidate_entry->passport_issue_date) && $candidate_entry->passport_issue_date != '')?'<h4>Issue Date: '.$candidate_entry->passport_issue_date.'</h4>':''; ?>
                                </td>
                                <td>
                                    <?php echo (isset($candidate_entry->passport_expiry_date) && $candidate_entry->passport_expiry_date != '')?'<h4>Expiry Date: '.$candidate_entry->passport_expiry_date.'</h4>':''; ?>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="4"><?php echo ($gulf_return != 'No')?'<h4>Gulf Return: '.$gulf_return.'</h4>':''; ?></td>
                            </tr>
                            @if(!empty($qualifications))
                                <tr>
                                    <td colspan="4"><h4>Educational Qualification: </h4></td>
                                </tr>
                                <tr>
                                    <td colspan="4">
                                        <table class="table table-bordered" border="1" style="width: 100%;">
                                            <tr>
                                                <th>Qualification</th>
                                                <th>Board</th>
                                                <th>Year</th>
                                                <th>Division</th>
                                            </tr>
                                            @foreach($qualifications as $qualification)
                                                <tr>
                                                    <td>{{ $qualification->qualification_type_name }}</td>
                                                    <td>{{ $qualification->board }}</td>
                                                    <td>{{ $qualification->year }}</td>
                                                    <td>{{ $qualification->division }}</td>
                                                </tr>
                                            @endforeach
                                        </table>
                                    </td>
                                </tr>
                            @endif
                            @if($experiences)
                                <tr>
                                    <td colspan="4"><h4>Experience: </h4></td>
                                </tr>
                                <tr>
                                    <td colspan="4">
                                        <table class="table table-bordered" border="1">
                                            <tr>
                                                <th>Country</th>
                                                <th>Date From</th>
                                                <th>Date From</th>
                                                <th>Total Experience</th>
                                                <th>Company</th>
                                                <th>Designation</th>
                                                <th>Job Details</th>
                                            </tr>
                                            @foreach($experiences as $experience)
                                                <tr>
                                                    <td>{{ $experience->country }}</td>
                                                    <td>{{ $experience->exp_from }}</td>
                                                    <td>{{ $experience->exp_to }}</td>
                                                    <td>{{ (int)$experience->no_of_exp_in_years }} Years</td>
                                                    <td>{{ $experience->company }}</td>
                                                    <td>{{ $experience->designation }}</td>
                                                    <td>{{ $experience->job_details }}</td>
                                                </tr>
                                            @endforeach
                                        </table>
                                    </td>
                                </tr>
                            @endif
                            <tr>
                                <td colspan="4">
                                    <h4>Interview Comments:</h4>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="4">
                                    <textarea class="form-control border-primary" style="width: 100%"></textarea>
                                </td>
                            </tr>

                        </table>
                            <?php /*
                        <div class="row">
                            <div class="col-md-2">
                                <?php echo (isset($company_info->company_logo) && $company_info->company_logo != '')?'<img src="'.url("/").'/public/images/'.$company_info->company_logo.'" class="img-thumbnail" title="Company Logo" alt="Company Logo">':''; ?>
                            </div>
                            <div class="col-md-8">
                                <?php echo (isset($company_info->company_name) && $company_info->company_name != '')?'<h2>'.$company_info->company_name.'</h2>':''; ?>
                            </div>
                            <div class="col-md-2">
                                <?php echo (isset($company_info->other_logo) && $company_info->other_logo != '')?'<img src="'.url("/").'/public/images/'.$company_info->other_logo.'" class="img-thumbnail" title="Company Logo" alt="Company Logo">':''; ?>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <h3>Job Application Form</h3>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-9">
                                <?php echo (isset($candidate_entry->position_name) && $candidate_entry->position_name != '')?'<h4>Job Applied For: '.$candidate_entry->position_name.'</h4>':''; ?>
                                <?php echo (isset($candidate_entry->company_applied_for_name) && $candidate_entry->company_applied_for_name != '')?'<h4>Company: '.$candidate_entry->company_applied_for_name.'</h4>':''; ?>
                                <?php echo (isset($candidate_entry->first_name) && $candidate_entry->first_name != '')?'<h4>Name: '.$candidate_entry->first_name.' '.$candidate_entry->middle_name.' '.$candidate_entry->last_name.'</h4>':''; ?>
                            </div>
                            <div class="col-md-3">
                                <?php echo (isset($attachments['photograph']) && $attachments['photograph'] != '')?'<img src="'.url("/").'/public/images/'.$attachments["photograph"].'" class="img-thumbnail" title="Photograph" alt="Photograph">':''; ?>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <?php echo (isset($candidate_entry->passport_no) && $candidate_entry->passport_no != '')?'<h4>PP No: '.$candidate_entry->passport_no.'</h4>':''; ?>
                                <?php echo ($gulf_return != 'No')?'<h4>Gulf Return: '.$gulf_return.'</h4>':''; ?>
                            </div>
                            <div class="col-md-4">
                                <?php echo (isset($candidate_entry->passport_issue_date) && $candidate_entry->passport_issue_date != '')?'<h4>Issue Date: '.$candidate_entry->passport_issue_date.'</h4>':''; ?>
                            </div>
                            <div class="col-md-4">
                                <?php echo (isset($candidate_entry->passport_expiry_date) && $candidate_entry->passport_expiry_date != '')?'<h4>Expiry Date: '.$candidate_entry->passport_expiry_date.'</h4>':''; ?>
                            </div>
                        </div>
                        @if(!empty($qualifications))
                            <div class="row">
                                <div class="col-md-12">
                                    <h4>Educational Qualification: </h4>
                                    <table class="table table-bordered">
                                        <tr>
                                            <th>Qualification</th>
                                            <th>Board</th>
                                            <th>Year</th>
                                            <th>Division</th>
                                        </tr>
                                        @foreach($qualifications as $qualification)
                                            <tr>
                                                <td>{{ $qualification->qualification_type_name }}</td>
                                                <td>{{ $qualification->board }}</td>
                                                <td>{{ $qualification->year }}</td>
                                                <td>{{ $qualification->division }}</td>
                                            </tr>
                                        @endforeach
                                    </table>
                                </div>
                            </div>
                        @endif
                        @if($experiences)
                            <div class="row">
                                <div class="col-md-12">
                                    <h4>Experience: </h4>
                                    <table class="table table-bordered">
                                        <tr>
                                            <th>Country</th>
                                            <th>Date From</th>
                                            <th>Date From</th>
                                            <th>Total Experience</th>
                                            <th>Company</th>
                                            <th>Designation</th>
                                            <th>Job Details</th>
                                        </tr>
                                        @foreach($experiences as $experience)
                                            <tr>
                                                <td>{{ $experience->country }}</td>
                                                <td>{{ $experience->exp_from }}</td>
                                                <td>{{ $experience->exp_to }}</td>
                                                <td>{{ (int)$experience->no_of_exp_in_years }} Years</td>
                                                <td>{{ $experience->company }}</td>
                                                <td>{{ $experience->designation }}</td>
                                                <td>{{ $experience->job_details }}</td>
                                            </tr>
                                        @endforeach
                                    </table>
                                </div>
                            </div>
                        @endif
                        <div class="row">
                            <div class="col-md-2">
                                <h4>Interview Comments:</h4>
                            </div>
                            <div class="col-md-10">
                                <textarea class="form-control border-primary"></textarea>
                            </div>
                        </div>

 */ ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>

    function printDoc(){
        var current_email = document.getElementById('current_email').value;
        var d = new Date();
        var cur_time = 'transaction-'+current_email+'-'+d.getFullYear()+'.'+d.getMonth()+'.'+d.getDate()+'.'+d.getHours()+'.'+d.getMinutes()+'.'+d.getSeconds()+'.'+d.getMilliseconds();

        // var cur_time = parseInt(parseFloat(Date.now())/1000);
        // alert(current_email);
        // return false;

        var mywindow = window.open('', 'PRINT', 'height=842,width=595');

        mywindow.document.write('<html><head><title>' + cur_time + '</title>');
        mywindow.document.write('</head><body >');
        mywindow.document.write(document.getElementById('print_container').innerHTML);
        mywindow.document.write('</body></html>');
        mywindow.document.close(); // necessary for IE >= 10
        mywindow.focus(); // necessary for IE >= 10*/
        mywindow.print();
        mywindow.close();
        return true;
    }

</script>
@endsection