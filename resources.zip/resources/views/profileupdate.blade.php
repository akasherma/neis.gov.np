@extends('dashboard_layouts.user_dashboard_layout')
@section('content')
    <section id="horizontal-form-layouts">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="horz-layout-colored-controls">Edit Your Profile</h4>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="card-content collpase show">
                        <div class="card-body">
                            <div class="card-text">
                                <p>Please fill all the required inputs</p>
                            </div>
                            <form action="{{url('/')}}/dashboard/profileupdate" method="post" enctype="multipart/form-data">
                                @csrf
                                <input type="hidden" name="id" value="{{$id}}" />
                                <div class="form-group">
                                    <p>Name</p>
                                    <input type="text" class="form-control border-primary" name="name" placeholder="Enter Your Name" value="{{$data->name}}"/>
                                </div>
                                <div class="form-group">
                                    <p>Email</p>
                                    <input type="email" class="form-control border-primary" name="email" placeholder="Enter Your Email" value="{{$data->email}}"/>
                                </div>

                                <div class="form-group">
                                    <p>Organisation Name</p>
                                    <input type="text" class="form-control border-primary" name="organization_name" placeholder="Enter Organisation Name" value="{{$data->organization_name}}"/>
                                </div>

                                <div class="form-group">
                                    <p>Address</p>
                                    <input type="text" class="form-control border-primary" name="address" placeholder="Enter Address" value="{{$data->address}}"/>
                                </div>

                                <div class="form-group">
                                    <p>Designation</p>
                                    <input type="text" class="form-control border-primary" name="designation" placeholder="Enter Designation" value="{{$data->designation}}"/>
                                </div>
                                <div class="form-group">
                                    <p>Phone No</p>
                                    <input type="text" class="form-control border-primary" name="phone" placeholder="Enter Phone No" value="{{$data->phone}}"/>
                                </div>

                                <input type="hidden" name="status" value="Y" />

                                <div class="form-actions right">
                                    <button type="button" class="btn btn-danger mr-1">
                                        <i class="ft-x"></i> Cancel
                                    </button>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="la la-check-square-o"></i> Save
                                    </button>
                                </div>
                            </form>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection