<a href="{{url('/')}}/usertype/add">Add</a>

@if ($message = Session::get('success'))
    <div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong>{{ $message }}</strong>
    </div>
@endif


@if ($message = Session::get('error'))
    <div class="alert alert-danger alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong>{{ $message }}</strong>
    </div>
@endif


@if ($message = Session::get('warning'))
    <div class="alert alert-warning alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong>{{ $message }}</strong>
    </div>
@endif


@if ($message = Session::get('info'))
    <div class="alert alert-info alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong>{{ $message }}</strong>
    </div>
@endif

<table border='1'>
    <tr>
        <th>ID</th>
        <th>User Type Name</th>
        <th>User Type Description</th>
        <th>Status</th>
        <th colspan="2">Action</th>
    </tr>
    @if(!empty($data))
        @foreach($data as $the_result)
            <tr>
                <td>{{$the_result->id}}</td>
                <td>{{$the_result->user_type_name}}</td>
                <td>{{$the_result->user_type_desc}}</td>
                <td>{{$the_result->status}}</td>
                <td>{{$the_result->created_at}}</td>
                <td>{{$the_result->updated_at}}</td>
                <td><a href="{{url('/')}}/usertype/edit/{{$the_result->id}}">Edit</a></td>
                <td><a href="{{url('/')}}/usertype/delete/{{$the_result->id}}">Delete</a></td>
            </tr>
        @endforeach
    @else
        <tr><td colspan="6"> No Records Found !</td>
        </tr>
@endif