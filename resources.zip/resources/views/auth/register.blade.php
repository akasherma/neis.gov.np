@extends('layouts.app')

@section('content')
    <div class="content-body"><section class="flexbox-container">
            <div class="col-12 d-flex align-items-center justify-content-center">
                <div class="col-md-4 col-10 box-shadow-2 p-0">
                    <div class="card border-grey border-lighten-3 px-1 py-1 m-0">
                        <div class="card-header border-0">
                            <div class="font-large-1  text-center">
                                Sign Up
                            </div>
                        </div>
                        <div class="card-content">

                            <div class="card-body">

                    <form method="POST" class="form-horizontal" action="{{ route('register') }}" aria-label="{{ __('Register') }}">
                        @csrf

                        <label for="name" class="col-form-label text-md-right">{{ __('Full Name') }}</label>

                        <fieldset class="form-group position-relative has-icon-left">

                            <input id="name" type="text" class="form-control{{ $errors->has('name') ? ' is-invalid' : '' }} round" name="name" value="{{ old('name') }}" required autofocus>

                            @if ($errors->has('name'))
                                <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('name') }}</strong>
                                    </span>
                            @endif

                            <div class="form-control-position">
                                <i class="ft-user"></i>
                            </div>
                        </fieldset>

                        <label for="email" class="col-form-label text-md-right">{{ __('Email Address') }}</label>

                        <fieldset class="form-group position-relative has-icon-left">

                            <input id="email" type="email" class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" value="{{ old('email') }}" required>

                            @if ($errors->has('email'))
                                <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                            @endif
                            <div class="form-control-position">
                                <i class="ft-mail"></i>
                            </div>
                        </fieldset>

                        <label for="password" class="col-form-label text-md-right">{{ __('Password') }}</label>

                        <fieldset class="form-group position-relative has-icon-left">


                            <input id="password" type="password" class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" name="password" required>

                            @if ($errors->has('password'))
                                <span class="invalid-feedback" role="alert">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                            @endif

                            <div class="form-control-position">
                                <i class="ft-lock"></i>
                            </div>
                        </fieldset>

                        <label for="password" class="col-form-label text-md-right">{{ __('Confirm Password') }}</label>

                        <fieldset class="form-group position-relative has-icon-left">

                            <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>

                            <div class="form-control-position">
                                <i class="ft-lock"></i>
                            </div>
                        </fieldset>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Register') }}
                                </button>
                            </div>
                        </div>
                    </form>
                            </div>

                            <p class="card-subtitle text-muted text-right font-small-3 mx-2 my-1">
                        <span>Already a member ?
                            <a href="{{ url('/') }}/login" class="card-link">Sign In</a>
                        </span>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
