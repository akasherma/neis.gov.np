@extends('dashboard_layouts.user_dashboard_layout')
@section('content')
    <section id="horizontal-form-layouts">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="horz-layout-colored-controls">Energy Fiscal Year For Report</h4>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <?php
                        $permalink = $url;
//                    $permalink = url('/').'/dashboard/entry-form';
//                    $permalink .= (!empty($this_province))?'/province/'.$this_province->location_slug:'';
//                    $permalink .= (!empty($this_district))?'/district/'.$this_district->location_slug:'';
//                    $permalink .= (!empty($this_local))?'/local/'.$this_local->location_slug:'';
                    ?>
                    <div class="card-content collpase show">
                        <div class="card-body row">
                            <?php 
                            $start = ''; 
                            $count = 0;
                            ?>
                            @if(!empty($energy_years))
                                @foreach($energy_years as $energy_year)
                                    <?php 
                                        $start = ($count++ < 1)?$energy_year->energy_year_start:$start; 
                                        $end = $energy_year->energy_year_end;
                                    ?>
                                        <div class="col-md-4 col-sm-6 form-body-listing ">
                                        <div>
                                            <h4>
                                                <a class="btn btn-lg btn-outline-primary round" href="{{ $permalink.'/fiscal-year/'.$energy_year->energy_year_start.'/'.$energy_year->energy_year_end }}">
                                                    {{ $energy_year->energy_year_start.'/'.$energy_year->energy_year_end }}
                                                    <span class="badge badge-primary"><?php echo 'Fiscal Year '; ?></span>
                                                </a>
                                            </h4>
                                        </div>
                                        <br>
                                        &nbsp;
                                    </div>
                                @endforeach

                            @endif
                        </div>
                    </div>
                    <div class="card-content collpase show">
                        <div class="card-body row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="card-title" id="horz-layout-colored-controls">Energy Trending</h4>
                                    </div>
                                </div>                                
                            </div>
                            <div class="col-md-3">
                            @if(!empty($start))
                                <select name="" id="starting" class="form-control">
                                    <option value="">Select Start Year</option>
                                    @for($i = $start; $i < $end; $i++)
                                        <option value="{{ $i }}">{{ $i }}</option>
                                    @endfor
                                </select>
                            @endif
                            </div>
                            <div class="col-md-3">
                            @if(!empty($end))
                                <select name="" id="ending" class="form-control" style="display: none;">
                                    <option value="">Select End Year</option>
                                    @for($j = ($start+1); $j <= $end; $j++)
                                        <option value="{{ $j }}">{{ $j }}</option>
                                    @endfor
                                </select>
                            @endif
                            </div>

                            <div class="col-md-3">
                                <div class="btn btn-sm btn-outline-primary round" id="now_go" style="display: none;">
                                    <h4>
                                        <a href="{{ $permalink }}" title="{{ $permalink }}" name="{{ $permalink }}" id="go_id">GO</a>
                                    </h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection