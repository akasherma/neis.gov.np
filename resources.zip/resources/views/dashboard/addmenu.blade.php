@extends('dashboard_layouts.user_dashboard_layout')
@section('content')
    <section id="horizontal-form-layouts">

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="horz-layout-colored-controls">{{ ucfirst($route) }} Menu</h4>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="card-content collpase show">
                        <div class="card-body">
                            <div class="card-text">
                                <p>Please fill all the required inputs</p>
                            </div>
                            <form action="{{url('/')}}/dashboard/menu/{{ $route }}" method="post" enctype="multipart/form-data">
                                <div class="form-body">
                                    <h4 class="form-section"><i class="la la-eye"></i> Menu Details</h4>
                                    @csrf
                                    <input type="hidden" name="formdata[id]" value="{{ $data->id }}">
                                    <div class="form-group">
                                        <p>Menu Name</p>
                                        <input type="text" class="form-control border-primary" name="formdata[menu_name]" placeholder="" value="{{ $data->menu_name }}" required />
                                    </div>
                                    <div class="form-group">
                                        <p>Menu Slug</p>
                                        <input type="text" class="form-control border-primary" name="formdata[menu_slug]" placeholder="" value="{{ $data->menu_slug }}" required />
                                    </div>
                                    <div class="form-group">
                                        <p>Menu Description</p>
                                        <input type="text" class="form-control border-primary" name="formdata[menu_desc]" placeholder="" value="{{ $data->menu_desc }}" />
                                    </div>
                                    <div class="form-group">
                                        <p>Menu Type</p>

                                        <select name="formdata[menu_type_id]" id="" class="form-control border-primary">
                                            @if($menu_type)
                                                @foreach($menu_type as $the_menu_type)
                                                    <option value="{{ $the_menu_type->id }}" {{ ($data->menu_type_id == $the_menu_type->id)?'selected':'' }}>{{ $the_menu_type->menu_type_name }}</option>
                                                @endforeach
                                            @endif
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <p>Menu Order</p>
                                        <input type="number" class="form-control border-primary" name="formdata[menu_order]" placeholder="" value="0" required />
                                    </div>
                                    <div class="form-actions right">
                                        <button type="button" class="btn btn-danger mr-1">
                                            <i class="ft-x"></i> Cancel
                                        </button>
                                        <button type="submit" class="btn btn-primary">
                                            <i class="la la-check-square-o"></i> Save
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection