@extends('dashboard_layouts.main_dashboard_layout')
@section('content')
    <section id="horizontal-form-layouts">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="this_title">Provincewise Energy {{ $this_energy_type->energy_type_name }} By {{ ucwords(str_replace("_", " ", $energy_topic)) }} of Fiscal Year [{{ $start }}/{{ $end }}]</h4>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <?php
                    $permalink = $url;
                    ?>
                    <div class="card-content collpase show">
                        <div class="card-body row">
                            @if(!empty($energy_topics))
                                @foreach($energy_topics as $energy_list)
                                    <div class="col-md-12 form-body-listing ">
                                        <div class="btn btn-sm btn-outline-primary round">
                                            <h4>
                                                <a class="" href="{{ $permalink.'/energy-topic/'.$energy_list }}">{{ ucwords(str_replace("_", " ",$energy_list)) }} Verses Energy</a>
                                            </h4>
                                        </div>
                                        <br>                                        &nbsp;
                                    </div>
                                @endforeach

                                @endif
                            <div class="col-md-12 form-body-listing">
                                <div id="container" style="height:500px;"></div>

                                <div class="table-responsive">
                                    <table border="1" cellspacing="3" cellpadding="3">
                                        <?php
                                        $col = array();
                                        $col_total_init = 0;
                                        ?>
                                        <tr>
                                            <th>&nbsp;</th>
                                            <?php
                                            if(!empty($provinces)){
                                                foreach($provinces as $the_province){
                                                    echo '<th><input type="hidden" class="x-axis" value="'.$the_province->location_name.'">'.$the_province->location_name.'</th>';
                                                    $col[$col_total_init] = 0;
                                                    $col_total_init++;
                                                }
                                                $col[$col_total_init] = 0;
                                            }
                                            ?>
                                            <th><input type="hidden" class="x-axis" value="Total">Total</th>
                                        </tr>
                                        <?php
                                        $count = 1;
                                        if(!empty($final_result)){
                                            foreach($final_result as $key=>$value){
                                                $total = 0;
                                                $col_count = 0;
                                                ?>

                                                <tr class="top_row">
                                                    <td>
                                                        {{ ucwords(str_replace('_', ' ', $key)) }}
                                                        <?php
                                                        echo '<input type="hidden" id="row'.$count.'" value="'.$key.'">';
                                                        ?>
                                                    </td>
                                                    <?php
                                                        if(is_array($value)){
                                                            foreach($value as $the_value){

//                                                                $col[$col_count] = (!empty($col[$col_count]))?(((float)$col[$col_count])/1000):0;

                                                                echo '<td><input type="hidden" class=" row'.$count.'" value="'.(((float)$the_value->qty)/1000).'">'.(((float)$the_value->qty)/1000).'</td>';
                                                                $total += (((float)$the_value->qty)/1000);
                                                                $col[$col_count] += (((float)$the_value->qty)/1000);
                                                                $col_count++;
                                                            }
                                                        }

                                                        $col[$col_count] += $total;
                                                        $count++;
                                                    ?>
                                                    <td>{{ $total }}</td>
                                                </tr>


                                        <?php
                                            }
                                        ?>

                                            <tr class="top_row">
                                                <td>
                                                    Total
                                                    <?php
                                                    echo '<input type="hidden" id="row'.$count.'" value="Total">';
                                                    ?>
                                                </td>
                                            <?php
                                                $col_total = 0;
                                            if(is_array($col)){
                                                foreach($col as $the_value){
//                                                    echo '<td><input type="hidden" class=" row'.$count.'" value="'.((float)$the_value).'">'.((float)$the_value).'</td>';
                                                    echo '<td>'.((float)$the_value).'</td>';
                                                    $col_total += (float)$the_value;
                                                }
                                            }
                                            ?>
                                                {{--<td>{{ $col_total }}</td>--}}
                                            </tr>
                                        <?php
                                        }
                                        ?>
                                    </table>
                                </div>

                                <script>

                                    function getRandomInt(max) {
                                        return Math.floor(Math.random() * Math.floor(max));
                                    }

                                    var this_title = document.getElementById("this_title").innerHTML;

                                    var categories_arr = new Array();

                                    var findit = document.getElementsByClassName('x-axis');
                                    for(var i = 0; i < findit.length; i++){
                                        var this_key = findit[i].value;
                                        categories_arr.push(this_key);
                                    }

                                    var series_data = [];

                                    var top_row = document.getElementsByClassName('top_row');

                                    for(var j=0;j<top_row.length;j++){
                                        var k = j+1;
                                        var row = 'row'+k;

                                        console.log(row);

                                        var row_arr = new Array();
                                        var find_row = document.getElementsByClassName(row);

                                        for (var i = 0; i < find_row.length; i++) {
                                            var this_key = find_row[i].value;
                                            row_arr.push(parseInt(this_key));
                                        }
                                        var find_id_row_value = document.getElementById(row).value;
                                        var obj_row = {name: find_id_row_value, data: row_arr};
                                        series_data.push(obj_row);

                                    }

                                    Highcharts.chart('container', {
                                        chart: {
                                            type: 'column'
                                        },
                                        title: {
                                            text: this_title
                                        },
                                        subtitle: {
                                            text: ''
                                        },
                                        xAxis: {
                                            categories: categories_arr,
                                            crosshair: true
                                        },
                                        yAxis: {
                                            min: 0,
                                            title: {
                                                text: 'Energy Unit (In Kilo GJ)'
                                            }
                                        },
                                        tooltip: {
                                            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                                            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                                                '<td style="padding:0"><b>{point.y:.1f} GJ</b></td></tr>',
                                            footerFormat: '</table>',
                                            shared: true,
                                            useHTML: true
                                        },
                                        plotOptions: {
                                            column: {
                                                pointPadding: 0.2,
                                                borderWidth: 0
                                            }
                                        },
                                        series: series_data
                                    });
                                </script>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection