@extends('dashboard_layouts.user_dashboard_layout')
@section('content')
<section id="horizontal-form-layouts">
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title" id="horz-layout-colored-controls">
                    Provincial Level Entry Form For {{ $this_energy_type->energy_type_name }}
                    {{--{{ ucfirst($route) }} {{ ucfirst($energy_type) }} Energy for Energy - {{ $this_energy->energy_name }} of fiscal year {{ $start }}/{{ $end }}--}}
                </h4>
                <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                <div class="heading-elements">
                    <ul class="list-inline mb-0">
                        <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                        <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                    </ul>
                </div>
            </div>
            <?php
            $readonly = ($route != 'edit')?'':'readonly';
            $disabled = ($route != 'edit')?'':'disabled';
            ?>
            <div class="card-content collpase show">
                <div class="card-body">
                    <div class="card-text">
                        <p>Please fill all the required inputs</p>
                    </div>

                    <div class="advance-filter">
                        <form action="{{url('/')}}/dashboard/entryform-province/{{ $this_energy_type->energy_type_slug }}/" id="filterform" method="get">
                        <div class="row">

                            @if(!empty($energy_year[0]))
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <p>Year</p>
                                        <select name="year" id="year" class="form-control border-primary" onchange="document.getElementById('filterform').submit();" required>
                                            <option value="">-Select Year-</option>
                                            @foreach($energy_year as $the_year)
                                                <option value="{{ $the_year->energy_year_start }}" {{ ($the_year->energy_year_start == $start)?'selected':'' }}>{{ $the_year->energy_year_start.'/'.$the_year->energy_year_end }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                            @endif

                            <?php $is_central_get = (!empty($is_central))?$is_central:0; ?>

                            <div class="col-md-10" id="no_central" <?php echo ($start > 1)?'style="display:block;"':'style="display:none;"'; ?>>
                                <div class="row">


                                    @if(!empty($provinces))
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <p>Province</p>
                                                <select name="province_id" id="province" class="form-control border-primary">
                                                    <option value="">-Select-</option>
                                                    @foreach($provinces as $the_location)
                                                        <option value="{{ $the_location->id }}" {{ ($province_id == $the_location->id)?'selected':'' }}>{{ $the_location->location_name }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                    @endif

                                    @if(!empty($districts))
                                            <div class="col-md-3">
                                            <div class="form-group">
                                                <p>District</p>
                                                <select name="district_id" id="district" class="form-control border-primary">
                                                    <option value="">---</option>
                                                    @foreach($districts as $the_location)
                                                        <?php
                                                        if($the_location->parent_id == $province_id || $province_id == ''){
                                                        ?>
                                                        <option value="{{ $the_location->id }}" {{ ($district_id == $the_location->id)?'selected':'' }} class="parent_{{ $the_location->parent_id }}">{{ $the_location->location_name }}</option>
                                                        <?php
                                                        }
                                                        ?>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                    @endif

                                    @if(!empty($local_governments))
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <p>Municipality</p>
                                                <select name="local_gov_id" id="local_gov_id" class="form-control border-primary">
                                                    <option value="">---</option>
                                                    @foreach($local_governments as $the_location)
                                                        <option value="{{ $the_location->id }}" {{ ($local_gov_id == $the_location->id)?'selected':'' }} class="parent_{{ $the_location->parent_id }}">{{ $the_location->location_name }}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                            <input type="hidden" name="status" value="Y" />
                                        </div>
                                    @endif

                                    <div class="col-md-2">
                                        <div class="form-group">
                                            <p>&nbsp;</p>
                                            <button class="form-control bg bg-warning" style="width: auto;">Go</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                        </form>
                    </div>

                    @if(!empty($start) && $start != date('Y'))

                        {{--http://localhost/wecs/public_html/dashboard/entryform/import/store--}}

                    <form action="{{url('/')}}/dashboard/entryform-province/{{ $this_energy_type->energy_type_slug }}" method="post" enctype="multipart/form-data">
                        @csrf
                        <input type="hidden" name="formdata[from_date]" value="{{ $start }}">
                        <input type="hidden" name="formdata[to_date]" value="{{ $end }}">
                        <input type="hidden" name="formdata[province_id]" value="{{ $province_id }}">
                        <input type="hidden" name="formdata[district_id]" value="{{ $district_id }}">
                        <input type="hidden" name="formdata[local_gov_id]" value="{{ $local_gov_id }}">
                        <div class="form-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <h4 class="form-section"><i class="la la-eye"></i> Entry Form For {{ $this_energy_type->energy_type_name }}</h4>
                                </div>
                                @if(!empty($energy_listing))
                                    <div class="col-md-12">
                                        <div class="row energy_listing">

                                            <div class="col-md-12">
                                                <div class="table-container">
                                                    <table class="table table-bordered">
                                                        <tr>
                                                            <th>Energy</th>
                                                            <th>Natural Qty</th>
                                                            <th>Natural Unit</th>
                                                            <th>Energy Equivalent in GJ</th>
                                                        </tr>
                                                        <?php $i = 0; ?>
                                                        @foreach($energy_listing as $the_energy)
                                                            <?php

                                                            $this_data = (!empty($data[$the_energy->id]))?$data[$the_energy->id]:'';
                                                            $natural_qty = (!empty($this_data->natural_qty))?$this_data->natural_qty:'';
                                                            $natural_unit = (!empty($this_data->natural_unit))?$this_data->natural_unit:'';
                                                            $scientific_qty = (!empty($this_data->scientific_qty))?$this_data->scientific_qty:'';

                                                            ?>
                                                            <tr>
                                                                <td>
                                                                    <strong>{{$the_energy->energy_name}}</strong><br>
                                                                    - {{$the_energy->fuel_type_name}}
                                                                    <input type="hidden" name="overall[{{$i}}][energy_id]" value="{{ $the_energy->id }}">
                                                                </td>
                                                                <td>
                                                                    <input type="number" min="0" step="any" name="overall[{{$i}}][natural_qty]" class="natural_qty form-control border-primary" value="{{ $natural_qty }}">
                                                                </td>
                                                                <td>
                                                                    <select name="overall[{{$i}}][natural_unit]" id="" class="natural_unit form-control">
                                                                        @if($units)
                                                                            @foreach($units as $the_unit)
                                                                                <option value="{{ $the_unit->unit_slug }}" {{ ($the_unit->unit_slug == $natural_unit)?'selected':'' }}>{{ $the_unit->unit_name }}</option>
                                                                            @endforeach
                                                                        @endif
                                                                    </select>
                                                                </td>
                                                                @if($units)
                                                                    @foreach($units as $the_unit)
                                                                        <input type="hidden" class="scientific_unit_conversion" value="{{ $scientific_qty }}" title="{{ $the_unit->unit_slug }}">
                                                                    @endforeach
                                                                @endif
                                                                <td>
                                                                    <input type="text" name="overall[{{$i}}][scientific_qty]" class="scientific_qty form-control border-primary" value="{{ $scientific_qty }}" readonly>
                                                                    <input type="hidden" name="overall[{{$i}}][scientific_unit]" value="GJ">
                                                                </td>
                                                            </tr>
                                                            <?php $i++; ?>
                                                        @endforeach

                                                    </table>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                @endif

                                @if($units)
                                    @foreach($units as $the_unit)
                                        <input type="hidden" class="scientific_unit_conversion_standard" value="{{ $the_unit->scientific_qty }}" title="{{ $the_unit->unit_slug }}">
                                    @endforeach
                                @endif

                                <div class="col-md-12">
                                    <div class="form-actions right">
                                        <button type="button" class="btn btn-danger mr-1">
                                            <i class="ft-x"></i> Cancel
                                        </button>
                                        <button type="submit" class="btn btn-primary">
                                            <i class="la la-check-square-o"></i> Save
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>

                    @endif

                </div>


            </div>
        </div>
    </div>
</div>
</section>
@endsection