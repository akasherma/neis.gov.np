@extends('dashboard_layouts.user_dashboard_layout')
@section('content')

    <section id="horizontal-form-layouts">

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="horz-layout-colored-controls">Menu Policy For :: {{$this_user_group->user_group_name}}</h4>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="card-content collpase show">
                        <div class="card-body">
                            <div class="card-text">
                                <p>Please fill all the required inputs</p>
                            </div>

                    <form class="form-horizontal" method="post" action="{{ url('/') }}/dashboard/user_group/{{$route}}">
                        {{ csrf_field() }}
                        <input type="hidden" name="user_group_id" value="{{$this_user_group->id}}" class="form-control"/>
                        <div class="form-group">
                            <div class="row">
                                @foreach($menus as $the_menu)
                                    <span class="col-md-2 col-md-offset-1">
                                    <?php
                                    $checked = (in_array($the_menu->id, $plot))?'checked':'';
                                    $active = (in_array($the_menu->id, $plot))?'active':'';
                                    ?>
                                    <label class="custom-control custom-control-primary custom-checkbox <?php echo $active; ?>">
                                        <input class="custom-control-input" type="checkbox" name="menu_id[]" value="{{$the_menu->id}}" <?php echo $checked; ?> />
                                        <span class="custom-control-indicator"></span>
                                        <span class="custom-control-label">{{ ucwords(str_replace('_', ' ',$the_menu->menu_name)) }}</span>
                                    </label>
                                    </span>
                                @endforeach

                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-2 col-md-offset-1">
                                <button type="submit" class="btn btn-success">Save Changes</button>
                            </div>
                        </div>
                    </form>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>
    {{--safsdf--}}
    <?php /*
    <section id="horizontal-form-layouts">

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="horz-layout-colored-controls">{{ ucfirst($route) }} User Group</h4>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="card-content collpase show">
                        <div class="card-body">
                            <div class="card-text">
                                <p>Please fill all the required inputs</p>
                            </div>

                            <form action="{{url('/')}}/dashboard/user_group/{{ $route }}" method="post" enctype="multipart/form-data">
                                <div class="form-body">
                                    <h4 class="form-section"><i class="la la-eye"></i> User Group Details</h4>
                                @csrf
                                    <input type="hidden" name="id" value="{{ $data->id }}">

                                    <div class="form-group">
                                    <p>User Group Name</p>
                                    <input type="text" class="form-control border-primary" name="user_group_name" placeholder="Enter User Group Name" value="{{ $data->user_group_name }}" required />
                                </div>
                                <div class="form-group">
                                    <p>User Group Description</p>
                                    <textarea class="form-control border-primary" name="user_group_desc">{{ $data->user_group_desc }}</textarea>
                                </div>
                                <div class="form-actions right">
                                    <button type="button" class="btn btn-danger mr-1">
                                        <i class="ft-x"></i> Cancel
                                    </button>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="la la-check-square-o"></i> Save
                                    </button>
                                </div>
                                </div>
                            </form>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>
 */ ?>
@endsection