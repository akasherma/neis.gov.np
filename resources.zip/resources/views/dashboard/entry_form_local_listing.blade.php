@extends('dashboard_layouts.user_dashboard_layout')
@section('content')
    <section id="horizontal-form-layouts">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="horz-layout-colored-controls">Entry Form</h4>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <?php

                    $permalink = $url;
                    ?>
                    <div class="card-content collpase show">
                        <div class="card-body row">
                            <div class="col-md-12 form-body-listing ">
                                <ul>
                                    <li>
                                        <h4>
                                            <a class="btn btn-md btn-outline-primary" href="{{ $permalink.'/direct' }}">{{ $this_district->location_name }} Entry
                                                <span style="display: block; font-size: 12px;">If no local data</span></a>
                                        </h4>
                                    </li>
                                    @if(!empty($locals))
                                        @foreach($locals as $the_location)
                                            <li>
                                                <h4>
                                                    <a class="btn btn-md btn-outline-primary" href="{{ $permalink.'/local/'.$the_location->location_slug }}">{{ $the_location->location_name }}</a>
                                                </h4>
                                            </li>
                                        @endforeach
                                    @endif
                                </ul>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection