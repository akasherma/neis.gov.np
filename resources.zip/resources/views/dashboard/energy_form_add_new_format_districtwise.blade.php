@extends('dashboard_layouts.user_dashboard_layout')
@section('content')
<section id="horizontal-form-layouts">
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title" id="horz-layout-colored-controls">
                    District Wise Entry Form For {{ $this_energy_type->energy_type_name }}
                    {{--{{ ucfirst($route) }} {{ ucfirst($energy_type) }} Energy for Energy - {{ $this_energy->energy_name }} of fiscal year {{ $start }}/{{ $end }}--}}
                </h4>
                <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                <div class="heading-elements">
                    <ul class="list-inline mb-0">
                        <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                        <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                    </ul>
                </div>
            </div>
            <?php
            $readonly = ($route != 'edit')?'':'readonly';
            $disabled = ($route != 'edit')?'':'disabled';
            ?>
            <div class="card-content collpase show">
                <div class="card-body">
                    <div class="card-text">
                        <p>Please fill all the required inputs</p>
                    </div>

                    <div class="advance-filter">
                        <form action="{{url('/')}}/dashboard/entryform-districtwise/{{ $this_energy_type->energy_type_slug }}/" id="filterform" method="get">
                        <div class="row">

                            @if(!empty($energy_year[0]))
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <p>Year</p>
                                        <select name="year" id="year" class="form-control border-primary" onchange="document.getElementById('filterform').submit();" required>
                                            <option value="">-Select Year-</option>
                                            @foreach($energy_year as $the_year)
                                                <option value="{{ $the_year->energy_year_start }}" {{ ($the_year->energy_year_start == $start)?'selected':'' }}>{{ $the_year->energy_year_start.'/'.$the_year->energy_year_end }}</option>
                                            @endforeach
                                        </select>

                                        <input type="hidden" name="is_central" value="0" />
                                    </div>
                                </div>
                            @endif

                            <?php $is_central_get = (!empty($is_central))?$is_central:0; ?>

                            <div class="col-md-10" id="no_central" <?php echo ($start > 1)?'style="display:block;"':'style="display:none;"'; ?>>
                                <div class="row">

                                    @if(!empty($provinces))
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <p>Province</p>
                                            <select name="province_id" id="province" class="form-control border-primary">
                                                @foreach($provinces as $the_location)
                                                    <option value="{{ $the_location->id }}" {{ ($province_id == $the_location->id)?'selected':'' }}>{{ $the_location->location_name }}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                    @endif

                                </div>

                            </div>
                            <div class="clearfix"></div>
                        </div>
                        </form>
                    </div>

                    @if(!empty($start) && $start != date('Y'))

                        <form action="{{url('/')}}/dashboard/entryform-districtwise/{{ $this_energy_type->energy_type_slug }}" method="post" enctype="multipart/form-data">
                            @csrf
                            <input type="hidden" name="formdata[from_date]" value="{{ $start }}">
                            <input type="hidden" name="formdata[to_date]" value="{{ $end }}">
                            <input type="hidden" name="formdata[province_id]" value="{{ $province_id }}">


                            <div class="table-responsive table-static-col">

                                <table class="table table-bordered">
                                    <tr>
                                        <th class="headcol">District</th>

                                        @if(!empty($energy_listing))
                                            @foreach($energy_listing as $the_energy)
                                                <th class="long" colspan="2">{{$the_energy->energy_name}}</th>
                                            @endforeach
                                         @endif
                                    </tr>
                                    <tr>
                                        <th class="headcol">&nbsp;</th>

                                        @if(!empty($energy_listing))
                                            @foreach($energy_listing as $the_energy)
                                                <th>Natural Qty</th>
                                                <th>Natural Unit</th>
                                            @endforeach
                                        @endif

                                    </tr>
                                    @if(!empty($districts))
                                        @foreach($districts as $the_location)
                                            <tr>
                                                <th class="headcol">{{ $the_location->location_name }}</th>

                                                <?php
                                                $count = 0;
                                                ?>

                                                @if(!empty($energy_listing))
                                                    @foreach($energy_listing as $the_energy)

                                                        <?php
                                                        $this_natural_qty = (!empty($data[$the_location->id][$the_energy->id]['natural_qty']))?$data[$the_location->id][$the_energy->id]['natural_qty']:'';
                                                        $this_natural_unit = (!empty($data[$the_location->id][$the_energy->id]['natural_unit']))?$data[$the_location->id][$the_energy->id]['natural_unit']:'';
                                                        ?>

                                                        <td class="long long-qty long-qty-{{$count}}" title="{{$count}}">
                                                            <input type="text" class="form-control districtwise_natural_qty" name="districtwise[{{$the_location->id}}][{{$the_energy->id}}][natural_qty]" value="{{ $this_natural_qty }}">
                                                        </td>
                                                        <td class="long long-unit long-unit-{{$count}}" title="{{$count++}}">
                                                            <select name="districtwise[{{$the_location->id}}][{{$the_energy->id}}][natural_unit]" class="form-control districtwise_natural_unit">
                                                                @if($units)
                                                                    @foreach($units as $the_unit)
                                                                        <option value="{{ $the_unit->unit_slug }}" {{ ($the_unit->unit_slug == $this_natural_unit)?'selected="selected"':'' }}>{{ $the_unit->unit_name }}</option>
                                                                    @endforeach
                                                                @endif
                                                            </select>
                                                        </td>
                                                    @endforeach
                                                @endif
                                            </tr>
                                        @endforeach
                                    @endif
                                    <tr>
                                        <th class="headcol">Overall</th>

                                        @if(!empty($energy_listing))
                                            <?php
                                            $count = 0;
                                            ?>
                                            @foreach($energy_listing as $the_energy)
                                                <?php
                                                $this_natural_qty = (!empty($data_overall[$the_energy->id]['natural_qty']))?$data_overall[$the_energy->id]['natural_qty']:'';
                                                $this_natural_unit = (!empty($data_overall[$the_energy->id]['natural_unit']))?$data_overall[$the_energy->id]['natural_unit']:'';
                                                ?>
                                                <td class="long">
                                                    <input type="text" id="overall_natural_qty_{{$count}}" class="natural_qty form-control" name="overall[{{$the_energy->id}}][natural_qty]" value="{{$this_natural_qty}}">
                                                </td>
                                                <td class="long long-unit-{{$count}}" title="{{$count++}}">
                                                    <select name="overall[{{$the_energy->id}}][natural_unit]" class="form-control districtwise_natural_unit">
                                                        @if($units)
                                                            @foreach($units as $the_unit)
                                                                <option value="{{ $the_unit->unit_slug }}" {{ ($the_unit->unit_slug == $this_natural_unit)?'selected="selected"':'' }}>{{ $the_unit->unit_name }}</option>
                                                            @endforeach
                                                        @endif
                                                    </select>
                                                </td>
                                            @endforeach
                                        @endif
                                    </tr>
                                </table>
                            </div>

                            @if($units)
                                @foreach($units as $the_unit)
                                    <input type="hidden" name="scientific_unit_conversion_standard[{{ $the_unit->unit_slug }}]" value="{{ $the_unit->scientific_qty }}" title="{{ $the_unit->unit_slug }}">
                                @endforeach
                            @endif

                            <div class="col-md-12">
                                <div class="form-actions right">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="la la-check-square-o"></i>
                                        <?php
                                        if(!empty($user_level->user_group_slug) && $user_level->user_group_slug == 'data-entry'){
                                            echo 'Save For Entry';
                                        }elseif(!empty($user_level->user_group_slug) && $user_level->user_group_slug == 'supervisor'){
                                            echo 'Validate & Publish';
                                        }else{
                                            echo 'Save';
                                        }
                                        ?>

                                    </button>
                                </div>
                            </div>

                        </form>
                        {{--http://localhost/wecs/public_html/dashboard/entryform/import/store--}}

                    @endif

                </div>


            </div>
        </div>
    </div>
</div>
</section>

@endsection