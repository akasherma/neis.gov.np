@extends('dashboard_layouts.datatables_list')
@section('content')
    <div class="app-content content">
        <div class="content-wrapper">
            <div class="content-body"><!-- Zero configuration table -->
                <section id="configuration">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">Fuel Type List <a href="{{url('/')}}/dashboard/fuel-type/add" class="btn btn-primary btn-xs">Add</a></h4>
                                    <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                                    {{--<div class="heading-elements">--}}
                                    {{--<ul class="list-inline mb-0">--}}
                                    {{--<li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>--}}
                                    {{--<li><a data-action="expand"><i class="ft-maximize"></i></a></li>--}}
                                    {{--</ul>--}}
                                    {{--</div>--}}
                                </div>
                                <div class="card-content collapse show">
                                    <div class="table-responsive card-body card-dashboard">
                                        <table class="table table-striped table-bordered zero-configuration">
                                            <thead>
                                            <tr>
                                                <th>S.No.</th>
                                                <th>Fuel Type Name</th>
                                                <th>Description</th>
                                                <th>Parent Fuel Type</th>
                                                <th>Last Fuel Type Status</th>
                                                <th >Action</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $count = 1; ?>
                                            @if(!is_null($data))
                                                @foreach($data as $the_result)
                                                    <tr>
                                                        <td>{{$count++}}</td>
                                                        <td>{{ $the_result->fuel_type_name }}</td>
                                                        <td>{{ $the_result->fuel_type_desc }}</td>
                                                        <td>{{ $the_result->fuel_type_parent }}</td>
                                                        <td>{{ ($the_result->is_last_child != 'Y')?'No':'Yes' }}</td>
                                                        <td><a href="{{url('/')}}/dashboard/fuel-type/update/{{$the_result->id}}" class="btn btn-primary btn-xs mb-1">Edit</a>
                                                            <a href="{{url('/')}}/dashboard/fuel-type/delete/{{$the_result->id}}" class="btn btn-danger btn-xs mb-1">Delete</a>
                                                        </td>
                                                    </tr>
                                                @endforeach
                                            @endif
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!--/ Zero configuration table -->
            </div>
        </div>
    </div>
@endsection