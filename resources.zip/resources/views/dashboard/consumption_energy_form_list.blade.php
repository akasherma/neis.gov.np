@extends('dashboard_layouts.datatables_list')
@section('content')
    <div class="app-content content">
        <div class="content-wrapper">
            <div class="content-body"><!-- Zero configuration table -->
                <section id="configuration">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">Consumption Energy List </h4>
                                    <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                                    {{--<div class="heading-elements">--}}
                                        {{--<ul class="list-inline mb-0">--}}
                                            {{--<li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>--}}
                                            {{--<li><a data-action="expand"><i class="ft-maximize"></i></a></li>--}}
                                        {{--</ul>--}}
                                    {{--</div>--}}
                                    {{--energy_id', 'central_id', 'province_id', 'district_id', 'local_gov_id', 'from_date', 'to_date--}}
                                </div>
                                <div class="card-content collapse show">
                                    <div class="table-responsive card-body card-dashboard">
                                        <table class="table table-striped table-bordered zero-configuration">
                                            <thead>
                                            <tr>
                                                <th>S.No.</th>
                                                <th>Energy</th>
                                                <th>Province</th>
                                                <th>District</th>
                                                <th>Local Govt</th>
                                                <th>From Date</th>
                                                <th>To Date</th>
                                                <th >Action</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $count = 1; ?>
                                            @if(!is_null($data))
                                                @foreach($data as $the_result)
                                                    <tr>
                                                        <td>{{$count++}}</td>

                                                        <td>{{ $the_result->energy_name }}</td>
                                                        <td>{{ $the_result->province }}</td>
                                                        <td>{{ $the_result->district }}</td>
                                                        <td>{{ $the_result->local_gov }}</td>
                                                        <td>{{ $the_result->from_date }}</td>
                                                        <td>{{ $the_result->to_date }}</td>
                                                        <td>
                                                            @if(empty($the_result->published_by))
                                                                @if($route == 'approve')
                                                                    <a href="{{url('/')}}/dashboard/consumption-energy-form/approve/{{$the_result->id}}" class="btn btn-primary btn-xs mb-1">Approve</a>
                                                                @elseif($route == 'check')
                                                                    <a href="{{url('/')}}/dashboard/consumption-energy-form/check/{{$the_result->id}}" class="btn btn-primary btn-xs mb-1">Check</a>
                                                                @else
                                                                    <a href="{{url('/')}}/dashboard/consumption-energy-form/edit/{{$the_result->id}}" class="btn btn-primary btn-xs mb-1">Edit</a>
                                                                @endif
                                                            @else
                                                                <a href="{{url('/')}}/dashboard/consumption-energy-form/view/{{$the_result->id}}" class="btn btn-primary btn-xs mb-1">View</a>
                                                            @endif
                                                                {{--<a href="{{url('/')}}/dashboard/consumption-energy-form/edit/{{$the_result->id}}" class="btn btn-primary btn-xs mb-1">Edit</a>--}}
                                                        </td>
                                                    </tr>
                                                @endforeach
                                            @endif
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!--/ Zero configuration table -->
            </div>
        </div>
    </div>
@endsection