@extends('dashboard_layouts.datatables_list')
@section('content')
    <div class="app-content content">
        <div class="content-wrapper">
            <div class="content-body"><!-- Zero configuration table -->
                <section id="configuration">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">Energy Types List <a href="{{url('/')}}/dashboard/energy_type/add" class="btn btn-primary btn-xs">Add</a></h4>
                                    <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                                    {{--<div class="heading-elements">--}}
                                        {{--<ul class="list-inline mb-0">--}}
                                            {{--<li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>--}}
                                            {{--<li><a data-action="expand"><i class="ft-maximize"></i></a></li>--}}
                                        {{--</ul>--}}
                                    {{--</div>--}}
                                </div>
                                <div class="card-content collapse show">
                                    <div class="table-responsive card-body card-dashboard">
                                        <table class="table table-striped table-bordered zero-configuration">
                                            <thead>
                                            <tr>
                                                <th>S.No.</th>
                                                <th>Energy Type Name</th>
                                                <th>Energy Type Slug</th>
                                                <th>Energy Type Description</th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $count = 1; ?>
                                            @if(!is_null($data))
                                                @foreach($data as $the_result)
                                                    <tr>
                                                        <td>{{$count++}}</td>
                                                        <td>{{ $the_result->energy_type_name }}</td>
                                                        <td>{{ $the_result->energy_type_slug }}</td>
                                                        <td>{{ substr($the_result->energy_type_desc, 0, 80) }}</td>
                                                        <td>{{ (!empty($the_result->status))?'Yes':'No' }}</td>
                                                        <td>
                                                            <a href="{{url('/')}}/dashboard/energy_type/{{$the_result->energy_type_slug}}" class="btn btn-primary btn-xs mb-1">Energy Bind With</a>
                                                            <a href="{{url('/')}}/dashboard/energy_type/update/{{$the_result->id}}" class="btn btn-primary btn-xs mb-1">Edit</a>
                                                            <a href="{{url('/')}}/dashboard/energy_type/{{$the_result->energy_type_slug}}/energylisting/" class="btn btn-primary btn-xs mb-1">Energy Listing</a>
                                                        </td>
                                                    </tr>
                                                @endforeach
                                            @endif
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!--/ Zero configuration table -->
            </div>
        </div>
    </div>
@endsection