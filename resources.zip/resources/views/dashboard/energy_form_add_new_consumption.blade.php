@extends('dashboard_layouts.user_dashboard_layout')
@section('content')
<section id="horizontal-form-layouts">
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title" id="horz-layout-colored-controls">
                    Entry Form For {{ $this_energy_type->energy_type_name }}
                    {{--{{ ucfirst($route) }} {{ ucfirst($energy_type) }} Energy for Energy - {{ $this_energy->energy_name }} of fiscal year {{ $start }}/{{ $end }}--}}
                </h4>
                <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                <div class="heading-elements">
                    <ul class="list-inline mb-0">
                        <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                        <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                    </ul>
                </div>
            </div>
            <?php
            $readonly = ($route != 'edit')?'':'readonly';
            $disabled = ($route != 'edit')?'':'disabled';
            ?>
            <div class="card-content collpase show">
                <div class="card-body">
                    <div class="card-text">
                        <p>Please fill all the required inputs</p>
                    </div>

                    <div class="advance-filter">
                        <form action="{{url('/')}}/dashboard/entryform/{{ $this_energy_type->energy_type_slug }}/" id="filterform" method="get">
                        <div class="row">

                            @if(!empty($energy_year[0]))
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <p>Year</p>
                                        <select name="year" id="year" class="form-control border-primary" onchange="document.getElementById('filterform').submit();" required>
                                            <option value="">-Select Year-</option>
                                            @foreach($energy_year as $the_year)
                                                <option value="{{ $the_year->energy_year_start }}" {{ ($the_year->energy_year_start == $start)?'selected':'' }}>{{ $the_year->energy_year_start.'/'.$the_year->energy_year_end }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                            @endif

                                @if(!empty($provinces))
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <p>Province</p>
                                        <select name="province_id" id="province" class="form-control border-primary">
                                            <option value="">-Select-</option>
                                            @foreach($provinces as $the_location)
                                                <option value="{{ $the_location->id }}" {{ ($province_id == $the_location->id)?'selected':'' }}>{{ $the_location->location_name }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                @endif

                                @if(!empty($districts))
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <p>District</p>
                                        <select name="district_id" id="district" class="form-control border-primary">
                                            <option value="">---</option>
                                            @foreach($districts as $the_location)
                                                <?php
                                                if($the_location->parent_id == $province_id || $province_id == ''){
                                                ?>
                                                    <option value="{{ $the_location->id }}" {{ ($district_id == $the_location->id)?'selected':'' }} class="parent_{{ $the_location->parent_id }}">{{ $the_location->location_name }}</option>
                                                <?php
                                                }
                                                ?>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                @endif

                                @if(!empty($local_governments))
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <p>Municipality</p>
                                        <select name="local_gov_id" id="local_gov_id" class="form-control border-primary">
                                            <option value="">---</option>
                                            @foreach($local_governments as $the_location)
                                                <option value="{{ $the_location->id }}" {{ ($local_gov_id == $the_location->id)?'selected':'' }} class="parent_{{ $the_location->parent_id }}">{{ $the_location->location_name }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    <input type="hidden" name="status" value="Y" />
                                </div>
                                @endif

                                <div class="col-md-2">
                                    <div class="form-group">
                                        <p>&nbsp;</p>
                                        <button class="form-control bg bg-warning" style="width: auto;">Go</button>
                                    </div>
                                </div>
                            <div class="clearfix"></div>
                        </div>
                        </form>
                    </div>

                    @if(!empty($start) && $start != date('Y'))

                    <form action="{{url('/')}}/dashboard/entryform/{{ $this_energy_type->energy_type_slug }}/{{ $route }}" method="post" enctype="multipart/form-data">
                        @csrf
                        <input type="hidden" name="formdata[from_date]" value="{{ $start }}">
                        <input type="hidden" name="formdata[to_date]" value="{{ $end }}">
                        <input type="hidden" name="formdata[province_id]" value="{{ $province_id }}">
                        <input type="hidden" name="formdata[district_id]" value="{{ $district_id }}">
                        <input type="hidden" name="formdata[local_gov_id]" value="{{ $local_gov_id }}">
                        <div class="form-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <h4 class="form-section"><i class="la la-eye"></i> Entry Form For {{ $this_energy_type->energy_type_name }}</h4>
                                </div>

                                <input type="hidden" name="formdata[energy_id]" value="{{ (!empty($this_energy))?$this_energy->id:null }}">

                                <input type="hidden" name="formdata[central_id]" value="{{ (!empty($central->id))?$central->id:null }}">

                                <input type="hidden" name="formdata[province_id]" value="{{ (!empty($this_province->id))?$this_province->id:null }}">

                                <input type="hidden" name="formdata[district_id]" value="{{ (!empty($this_district->id))?$this_district->id:null }}">

                                <input type="hidden" name="formdata[local_gov_id]" value="{{ (!empty($this_local->id))?$this_local->id:null }}">



                                @if(!empty($energy_listing))
                                    <div class="col-md-12">
                                        <div class="row energy_listing">
                                            <div class="col-md-3">
                                                <ul class="nav nav-tabs" id="myTab" role="tablist">
                                                    <?php
                                                    $active = 'active';
                                                    ?>
                                                    @foreach($energy_listing as $the_energy)
                                                        <li class="nav-item">
                                                            <a class="nav-link {{ $active }}" id="{{$the_energy->energy_slug}}-tab" data-toggle="tab" href="#{{ strtolower($the_energy->energy_slug) }}" role="tab" aria-controls="{{ strtolower($the_energy->energy_name) }}" aria-selected="true">{{$the_energy->energy_name}}</a>
                                                        </li>
                                                        <?php $active = ''; ?>
                                                    @endforeach
                                                </ul>
                                            </div>
                                            <div class="col-md-9">
                                                <div class="tab-content" id="myTabContent">
                                                    <?php
                                                    $active = 'show active';
                                                    ?>
                                                    @foreach($energy_listing as $the_energy)
                                                        <div class="tab-pane fade {{ $active }}" id="{{ $the_energy->energy_slug }}" role="tabpanel" aria-labelledby="{{ strtolower($the_energy->energy_slug) }}-tab">
                                                            <h4>{{ $the_energy->energy_name }}</h4>
                                                            <div class="col-md-12">
                                                                <div class="panel-group" id="accordion">

                                                                    <?php if($this_energy_type->energy_type_slug == 'consumption'): ?>
                                                                    <div class="panel panel-default">
                                                                        <div class="panel-heading">
                                                                            <h4 class="panel-title">
                                                                                <a data-toggle="collapse" data-parent="#accordion" href="#collapse3">Sectors</a>
                                                                            </h4>
                                                                        </div>
                                                                        <div id="collapse3" class="panel-collapse collapse in show">
                                                                            <div class="panel-body">
                                                                                <div class="row">
                                                                                    <div class="col-md-12">
                                                                                        <table class="table">
                                                                                            <tr>
                                                                                                <th>Name</th>
                                                                                                <th>Natural Qty</th>
                                                                                                <th>Natural Unit &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                                                                                                <th>Scientific Qty</th>
                                                                                                <th>Scientific Unit</th>
                                                                                            </tr>
                                                                                            @if($sectors)
                                                                                                @foreach($sectors as $the_sector)
                                                                                                    <tr>
                                                                                                        <td>
                                                                                                            <input type="hidden" name="sector[id][]" value="{{ $the_sector->id }}">
                                                                                                            <input type="text" class="form-control border-primary" value="{{ $the_sector->sector_name }}" readonly>
                                                                                                        </td>
                                                                                                        <td>
                                                                                                            <input type="number" step="any" name="sector[natural_qty][]" class="natural_qty form-control border-primary" value="{{ (!empty($the_sector->natural_qty)?$the_sector->natural_qty:'') }}">
                                                                                                        </td>
                                                                                                        <td>
                                                                                                            <select name="sector[natural_unit][]" id="" class="natural_unit form-control">
                                                                                                                @if($units)
                                                                                                                    @foreach($units as $the_unit)
                                                                                                                        <option value="{{ $the_unit->unit_slug }}" {{ ($the_unit->unit_slug == $the_sector->natural_unit)?'selected':'' }}>{{ $the_unit->unit_name }}</option>
                                                                                                                    @endforeach
                                                                                                                @endif
                                                                                                            </select>
                                                                                                        </td>
                                                                                                        @if($units)
                                                                                                            @foreach($units as $the_unit)
                                                                                                                <input type="hidden" class="scientific_unit_conversion" value="{{ $the_unit->scientific_qty }}" title="{{ $the_unit->unit_slug }}">
                                                                                                            @endforeach
                                                                                                        @endif
                                                                                                        <td>
                                                                                                            <input type="text" name="sector[scientific_qty][]" class="scientific_qty form-control border-primary" value="{{ (!empty($the_sector->scientific_qty)?$the_sector->scientific_qty:'') }}" readonly>
                                                                                                        </td>
                                                                                                        <td>
                                                                                                            <input type="text" name="sector[scientific_unit][]" class="form-control border-primary" value="GJ" readonly>
                                                                                                        </td>
                                                                                                    </tr>
                                                                                                @endforeach
                                                                                            @endif
                                                                                        </table>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <?php endif;?>

                                                                    <div class="panel panel-default">
                                                                        <div class="panel-heading">
                                                                            <h4 class="panel-title">
                                                                                <a data-toggle="collapse" data-parent="#accordion" href="#collapse4">Overall</a>
                                                                            </h4>
                                                                        </div>
                                                                        <div id="collapse4" class="panel-collapse collapse in show">
                                                                            <div class="panel-body">
                                                                                <div class="row">
                                                                                    <div class="col-md-12">
                                                                                        <table class="table">
                                                                                            <tr>
                                                                                                <th>Name</th>
                                                                                                <th>Natural Qty</th>
                                                                                                <th>Natural Unit &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                                                                                                <th>Scientific Qty</th>
                                                                                                <th>Scientific Unit</th>
                                                                                            </tr>
                                                                                            <tr>
                                                                                                <td>
                                                                                                    <input type="hidden" name="overall[id]" value="0">
                                                                                                    <input type="text" class="form-control border-primary" value="Overall" readonly>
                                                                                                </td>
                                                                                                <td>
                                                                                                    <input type="number" min="1" step="any" name="overall[natural_qty]" class="natural_qty form-control border-primary" value="{{ (!empty($overall->natural_qty)?$overall->natural_qty:'') }}">
                                                                                                </td>
                                                                                                <td>
                                                                                                    <select name="overall[natural_unit]" id="" class="natural_unit form-control">
                                                                                                        @if($units)
                                                                                                            @foreach($units as $the_unit)
                                                                                                                <option value="{{ $the_unit->unit_slug }}" {{ ($the_unit->unit_slug == $overall->natural_unit)?'selected':'' }}>{{ $the_unit->unit_name }}</option>
                                                                                                            @endforeach
                                                                                                        @endif
                                                                                                    </select>
                                                                                                </td>
                                                                                                @if($units)
                                                                                                    @foreach($units as $the_unit)
                                                                                                        <input type="hidden" class="scientific_unit_conversion" value="{{ $the_unit->scientific_qty }}" title="{{ $the_unit->unit_slug }}">
                                                                                                    @endforeach
                                                                                                @endif
                                                                                                <td>
                                                                                                    <input type="text" name="overall[scientific_qty]" class="scientific_qty form-control border-primary" value="{{ (!empty($overall->scientific_qty)?$overall->scientific_qty:'') }}" readonly>
                                                                                                </td>
                                                                                                <td>
                                                                                                    <input type="text" name="overall[scientific_unit]" class="form-control border-primary" value="GJ" readonly>
                                                                                                </td>
                                                                                            </tr>
                                                                                        </table>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <?php $active = ''; ?>
                                                    @endforeach
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @endif

                                @if($units)
                                    @foreach($units as $the_unit)
                                        <input type="hidden" class="scientific_unit_conversion_standard" value="{{ $the_unit->scientific_qty }}" title="{{ $the_unit->unit_slug }}">
                                    @endforeach
                                @endif

                                <div class="col-md-12">
                                    <div class="form-actions right">
                                        <button type="submit" class="btn btn-primary">
                                            <i class="la la-check-square-o"></i>
                                            <?php
                                            if(!empty($user_level->user_group_slug) && $user_level->user_group_slug == 'data-entry'){
                                                echo 'Save For Entry';
                                            }elseif(!empty($user_level->user_group_slug) && $user_level->user_group_slug == 'supervisor'){
                                                echo 'Validate & Publish';
                                            }else{
                                                echo 'Save';
                                            }
                                            ?>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>

                    @endif

                </div>


            </div>
        </div>
    </div>
</div>
</section>
@endsection