@extends('dashboard_layouts.user_dashboard_layout')
@section('content')
    <section id="horizontal-form-layouts">

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="horz-layout-colored-controls">{{ ucfirst($route) }} Location Type <a href="{{url('/')}}/dashboard/location-type" class="btn btn-primary btn-xs">[ Back ]</a></h4>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="card-content collpase show">
                        <div class="card-body">
                            <div class="card-text">
                                <p>Please fill all the required inputs</p>
                            </div>
                            <form action="{{url('/')}}/dashboard/location-type/{{ $route }}" method="post" enctype="multipart/form-data">
                                <div class="form-body">
                                    <h4 class="form-section"><i class="la la-eye"></i> Location Type Details</h4>
                                    @csrf
                                    <input type="hidden" name="formdata[id]" value="{{ $data->id }}">
                                    <div class="form-group">
                                        <p>Location Type Name</p>
                                        <input type="text" class="form-control border-primary" name="formdata[location_type_name]" value="{{ $data->location_type_name }}" placeholder="Enter Location Type Name" required />
                                    </div>
                                    <div class="form-group">
                                        <p>Location Type Description</p>
                                        <input type="text" class="form-control border-primary" name="formdata[location_type_desc]" value="{{ $data->location_type_desc }}" placeholder="Enter Location Type Description" />
                                    </div>

                                    <div class="form-group">
                                        <p>Choose Single Child Location Type</p>
                                        <select name="formdata[child_id]" class="form-control" id="type-change" >
                                            <option value="" selected disabled>-Select-</option>
                                            @if($child_location_type)
                                                @foreach($child_location_type as $the_location_type)
                                                    <option value="{{$the_location_type->id}}" {{($data->child_id == $the_location_type->id)?'selected': ''}}>{{$the_location_type->location_type_name}}</option>
                                                @endforeach
                                            @endif
                                        </select>
                                    </div>
                                    <input type="hidden" name="status" value="Y" />
                                    <div class="form-actions right">
                                        <button type="button" class="btn btn-danger mr-1">
                                            <i class="ft-x"></i> Cancel
                                        </button>
                                        <button type="submit" class="btn btn-primary">
                                            <i class="la la-check-square-o"></i> Save
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection