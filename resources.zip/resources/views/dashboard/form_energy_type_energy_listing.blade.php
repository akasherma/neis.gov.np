@extends('dashboard_layouts.user_dashboard_layout')
@section('content')
    <section id="horizontal-form-layouts">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="horz-layout-colored-controls">{{ $this_energy_type->energy_type_name }} Energy Type For Energy Topic Field Policy</h4>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="card-content collpase show">
                        <div class="card-body row">
                            @if(!empty($energy_lists))
                                @foreach($energy_lists as $energy_list)
                                    <div class="col-md-3 form-body-listing ">
                                        <div class="btn btn-sm btn-outline-danger round">
                                            <h4>
                                                <a class="" href="{{ url('/').'/entry-form/'.$this_energy_type->energy_type_slug.'/energy/'.$energy_list->energy_slug }}">{{ $energy_list->energy_name }}</a>
                                            </h4>
                                            <p><?php echo str_replace('_', ' ', str_replace(',', '<br>', ucwords($energy_list->field_topics))); ?></p>
                                        </div>
                                    </div>
                                @endforeach

                                @endif
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection