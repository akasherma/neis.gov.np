@extends('dashboard_layouts.user_dashboard_layout')
@section('content')
    <section id="horizontal-form-layouts" class="province_listing">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="horz-layout-colored-controls">Entry Form</h4>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <?php
                    $permalink = $url;
                    ?>
                    <div class="card-content collpase show">
                        <div class="card-body row">
                            <div class="col-md-12 form-body-listing ">
                                <ul>
                                    <li>
                                        <h4>
                                            <a class="btn btn-md btn-outline-primary" href="{{ $permalink.'/direct' }}">Central Entry
                                                <span style="display: block; font-size: 0.75rem;">If no provincewise data</span>
                                            </a>
                                        </h4>
                                    </li>
                                    @if(!empty($provinces))
                                        @foreach($provinces as $province)
                                            <li>
                                                <h4>
                                                    <a class="btn btn-md btn-outline-primary" href="{{ $permalink.'/province/'.$province->location_slug }}">{{ $province->location_name }}</a>
                                                </h4>
                                            </li>
                                        @endforeach
                                    @endif
                                </ul>                                    &nbsp;
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection