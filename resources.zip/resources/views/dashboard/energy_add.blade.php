@extends('dashboard_layouts.user_dashboard_layout')
@section('content')
    <section id="horizontal-form-layouts">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="horz-layout-colored-controls">{{ ucfirst($route) }} Energy <a href="{{url('/')}}/dashboard/energy" class="btn btn-primary btn-xs">[ Back ]</a></h4>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="card-content collpase show">
                        <div class="card-body">
                            <div class="card-text">
                                <p>Please fill all the required inputs</p>
                            </div>
                            <form action="{{url('/')}}/dashboard/energy/{{ $route }}" method="post" enctype="multipart/form-data">
                                <div class="form-body">
                                    <h4 class="form-section"><i class="la la-eye"></i> Energy Details</h4>
                                    @csrf
                                    <input type="hidden" name="formdata[id]" value="{{ $data->id }}">

                                    {{----}}
                                    {{--$objEnergy->energy_name = '';
        $objEnergy->energy_slug = '';
        $objEnergy->energy_desc = '';
        $objEnergy->energy_type_id = '';
        $objEnergy->fuel_type_id = '';--}}

                                    <div class="form-group">
                                        <p>Energy</p>
                                        <input type="text" class="form-control border-primary" name="formdata[energy_name]" value="{{ $data->energy_name }}" required />
                                    </div>
                                    <div class="form-group">
                                        <p>Energy Description</p>
                                        <textarea class="form-control border-primary" name="formdata[energy_desc]">{{ $data->energy_desc }}</textarea>
                                    </div>
                                    <div class="form-group">
                                        <p>Fuel Type</p>
                                        <select name="formdata[fuel_type_id]"  class="form-control border-primary">
                                            @if($fuel_type)
                                                @foreach($fuel_type as $the_fuel_type)
                                                    <option value="{{ $the_fuel_type->id }}" {{ ($data->fuel_type_id == $the_fuel_type->id)?'selected':'' }}>{{ $the_fuel_type->fuel_type_name }}</option>
                                                @endforeach
                                            @endif
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <p>Status</p>
                                        <select name="formdata[status]"  class="form-control border-primary">
                                            <option value="N" {{ ($data->status == "N")?'selected':'' }}>No</option>
                                            <option value="Y" {{ ($data->status == "Y")?'selected':'' }}>Yes</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <p>Economic Survey Status</p>
                                        <select name="formdata[economic_survey_status]"  class="form-control border-primary">
                                            <option value="N" {{ ($data->economic_survey_status == "N")?'selected':'' }}>No</option>
                                            <option value="Y" {{ ($data->economic_survey_status == "Y")?'selected':'' }}>Yes</option>
                                        </select>
                                    </div>
                                    <input type="hidden" name="status" value="Y" />
                                    <div class="form-actions right">
                                        <button type="button" class="btn btn-danger mr-1">
                                            <i class="ft-x"></i> Cancel
                                        </button>
                                        <button type="submit" class="btn btn-primary">
                                            <i class="la la-check-square-o"></i> Save
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection