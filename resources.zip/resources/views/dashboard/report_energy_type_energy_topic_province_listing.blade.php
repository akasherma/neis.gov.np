@extends('dashboard_layouts.user_dashboard_layout')
@section('content')
    <section id="horizontal-form-layouts">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="horz-layout-colored-controls">{{ $this_energy_type->energy_type_name }} Energy Type For Energy Topic Field Policy</h4>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <?php
                    $permalink = $url;
//                    $permalink = url('/').'/dashboard/entry-form';
//                    $permalink .= (!empty($this_province))?'/province/'.$this_province->location_slug:'';
//                    $permalink .= (!empty($this_district))?'/district/'.$this_district->location_slug:'';
//                    $permalink .= (!empty($this_local))?'/local/'.$this_local->location_slug:'';
//                    $permalink .= (!empty($start) && !empty($end))?'/fiscal-year/'.$start.'/'.$end:'';
                    ?>
                    <div class="card-content collpase show">
                        <div class="card-body row">
                            <div class="col-md-3 form-body-listing ">
                                <div class="btn btn-sm btn-outline-primary round">
                                    <h4>
                                        <a class="" href="{{ $permalink.'/direct' }}">Central Entry</a>
                                        <a class="" href="{{ $permalink.'/direct' }}"><span style="display: block; font-size: 12px;">If no provincewise data</span></a>
                                    </h4>
                                </div>
                                <br>
                                &nbsp;
                            </div>
                            @if(!empty($provinces))
                                @foreach($provinces as $province)
                                    <div class="col-md-3 form-body-listing ">
                                        <div class="btn btn-sm btn-outline-primary round">
                                            <h4>
                                                <a class="" href="{{ $permalink.'/province/'.$province->location_slug }}">{{ $province->location_name }}</a>
                                            </h4>
                                            <p>{{ $province->location_desc }}</p>
                                        </div>
                                        <br>
                                        &nbsp;
                                    </div>
                                @endforeach
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection