@extends('dashboard_layouts.main_dashboard_layout')
@section('content')
<section id="horizontal-form-layouts">
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">

                <?php
                $province_name_final = (!empty($province_name->location_name))?$province_name->location_name:'';
                $district_name_final = (!empty($district_name->location_name))?$district_name->location_name:'';

                $province_name_final = ($district_name_final != '')?'':$province_name_final;
                ?>

                <h4 class="card-title" id="horz-layout-colored-controls">
                    Report For {{ $this_energy_type->energy_type_name }} in {{ $province_name_final }}{{ ($district_name_final != '')?' '.$district_name_final.' district':'' }}
                </h4>

                <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                <div class="heading-elements">
                    <ul class="list-inline mb-0">
                        <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                        <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                    </ul>
                </div>
            </div>
            <?php
            $readonly = 'readonly';
            $disabled = 'disabled';
            ?>
            <div class="card-content collpase show">
                <div class="card-body">
                    <div class="card-text">
                        <p>Please fill all the required inputs</p>
                    </div>

                    <div class="advance-filter">
                        <form action="{{url('/')}}/dashboard/reportnew/{{ $this_energy_type->energy_type_slug }}/" id="filterform" method="get">
                        <div class="row">

                            @if(!empty($energy_year[0]))
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <p>Year</p>
                                        <select name="year" id="year" class="form-control border-primary" onchange="document.getElementById('filterform').submit();" required>
                                            <option value="">-Select Year-</option>
                                            @foreach($energy_year as $the_year)
                                                <option value="{{ $the_year->energy_year_start }}" {{ ($the_year->energy_year_start == $start)?'selected':'' }}>{{ $the_year->energy_year_start.'/'.$the_year->energy_year_end }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                            @endif

                            @if(!empty($provinces))
                            <div class="col-md-2">
                                <div class="form-group">
                                    <p>Province</p>
                                    <select name="province_id" id="province" class="form-control border-primary" required>
                                        <option value="">-Select-</option>
                                        @foreach($provinces as $the_location)
                                            <option value="{{ $the_location->id }}" {{ ($province_id == $the_location->id)?'selected':'' }}>{{ $the_location->location_name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            @endif

                            @if(!empty($districts))
                            {{--<div class="col-md-2">--}}
                                {{--<div class="form-group">--}}
                                    {{--<p>District</p>--}}
                                    {{--<select name="district_id" id="district" class="form-control border-primary">--}}
                                        {{--<option value="">---</option>--}}
                                        {{--@foreach($districts as $the_location)--}}
                                            {{--<?php--}}
                                            {{--if($the_location->parent_id == $province_id || $province_id == ''){--}}
                                            {{--?>--}}
                                                {{--<option value="{{ $the_location->id }}" {{ ($district_id == $the_location->id)?'selected':'' }} class="parent_{{ $the_location->parent_id }}">{{ $the_location->location_name }}</option>--}}
                                            {{--<?php--}}
                                            {{--}--}}
                                            {{--?>--}}
                                        {{--@endforeach--}}
                                    {{--</select>--}}
                                {{--</div>--}}
                            {{--</div>--}}
                            @endif

                            @if(!empty($local_governments))
                            {{--<div class="col-md-2">--}}
                                {{--<div class="form-group">--}}
                                    {{--<p>Municipality</p>--}}
                                    {{--<select name="local_gov_id" id="local_gov_id" class="form-control border-primary">--}}
                                        {{--<option value="">---</option>--}}
                                        {{--@foreach($local_governments as $the_location)--}}
                                            {{--<option value="{{ $the_location->id }}" {{ ($local_gov_id == $the_location->id)?'selected':'' }} class="parent_{{ $the_location->parent_id }}">{{ $the_location->location_name }}</option>--}}
                                        {{--@endforeach--}}
                                    {{--</select>--}}
                                {{--</div>--}}
                                {{--<input type="hidden" name="status" value="Y" />--}}
                            {{--</div>--}}
                            @endif
                            <div class="col-md-2">
                                <div class="form-group">
                                    <p>Output</p>
                                    {{--<select name="output" id="output" class="form-control border-primary">--}}
                                        {{--<option value="overall">Total Energy {{ $this_energy_type->energy_type_name }} Share By Fuel Types [ Pie-Chart ]</option>--}}
                                        {{--<option value="fueltype">Energy {{ $this_energy_type->energy_type_name }} By Fuel Types [ Bar Diagram ]</option>--}}
                                        {{--<option value="districtwise">Energy {{ $this_energy_type->energy_type_name }} In Districts By Fuel Types [ Bar Diagram ]</option>--}}

                                        {{--<option value="overall_sectorwise">Total Energy {{ $this_energy_type->energy_type_name }} Share By Sectors [ Pie-Chart ]</option>--}}
                                        {{--<option value="sectorwise">Energy {{ $this_energy_type->energy_type_name }} By Sectors [ Bar Diagram ]</option>--}}

                                    {{--</select>--}}

                                    <select name="output" id="output" class="form-control border-primary">
                                        <option value="overall" {{ (!empty($output) && $output == 'overall')?'selected="selected"':'' }}>Total Energy {{ $this_energy_type->energy_type_name }} Share By Fuel Types [ Pie-Chart ]</option>
                                        <option value="fueltype" {{ (!empty($output) && $output == 'fueltype')?'selected="selected"':'' }}>Energy {{ $this_energy_type->energy_type_name }} By Fuel Types [ Bar Diagram ]</option>
                                        <option value="districtwise" {{ (!empty($output) && $output == 'districtwise')?'selected="selected"':'' }}>Energy {{ $this_energy_type->energy_type_name }} In Districts By Fuel Types [ Bar Diagram ]</option>

                                        <option value="overall_sectorwise" {{ (!empty($output) && $output == 'overall_sectorwise')?'selected="selected"':'' }}>Total Energy {{ $this_energy_type->energy_type_name }} Share By Sectors [ Pie-Chart ]</option>
                                        <option value="sectorwise" {{ (!empty($output) && $output == 'sectorwise')?'selected="selected"':'' }}>Energy {{ $this_energy_type->energy_type_name }} By Sectors [ Bar Diagram ]</option>
                                    </select>
                                </div>
                                <input type="hidden" name="status" value="Y" />
                            </div>

                            <div class="col-md-2">
                                <div class="form-group">
                                    <p>&nbsp;</p>
                                    <button class="form-control bg bg-warning" style="width: auto;">Go</button>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                        </form>
                    </div>

                    @if(!empty($start) && $start != date('Y') && $province_id != '')

                        <section id="horizontal-form-layouts">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card">
                                        <div class="card-header">

                                            <h4 class="card-title" id="this_title" style="display: none;">Energy {{ $this_energy_type->energy_type_name }} in {{ $province_name_final }}{{ ($district_name_final != '')?' '.$district_name_final.' district':'' }} By Sectors ({{ $start }})</h4>

                                            {{--<h4 class="card-title" id="this_title">Energy {{ ucwords(str_replace("_", " ", $energy_type_slug)) }}--}}
                                                {{--For  {{ ucwords(str_replace("_", " ", 'Total Energy')) }} of Fiscal Year [{{ $start }}/{{ $end }}]</h4>--}}
                                            <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                                            <div class="heading-elements">
                                                <ul class="list-inline mb-0">
                                                    <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                                    <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="card-content collpase show">
                                            <div class="card-body row">
                                                <div class="col-md-12 form-body-listing">

                                                    <div style=" border: 2px solid #333; padding: 30px 30px 60px; ">
                                                        <div id="container" style="height:500px;"></div>
                                                        <span id="total"></span>
                                                    </div>
                                                    <p>In PJ</p>
                                                    <div class="table-responsive">
                                                        <table class="table table-striped table-bordered">
                                                            <?php
                                                            $col = array();
                                                            $col_total_init = 0;
                                                            ?>
                                                            <tr>
                                                                <th colspan="2">Fuel Type</th>
                                                                <?php
                                                                if(!empty($col_send)){
                                                                    foreach($col_send as $the_col){
                                                                        echo '<th><input type="hidden" class="x-axis" value="'.$the_col.'">'.$the_col.'</th>';
                                                                        $col[$col_total_init] = 0;
                                                                        $col_total_init++;
                                                                    }
                                                                    $col[$col_total_init] = 0;
                                                                }
                                                                ?>
                                                                <th>
                                                                    {{--<input type="hidden" class="x-axis" value="Total2">--}}
                                                                    Grand Total
                                                                </th>
                                                            </tr>
                                                                <?php
                                                                $count = 1;
                                                                $row_class= '';
                                                                $row_key= '';
                                                                $counter = 0;
                                                                $color_arr = array('table-primary', 'table-success', 'table-info', 'table-warning');
                                                                if(!empty($final_result)){
                                                                foreach($final_result as $key=>$value){

                                                                $this_key = (!empty($key))?explode('-', $key):array();

                                                                $this_first_key = (is_array($this_key) && (!empty($this_key[0])))?$this_key[0]:'';

                                                                $total = 0;
                                                                $col_count = 0;

                                                                $counter += ($this_first_key != $row_key)?1:0;

                                                                $counter = ($counter < count($color_arr))?$counter:0;

                                                                $row_class = $color_arr[$counter];

                                                                ?>

                                                                <tr class="top_row {{ $row_class }}" title="Key: {{ $row_key }} & Counter: {{ $counter }}">
                                                                    <th>
                                                                        {{ ($this_first_key != $row_key)?$this_first_key:'' }}
                                                                        <?php $row_key = ($this_first_key != $row_key)?$this_first_key:$row_key;
                                                                        $second_term = ((!empty($this_key[1])))?ucwords(str_replace('_', ' ', $this_key[1])):'';
                                                                        ?>
                                                                    </th>
                                                                    <td>
                                                                        {{ $second_term }}
                                                                        <?php
                                                                        echo '<input type="hidden" id="row'.$count.'" value="'.$second_term.'">';
                                                                        ?>
                                                                    </td>
                                                                    <?php
                                                                    if(!empty($value[0])){
                                                                        foreach($value as $the_value){

                                                                            if(empty($col[$col_count])){
                                                                                $col[$col_count] = 0;
                                                                            }

//                                                                $col[$col_count] = (!empty($col[$col_count]))?(((float)$col[$col_count])/1000):0;
                                                                            $this_no = (((float)$the_value));
//                                                                echo '<td><input type="hidden" class=" row'.$count.'" value="'.$this_no.'">'.(round($this_no,2)).'</td>';
                                                                            echo '<td><input type="hidden" class=" row'.$count.'" value="'.$this_no.'">'.(round($this_no,2)).'</td>';
                                                                            $total += abs($this_no);

                                                                            $col[$col_count] += abs($this_no);
                                                                            $col_count++;
                                                                        }
                                                                    }

                                                                    //                                                        $col[$col_count] = (!empty($col[$col_count]))?(((float)$col[$col_count])/1000):0;

                                                                    $col[$col_count] += $total;
                                                                    //                                                        $col_count++;
                                                                    ?>
                                                                    <td>
                                                                        <?php

                                                                        //                                                        echo '<pre>';
                                                                        //                                                        print_r($col);

                                                                        ?>
                                                                        {{ round($total, 2) }}</td>
                                                                </tr>

                                                                <?php
                                                                $count++;
                                                                }
                                                                ?>

                                                                <tr class="top_row table-active">
                                                                    <td colspan="2">
                                                                        Grand Total
                                                                        <?php
                                                                        echo '<input type="hidden" id="row'.$count.'" value="">';
                                                                        ?>
                                                                    </td>
                                                                    <?php
                                                                    $col_total = 0;
                                                                    if(!empty($col) && is_array($col)){
                                                                        foreach($col as $the_value){
                                                                            $this_no = ((float)$the_value) * 1000;
//                                                            echo '<td><input type="hidden" class=" row'.$count.'" value="'.$this_no.'">'.(round($this_no,2)).'</td>';;
                                                                            echo '<td>'.(round($this_no,2)).'</td>';
                                                                            $col_total += (float)$the_value;
                                                                        }
                                                                    }
                                                                    $count++;
                                                                    ?>
                                                                    {{--<td>{{ $col_total }}</td>--}}
                                                                </tr>
                                                                <?php
                                                                }
                                                                ?>

                                                        </table>
                                                    </div>

                                                    <script>

                                                        function getRandomInt(max) {
                                                            return Math.floor(Math.random() * Math.floor(max));
                                                        }

                                                        var this_title = document.getElementById("this_title").innerHTML;



                                                        var categories_arr = new Array();

                                                        var findit = document.getElementsByClassName('x-axis');
                                                        for(var i = 0; i < findit.length; i++){
                                                            var this_key = findit[i].value;
                                                            categories_arr.push(this_key);
                                                        }

                                                        var series_data = [];

                                                        var top_row = document.getElementsByClassName('top_row');

                                                        for(var j=0;j<top_row.length;j++){
                                                            var k = j+1;
                                                            var row = 'row'+k;

                                                            console.log(row);

                                                            var row_arr = new Array();
                                                            var find_row = document.getElementsByClassName(row);

                                                            for (var i = 0; i < find_row.length; i++) {
                                                                var this_key = find_row[i].value;
                                                                row_arr.push(parseInt(this_key));
                                                            }
                                                            var find_id_row_value = document.getElementById(row).value;
                                                            var obj_row = {name: find_id_row_value, data: row_arr};
                                                            series_data.push(obj_row);

                                                        }

                                                        Highcharts.chart('container', {
                                                            chart: {
                                                                type: 'column'
                                                            },
                                                            title: {
                                                                text: this_title
                                                            },
                                                            subtitle: {
                                                                text: ''
                                                            },
                                                            xAxis: {
                                                                categories: categories_arr,
                                                                crosshair: true
                                                            },
                                                            yAxis: {
                                                                min: 0,
                                                                title: {
                                                                    text: 'Energy Unit (In PJ)'
                                                                }
                                                            },
                                                            tooltip: {
                                                                headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                                                                pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                                                                    '<td style="padding:0"><b>{point.y:.2f} PJ</b></td></tr>',
                                                                footerFormat: '</table>',
                                                                shared: true,
                                                                useHTML: true
                                                            },
                                                            plotOptions: {
                                                                column: {
                                                                    pointPadding: 0.2,
                                                                    borderWidth: 0
                                                                }
                                                            },
                                                            series: series_data
                                                        });
                                                    </script>
                                                </div>
                                            </div>


                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>

                    @endif

                </div>


            </div>
        </div>
    </div>
</div>
</section>
@endsection