@extends('dashboard_layouts.main_dashboard_layout')

@section('content')

<h2 class="text text-warning card-title text-bold-700 my-2">Welcome To Admin Dashboard !!!</h2>

<hr>

<div class="row match-height">
    <div class="col-xl-12 col-lg-12">
        <h5 class="card-title text-bold-700 my-2">Log Details</h5>
        <div class="card">
            <div class="card-content">
                <div class="card-body">
                    <div class="col-12 timeline-left" id="activity">
                        <div class="timeline pt-2">
                            <?php
                                $arr_color = array(
                                    'danger', 'primary', 'dark', 'warning', 'info', 'success'
                                );
                                $counter = 0;
                            ?>
                            @if(!empty($data))
                            <ul class="list-unstyled base-timeline activity-timeline">
                                @foreach($data as $the_data)
                                    <?php
                                        $counter = (!empty($arr_color[$counter]))?$counter:0;
                                    ?>
                                <li class="">
                                    <div class="timeline-icon bg-{{ $arr_color[$counter] }}">
                                        <i class="ft-map-pin font-medium-1"></i>
                                    </div>
                                    <div class="act-time" title="[ {{ date('F d, Y',strtotime($the_data->created_at)) }} ]">
                                        [ <?php
                                        $created_at = $the_data->created_at;

                                        $date = new DateTime($created_at);
                                        $now = new DateTime();

                                        $day = $date->diff($now)->format("%d");
                                        if($day == 0)
                                            echo 'Today';
                                        elseif ($day < 2)
                                            echo 'Yesterday';
                                        else
                                            echo $day.' days ago';

                                        ?> ]
                                        <br>
                                        <?php
                                            $name = explode(' ', $the_data->name);
                                            ?>
                                        [ By {{ (!empty($name[0]))?$name[0]:'' }} ]

                                    </div>
                                    <div class="base-timeline-info">
                                        <p><a href="#" class="text-$arr_color[$counter]">{{ $the_data->menu_name }}</a></p>
                                        <?php
                                        $data = @unserialize($the_data->log_details);
                                        if ($data !== false) {
                                            $log_details = unserialize($the_data->log_details);
                                            if(is_array($log_details)){
                                                foreach($log_details as $the_log){
                                                    echo '<p>'.$the_log.'</p>';
                                                }
                                            }
                                        }
                                        ?>
                                    </div>
                                    <small class="text-muted">
                                    </small>
                                </li>
                                    <?php $counter++; ?>
                                @endforeach
                            </ul>
                                @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
@endsection