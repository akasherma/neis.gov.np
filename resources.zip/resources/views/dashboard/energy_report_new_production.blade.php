@extends('dashboard_layouts.main_dashboard_layout')
@section('content')
<section id="horizontal-form-layouts">
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">

                <?php
                $province_name_final = (!empty($province_name->location_name))?$province_name->location_name:'';
                $district_name_final = (!empty($district_name->location_name))?$district_name->location_name:'';

                $province_name_final = ($district_name_final != '')?'':$province_name_final;
                ?>

                <h4 class="card-title" id="horz-layout-colored-controls">
                    Report For {{ $this_energy_type->energy_type_name }} in {{ $province_name_final }}{{ ($district_name_final != '')?' '.$district_name_final.' district':'' }}
                </h4>

                <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                <div class="heading-elements">
                    <ul class="list-inline mb-0">
                        <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                        <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                    </ul>
                </div>
            </div>
            <?php
            $readonly = 'readonly';
            $disabled = 'disabled';
            ?>
            <div class="card-content collpase show">
                <div class="card-body">
                    <div class="card-text">
                        <p>Please fill all the required inputs</p>
                    </div>

                    <div class="advance-filter">
                        <form action="{{url('/')}}/dashboard/reportnew/{{ $this_energy_type->energy_type_slug }}/" id="filterform" method="get">
                        <div class="row">

                            @if(!empty($energy_year[0]))
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <p>Year</p>
                                        <select name="year" id="year" class="form-control border-primary" onchange="document.getElementById('filterform').submit();" required>
                                            <option value="">-Select Year-</option>
                                            @foreach($energy_year as $the_year)
                                                <option value="{{ $the_year->energy_year_start }}" {{ ($the_year->energy_year_start == $start)?'selected':'' }}>{{ $the_year->energy_year_start.'/'.$the_year->energy_year_end }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                            @endif

                            @if(!empty($provinces))
                            <div class="col-md-2">
                                <div class="form-group">
                                    <p>Province</p>
                                    <select name="province_id" id="province" class="form-control border-primary" required>
                                        <option value="">-Select-</option>
                                        @foreach($provinces as $the_location)
                                            <option value="{{ $the_location->id }}" {{ ($province_id == $the_location->id)?'selected':'' }}>{{ $the_location->location_name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            @endif

                            @if(!empty($districts))
                            <div class="col-md-2">
                                <div class="form-group">
                                    <p>District</p>
                                    <select name="district_id" id="district" class="form-control border-primary">
                                        <option value="">---</option>
                                        @foreach($districts as $the_location)
                                            <?php
                                            if($the_location->parent_id == $province_id || $province_id == ''){
                                            ?>
                                                <option value="{{ $the_location->id }}" {{ ($district_id == $the_location->id)?'selected':'' }} class="parent_{{ $the_location->parent_id }}">{{ $the_location->location_name }}</option>
                                            <?php
                                            }
                                            ?>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            @endif

                            @if(!empty($local_governments))
                            <div class="col-md-2">
                                <div class="form-group">
                                    <p>Municipality</p>
                                    <select name="local_gov_id" id="local_gov_id" class="form-control border-primary">
                                        <option value="">---</option>
                                        @foreach($local_governments as $the_location)
                                            <option value="{{ $the_location->id }}" {{ ($local_gov_id == $the_location->id)?'selected':'' }} class="parent_{{ $the_location->parent_id }}">{{ $the_location->location_name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <input type="hidden" name="status" value="Y" />
                            </div>
                            @endif
                            <div class="col-md-2">
                                <div class="form-group">
                                    <p>Output</p>
                                    <select name="output" id="output" class="form-control border-primary">
                                        <option value="overall">Total Energy {{ $this_energy_type->energy_type_name }} Share By Fuel Types [ Pie-Chart ]</option>
                                        <option value="fueltype">Energy {{ $this_energy_type->energy_type_name }} By Fuel Types [ Bar Diagram ]</option>
                                        <option value="districtwise">Energy {{ $this_energy_type->energy_type_name }} In Districts By Fuel Types [ Bar Diagram ]</option>

                                    </select>
                                </div>
                                <input type="hidden" name="status" value="Y" />
                            </div>

                            <div class="col-md-2">
                                <div class="form-group">
                                    <p>&nbsp;</p>
                                    <button class="form-control bg bg-warning" style="width: auto;">Go</button>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                        </form>
                    </div>

                    @if(!empty($start) && $start != date('Y') && $province_id != '')

                        {{--http://localhost/wecs/public_html/dashboard/entryform/import/store--}}

                        <section id="horizontal-form-layouts">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="card">
                                        <div class="card-header">
                                            <h4 class="card-title" id="this_title">Total Energy {{ $this_energy_type->energy_type_name }} Total Energy of Fiscal Year [{{ $start }}/{{ $end }}]</h4>
                                            <input type="hidden" id="this_name" value="{{ ucwords(str_replace("_", " ", $energy_topic)) }}">
                                            <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                                            <div class="heading-elements">
                                                <ul class="list-inline mb-0">
                                                    <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                                    <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                                                </ul>
                                            </div>
                                        </div>
                                        <?php
                                        $permalink = $url;
                                        ?>
                                        <div class="card-content collpase show">
                                            <div class="card-body row">
                                                <div class="col-md-12 form-body-listing">

                                                    <div style=" border: 2px solid #333; padding: 30px 30px 60px; ">
                                                        <div id="container" style="height:500px;"></div>
                                                        <span id="total"></span>
                                                    </div>

                                                    <div class="table-responsive">
                                                        <table border="1" cellspacing="3" cellpadding="3">
                                                            <tr>
                                                                <th>Total Energy</th>
                                                                <th>Energy Unit (In Kilo GJ)</th>
                                                            </tr>

                                                            <?php
                                                            $count = 1;
                                                            $col = array();
                                                            if(!empty($final_result)){
                                                            $total = 0;
                                                            $col_count = 0;
                                                            foreach($final_result as $key=>$value){
                                                            ?>

                                                            <tr class="top_row">
                                                                <th>
                                                                    {{ ucwords(str_replace('_', ' ', $key)) }}
                                                                    <?php
                                                                    $col[$col_count] = (!empty($col[$col_count]))?((float)$col[$col_count]):0;
                                                                    echo '<input type="hidden" id="row'.$count.'" value="'.$key.'-'.(((float)$value->qty)/1000).'">';
                                                                    ?>
                                                                </th>
                                                                <?php
                                                                echo '<td><input type="hidden" class=" row'.$count.'" value="'.(((float)$value->qty)/1000).'">'.(((float)$value->qty)/1000).'</td>';
                                                                $total += (((float)$value->qty)/1000);
                                                                $col[$col_count] += (((float)$value->qty)/1000);
                                                                $col_count++;


                                                                $count++;
                                                                ?>
                                                            </tr>


                                                            <?php
                                                            }
                                                            ?>

                                                            <tr class="">
                                                                <th>
                                                                    Total
                                                                    <?php
                                                                    echo '<input type="hidden" id="row'.$count.'" value="Total">';
                                                                    ?>
                                                                </th>
                                                                <td>{{ $total }}</td>
                                                            </tr>
                                                            <?php
                                                            }
                                                            ?>
                                                        </table>
                                                    </div>

                                                    <script>

                                                        function getRandomInt(max) {
                                                            return Math.floor(Math.random() * Math.floor(max));
                                                        }

                                                        var this_title = document.getElementById("this_title").innerHTML;

                                                        var this_name = document.getElementById("this_name").value;

                                                        // var categories_arr = new Array();

                                                        // var findit = document.getElementsByClassName('x-axis');
                                                        // for(var i = 0; i < findit.length; i++){
                                                        //     var this_key = findit[i].value;
                                                        //     categories_arr.push(this_key);
                                                        // }

                                                        var series_data = [];

                                                        var top_row = document.getElementsByClassName('top_row');

                                                        for(var j=0;j<top_row.length;j++){
                                                            var k = j+1;
                                                            var row = 'row'+k;

                                                            // console.log(row);

                                                            var y_value = 0;
                                                            var find_row = document.getElementsByClassName(row);

                                                            var y_value = find_row[0].value;

                                                            // for (var i = 0; i < find_row.length; i++) {
                                                            //     var this_key = find_row[i].value;
                                                            //     row_arr.push(parseInt(this_key));
                                                            // }
                                                            var find_id_row_value = document.getElementById(row).value;

                                                            // console.log(row);

                                                            // {
                                                            //     name: 'Chrome',
                                                            //         y: 61.41,
                                                            //     sliced: true,
                                                            //     selected: true
                                                            // }

                                                            if(k < 2)
                                                                var obj_row = {name: find_id_row_value, y: parseFloat(y_value), sliced: true, selected: true};
                                                            else
                                                                var obj_row = {name: find_id_row_value, y: parseFloat(y_value)};

                                                            series_data.push(obj_row);

                                                        }

                                                        // console.log(series_data);

                                                        // return false;

                                                        // var series_data = [obj_row1, obj_row2, obj_row3, obj_row4, obj_row5, obj_row6];

                                                        Highcharts.chart('container', {
                                                            chart: {
                                                                plotBackgroundColor: null,
                                                                plotBorderWidth: null,
                                                                plotShadow: false,
                                                                type: 'pie'
                                                            },
                                                            title: {
                                                                text: this_title
                                                            },
                                                            tooltip: {
                                                                pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
                                                            },
                                                            plotOptions: {
                                                                pie: {
                                                                    allowPointSelect: true,
                                                                    cursor: 'pointer',
                                                                    dataLabels: {
                                                                        enabled: true,
                                                                        format: '<b>{point.name}</b>: {point.percentage:.1f} %'
                                                                    }
                                                                }
                                                            },
                                                            series: [{
                                                                name: this_name,
                                                                colorByPoint: true,
                                                                data: series_data
                                                            }]
                                                        });
                                                    </script>
                                                </div>
                                            </div>


                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>

                    @endif

                </div>


            </div>
        </div>
    </div>
</div>
</section>
@endsection