@extends('dashboard_layouts.user_dashboard_layout')
@section('content')
    <section id="horizontal-form-layouts">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="horz-layout-colored-controls">{{ ucfirst($route) }} Production Energy "{{ $data->energy_name }}" of fiscal year {{ $data->from_date }} / {{ $data->to_date }}</h4>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <?php
                    $readonly = ($route != 'edit' && $route != 'view')?'':'readonly';
                    $disabled = ($route != 'edit' && $route != 'view')?'':'disabled';
                    $field_readonly = ($route != 'view')?'':'readonly';
                    $field_disabled = ($route != 'view')?'':'disabled';
                    $display = ($route != 'view')?'block':'none';
                    ?>
                    <div class="card-content collpase show">
                        <div class="card-body">
                            <div class="card-text">
                                <p>Please fill all the required inputs</p>
                            </div>
                            <form action="{{url('/')}}/dashboard/entry-form/production/edit" method="post" enctype="multipart/form-data">
                                @csrf
                                <input type="hidden" name="from_date" value="{{ $data->from_date }}">
                                <input type="hidden" name="from_date" value="{{ $data->to_date }}">
                                <input type="hidden" name="route" value="{{ $route }}">
                                <div class="form-body">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <h4 class="form-section"><i class="la la-eye"></i> Production Energy Details for Energy - "{{ $data->energy_name }}"</h4>
                                            <input type="hidden" name="formdata[id]" value="{{ $data->id }}">
                                        </div>

                                        <input type="hidden" name="formdata[energy_id]" value="{{ (!empty($data->energy_id))?$data->energy_id:null }}">

                                        <input type="hidden" name="formdata[central_id]" value="{{ (!empty($central->id))?$central->id:null }}">

                                        @if(!empty($provinces))
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <p>Province</p>
                                                    <select name="formdata[province_id]" id="" class="form-control border-primary" {{$disabled}}>
                                                        <option value="">N/A</option>
                                                        @foreach($provinces as $the_location)
                                                            <option value="{{ $the_location->id }}" {{ ($data->province_id == $the_location->id)?'selected':'' }}>{{ $the_location->location_name }}</option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>
                                        @endif

                                        @if(!empty($districts))
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <p>District</p>
                                                    <select name="formdata[district_id]" id="" class="form-control border-primary" {{$disabled}}>
                                                        <option value="">N/A</option>
                                                        @foreach($districts as $the_location)
                                                            <option value="{{ $the_location->id }}" {{ ($data->district_id == $the_location->id)?'selected':'' }} class="parent_{{ $the_location->parent_id }}">{{ $the_location->location_name }}</option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>
                                        @endif

                                        @if(!empty($local_governments))
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <p>Local Government</p>
                                                    <select name="formdata[local_gov_id]" id="" class="form-control border-primary" {{$disabled}}>
                                                        <option value="">N/A</option>
                                                        @foreach($local_governments as $the_location)
                                                            <option value="{{ $the_location->id }}" {{ ($data->local_gov_id == $the_location->id)?'selected':'' }} class="parent_{{ $the_location->parent_id }}">{{ $the_location->location_name }}</option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                                <input type="hidden" name="status" value="Y" />
                                            </div>
                                        @endif
                                        <div class="clearfix"></div>
                                        @if($units)
                                            <?php
                                            //                                            echo '<pre>';
                                            //                                            print_r(json_decode($units));
                                            //                                            echo '</pre>';
                                            ?>
                                            @foreach($units as $the_unit)
                                                <input type="hidden" class="scientific_unit_conversion_standard" value="{{ $the_unit->scientific_qty }}" title="{{ $the_unit->unit_slug }}">
                                            @endforeach
                                        @endif
                                        <div class="col-md-12">
                                            <div class="panel-group" id="accordion">
                                                <?php if(in_array('land_type', $field_topics)): ?>
                                                <div class="panel panel-default">
                                                    <div class="panel-heading">
                                                        <h4 class="panel-title">
                                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">
                                                                Land Type</a>
                                                        </h4>
                                                    </div>
                                                    <div id="collapse2" class="panel-collapse collapse in show">
                                                        <div class="panel-body">
                                                            <div class="row">
                                                                <div class="col-md-12">
                                                                    <table class="table">
                                                                        <tr>
                                                                            <th>Name</th>
                                                                            <th>Natural Qty</th>
                                                                            <th>Natural Unit &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                                                                            <th>Scientific Qty</th>
                                                                            <th>Scientific Unit</th>
                                                                        </tr>
                                                                        @if($land_types)
                                                                            @foreach($land_types as $the_land_type)
                                                                                <tr>
                                                                                    <td>
                                                                                        <input type="hidden" name="land_type[id][]" value="{{ $the_land_type->id }}">
                                                                                        <input type="text" class="form-control border-primary" value="{{ $the_land_type->land_type_name }}" readonly>
                                                                                    </td>
                                                                                    <td>
                                                                                        <input type="number" step="any" name="land_type[natural_qty][]" class="natural_qty form-control border-primary" value="{{ (!empty($the_land_type->natural_qty)?$the_land_type->natural_qty:'') }}" {{ $field_readonly }}>
                                                                                    </td>
                                                                                    <td>
                                                                                        <select name="land_type[natural_unit][]" id="" class="natural_unit form-control" {{ $field_disabled }}>
                                                                                            @if($units)
                                                                                                @foreach($units as $the_unit)
                                                                                                    <option value="{{ $the_unit->unit_slug }}" {{ ($the_unit->unit_slug == $the_land_type->natural_unit)?'selected':'' }}>{{ $the_unit->unit_name }}</option>
                                                                                                @endforeach
                                                                                            @endif
                                                                                        </select>
                                                                                    </td>
                                                                                    @if($units)
                                                                                        @foreach($units as $the_unit)
                                                                                            <input type="hidden" class="scientific_unit_conversion" value="{{ $the_unit->scientific_qty }}" title="{{ $the_unit->unit_slug }}">
                                                                                        @endforeach
                                                                                    @endif
                                                                                    <td>
                                                                                        <input type="text" name="land_type[scientific_qty][]" class="scientific_qty form-control border-primary" value="{{ (!empty($the_land_type->scientific_qty)?$the_land_type->scientific_qty:'') }}" readonly>
                                                                                    </td>
                                                                                    <td>
                                                                                        <input type="text" name="land_type[scientific_unit][]" class="form-control border-primary" value="GJ" readonly>
                                                                                    </td>
                                                                                </tr>
                                                                            @endforeach
                                                                        @endif
                                                                    </table>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php endif;?>

                                                <?php if(in_array('sector', $field_topics)): ?>
                                                <div class="panel panel-default">
                                                    <div class="panel-heading">
                                                        <h4 class="panel-title">
                                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse3">Sectors</a>
                                                        </h4>
                                                    </div>
                                                    <div id="collapse3" class="panel-collapse collapse in show">
                                                        <div class="panel-body">
                                                            <div class="row">
                                                                <div class="col-md-12">
                                                                    <table class="table">
                                                                        <tr>
                                                                            <th>Name</th>
                                                                            <th>Natural Qty</th>
                                                                            <th>Natural Unit &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                                                                            <th>Scientific Qty</th>
                                                                            <th>Scientific Unit</th>
                                                                        </tr>
                                                                        @if($sectors)
                                                                            @foreach($sectors as $the_sector)
                                                                                <tr>
                                                                                    <td>
                                                                                        <input type="hidden" name="sector[id][]" value="{{ $the_sector->id }}">
                                                                                        <input type="text" class="form-control border-primary" value="{{ $the_sector->sector_name }}" readonly>
                                                                                    </td>
                                                                                    <td>
                                                                                        <input type="number" step="any" name="sector[natural_qty][]" class="natural_qty form-control border-primary" value="{{ (!empty($the_sector->natural_qty)?$the_sector->natural_qty:'') }}" {{ $field_readonly }}>
                                                                                    </td>
                                                                                    <td>
                                                                                        <select name="sector[natural_unit][]" id="" class="natural_unit form-control" {{ $field_disabled }}>
                                                                                            @if($units)
                                                                                                @foreach($units as $the_unit)
                                                                                                    <option value="{{ $the_unit->unit_slug }}" {{ ($the_unit->unit_slug == $the_sector->natural_unit)?'selected':'' }}>{{ $the_unit->unit_name }}</option>
                                                                                                @endforeach
                                                                                            @endif
                                                                                        </select>
                                                                                    </td>
                                                                                    @if($units)
                                                                                        @foreach($units as $the_unit)
                                                                                            <input type="hidden" class="scientific_unit_conversion" value="{{ $the_unit->scientific_qty }}" title="{{ $the_unit->unit_slug }}">
                                                                                        @endforeach
                                                                                    @endif
                                                                                    <td>
                                                                                        <input type="text" name="sector[scientific_qty][]" class="scientific_qty form-control border-primary" value="{{ (!empty($the_sector->scientific_qty)?$the_sector->scientific_qty:'') }}" readonly>
                                                                                    </td>
                                                                                    <td>
                                                                                        <input type="text" name="sector[scientific_unit][]" class="form-control border-primary" value="GJ" readonly>
                                                                                    </td>
                                                                                </tr>
                                                                            @endforeach
                                                                        @endif
                                                                    </table>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <?php endif;?>

                                                <?php if(in_array('river', $field_topics)): ?>
                                                <div class="panel panel-default">
                                                    <div class="panel-heading">
                                                        <h4 class="panel-title">
                                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse4">River</a>
                                                        </h4>
                                                    </div>
                                                    <div id="collapse4" class="panel-collapse collapse in show">
                                                        <div class="panel-body">
                                                            <div class="row">
                                                                <div class="col-md-12">
                                                                    <table class="table">
                                                                        <tr>
                                                                            <th>Name</th>
                                                                            <th>Natural Qty</th>
                                                                            <th>Natural Unit &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                                                                            <th>Scientific Qty</th>
                                                                            <th>Scientific Unit</th>
                                                                        </tr>
                                                                        @if($rivers)
                                                                            @foreach($rivers as $the_energy_type)
                                                                                <tr>
                                                                                    <td>
                                                                                        <input type="hidden" name="river[id][]" value="{{ $the_energy_type->id }}">
                                                                                        <input type="text" class="form-control border-primary" value="{{ $the_energy_type->river_name }}" readonly>
                                                                                    </td>
                                                                                    <td>
                                                                                        <input type="number" step="any" name="river[natural_qty][]" class="natural_qty form-control border-primary" value="{{ (!empty($the_energy_type->natural_qty)?$the_energy_type->natural_qty:'') }}" {{ $field_readonly }}>
                                                                                    </td>
                                                                                    <td>
                                                                                        <select name="river[natural_unit][]" id="" class="natural_unit form-control" {{ $field_disabled }}>
                                                                                            @if($units)
                                                                                                @foreach($units as $the_unit)
                                                                                                    <option value="{{ $the_unit->unit_slug }}" {{ ($the_unit->unit_slug == $the_energy_type->natural_unit)?'selected':'' }}>{{ $the_unit->unit_name }}</option>
                                                                                                @endforeach
                                                                                            @endif
                                                                                        </select>
                                                                                    </td>
                                                                                    @if($units)
                                                                                        @foreach($units as $the_unit)
                                                                                            <input type="hidden" class="scientific_unit_conversion" value="{{ $the_unit->scientific_qty }}" title="{{ $the_unit->unit_slug }}">
                                                                                        @endforeach
                                                                                    @endif
                                                                                    <td>
                                                                                        <input type="text" name="river[scientific_qty][]" class="scientific_qty form-control border-primary" value="{{ (!empty($the_energy_type->scientific_qty)?$the_energy_type->scientific_qty:'') }}" readonly>
                                                                                    </td>
                                                                                    <td>
                                                                                        <input type="text" name="river[scientific_unit][]" class="form-control border-primary" value="GJ" readonly>
                                                                                    </td>
                                                                                </tr>
                                                                            @endforeach
                                                                        @endif
                                                                    </table>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <?php endif;?>

                                                <?php if(in_array('geographic_region', $field_topics)): ?>
                                                <div class="panel panel-default">
                                                    <div class="panel-heading">
                                                        <h4 class="panel-title">
                                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse4">Geographic Region</a>
                                                        </h4>
                                                    </div>
                                                    <div id="collapse4" class="panel-collapse collapse in show">
                                                        <div class="panel-body">
                                                            <div class="row">
                                                                <div class="col-md-12">
                                                                    <table class="table">
                                                                        <tr>
                                                                            <th>Name</th>
                                                                            <th>Natural Qty</th>
                                                                            <th>Natural Unit &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                                                                            <th>Scientific Qty</th>
                                                                            <th>Scientific Unit</th>
                                                                        </tr>
                                                                        @if($geographic_regions)
                                                                            @foreach($geographic_regions as $the_energy_type)
                                                                                <tr>
                                                                                    <td>
                                                                                        <input type="hidden" name="geographic_region[id][]" value="{{ $the_energy_type->id }}">
                                                                                        <input type="text" class="form-control border-primary" value="{{ $the_energy_type->geographic_region_name }}" readonly>
                                                                                    </td>
                                                                                    <td>
                                                                                        <input type="number" step="any" name="geographic_region[natural_qty][]" class="natural_qty form-control border-primary" value="{{ (!empty($the_energy_type->natural_qty)?$the_energy_type->natural_qty:'') }}" {{ $field_readonly }}>
                                                                                    </td>
                                                                                    <td>
                                                                                        <select name="geographic_region[natural_unit][]" id="" class="natural_unit form-control" {{ $field_disabled }}>
                                                                                            @if($units)
                                                                                                @foreach($units as $the_unit)
                                                                                                    <option value="{{ $the_unit->unit_slug }}" {{ ($the_unit->unit_slug == $the_energy_type->natural_unit)?'selected':'' }}>{{ $the_unit->unit_name }}</option>
                                                                                                @endforeach
                                                                                            @endif
                                                                                        </select>
                                                                                    </td>
                                                                                    @if($units)
                                                                                        @foreach($units as $the_unit)
                                                                                            <input type="hidden" class="scientific_unit_conversion" value="{{ $the_unit->scientific_qty }}" title="{{ $the_unit->unit_slug }}">
                                                                                        @endforeach
                                                                                    @endif
                                                                                    <td>
                                                                                        <input type="text" name="geographic_region[scientific_qty][]" class="scientific_qty form-control border-primary" value="{{ (!empty($the_energy_type->scientific_qty)?$the_energy_type->scientific_qty:'') }}" readonly>
                                                                                    </td>
                                                                                    <td>
                                                                                        <input type="text" name="geographic_region[scientific_unit][]" class="form-control border-primary" value="GJ" readonly>
                                                                                    </td>
                                                                                </tr>
                                                                            @endforeach
                                                                        @endif
                                                                    </table>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <?php endif;?>
                                                <div class="panel panel-default">
                                                    <div class="panel-heading">
                                                        <h4 class="panel-title">
                                                            <a data-toggle="collapse" data-parent="#accordion" href="#collapse4">Overall</a>
                                                        </h4>
                                                    </div>
                                                    <div id="collapse4" class="panel-collapse collapse in show">
                                                        <div class="panel-body">
                                                            <div class="row">
                                                                <div class="col-md-12">
                                                                    <table class="table">
                                                                        <tr>
                                                                            <th>Name</th>
                                                                            <th>Natural Qty</th>
                                                                            <th>Natural Unit &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</th>
                                                                            <th>Scientific Qty</th>
                                                                            <th>Scientific Unit</th>
                                                                        </tr>
                                                                        <tr>
                                                                            <td>
                                                                                <input type="hidden" name="overall[id]" value="0">
                                                                                <input type="text" class="form-control border-primary" value="Overall" readonly>
                                                                            </td>
                                                                            <td>
                                                                                <input type="number" step="any" name="overall[natural_qty]" class="natural_qty form-control border-primary" value="{{ (!empty($overall->natural_qty)?$overall->natural_qty:'') }}" {{ $field_readonly }}>
                                                                            </td>
                                                                            <td>
                                                                                <select name="overall[natural_unit]" id="" class="natural_unit form-control" {{ $field_disabled }}>
                                                                                    @if($units)
                                                                                        @foreach($units as $the_unit)
                                                                                            <option value="{{ $the_unit->unit_slug }}" {{ (!empty($overall->natural_unit) && $the_unit->unit_slug == $overall->natural_unit)?'selected':'' }}>{{ $the_unit->unit_name }}</option>
                                                                                        @endforeach
                                                                                    @endif
                                                                                </select>
                                                                            </td>
                                                                            @if($units)
                                                                                @foreach($units as $the_unit)
                                                                                    <input type="hidden" class="scientific_unit_conversion" value="{{ $the_unit->scientific_qty }}" title="{{ $the_unit->unit_slug }}">
                                                                                @endforeach
                                                                            @endif
                                                                            <td>
                                                                                <input type="text" name="overall[scientific_qty]" class="scientific_qty form-control border-primary" value="{{ (!empty($overall->scientific_qty)?$overall->scientific_qty:'') }}" readonly>
                                                                            </td>
                                                                            <td>
                                                                                <input type="text" name="overall[scientific_unit]" class="form-control border-primary" value="GJ" readonly>
                                                                            </td>
                                                                        </tr>
                                                                    </table>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-12" style="display: {{ $display }}">
                                            <div class="form-actions right">
                                                <button type="button" class="btn btn-danger mr-1">
                                                    <i class="ft-x"></i> Cancel
                                                </button>
                                                <button type="submit" class="btn btn-primary">
                                                    <i class="la la-check-square-o"></i> Save
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection