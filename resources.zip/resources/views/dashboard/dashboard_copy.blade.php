@extends('dashboard_layouts.main_dashboard_layout')

@section('content')

<p>Welcome To Admin Dashboard !!!</p>

<?php
for($i = 1; $i <= 12; $i++){
    echo '<input type="text" class="x-axis" value="'.date("M", mktime(0,0,0,$i,3,1975)).'">';
}
?>




<div class="row match-height">
    <div class="col-md-12">
        <div id="container" style="min-width: 310px; max-width: 800px; height: 400px; margin: 0 auto"></div>

        <script>

            var categories_arr = new Array();

            $('.x-axis').each(function(){
                var this_key = $(this).attr("value");
                // var this_arr = new Array();
                // text: 'Alabama', value: 'AL'
                // this_arr['text'] = this_key;
                // this_arr['value'] = this_key.toLowerCase();
                // console.log(this_arr);

                // var this_obj = {text: this_key ,value: this_key.toLowerCase()};

                // console.log(this_obj);

                // destination_place.push(this_arr);

                categories_arr.push(this_key);

            });

            Highcharts.chart('container', {
                chart: {
                    type: 'column'
                },
                title: {
                    text: 'High Chart Data Entry'
                },
                subtitle: {
                    text: ''
                },
                xAxis: {
                    categories: [
                        'Jan',
                        'Feb',
                        'Mar',
                        'Apr',
                        'May',
                        'Jun',
                        'Jul',
                        'Aug',
                        'Sep',
                        'Oct',
                        'Nov',
                        'Dec'
                    ],
                    crosshair: true
                },
                yAxis: {
                    min: 0,
                    title: {
                        text: 'Unit Title (unit)'
                    }
                },
                tooltip: {
                    headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
                    pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                        '<td style="padding:0"><b>{point.y:.1f} mm</b></td></tr>',
                    footerFormat: '</table>',
                    shared: true,
                    useHTML: true
                },
                plotOptions: {
                    column: {
                        pointPadding: 0.2,
                        borderWidth: 0
                    }
                },
                series: [{
                    name: 'Industrial',
                    data: [49.9, 71.5, 106.4, 129.2, 144.0, 176.0, 135.6, 148.5, 216.4, 194.1, 95.6, 54.4]

                }, {
                    name: 'Commercial',
                    data: [83.6, 78.8, 98.5, 93.4, 106.0, 84.5, 105.0, 104.3, 91.2, 83.5, 106.6, 92.3]

                }, {
                    name: 'Agricultural',
                    data: [48.9, 38.8, 39.3, 41.4, 47.0, 48.3, 59.0, 59.6, 52.4, 65.2, 59.3, 51.2]

                }, {
                    name: 'Others',
                    data: [42.4, 33.2, 34.5, 39.7, 52.6, 75.5, 57.4, 60.4, 47.6, 39.1, 46.8, 51.1]

                }]
            });
        </script>
    </div>
    <div class="col-xl-6 col-lg-12">
        <h5 class="card-title text-bold-700 my-2">Log Details</h5>
        <div class="card">
            <div class="card-content">
                <div class="card-body">
                    <div class="col-12 timeline-left" id="activity">
                        <div class="timeline pt-2">
                            <?php
                                $arr_color = array(
                                    'danger', 'primary', 'dark', 'warning', 'info', 'success'
                                );
                                $counter = 0;
                            ?>
                            @if(!empty($data))
                            <ul class="list-unstyled base-timeline activity-timeline">
                                @foreach($data as $the_data)
                                    <?php
                                        $counter = (!empty($arr_color[$counter]))?$counter:0;
                                    ?>
                                <li class="">
                                    <div class="timeline-icon bg-{{ $arr_color[$counter] }}">
                                        <i class="ft-map-pin font-medium-1"></i>
                                    </div>
                                    <div class="act-time" title="[ {{ date('F d, Y',strtotime($the_data->created_at)) }} ]">
                                        [ <?php
                                        $created_at = $the_data->created_at;

                                        $date = new DateTime($created_at);
                                        $now = new DateTime();

                                        $day = $date->diff($now)->format("%d");
                                        if($day == 0)
                                            echo 'Today';
                                        elseif ($day < 2)
                                            echo 'Yesterday';
                                        else
                                            echo $day.' days ago';

                                        ?> ]
                                        <br>
                                        <?php
                                            $name = explode(' ', $the_data->name);
                                            ?>
                                        [ By {{ (!empty($name[0]))?$name[0]:'' }} ]

                                    </div>
                                    <div class="base-timeline-info">
                                        <p><a href="#" class="text-$arr_color[$counter]">{{ $the_data->menu_name }}</a></p>
                                        <?php
                                        $log_details = unserialize($the_data->log_details);
                                        if(is_array($log_details)){
                                            foreach($log_details as $the_log){
                                                echo '<p>'.$the_log.'</p>';
                                            }
                                        }
                                        ?>
                                    </div>
                                    <small class="text-muted">
                                    </small>
                                </li>
                                    <?php $counter++; ?>
                                @endforeach
                            </ul>
                                @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-6 col-lg-12">
        <h5 class="card-title text-bold-700 my-2">Energy Summary</h5>
        <div class="card">
            <div class="card-content">
                <div id="product-summary" class="media-list position-relative">
                    <div class="table-responsive">
                        <table class="table table-padded table-xl mb-0" id="product-summary-table">
                            <thead>
                            <tr>
                                <th class="border-top-0">Product</th>
                                <th class="border-top-0">Brand</th>
                                <th class="border-top-0">Category</th>
                                <th class="border-top-0">Sales</th>
                                <th class="border-top-0">Stock level</th>
                                <th class="border-top-0">Actions</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td class="text-truncate">iPhone X</td>
                                <td class="text-truncate">
                                    <a href="#">Apple</a>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-outline-danger round" type="button">Mobile</button>
                                </td>
                                <td class="text-truncate">
                                        <span>
                                            <i class="ft-arrow-up success"></i> 6.89%</span>
                                </td>
                                <td>
                                    <div class="progress progress-sm mt-1 mb-0 box-shadow-2">
                                        <div class="progress-bar bg-gradient-x-danger" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0"
                                             aria-valuemax="100"></div>
                                    </div>
                                </td>
                                <td class="text-truncat mr-1">
                                    <a href="#">
                                        <i class="ft-shopping-cart blue-grey lighten-2 font-medium-5 ml-1"></i>
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-truncate">iPhone X</td>
                                <td class="text-truncate">
                                    <a href="#">Apple</a>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-outline-danger round" type="button">Mobile</button>
                                </td>
                                <td class="text-truncate">
                                        <span>
                                            <i class="ft-arrow-up success"></i> 6.89%</span>
                                </td>
                                <td>
                                    <div class="progress progress-sm mt-1 mb-0 box-shadow-2">
                                        <div class="progress-bar bg-gradient-x-danger" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0"
                                             aria-valuemax="100"></div>
                                    </div>
                                </td>
                                <td class="text-truncat mr-1">
                                    <a href="#">
                                        <i class="ft-shopping-cart blue-grey lighten-2 font-medium-5 ml-1"></i>
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-truncate">iPhone X</td>
                                <td class="text-truncate">
                                    <a href="#">Apple</a>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-outline-danger round" type="button">Mobile</button>
                                </td>
                                <td class="text-truncate">
                                        <span>
                                            <i class="ft-arrow-up success"></i> 6.89%</span>
                                </td>
                                <td>
                                    <div class="progress progress-sm mt-1 mb-0 box-shadow-2">
                                        <div class="progress-bar bg-gradient-x-danger" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0"
                                             aria-valuemax="100"></div>
                                    </div>
                                </td>
                                <td class="text-truncat mr-1">
                                    <a href="#">
                                        <i class="ft-shopping-cart blue-grey lighten-2 font-medium-5 ml-1"></i>
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-truncate">iPhone X</td>
                                <td class="text-truncate">
                                    <a href="#">Apple</a>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-outline-danger round" type="button">Mobile</button>
                                </td>
                                <td class="text-truncate">
                                        <span>
                                            <i class="ft-arrow-up success"></i> 6.89%</span>
                                </td>
                                <td>
                                    <div class="progress progress-sm mt-1 mb-0 box-shadow-2">
                                        <div class="progress-bar bg-gradient-x-danger" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0"
                                             aria-valuemax="100"></div>
                                    </div>
                                </td>
                                <td class="text-truncat mr-1">
                                    <a href="#">
                                        <i class="ft-shopping-cart blue-grey lighten-2 font-medium-5 ml-1"></i>
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-truncate">iPhone X</td>
                                <td class="text-truncate">
                                    <a href="#">Apple</a>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-outline-danger round" type="button">Mobile</button>
                                </td>
                                <td class="text-truncate">
                                        <span>
                                            <i class="ft-arrow-up success"></i> 6.89%</span>
                                </td>
                                <td>
                                    <div class="progress progress-sm mt-1 mb-0 box-shadow-2">
                                        <div class="progress-bar bg-gradient-x-danger" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0"
                                             aria-valuemax="100"></div>
                                    </div>
                                </td>
                                <td class="text-truncat mr-1">
                                    <a href="#">
                                        <i class="ft-shopping-cart blue-grey lighten-2 font-medium-5 ml-1"></i>
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-truncate">iPhone X</td>
                                <td class="text-truncate">
                                    <a href="#">Apple</a>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-outline-danger round" type="button">Mobile</button>
                                </td>
                                <td class="text-truncate">
                                        <span>
                                            <i class="ft-arrow-up success"></i> 6.89%</span>
                                </td>
                                <td>
                                    <div class="progress progress-sm mt-1 mb-0 box-shadow-2">
                                        <div class="progress-bar bg-gradient-x-danger" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0"
                                             aria-valuemax="100"></div>
                                    </div>
                                </td>
                                <td class="text-truncat mr-1">
                                    <a href="#">
                                        <i class="ft-shopping-cart blue-grey lighten-2 font-medium-5 ml-1"></i>
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-truncate">iPhone X</td>
                                <td class="text-truncate">
                                    <a href="#">Apple</a>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-outline-danger round" type="button">Mobile</button>
                                </td>
                                <td class="text-truncate">
                                        <span>
                                            <i class="ft-arrow-up success"></i> 6.89%</span>
                                </td>
                                <td>
                                    <div class="progress progress-sm mt-1 mb-0 box-shadow-2">
                                        <div class="progress-bar bg-gradient-x-danger" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0"
                                             aria-valuemax="100"></div>
                                    </div>
                                </td>
                                <td class="text-truncat mr-1">
                                    <a href="#">
                                        <i class="ft-shopping-cart blue-grey lighten-2 font-medium-5 ml-1"></i>
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-truncate">iPhone X</td>
                                <td class="text-truncate">
                                    <a href="#">Apple</a>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-outline-danger round" type="button">Mobile</button>
                                </td>
                                <td class="text-truncate">
                                        <span>
                                            <i class="ft-arrow-up success"></i> 6.89%</span>
                                </td>
                                <td>
                                    <div class="progress progress-sm mt-1 mb-0 box-shadow-2">
                                        <div class="progress-bar bg-gradient-x-danger" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0"
                                             aria-valuemax="100"></div>
                                    </div>
                                </td>
                                <td class="text-truncat mr-1">
                                    <a href="#">
                                        <i class="ft-shopping-cart blue-grey lighten-2 font-medium-5 ml-1"></i>
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-truncate">iPhone X</td>
                                <td class="text-truncate">
                                    <a href="#">Apple</a>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-outline-danger round" type="button">Mobile</button>
                                </td>
                                <td class="text-truncate">
                                        <span>
                                            <i class="ft-arrow-up success"></i> 6.89%</span>
                                </td>
                                <td>
                                    <div class="progress progress-sm mt-1 mb-0 box-shadow-2">
                                        <div class="progress-bar bg-gradient-x-danger" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0"
                                             aria-valuemax="100"></div>
                                    </div>
                                </td>
                                <td class="text-truncat mr-1">
                                    <a href="#">
                                        <i class="ft-shopping-cart blue-grey lighten-2 font-medium-5 ml-1"></i>
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-truncate">iPhone X</td>
                                <td class="text-truncate">
                                    <a href="#">Apple</a>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-outline-danger round" type="button">Mobile</button>
                                </td>
                                <td class="text-truncate">
                                        <span>
                                            <i class="ft-arrow-up success"></i> 6.89%</span>
                                </td>
                                <td>
                                    <div class="progress progress-sm mt-1 mb-0 box-shadow-2">
                                        <div class="progress-bar bg-gradient-x-danger" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0"
                                             aria-valuemax="100"></div>
                                    </div>
                                </td>
                                <td class="text-truncat mr-1">
                                    <a href="#">
                                        <i class="ft-shopping-cart blue-grey lighten-2 font-medium-5 ml-1"></i>
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-truncate">iPhone X</td>
                                <td class="text-truncate">
                                    <a href="#">Apple</a>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-outline-danger round" type="button">Mobile</button>
                                </td>
                                <td class="text-truncate">
                                        <span>
                                            <i class="ft-arrow-up success"></i> 6.89%</span>
                                </td>
                                <td>
                                    <div class="progress progress-sm mt-1 mb-0 box-shadow-2">
                                        <div class="progress-bar bg-gradient-x-danger" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0"
                                             aria-valuemax="100"></div>
                                    </div>
                                </td>
                                <td class="text-truncat mr-1">
                                    <a href="#">
                                        <i class="ft-shopping-cart blue-grey lighten-2 font-medium-5 ml-1"></i>
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-truncate">Shoes</td>
                                <td class="text-truncate">
                                    <a href="#">Nike</a>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-outline-warning round" type="button">Fashion</button>
                                </td>
                                <td class="text-truncate">
                                        <span>
                                            <i class="ft-arrow-down danger"></i> 5.15%</span>
                                </td>
                                <td>
                                    <div class="progress progress-sm mt-1 mb-0 box-shadow-2">
                                        <div class="progress-bar bg-gradient-x-success" role="progressbar" style="width: 75%" aria-valuenow="75" aria-valuemin="0"
                                             aria-valuemax="100"></div>
                                    </div>
                                </td>
                                <td class="text-truncat mr-1">
                                    <a href="#">
                                        <i class="ft-shopping-cart blue-grey lighten-2 font-medium-5 ml-1"></i>
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-truncate">OnePlus</td>
                                <td class="text-truncate">
                                    <a href="#">MI</a>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-outline-danger round" type="button">Mobile</button>
                                </td>
                                <td class="text-truncate">
                                        <span>
                                            <i class="ft-arrow-up success"></i> 9.89%</span>
                                </td>
                                <td>
                                    <div class="progress progress-sm mt-1 mb-0 box-shadow-2">
                                        <div class="progress-bar bg-gradient-x-danger" role="progressbar" style="width: 50%" aria-valuenow="50" aria-valuemin="0"
                                             aria-valuemax="100"></div>
                                    </div>
                                </td>
                                <td class="text-truncat mr-1">
                                    <a href="#">
                                        <i class="ft-shopping-cart blue-grey lighten-2 font-medium-5 ml-1"></i>
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td class="text-truncate">Watch</td>
                                <td class="text-truncate">
                                    <a href="#">Rolex</a>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-outline-success round" type="button">Watch</button>
                                </td>
                                <td class="text-truncate">
                                        <span>
                                            <i class="ft-arrow-up success"></i> 15.89%</span>
                                </td>
                                <td>
                                    <div class="progress progress-sm mt-1 mb-0 box-shadow-2">
                                        <div class="progress-bar bg-gradient-x-success" role="progressbar" style="width: 90%" aria-valuenow="90" aria-valuemin="0"
                                             aria-valuemax="100"></div>
                                    </div>
                                </td>
                                <td class="text-truncat mr-1">
                                    <a href="#">
                                        <i class="ft-shopping-cart blue-grey lighten-2 font-medium-5 ml-1"></i>
                                    </a>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection