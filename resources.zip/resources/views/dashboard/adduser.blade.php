@extends('dashboard_layouts.user_dashboard_layout')
@section('content')
    <section id="horizontal-form-layouts">

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="horz-layout-colored-controls">{{ ucfirst($route) }} User</h4>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="card-content collpase show">
                        <div class="card-body">
                            <div class="card-text">
                                <p>Please fill all the required inputs</p>
                            </div>
                            <form action="{{url('/')}}/dashboard/user/{{ $route }}" method="post" enctype="multipart/form-data">
                                @csrf
                                <div class="form-body">
                                    <h4 class="form-section"><i class="la la-eye"></i> User Details</h4>
                                    @csrf
                                    <h5 class="form-section">Personal Information</h5>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <input type="hidden" name="formdata[id]" value="{{ $data->id }}">
                                            <div class="form-group">
                                                <p>Name</p>
                                                <input type="text" class="form-control border-primary" name="formdata[name]" placeholder="Enter Your Name" value="{{ $data->name }}" required />
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <p>Email</p>
                                                <input type="email" class="form-control border-primary" name="formdata[email]" placeholder="Enter Your Email" value="{{ $data->email }}" required />
                                            </div>
                                        </div>
                                        @if($data->password == '')
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <p>Password</p>
                                                <input type="password" class="form-control border-primary" name="formdata[password]" placeholder="Enter Your Password" value="" required />
                                            </div>
                                        </div>
                                        @endif
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <p>Phone No</p>
                                                <input type="text" class="form-control border-primary" name="formdata[phone]" placeholder="Enter Your Phone No" value="{{ $data->phone }}" required />
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <p>Address</p>
                                                <input type="text" class="form-control border-primary" name="formdata[address]" placeholder="Enter Your Address" value="{{ $data->address }}" required />
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <p>Designation</p>
                                                <input type="text" class="form-control border-primary" name="formdata[designation]" placeholder="Enter Your Designation" value="{{ $data->designation }}" required />
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <p>Organization Name</p>
                                                <input type="text" class="form-control border-primary" name="formdata[organization_name]" placeholder="Enter Your organization name" value="{{ $data->organization_name }}" required />
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-12">
                                            <h5 class="form-section">User Privilege</h5>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <p>User Group</p>

                                                <select name="formdata[user_group_id]" id="" class="form-control border-primary">
                                                    @if($user_group)
                                                        @foreach($user_group as $the_user_group)
                                                            <option value="{{ $the_user_group->id }}" {{ ($data->user_group_id == $the_user_group->id)?'selected':'' }}>{{ $the_user_group->user_group_name }}</option>
                                                        @endforeach
                                                    @endif
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="form-group">
                                                <p>Are You from Central Office</p>
                                                <select name="formdata[is_central]" id="" class="form-control border-primary" onchange="changePrivilege(this.value);">
                                                    <option value="0" {{ (!empty($data->is_central) && $data->is_central == '0')?'selected':'' }}>No</option>
                                                    <option value="1" {{ (!empty($data->is_central) && $data->is_central == '1')?'selected':'' }}>Yes</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div id="privilege">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <p>Province</p>
                                                    <select name="formdata[province_id]" id="" class="form-control border-primary">
                                                        <option value="0">Select Province</option>
                                                        @if($provinces)
                                                            @foreach($provinces as $the_location)
                                                                <option value="{{ $the_location->id }}" {{ (!empty($data->province_id) && $data->province_id == $the_location->id)?'selected':'' }}>{{ $the_location->location_name }}</option>
                                                            @endforeach
                                                        @endif
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <p>District</p>
                                                    <select name="formdata[district_id]" id="" class="form-control border-primary">
                                                        <option value="0">Select District</option>
                                                        @if($districts)
                                                            @foreach($districts as $the_location)
                                                                <option value="{{ $the_location->id }}" {{ (!empty($data->district_id) && $data->district_id == $the_location->id)?'selected':'' }}>{{ $the_location->location_name }}</option>
                                                            @endforeach
                                                        @endif
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <p>Local Government</p>
                                                    <select name="formdata[local_govt_id]" id="" class="form-control border-primary">
                                                        <option value="0">Select Local Government</option>
                                                        @if($local_governments)
                                                            @foreach($local_governments as $the_location)
                                                                <option value="{{ $the_location->id }}" {{ (!empty($data->local_govt_id) && $data->local_govt_id == $the_location->id)?'selected':'' }}>{{ $the_location->location_name }}</option>
                                                            @endforeach
                                                        @endif
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-actions right">
                                        <button type="button" class="btn btn-danger mr-1">
                                            <i class="ft-x"></i> Cancel
                                        </button>
                                        <button type="submit" class="btn btn-primary">
                                            <i class="la la-check-square-o"></i> Save
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>
<script>
function changePrivilege(val){
    if(val == '0'){
        document.getElementById('privilege').style.display="block";
    }else{
        document.getElementById('privilege').style.display="none";
    }
}
</script>
@endsection