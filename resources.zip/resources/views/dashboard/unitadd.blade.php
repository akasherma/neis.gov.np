@extends('dashboard_layouts.user_dashboard_layout')
@section('content')
    <section id="horizontal-form-layouts">

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="horz-layout-colored-controls">{{ ucfirst($route) }} Unit  <a href="{{url('/')}}/dashboard/unit" class="btn btn-primary btn-xs">[ Back ]</a></h4>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="card-content collpase show">
                        <div class="card-body">
                            <div class="card-text">
                                <p>Please fill all the required inputs</p>
                            </div>
                            <form action="{{url('/')}}/dashboard/unit/{{ $route }}" method="post" enctype="multipart/form-data">
                                <div class="form-body">
                                    <h4 class="form-section"><i class="la la-eye"></i> Unit Details</h4>
                                    @csrf
                                    <input type="hidden" name="formdata[id]" value="{{ $data->id }}">
                                    <div class="form-group">
                                        <p>Unit Name</p>
                                        <input type="text" class="form-control border-primary" name="formdata[unit_name]" value="{{ $data->unit_name }}" placeholder="Enter Unit Name" required />
                                    </div>
                                    <div class="form-group">
                                        <p>Unit Short Form Name</p>
                                        <input type="text" class="form-control border-primary" name="formdata[unit_short_form]" value="{{ $data->unit_short_form }}" placeholder="Enter Unit Short Form Name" required />
                                    </div>
                                    <div class="form-group">
                                        <p>Unit Description</p>
                                        <input type="text" class="form-control border-primary" name="formdata[unit_desc]" value="{{ $data->unit_desc }}" placeholder="Enter Unit Description" required />
                                    </div>
                                    <input type="hidden" name="status" value="Y" />
                                    <div class="form-actions right">
                                        <button type="button" class="btn btn-danger mr-1">
                                            <i class="ft-x"></i> Cancel
                                        </button>
                                        <button type="submit" class="btn btn-primary">
                                            <i class="la la-check-square-o"></i> Save
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection