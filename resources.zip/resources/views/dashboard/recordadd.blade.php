@extends('dashboard_layouts.user_dashboard_layout')
@section('content')
    <section id="horizontal-form-layouts">

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="horz-layout-colored-controls">{{ ucfirst($route) }} {{ (!empty($menu->menu_name))?$menu->menu_name:'Record' }}  <a href="{{url('/')}}/dashboard/records/{{ $menu->menu_slug }}/" class="btn btn-primary btn-xs">[ Back ]</a></h4>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="card-content collpase show">
                        <div class="card-body">
                            <div class="card-text">
                                <p>Please fill all the required inputs</p>
                            </div>
                            <form action="{{url('/')}}/dashboard/records/{{ $menu->menu_slug }}/{{ $route }}" method="post" enctype="multipart/form-data">
                                <div class="form-body">
                                    <h4 class="form-section"><i class="la la-eye"></i> {{ $menu->menu_name }} Details</h4>
                                    @csrf
                                    <input type="hidden" name="formdata[id]" value="{{ $data->id }}">
                                    <input type="hidden" name="formdata[menu_id]" value="{{ $menu->id }}">
                                    <div class="form-group">
                                        <p>{{ $menu->menu_name }} Name</p>
                                        <input type="text" class="form-control border-primary" name="formdata[record_name]" value="{{ $data->record_name }}" placeholder="Enter Name" required />
                                    </div>

                                    @if($menu->menu_slug == 'hydropower-station')
                                    <div class="form-group">
                                        <p>{{ $menu->menu_name }} Type</p>
                                        <input type="text" class="form-control border-primary" name="formdata[record_type]" value="{{ $data->record_type }}" placeholder="Enter Type" />
                                    </div>
                                    @endif

                                    <div class="form-group">
                                        <p>{{ $menu->menu_name }} Description</p>
                                        <input type="text" class="form-control border-primary" name="formdata[record_desc]" value="{{ $data->record_desc }}" placeholder="Enter Description" required />
                                    </div>
                                    <div class="form-group">
                                        <p>Address</p>
                                        <input type="text" class="form-control border-primary" name="formdata[address]" value="{{ $data->address }}" placeholder="Enter Address" />
                                    </div>
                                    <div class="form-group">
                                        <p>Installed Capacity</p>
                                        <input type="text" class="form-control border-primary" name="formdata[capacity]" value="{{ $data->capacity }}" placeholder="Enter Installed Capacity" />
                                    </div>
                                    <div class="form-group">
                                        <p>Unit</p>
                                        <input type="text" class="form-control border-primary" name="formdata[unit]" value="{{ $data->unit}}" placeholder="Enter Unit" />
                                    </div>
                                    <div class="form-group">
                                        <p>Latitude</p>
                                        <input type="text" class="form-control border-primary" name="formdata[lat]" value="{{ $data->lat}}" placeholder="Enter Latitude" />
                                    </div>
                                    <div class="form-group">
                                        <p>Longitude</p>
                                        <input type="text" class="form-control border-primary" name="formdata[lang]" value="{{ $data->lang}}" placeholder="Enter Longitude" />
                                    </div>
                                    <input type="hidden" name="status" value="Y" />
                                    <div class="form-actions right">
                                        <button type="button" class="btn btn-danger mr-1">
                                            <i class="ft-x"></i> Cancel
                                        </button>
                                        <button type="submit" class="btn btn-primary">
                                            <i class="la la-check-square-o"></i> Save
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection