@extends('dashboard_layouts.user_dashboard_layout')
@section('content')
    <section id="horizontal-form-layouts">

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="horz-layout-colored-controls">{{ ucfirst($route) }} Energy Year <a href="{{url('/')}}/dashboard/energy-year" class="btn btn-primary btn-xs">[ Back ]</a></h4>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="card-content collpase show">
                        <div class="card-body">
                            <div class="card-text">
                                <p>Please fill all the required inputs</p>
                            </div>
                            <form action="{{url('/')}}/dashboard/energy-year/{{ $route }}" method="post" enctype="multipart/form-data">
                                <div class="form-body">
                                    <h4 class="form-section"><i class="la la-eye"></i> Energy Year Details</h4>
                                    @csrf
                                    <input type="hidden" name="formdata[id]" value="{{ $data->id }}">
                                    <input type="hidden" name="formdata[status]" value="Y">
                                    <div class="form-group">
                                        <p>Energy Year Start</p>
                                        <input type="number" class="form-control border-primary" name="formdata[energy_year_start]" value="{{ $data->energy_year_start }}" placeholder="Enter Energy Year Start" required />
                                    </div>
                                    <div class="form-group">
                                        <p>Energy Year End</p>
                                        <input type="number" class="form-control border-primary" name="formdata[energy_year_end]" value="{{ $data->energy_year_end }}" placeholder="Enter Energy Year End" required />
                                    </div>
                                    <div class="form-group">
                                        <p>Is Completed</p>
                                        <select name="formdata[is_completed]" class="form-control" id="type-change" >
                                            <option value="N" {{($data->is_completed == 'N')?'selected': ''}}>No</option>
                                            <option value="Y" {{($data->is_completed == 'Y')?'selected': ''}}>Yes</option>
                                        </select>
                                    </div>

                                    <input type="hidden" name="status" value="Y" />
                                    <div class="form-actions right">
                                        <button type="button" class="btn btn-danger mr-1">
                                            <i class="ft-x"></i> Cancel
                                        </button>
                                        <button type="submit" class="btn btn-primary">
                                            <i class="la la-check-square-o"></i> Save
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection