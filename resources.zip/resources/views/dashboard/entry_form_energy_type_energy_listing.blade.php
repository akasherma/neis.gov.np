@extends('dashboard_layouts.user_dashboard_layout')
@section('content')
    <section id="horizontal-form-layouts">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="horz-layout-colored-controls">{{ $this_energy_type->energy_type_name }} Energy Type For Energy Topic Field Policy</h4>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <?php
                    $permalink = $url;
//                    $permalink = url('/').'/dashboard/entry-form';
//                    $permalink .= (!empty($this_province))?'/province/'.$this_province->location_slug:'';
//                    $permalink .= (!empty($this_district))?'/district/'.$this_district->location_slug:'';
//                    $permalink .= (!empty($this_local))?'/local/'.$this_local->location_slug:'';
//                    $permalink .= (!empty($start) && !empty($end))?'/fiscal-year/'.$start.'/'.$end:'';
                    ?>
                    <div class="card-content collpase show">
                        <div class="card-body row">
                            @if(!empty($energy_lists))
                            <div class="col-md-12 form-body-listing ">
                                <ul>
                                @foreach($energy_lists as $energy_list)
                                <li>
                                    <h4>
                                        @if(!empty($energy_list->form_id) && $energy_list->form_id != '')
                                        <a class="btn btn-lg btn-primary" href="{{ url('/').'/dashboard/'.$this_energy_type->energy_type_slug.'-energy-form/edit/'.$energy_list->form_id }}">
                                            {{ $energy_list->energy_name }}
                                        </a>
                                        @else
                                            <a class="btn btn-lg btn-outline-primary" href="{{ $permalink.'/'.$energy_list->energy_slug }}">
                                                {{ $energy_list->energy_name }}
                                            </a>
                                        @endif
                                    </h4>
                                </li>
                                @endforeach
                                </ul>
                            </div>

                            @endif
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection