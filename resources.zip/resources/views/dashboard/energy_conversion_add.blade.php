@extends('dashboard_layouts.user_dashboard_layout')
@section('content')
    <section id="horizontal-form-layouts">

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title" id="horz-layout-colored-controls">{{ ucfirst($route) }} Energy Conversion <a href="{{url('/')}}/dashboard/energy-conversion" class="btn btn-primary btn-xs">[ Back ]</a></h4>
                        <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                        <div class="heading-elements">
                            <ul class="list-inline mb-0">
                                <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="card-content collpase show">
                        <div class="card-body">
                            <div class="card-text">
                                <p>Please fill all the required inputs</p>
                            </div>
                            <form action="{{url('/')}}/dashboard/energy-conversion/{{ $route }}" method="post" enctype="multipart/form-data">
                                <div class="form-body">
                                    <h4 class="form-section"><i class="la la-eye"></i> Energy Conversion Details</h4>
                                    @csrf
                                    <input type="hidden" name="formdata[id]" value="{{ $data->id }}">

                                    {{----}}
                                    {{--$objEnergyConversion->energy_id = $formdata['energy_id'];--}}
                                    {{--$objEnergyConversion->natural_unit = $formdata['natural_unit'];--}}
                                    {{--$objEnergyConversion->natural_qty = $formdata['natural_qty'];--}}
                                    {{--$objEnergyConversion->scientific_unit = $formdata['scientific_unit'];--}}
                                    {{--$objEnergyConversion->scientific_qty = $formdata['scientific_qty'];--}}

                                    <div class="form-group">
                                        <p>Energy</p>
                                        <select name="formdata[energy_id]" id="" class="form-control border-primary" required>
                                            @if($energy_list)
                                                @foreach($energy_list as $the_energy_list)
                                                    <option value="{{ $the_energy_list->id }}" {{ ($data->energy_id == $the_energy_list->id)?'selected':'' }}>{{ $the_energy_list->energy_name }}</option>
                                                @endforeach
                                            @endif
                                        </select>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <p>Natural Quantity</p>
                                                <input type="number" min="0" step="any" class="form-control border-primary" name="formdata[natural_qty]" value="{{ ($data->natural_qty != 0 )?$data->natural_qty:'' }}" required />
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <p>Natural Unit</p>
                                                <select name="formdata[natural_unit]" id="" class="form-control border-primary" required>
                                                    @if($units)
                                                        @foreach($units as $the_unit)
                                                            <option value="{{ $the_unit->id }}" {{ ($data->natural_unit == $the_unit->id)?'selected':'' }}>{{ $the_unit->unit_name }}</option>
                                                        @endforeach
                                                    @endif
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <p>Scientific Quantity</p>
                                                <input type="number" min="0" step="any" class="form-control border-primary" name="formdata[scientific_qty]" value="{{ ($data->scientific_qty != '' )?$data->scientific_qty:0 }}" required />
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <p>Scientific Unit</p>
                                                <input type="text" class="form-control border-primary" name="formdata[scientific_unit]" value="GJ" readonly />
                                            </div>
                                        </div>
                                    </div>
                                    <input type="hidden" name="status" value="Y" />
                                    <div class="form-actions right">
                                        <button type="button" class="btn btn-danger mr-1">
                                            <i class="ft-x"></i> Cancel
                                        </button>
                                        <button type="submit" class="btn btn-primary">
                                            <i class="la la-check-square-o"></i> Save
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection