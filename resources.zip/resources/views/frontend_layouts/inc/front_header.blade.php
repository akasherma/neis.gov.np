<!-- Header -->
<header class="header-container">
    <div class="header container-fluid">
        <div class="row">
            <div class="col-lg-8 col-sm-8 col-md-8 col-xs-12">
                <!-- Header Logo -->
                <a class="logo" title="National Energy Commission Secretariat" href="{{ url('/') }}"><img src="{{ url('/') }}/resources/assets/frontend/assets/images/wecs-neis-logo.jpg" alt="Water and Energy Commission Secretariat" style="width: 100%"></a>
                <!-- End Header Logo -->
            </div>
            <!-- Top Cart -->
            <div class="col-lg-4 col-sm-4 col-md-4 col-xs-12">
                <a class="pull-right" title="Login" href="{{ url('/') }}/login">Login</a><span class="pull-right">&nbsp;&nbsp;|&nbsp;&nbsp;</span><a class="pull-right" title="Home" href="{{ url('/') }}/login"><i class="fa fa-home"></i></a>
                <div class="clearfix"></div>
                <div class="signup hidden-xs">
                    <img src="{{ url('/') }}/resources/assets/frontend/assets/images/flag.gif" alt="Water and Energy Commission Secretariat">
                </div>
                <div class="clearfix"></div>

            </div>
            <!-- End Top Cart -->
        </div>
    </div>
</header>
<!-- end header -->

<?php

$current_url = url()->current();

$result = App\EnergyYear::getEnergyYear();
$start_date = 1995;
$end_date = date('Y');
if(!empty($result)){
    $start_date = $result[0];
    $end_date = $result[(count($result) - 1)];
}
//echo '<pre>';
//print_r($start_date);
//print_r($result);
//print_r($end_date);
//echo '</pre>';

$result_records = App\Menu::recordList();

?>

<div class="main-nav-wrapper nav-wrapper-2">
    <nav>
        <div class="main-nav main-nav-2 type-1">
            <div class="container-fluid">
                <ul class="nav-main-menu">
                    <li class="active"><a href="{{ url('/') }}" class="{{ ($current_url == url('/'))?'active':'' }}">HOME</a></li>
                    <li><a href="{{ url('/') }}/page/about-us" class="{{ ($current_url == url('/').'/page/about-us')?'active':'' }}">ABOUT US</a></li>
                    <li>
                        <a href="#">Energy Data</a>
                        <ul>
                            <li>
                                <a href="#">Federal</a>
                                <ul>
                                    <li>
                                        <a href="{{ url('/') }}/report/energy-consumption-share-by-fueltypes">National Energy Consumption By Fuel Types [ Pie Chart ]</a>
                                    </li>
                                    <li>
                                        <a href="{{ url('/') }}/report/energy-consumption-share-by-sectors">National Energy Consumption By Sectors [ Pie Chart ]</a>
                                    </li>
                                    <li>
                                        <a href="{{ url('/') }}/report/energy-consumption-by-sectors">National Energy Consumption By Sectors [ Bar Diagram ]</a>
                                    </li>
	                            <li><a href="{{ url('/') }}/report/energy-supply-demand-balance">Energy Balance[ Tabular Data ]</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="#">Province</a>
                                <ul>
                                    <li>
                                        <a href="{{ url('/') }}/report/province/province-1">Koshi Province</a>
                                    </li>
                                    <li>
                                        <a href="{{ url('/') }}/report/province/province-2">Madhesh Province</a>
                                    </li>
                                    <li>
                                        <a href="{{ url('/') }}/report/province/province-3">Bagmati  Province</a>
                                    </li>
                                    <li>
                                        <a href="{{ url('/') }}/report/province/province-4">Gandaki Province</a>
                                    </li>
                                    <li>
                                        <a href="{{ url('/') }}/report/province/province-5">Lumbini Province</a>
                                    </li>
                                    <li>
                                        <a href="{{ url('/') }}/report/province/province-6">Karnali Province</a>
                                    </li>
                                    <li>
                                        <a href="{{ url('/') }}/report/province/province-7">Sudurpashchim Province</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li><a href="{{ url('/') }}/power-plant-storage" class="{{ ($current_url == url('/').'/power-plant-storage')?'active':'' }}">Power Plant / Storage</a>
                        @if(!empty($result_records) && is_array($result_records))
                            <ul class="">
                                @foreach($result_records as $key=>$value)
                                    <li>
                                        <a href="{{ url('/') }}/power-plant-storage?topic={{ $key}}">{{ $value}}</a>
                                    </li>
                                @endforeach
                            </ul>
                        @endif
                    </li>
                    <li><a href="{{ url('/') }}/energy-conversion" class="{{ ($current_url == url('/').'/energy-conversion')?'active':'' }}">ENERGY CONVERSION</a></li>
                    <li><a href="{{ url('/') }}/sdg-7" class="{{ ($current_url == url('/').'/sdg-7')?'active':'' }}">SDG-7</a></li>
                    <li><a href="{{ url('/') }}/page/links" class="{{ ($current_url == url('/').'/page/links')?'active':'' }}">LINKS</a></li>
                    <li><a href="{{ url('/') }}/page/contact-us" class="{{ ($current_url == url('/').'/page/contact-us')?'active':'' }}">CONTACTS</a></li>
                </ul>


                <ul class="nav-main-menu small-screen">
                    <li><a href="{{ url('/') }}">HOME</a></li>
                    <li><a href="{{ url('/') }}/page/about-us">ABOUT US</a></li>
                    <li>
                        <a href="#">Energy Data</a>
                        <ul>
                            <li>
                                <a href="#">Federal</a>
                                <ul>
                                    <li>
                                        <a href="{{ url('/') }}/report/energy-consumption-share-by-fueltypes">National Energy Consumption By Fuel Types [ Pie Chart ]</a>
                                    </li>
                                    <li>
                                        <a href="{{ url('/') }}/report/energy-consumption-share-by-sectors">National Energy Consumption By Sectors [ Pie Chart ]</a>
                                    </li>
                                    <li>
                                        <a href="{{ url('/') }}/report/energy-consumption-by-sectors">National Energy Consumption By Sectors [ Bar Diagram ]</a>
                                    </li>
                                    <li><a href="{{ url('/') }}/report/energy-supply-demand-balance">Energy Balance [ Tabular Data ]</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="#">Province</a>
                                <ul>
                                    <li>
                                        <a href="{{ url('/') }}/report/province/province-1">Koshi Province</a>
                                    </li>
                                    <li>
                                        <a href="{{ url('/') }}/report/province/province-2">Madhesh Province</a>
                                    </li>
                                    <li>
                                        <a href="{{ url('/') }}/report/province/province-3">Bagmati  Province</a>
                                    </li>
                                    <li>
                                        <a href="{{ url('/') }}/report/province/province-4">Gandaki Province</a>
                                    </li>
                                    <li>
                                        <a href="{{ url('/') }}/report/province/province-5">Lumbini Province</a>
                                    </li>
                                    <li>
                                        <a href="{{ url('/') }}/report/province/province-6">Karnali Province</a>
                                    </li>
                                    <li>
                                        <a href="{{ url('/') }}/report/province/province-7">Sudurpashchim Province</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                    <li><a href="{{ url('/') }}/power-plant-storage">Power Plant / Storage</a>
                        @if(!empty($result_records) && is_array($result_records))
                            <ul class="">
                                @foreach($result_records as $key=>$value)
                                    <li>
                                        <a href="{{ url('/') }}/power-plant-storage?topic={{ $key}}">{{ $value}}</a>
                                    </li>
                                @endforeach
                            </ul>
                        @endif
                    </li>
                    <li><a href="{{ url('/') }}/energy-conversion" class="{{ ($current_url == url('/').'/energy-conversion')?'active':'' }}">ENERGY CONVERSION</a></li>
                    <li><a href="{{ url('/') }}/sdg-7" class="{{ ($current_url == url('/').'/sdg-7')?'active':'' }}">SDG-7</a></li>
                    <li><a href="{{ url('/') }}/page/links">LINKS</a></li>
                    <li><a href="{{ url('/') }}/page/contact-us">CONTACTS</a></li>
                </ul>
                <div class="nav-hamburger-wrapper">
                    <div class="cell-vertical-wrapper">
                        <div class="cell-middle">
                            <div class="nav-hamburger"><span></span></div>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </nav>
</div>

<!--<div class="marquee-container">-->
<!--    <div class="container">-->
<!--        <div class="row sliding">-->
<!--            <div class="col-md-12">-->
<!--                <marquee>[ The site is under test version. All the data needs to be validated. Final version will be ready within this fiscal year 078/079 ]</marquee>-->
<!--            </div>-->
<!--        </div>-->
<!--    </div>-->
<!--</div>-->

<main>