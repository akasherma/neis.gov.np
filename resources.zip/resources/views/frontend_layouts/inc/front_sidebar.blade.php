{{--<div class="block-service-style-05">--}}

    {{--<ul class="">--}}

        {{--<li class="resources">--}}
            {{--<a href="{{ url('/') }}/report/resources">Resources</a>--}}
        {{--</li>--}}
        {{--<li class="production">--}}
            {{--<a href="{{ url('/') }}/report/production">Production</a>--}}
        {{--</li>--}}
        {{--<li class="consumption">--}}
            {{--<a href="{{ url('/') }}/report/consumption">Consumption</a>--}}
        {{--</li>--}}
        {{--<li class="import">--}}
            {{--<a href="{{ url('/') }}/report/import">Import</a>--}}
        {{--</li>--}}
        {{--<li class="export">--}}
            {{--<a href="{{ url('/') }}/report/export">Export</a>--}}
        {{--</li>--}}
    {{--</ul>--}}

{{--</div>--}}

<section class="no-padding-bottom">
    <div class="widget team-section-01">

        <!--h5>SECRETARY</h5-->

        <div class="team-style-01 text-center section-block-p">

            <div class="image">
                
                <img src="https://neis.gov.np/public/images/ram-prasad-ghimire.jpg" alt="Ram Prasad Ghimire">
                
                <!--<img src="https://neis.gov.np/public/images/sushil-chandra-tiwari.jpg" alt="Sushil Chandra Tiwari">-->
                
                <!--<img src="{{ url('/') }}/resources/assets/frontend/assets/images/dinesh-Kumar-ghimire.jpg" alt="dinesh-Kumar-ghimire">-->

                <div class="overlay">



                </div>

            </div>

            <h5 class="name">Ram Prasad Ghimire</h5>

            <p class="job">Secretary</p>

        </div>

    </div>
</section>

<section class="no-padding-bottom">

    <div class="widget team-section-01">

        <div class="team-style-01 text-center section-block-p">

            {{--<div class="image">--}}
                {{----}}
                {{--<img src="{{ url('/') }}/resources/assets/frontend/uploaded/Kumari-Tara-Ghimire.jpg" alt="Information Officer">--}}

                {{--<div class="overlay">--}}



                {{--</div>--}}

            {{--</div>--}}

            {{--<h5 class="name">Ms. Kumari Tara Ghimire</h5>--}}

            {{--<p class="job">Section Officer</p>--}}

            {{--<p><!--strong>Mobile: </strong>9866019802 <strong>Office: </strong>4211423<br-->--}}

            {{--<strong>Email: </strong>kumaritara@wecs.gov.np</p>--}}

        </div>

    </div>
</section>