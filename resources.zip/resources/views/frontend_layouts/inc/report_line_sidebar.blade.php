
<section class="no-padding-bottom right-design">
    <div class="widget team-section-01">

        <h2 class="card-title">
            Filter
        </h2>
        <form action="{{ $url }}" method="get">
            @csrf
            <?php
            $start = (!empty($_GET['start']))?$_GET['start']:2005;
            
            $end = 2023;
            
            ?>

            <div class="p-15">
                <div class="row">
                    <div class="col-md-6">

                        <h4>From Year</h4>

                        <select name="start" class="form-control">
                            <option value="">Select Start Year</option>
                            @for($i = 2000; $i < $end; $i++)
                                <option value="{{ $i }}" {{ ($i == $start)?'selected':'' }}>{{$i}}</option>
                            @endfor

                        </select>

                    </div>
                    <div class="col-md-6">

                        <h4>To Year</h4>

                        <select name="end" class="form-control">
                            <option value="">Select End Year</option>
                            @for($i = 2000; $i <= $end; $i++)
                                <option value="{{ $i }}" {{ ($i == $end)?'selected':'' }}>{{$i}}</option>
                            @endfor

                        </select>

                    </div>
                </div>

                <input type="submit" class="btn btn-primary btn-xs " value="Submit">

            </div>

        </form>

        <hr>

        <h2 class="card-title">
            National Energy Data
        </h2>

        <ul class="mt-15">
            <li>
                <a href="{{url('/')}}/report/energy-consumption-share-by-fueltypes" class="{{ ($url == url('/').'/report/energy-consumption-share-by-fueltypes')?'active':'' }}">By Fuel Types [ Pie Chart ] <span class="pull-right pr-10"><i class="fa fa-pie-chart"></i></span></a>
            </li>
            <li>
                <a href="{{url('/')}}/report/energy-consumption-share-by-sectors" class="{{ ($url == url('/').'/report/energy-consumption-share-by-sectors')?'active':'' }}" > By Sectors [ Pie Chart ] <span class="pull-right pr-10"><i class="fa fa-pie-chart"></i></span></a>
            </li>
            <li>
                <a href="{{url('/')}}/report/energy-consumption-by-sectors" class="{{ ($url == url('/').'/report/energy-consumption-by-sectors')?'active':'' }}">By Sectors [ Bar Diagram ] <span class="pull-right pr-10"><i class="fa fa-bar-chart"></i></span></a>
            </li>
            <li>
                <a href="{{url('/')}}/report/consumption-energy-topic-energy-line-graph" class="{{ ($url == url('/').'/report/consumption-energy-topic-energy-line-graph')?'active':'' }}">By Line Graph [ Bar Diagram ] <span class="pull-right pr-10"><i class="fa fa-bar-chart"></i></span></a>
            </li>
            <li>
                <a href="{{url('/')}}/report/energy-consumption-by-trend-bar-graph" class="{{ ($url == url('/').'/report/energy-consumption-by-trend-bar-graph')?'active':'' }}">By Year [ Bar Diagram ] <span class="pull-right pr-10"><i class="fa fa-bar-chart"></i></span></a>
            </li>
            <li>
                <a href="{{url('/')}}/report/energy-supply-demand-balance" class="{{ ($url == url('/').'/report/energy-supply-demand-balance')?'active':'' }}">Energy Balance[ Tabular Data ] <span class="pull-right pr-10"><i class="fa fa-th"></i></span></a>
            </li>
        </ul>

        <hr>

        <h2 class="card-title">
            Provincial Energy Data
        </h2>

        <ul class="mt-15">
            <li>
                <a href="{{url('/')}}/report/province/province-1" class="{{ ($url == url('/').'/report/province/province-1')?'active':'' }}">Koshi Pradesh <span class="pull-right pr-10"><i class="fa fa-external-link"></i></span></a>
            </li>
            <li>
                <a href="{{url('/')}}/report/province/province-2" class="{{ ($url == url('/').'/report/province/province-2')?'active':'' }}">Madhesh Pradesh <span class="pull-right pr-10"><i class="fa fa-external-link"></i></span></a>
            </li>
            <li>
                <a href="{{url('/')}}/report/province/province-3" class="{{ ($url == url('/').'/report/province/province-3')?'active':'' }}">Bagmati Pradesh <span class="pull-right pr-10"><i class="fa fa-external-link"></i></span></a>
            </li>
            <li>
                <a href="{{url('/')}}/report/province/province-4" class="{{ ($url == url('/').'/report/province/province-4')?'active':'' }}">Gandaki Pradesh <span class="pull-right pr-10"><i class="fa fa-external-link"></i></span></a>
            </li>
            <li>
                <a href="{{url('/')}}/report/province/province-5" class="{{ ($url == url('/').'/report/province/province-5')?'active':'' }}">Lumbini Pradesh <span class="pull-right pr-10"><i class="fa fa-external-link"></i></span></a>
            </li>
            <li>
                <a href="{{url('/')}}/report/province/province-6" class="{{ ($url == url('/').'/report/province/province-6')?'active':'' }}">Karnali Pradesh <span class="pull-right pr-10"><i class="fa fa-external-link"></i></span></a>
            </li>
            <li>
                <a href="{{url('/')}}/report/province/province-7" class="{{ ($url == url('/').'/report/province/province-7')?'active':'' }}">Sudur Paschim Pradesh <span class="pull-right pr-10"><i class="fa fa-external-link"></i></span></a>
            </li>
        </ul>

        <hr>



    </div>
</section>
