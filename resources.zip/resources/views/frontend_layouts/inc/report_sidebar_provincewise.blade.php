
<section class="no-padding-bottom right-design">
    <div class="widget team-section-01">

        <h2 class="card-title">
            Filter
        </h2>
        <form action="{{ $url }}" method="get" id="filter_form">
            @csrf
            <?php
            $start = (!empty($_GET['start']))?$_GET['start']:'2019';
            $output = (!empty($_GET['output']))?$_GET['output']:'overall';
            ?>

            <div class="p-15">

                <?php /*
                <h5>By Fiscal Year</h5>

                <ul class="nav navbar-nav">
                    <li>
                        <input type="checkbox" name="start" value="2019" {{ ($start == 2019)?'checked':'' }}> 2019/2020
                    </li>
                </ul>
                
                */ ?>

                <h5>By Output </h5>

                <ul class="nav navbar-nav">
                    <li>
                        <input type="radio" name="output" value="overall" {{ ($output == 'overall')?'checked':'' }} onclick="document.getElementById('filter_form').submit();"> By Fuel Types [ Pie-Chart ]
                    </li>
                    <li>
                        <input type="radio" name="output" value="fueltype" {{ ($output == 'fueltype')?'checked':'' }} onclick="document.getElementById('filter_form').submit();"> By Fuel Types [ Bar Diagram ]
                    </li>
                    <li>
                        <input type="radio" name="output" value="districtwise" {{ ($output == 'districtwise')?'checked':'' }} onclick="document.getElementById('filter_form').submit();"> By Districts [ Bar Diagram ]
                    </li>
                    <li>
                        <input type="radio" name="output" value="overall_sectorwise" {{ ($output == 'overall_sectorwise')?'checked':'' }} onclick="document.getElementById('filter_form').submit();"> By Sectors [ Pie-Chart ]
                    </li>
                    <li>
                        <input type="radio" name="output" value="sectorwise" {{ ($output == 'sectorwise')?'checked':'' }} onclick="document.getElementById('filter_form').submit();"> By Sectors [ Bar Diagram ]
                    </li>
                </ul>

                {{--<input type="submit" class="btn btn-primary btn-xs " value="Submit">--}}

            </div>

        </form>

        <hr>

        <h2 class="card-title">
            Provincial Energy Data
        </h2>

        <ul class="mt-15">
            <li>
                <a href="{{url('/')}}/report/province/province-1" class="{{ ($url == url('/').'/report/province/province-1')?'active':'' }}">Koshi Pradesh <span class="pull-right pr-10"><i class="fa fa-external-link"></i></span></a>
            </li>
            <li>
                <a href="{{url('/')}}/report/province/province-2" class="{{ ($url == url('/').'/report/province/province-2')?'active':'' }}">Madhesh Pradesh <span class="pull-right pr-10"><i class="fa fa-external-link"></i></span></a>
            </li>
            <li>
                <a href="{{url('/')}}/report/province/province-3" class="{{ ($url == url('/').'/report/province/province-3')?'active':'' }}">Bagmati Pradesh <span class="pull-right pr-10"><i class="fa fa-external-link"></i></span></a>
            </li>
            <li>
                <a href="{{url('/')}}/report/province/province-4" class="{{ ($url == url('/').'/report/province/province-4')?'active':'' }}">Gandaki Pradesh <span class="pull-right pr-10"><i class="fa fa-external-link"></i></span></a>
            </li>
            <li>
                <a href="{{url('/')}}/report/province/province-5" class="{{ ($url == url('/').'/report/province/province-5')?'active':'' }}">Lumbini Pradesh <span class="pull-right pr-10"><i class="fa fa-external-link"></i></span></a>
            </li>
            <li>
                <a href="{{url('/')}}/report/province/province-6" class="{{ ($url == url('/').'/report/province/province-6')?'active':'' }}">Karnali Pradesh <span class="pull-right pr-10"><i class="fa fa-external-link"></i></span></a>
            </li>
            <li>
                <a href="{{url('/')}}/report/province/province-7" class="{{ ($url == url('/').'/report/province/province-7')?'active':'' }}">Sudur Paschim Pradesh <span class="pull-right pr-10"><i class="fa fa-external-link"></i></span></a>
            </li>
        </ul>

        <hr>

        <h2 class="card-title">
            National Energy Data
        </h2>

        <ul class="mt-15">
            <li>
                <a href="{{url('/')}}/report/energy-consumption-share-by-fueltypes" class="{{ ($url == url('/').'/report/energy-consumption-share-by-fueltypes')?'active':'' }}">By Fuel Types [ Pie Chart ] <span class="pull-right pr-10"><i class="fa fa-pie-chart"></i></span></a>
            </li>
            <li>
                <a href="{{url('/')}}/report/energy-consumption-share-by-sectors" class="{{ ($url == url('/').'/report/energy-consumption-share-by-sectors')?'active':'' }}" > By Sectors [ Pie Chart ] <span class="pull-right pr-10"><i class="fa fa-pie-chart"></i></span></a>
            </li>
            <li>
                <a href="{{url('/')}}/report/energy-consumption-by-sectors" class="{{ ($url == url('/').'/report/energy-consumption-by-sectors')?'active':'' }}">By Sectors [ Bar Diagram ] <span class="pull-right pr-10"><i class="fa fa-bar-chart"></i></span></a>
            </li>
            <li>
                <a href="{{url('/')}}/report/energy-supply-demand-balance" class="{{ ($url == url('/').'/report/energy-supply-demand-balance')?'active':'' }}">Energy Balance[ Tabular Data ] <span class="pull-right pr-10"><i class="fa fa-th"></i></span></a>
            </li>
        </ul>

        <hr>

    </div>
</section>
