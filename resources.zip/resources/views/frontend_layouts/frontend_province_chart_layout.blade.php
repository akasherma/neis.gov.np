<!DOCTYPE html>
<html class="no-js">
<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>National Energy Information System :: Government of Nepal</title>

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- link rel="apple-touch-icon" sizes="57x57" href="favicon/apple-touch-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="favicon/apple-touch-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="favicon/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="favicon/apple-touch-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="favicon/apple-touch-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="favicon/apple-touch-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="favicon/apple-touch-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="favicon/apple-touch-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="favicon/apple-touch-icon-180x180.png">
    <link rel="icon" type="image/png" href="favicon/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="favicon/favicon-194x194.png" sizes="194x194">
    <link rel="icon" type="image/png" href="favicon/favicon-96x96.png" sizes="96x96">
    <link rel="icon" type="image/png" href="favicon/android-chrome-192x192.png" sizes="192x192">
    <link rel="icon" type="image/png" href="favicon/favicon-16x16.png" sizes="16x16">
    <link rel="manifest" href="favicon/manifest.json">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="msapplication-TileImage" content="favicon/mstile-144x144.png">
    <meta name="theme-color" content="#ffffff" -->
    <link rel="stylesheet" href="{{ url('/') }}/resources/assets/frontend/vendors/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="{{ url('/') }}/resources/assets/frontend/vendors/animate/animate.min.css">
    <link rel="stylesheet" href="{{ url('/') }}/resources/assets/frontend/assets/fonts/wolverine/styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;400;700&display=swap" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css2?family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="{{ url('/') }}/resources/assets/frontend/vendors/slick/slick.css">
    <link rel="stylesheet" type="text/css" href="{{ url('/') }}/resources/assets/frontend/vendors/full-page/jquery.fullPage.css">
    <!--Main stylesheet-->
    <link rel="stylesheet" href="{{ url('/') }}/resources/assets/frontend/assets/css/main.css">
    <link rel="stylesheet" href="{{ url('/') }}/resources/assets/frontend/assets/css/fontawesome.css">
    <link rel="stylesheet" href="{{ url('/') }}/resources/assets/frontend/assets/css/caMenu.css">
    <!--Modernizr js-->
    <script src="{{ url('/') }}/resources/assets/frontend/vendors/modernizr/modernizr-2.8.3-respond-1.4.2.min.js"></script>
    <style> .nav-main-menu > li > ul{display:none;}</style>

    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script src="https://code.highcharts.com/modules/exporting.js"></script>
    <script src="https://code.highcharts.com/modules/export-data.js"></script>
    <script src="https://code.highcharts.com/modules/accessibility.js"></script>

</head>

<body class="creative-page">

@include('frontend_layouts.inc.front_header')

<!-- site header -->

<header class="site-header">

    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3 service-item-wrapper text-left section-block">

                @include('frontend_layouts.inc.report_sidebar_provincewise')

            </div>
            <div class="col-md-9 bs-example">

                @yield('content')

            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</header>

@include('frontend_layouts.inc.front_footer')

<!--end site footer-->

</main>

<script src="{{ url('/') }}/resources/assets/frontend/vendors/jquery/jquery-1.11.2.min.js"></script>
<script src="{{ url('/') }}/resources/assets/frontend/vendors/stellar/jquery.stellar.min.js"></script>
<script src="{{ url('/') }}/resources/assets/frontend/vendors/waypoints/lib/jquery.waypoints.min.js"></script>
<script src="{{ url('/') }}/resources/assets/frontend/vendors/smooth-scroll/SmoothScroll.js"></script>
<script src="{{ url('/') }}/resources/assets/frontend/vendors/bootstrap/bootstrap.min.js"></script>
<script type="text/javascript" src="{{ url('/') }}/resources/assets/frontend/vendors/slick/slick.js"></script>
<script type="text/javascript" src="{{ url('/') }}/resources/assets/frontend/vendors/magnific-popup/jquery.magnific-popup.js"></script>
<script src="{{ url('/') }}/resources/assets/frontend/vendors/isotope/isotope.pkgd.min.js"></script>
<script src="{{ url('/') }}/resources/assets/frontend/vendors/isotope/packery-mode.pkgd.min.js"></script>
<script type="text/javascript" src="{{ url('/') }}/resources/assets/frontend/vendors/img-loaded/imagesloaded.pkgd.min.js"></script>
<script src="{{ url('/') }}/resources/assets/frontend/assets/js/main.js"></script>
<script>
    $(document).ready(function(){
        // alert('asdf');
        // var output = $('#output').val();
        //
        // if(output != 'trend'){
        //     $('#fiscal_year').css("display", "block");
        //     $('#year_range').css("display", "none");
        // }else {
        //     $('#year_range').css("display", "block")
        //     $('#fiscal_year').css("display", "none");
        // }
        //
        // $('#output').on('change', function(){
        //     output = $(this).val();
        //
        //     // alert(output);
        //
        //     if(output != 'trend'){
        //         $('#fiscal_year').css("display", "block");
        //         $('#year_range').css("display", "none");
        //     }else {
        //         $('#year_range').css("display", "block")
        //         $('#fiscal_year').css("display", "none");
        //     }
        //
        // });

    });
</script>
</body>
</html>
