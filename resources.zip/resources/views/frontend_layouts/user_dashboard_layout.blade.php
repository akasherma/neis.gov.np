<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <title>National Energy Information System :: Government of Nepal</title>
    <link rel="shortcut icon" type="image/x-icon" href="{{ url('/') }}/resources/assets/ppentry/app-assets/images/ico/favicon.ico">
    <link href="https://fonts.googleapis.com/css?family=Muli:400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="https://maxcdn.icons8.com/fonts/line-awesome/1.1/css/line-awesome-font-awesome.min.css" rel="stylesheet">
    <!-- BEGIN VENDOR CSS-->
    <link rel="stylesheet" type="text/css" href="{{ url('/') }}/resources/assets/ppentry/app-assets/css/vendors.min.css">
    <link rel="stylesheet" type="text/css" href="{{ url('/') }}/resources/assets/ppentry/app-assets/vendors/css/forms/toggle/switchery.min.css">
    <link rel="stylesheet" type="text/css" href="{{ url('/') }}/resources/assets/ppentry/app-assets/css/plugins/forms/switch.min.css">
    <link rel="stylesheet" type="text/css" href="{{ url('/') }}/resources/assets/ppentry/app-assets/css/core/colors/palette-switch.min.css">
    <link rel="stylesheet" type="text/css" href="{{ url('/') }}/resources/assets/ppentry/app-assets/vendors/css/charts/chartist.css">
    <link rel="stylesheet" type="text/css" href="{{ url('/') }}/resources/assets/ppentry/app-assets/vendors/css/charts/chartist-plugin-tooltip.css">
    <!-- END VENDOR CSS-->
    <!-- BEGIN CHAMELEON  CSS-->
    <link rel="stylesheet" type="text/css" href="{{ url('/') }}/resources/assets/ppentry/app-assets/css/app.min.css">
    <!-- END CHAMELEON  CSS-->
    <!-- BEGIN Page Level CSS-->
    <link rel="stylesheet" type="text/css" href="{{ url('/') }}/resources/assets/ppentry/app-assets/css/core/menu/menu-types/vertical-menu.min.css">
    <link rel="stylesheet" type="text/css" href="{{ url('/') }}/resources/assets/ppentry/app-assets/css/core/colors/palette-gradient.min.css">
    <link rel="stylesheet" type="text/css" href="{{ url('/') }}/resources/assets/ppentry/app-assets/css/core/colors/palette-gradient.min.css">
    <link rel="stylesheet" type="text/css" href="{{ url('/') }}/resources/assets/ppentry/app-assets/css/pages/chat-application.css">
    <link rel="stylesheet" type="text/css" href="{{ url('/') }}/resources/assets/ppentry/app-assets/css/pages/dashboard-analytics.min.css">
    <!-- END Page Level CSS-->
    <!-- BEGIN Custom CSS-->
    <link rel="stylesheet" type="text/css" href="{{ url('/') }}/resources/assets/ppentry/assets/css/style.css">
    <!-- END Custom CSS-->
  </head>
  <body class="vertical-layout vertical-menu 2-columns menu-expanded fixed-navbar" data-open="click" data-menu="vertical-menu" data-color="bg-gradient-x-purple-blue" data-col="2-columns">

    @include("frontend_layouts.inc.front_header")
    
    <div class="main-menu menu-fixed menu-light menu-accordion menu-shadow " data-scroll-to-active="true" data-img="{{ url('/') }}/resources/assets/ppentry/app-assets/images/backgrounds/02.jpg">
      <div class="navbar-header">
        <ul class="nav navbar-nav flex-row">       
          <li class="nav-item mr-auto"><a class="navbar-brand" href="{{url('/')}}/user/dashboard">
            <!-- <img class="brand-logo" alt="Chameleon admin logo" src="{{ url('/') }}/resources/assets/ppentry/app-assets/images/logo/logo.png"/> -->
              <h3 class="brand-text">NEIS</h3></a></li>
          <li class="nav-item d-md-none"><a class="nav-link close-navbar"><i class="ft-x"></i></a></li>
        </ul>
      </div>
      <div class="main-menu-content">
        @include("frontend_layouts.inc.front_sidebar")
      </div>
      <div class="navigation-background"></div>
    </div>

    <div class="app-content content">
      <div class="content-wrapper">
        <div class="content-wrapper-before"></div>
        <div class="content-header row">
        </div>
        <div class="content-body"><!-- Revenue, Hit Rate & Deals -->
            @yield('content')
<!--/ Revenue, Hit Rate & Deals -->
<!-- Emails Products & Avg Deals -->

<!--/ Emails Products & Avg Deals -->
<!--/ Total earning & Recent Sales  -->
        </div>
      </div>
    </div>
    <!-- ////////////////////////////////////////////////////////////////////////////-->

    @include("frontend_layouts.inc.front_footer")


    <!-- BEGIN VENDOR JS-->
    <script src="{{ url('/') }}/resources/assets/ppentry/app-assets/vendors/js/vendors.min.js" type="text/javascript"></script>
    <script src="{{ url('/') }}/resources/assets/ppentry/app-assets/vendors/js/forms/toggle/switchery.min.js" type="text/javascript"></script>
    <script src="{{ url('/') }}/resources/assets/ppentry/app-assets/js/scripts/forms/switch.min.js" type="text/javascript"></script>
    <!-- BEGIN VENDOR JS-->
    <!-- BEGIN PAGE VENDOR JS-->
    <script src="{{ url('/') }}/resources/assets/ppentry/app-assets/vendors/js/charts/chartist.min.js" type="text/javascript"></script>
    <script src="{{ url('/') }}/resources/assets/ppentry/app-assets/vendors/js/charts/chartist-plugin-tooltip.min.js" type="text/javascript"></script>
    <!-- END PAGE VENDOR JS-->
    <!-- BEGIN CHAMELEON  JS-->
    <script src="{{ url('/') }}/resources/assets/ppentry/app-assets/js/core/app-menu.min.js" type="text/javascript"></script>
    <script src="{{ url('/') }}/resources/assets/ppentry/app-assets/js/core/app.min.js" type="text/javascript"></script>
    <script src="{{ url('/') }}/resources/assets/ppentry/app-assets/js/scripts/customizer.min.js" type="text/javascript"></script>
    <script src="{{ url('/') }}/resources/assets/ppentry/app-assets/vendors/js/jquery.sharrre.js" type="text/javascript"></script>
    <!-- END CHAMELEON  JS-->
    <!-- BEGIN PAGE LEVEL JS-->
    <script src="{{ url('/') }}/resources/assets/ppentry/app-assets/js/scripts/pages/dashboard-analytics.min.js" type="text/javascript"></script>
    <!-- END PAGE LEVEL JS-->
  </body>
</html>
            
