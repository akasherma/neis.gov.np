<!DOCTYPE html>
<html class="no-js">
<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>National Energy Commission Secretariat :: Government of Nepal</title>

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- link rel="apple-touch-icon" sizes="57x57" href="favicon/apple-touch-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="favicon/apple-touch-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="favicon/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="favicon/apple-touch-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="favicon/apple-touch-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="favicon/apple-touch-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="favicon/apple-touch-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="favicon/apple-touch-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="favicon/apple-touch-icon-180x180.png">
    <link rel="icon" type="image/png" href="favicon/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="favicon/favicon-194x194.png" sizes="194x194">
    <link rel="icon" type="image/png" href="favicon/favicon-96x96.png" sizes="96x96">
    <link rel="icon" type="image/png" href="favicon/android-chrome-192x192.png" sizes="192x192">
    <link rel="icon" type="image/png" href="favicon/favicon-16x16.png" sizes="16x16">
    <link rel="manifest" href="favicon/manifest.json">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="msapplication-TileImage" content="favicon/mstile-144x144.png">
    <meta name="theme-color" content="#ffffff" -->
    <link rel="stylesheet" href="{{ url('/') }}/resources/assets/frontend/vendors/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="{{ url('/') }}/resources/assets/frontend/vendors/animate/animate.min.css">
    <link rel="stylesheet" href="{{ url('/') }}/resources/assets/frontend/assets/fonts/wolverine/styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@100;400;700&display=swap" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css2?family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="{{ url('/') }}/resources/assets/frontend/vendors/slick/slick.css">
    <link rel="stylesheet" type="text/css" href="{{ url('/') }}/resources/assets/frontend/vendors/full-page/jquery.fullPage.css">
    <!--Main stylesheet-->
    <link rel="stylesheet" href="{{ url('/') }}/resources/assets/frontend/assets/css/main.css">
    <link rel="stylesheet" href="{{ url('/') }}/resources/assets/frontend/assets/css/fontawesome.css">
    <link rel="stylesheet" href="{{ url('/') }}/resources/assets/frontend/assets/css/caMenu.css">
    <!--Modernizr js-->
    <script src="{{ url('/') }}/resources/assets/frontend/vendors/modernizr/modernizr-2.8.3-respond-1.4.2.min.js"></script>
    <style> .nav-main-menu > li > ul{display:none;}</style>

    <script src="https://code.highcharts.com/highcharts.js"></script>
    <script src="https://code.highcharts.com/modules/exporting.js"></script>
    <script src="https://code.highcharts.com/modules/export-data.js"></script>

</head>

<body class="creative-page">

@include('frontend_layouts.inc.front_header')

<!-- site header -->

<header class="site-header">

    <div class="container">
        <div class="row">
            <div class="col-md-9 bs-example">


                <form class="" action="{{ url('/') }}/report" method="post">
                    @csrf
                    <div class="row">
                        <div class="col-md-2">
                            <?php
                            $output = (!empty($output))?$output:'direct';
                            $start = (!empty($start))?$start:(date('Y') - 2);
                            $energy_type = (!empty($energy_type))?$energy_type:'consumption';
                            $energy_topic = (!empty($energy_topic))?$energy_topic:'_';

                            $result = App\EnergyYear::getEnergyYear();
                            $start_date = 1995;
                            $end_date = date('Y');
                            if(!empty($result)){
                                $start_date = $result[0];
                                $end_date = $result[(count($result) - 1)];
                            }

                            ?>
                            <div class="form-group">
                                <label for="">Output</label>
                                <select name="searchdata[output]" id="output" class="form-control">
                                    <option value="direct" {{ ($output == 'direct')?'selected':'' }}>Pie Chart</option>
                                    <option value="tabular" {{ ($output == 'tabular')?'selected':'' }}>Bar Diagram</option>
                                    <option value="trend" {{ ($output == 'trend')?'selected':'' }}>Line Graph</option>
                                    <option value="provincewise" {{ ($output == 'provincewise')?'selected':'' }}>Bar Biagram [Provincewise]</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div id="fiscal_year" class="form-group direct tabular" style="{{ ($output != 'trend')?'display:block;':'display:none;' }}">
                                <label for="">Fiscal Year</label>
                                <select name="searchdata[date_from]" class="form-control">
                                    @if(!empty($result))
                                        @foreach($result as $the_result)
                                            <?php $j = $the_result + 1; ?>
                                            <option value="{{ $the_result }}" {{ ($start == $the_result)?'selected':'' }}>{{ $the_result }}/{{ $j }}</option>
                                        @endforeach
                                    @else
                                        @for($i = $end_date; $i >= $start_date; $i--)
                                            <?php $j = $i + 1; ?>
                                            <option value="{{ $i }}" {{ ($start == $i)?'selected':'' }}>{{ $i }}/{{ $j }}</option>
                                        @endfor
                                    @endif
                                </select>
                            </div>
                            <?php
//                                $year_range = rsort($result);
                                sort($result, SORT_NATURAL | SORT_FLAG_CASE);

                            //                                echo '<pre>';
//                                print_r($year_range);
//                                exit();

                            ?>
                            <div id="year_range" class="form-group trend" style="{{ ($output == 'trend')?'display:block;':'display:none;' }}">
                                <label for="">Year Range</label>
                                <select name="searchdata[year_range][]" class="form-control" multiple>
                                    @if(!empty($result))
                                        @foreach($result as $the_result)
                                            <?php $j = $the_result + 1; ?>
                                            <option value="{{ $the_result }}">{{ $the_result }}</option>
                                        @endforeach
                                        <option value="{{ $j }}">{{ $j }}</option>
                                    @else
                                        @for($i = $end_date; $i >= $start_date; $i--)
                                            <?php $j = $i + 1; ?>
                                            <option value="{{ $i }}">{{ $i }}</option>
                                        @endfor
                                        <option value="{{ $j }}">{{ $j }}</option>
                                    @endif
                                </select>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="">Energy</label>
                                <select name="searchdata[energy_type]" id="" class="form-control">
                                    <option value="consumption" {{ ($energy_type == 'consumption')?'selected':'' }}>Consumption</option>
                                    <option value="resources" {{ ($energy_type == 'resources')?'selected':'' }}>Resources</option>
                                    <option value="production" {{ ($energy_type == 'production')?'selected':'' }}>Production</option>
                                    <option value="import" {{ ($energy_type == 'import')?'selected':'' }}>Import</option>
                                    <option value="export" {{ ($energy_type == 'export')?'selected':'' }}>Export</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="">Topic</label>
                                <select name="searchdata[energy_topic]" id="" class="form-control">
                                    <option value="sector" {{ ($energy_topic == 'sector')?'selected':'' }}>Sectors</option>
                                    <option value="land_type" {{ ($energy_topic == 'land_type')?'selected':'' }}>Land Types</option>
                                    <option value="geographic_region" {{ ($energy_topic == 'geographic_region')?'selected':'' }}>Geographic Regions</option>
                                    <option value="river" {{ ($energy_topic == 'river')?'selected':'' }}>Rivers</option>
                                    <option value="_" {{ ($energy_topic == '_')?'selected':'' }}>All Energy</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <div class="form-group">
                                <label for="">&nbsp;</label>
                                <button type="submit" class="btn btn-primary">Search</button>
                            </div>
                        </div>
                    </div>

                </form>

                @yield('content')

            </div>
            <div class="col-md-3 service-item-wrapper text-left section-block">

                @include('frontend_layouts.inc.front_sidebar')

            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</header>

@include('frontend_layouts.inc.front_footer')

<!--end site footer-->

</main>

<script src="{{ url('/') }}/resources/assets/frontend/vendors/jquery/jquery-1.11.2.min.js"></script>
<script src="{{ url('/') }}/resources/assets/frontend/vendors/stellar/jquery.stellar.min.js"></script>
<script src="{{ url('/') }}/resources/assets/frontend/vendors/waypoints/lib/jquery.waypoints.min.js"></script>
<script src="{{ url('/') }}/resources/assets/frontend/vendors/smooth-scroll/SmoothScroll.js"></script>
<script src="{{ url('/') }}/resources/assets/frontend/vendors/bootstrap/bootstrap.min.js"></script>
<script type="text/javascript" src="{{ url('/') }}/resources/assets/frontend/vendors/slick/slick.js"></script>
<script type="text/javascript" src="{{ url('/') }}/resources/assets/frontend/vendors/magnific-popup/jquery.magnific-popup.js"></script>
<script src="{{ url('/') }}/resources/assets/frontend/vendors/isotope/isotope.pkgd.min.js"></script>
<script src="{{ url('/') }}/resources/assets/frontend/vendors/isotope/packery-mode.pkgd.min.js"></script>
<script type="text/javascript" src="{{ url('/') }}/resources/assets/frontend/vendors/img-loaded/imagesloaded.pkgd.min.js"></script>
<script src="{{ url('/') }}/resources/assets/frontend/assets/js/main.js"></script>
<script>
    $(document).ready(function(){
        // alert('asdf');
        var output = $('#output').val();

        if(output != 'trend'){
            $('#fiscal_year').css("display", "block");
            $('#year_range').css("display", "none");
        }else {
            $('#year_range').css("display", "block")
            $('#fiscal_year').css("display", "none");
        }

        $('#output').on('change', function(){
            output = $(this).val();

            // alert(output);

            if(output != 'trend'){
                $('#fiscal_year').css("display", "block");
                $('#year_range').css("display", "none");
            }else {
                $('#year_range').css("display", "block")
                $('#fiscal_year').css("display", "none");
            }

        });

    });
</script>
</body>
</html>
