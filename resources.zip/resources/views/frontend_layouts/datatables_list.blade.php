<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="description" content="Chameleon Admin is a modern Bootstrap 4 webapp &amp; admin dashboard html template with a large number of components, elegant design, clean and organized code.">
    <meta name="keywords" content="admin template, Chameleon admin template, dashboard template, gradient admin template, responsive admin template, webapp, eCommerce dashboard, analytic dashboard">
    <meta name="author" content="ThemeSelect">
    <title>NEIS</title>
    <link rel="apple-touch-icon" href="{{ url('/') }}/resources/assets/ppentry/app-assets/images/ico/apple-icon-120.png">
    <link rel="shortcut icon" type="image/x-icon" href="{{ url('/') }}/resources/assets/ppentry/app-assets/images/ico/favicon.ico">
    <link href="https://fonts.googleapis.com/css?family=Muli:400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="https://maxcdn.icons8.com/fonts/line-awesome/1.1/css/line-awesome-font-awesome.min.css" rel="stylesheet">
    <!-- BEGIN VENDOR CSS-->
    <link rel="stylesheet" type="text/css" href="{{ url('/') }}/resources/assets/ppentry/app-assets/css/vendors.min.css">
    <link rel="stylesheet" type="text/css" href="{{ url('/') }}/resources/assets/ppentry/app-assets/vendors/css/forms/toggle/switchery.min.css">
    <link rel="stylesheet" type="text/css" href="{{ url('/') }}/resources/assets/ppentry/app-assets/css/plugins/forms/switch.min.css">
    <link rel="stylesheet" type="text/css" href="{{ url('/') }}/resources/assets/ppentry/app-assets/css/core/colors/palette-switch.min.css">
    <link rel="stylesheet" type="text/css" href="{{ url('/') }}/resources/assets/ppentry/app-assets/vendors/css/tables/datatable/datatables.min.css">
    <!-- END VENDOR CSS-->
    <!-- BEGIN CHAMELEON  CSS-->
    <link rel="stylesheet" type="text/css" href="{{ url('/') }}/resources/assets/ppentry/app-assets/css/app.min.css">
    <!-- END CHAMELEON  CSS-->
    <!-- BEGIN Page Level CSS-->
    <link rel="stylesheet" type="text/css" href="{{ url('/') }}/resources/assets/ppentry/app-assets/css/core/menu/menu-types/vertical-menu.min.css">
    <link rel="stylesheet" type="text/css" href="{{ url('/') }}/resources/assets/ppentry/app-assets/css/core/colors/palette-gradient.min.css">
    <!-- END Page Level CSS-->
    <!-- BEGIN Custom CSS-->
    <link rel="stylesheet" type="text/css" href="{{ url('/') }}/resources/assets/ppentry/assets/css/style.css">
    <!-- END Custom CSS-->
      <script src="{{ url('/') }}/resources/assets/ppentry/app-assets/js/jquery-3.3.1.min.js"></script>
  </head>
  <body class="vertical-layout vertical-menu 2-columns   menu-expanded fixed-navbar" data-open="click" data-menu="vertical-menu" data-color="bg-gradient-x-purple-blue" data-col="2-columns">

    @include("frontend_layouts.inc.front_header")
    
    <div class="main-menu menu-fixed menu-light menu-accordion    menu-shadow " data-scroll-to-active="true" data-img="../../../app-assets/images/backgrounds/02.jpg">
      <div class="navbar-header">
        <ul class="nav navbar-nav flex-row">       
          <li class="nav-item mr-auto"><a class="navbar-brand" href="{{url('/')}}/user/dashboard">
              
            <img class="brand-logo" alt="Logo" src="{{ url('/') }}/resources/assets/ppentry/app-assets/images/logo/logo.png"/>
              <h3 class="brand-text">PPEntry</h3></a></li>
          <li class="nav-item d-md-none"><a class="nav-link close-navbar"><i class="ft-x"></i></a></li>
        </ul>
      </div>
      <div class="main-menu-content">
        
        @include("frontend_layouts.inc.front_sidebar")
        
      </div>
      <div class="navigation-background"></div>
    </div>
    @yield('content')

    @include("frontend_layouts.inc.front_footer")

    <!-- BEGIN VENDOR JS-->
    <script src="{{ url('/') }}/resources/assets/ppentry/app-assets/vendors/js/vendors.min.js" type="text/javascript"></script>
    <script src="{{ url('/') }}/resources/assets/ppentry/app-assets/vendors/js/forms/toggle/switchery.min.js" type="text/javascript"></script>
    <script src="{{ url('/') }}/resources/assets/ppentry/app-assets/js/scripts/forms/switch.min.js" type="text/javascript"></script>
    <!-- BEGIN VENDOR JS-->
    <!-- BEGIN PAGE VENDOR JS-->
    <script src="{{ url('/') }}/resources/assets/ppentry/app-assets/vendors/js/tables/datatable/datatables.min.js" type="text/javascript"></script>
    <!-- END PAGE VENDOR JS-->
    <!-- BEGIN CHAMELEON  JS-->
    <script src="{{ url('/') }}/resources/assets/ppentry/app-assets/js/core/app-menu.min.js" type="text/javascript"></script>
    <script src="{{ url('/') }}/resources/assets/ppentry/app-assets/js/core/app.min.js" type="text/javascript"></script>
    <script src="{{ url('/') }}/resources/assets/ppentry/app-assets/js/scripts/customizer.min.js" type="text/javascript"></script>
    <script src="{{ url('/') }}/resources/assets/ppentry/app-assets/vendors/js/jquery.sharrre.js" type="text/javascript"></script>
    <!-- END CHAMELEON  JS-->
    <!-- BEGIN PAGE LEVEL JS-->
    <script src="{{ url('/') }}/resources/assets/ppentry/app-assets/js/scripts/tables/datatables/datatable-basic.min.js" type="text/javascript"></script>
    <!-- END PAGE LEVEL JS-->
  </body>
</html>