<a href="{{url('/')}}/add/user">Add</a>

@if ($message = Session::get('success'))
    <div class="alert alert-success alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong>{{ $message }}</strong>
    </div>
@endif


@if ($message = Session::get('error'))
    <div class="alert alert-danger alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong>{{ $message }}</strong>
    </div>
@endif


@if ($message = Session::get('warning'))
    <div class="alert alert-warning alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong>{{ $message }}</strong>
    </div>
@endif


@if ($message = Session::get('info'))
    <div class="alert alert-info alert-block">
        <button type="button" class="close" data-dismiss="alert">×</button>
        <strong>{{ $message }}</strong>
    </div>
@endif

<table border='1'>
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Password</th>
        <th>Company Name</th>
        <th>Company Logo</th>
        <th>Other Logo</th>
        <th>Parent ID</th>
        <th>User Type ID</th>
        <th>Is Admin</th>
        <th>Status</th>
        <th colspan="2">Action</th>
    </tr>
    @if(!empty($data))
        @foreach($data as $the_result)
            <tr>
                <td>{{$the_result->id}}</td>
                <td>{{$the_result->name}}</td>
                <td>{{$the_result->email}}</td>
                <td>{{$the_result->password}}</td>
                <td>{{$the_result->company_name}}</td>
                <td>
                    @if($the_result->company_logo != '')
                        <img src="{{url('/').'/public/uploads/'.$the_result->company_logo}}" alt="image" style="height: 60px;" />
                    @else
                        No Image
                    @endif
                </td>
                <td>
                    @if($the_result->other_logo != '')
                        <img src="{{url('/').'/public/uploads/'.$the_result->other_logo}}" alt="image" style="height: 60px;" />
                    @else
                        No Image
                    @endif
                </td>
                <td>{{$the_result->parent_id}}</td>
                <td>{{$the_result->user_type_id}}</td>
                <td>{{$the_result->is_admin}}</td>
                <td>{{$the_result->status}}</td>
                <td>{{$the_result->created_at}}</td>
                <td>{{$the_result->updated_at}}</td>
                <td><a href="{{url('/')}}/edit/user/{{$the_result->id}}">Edit</a></td>
                <td><a href="{{url('/')}}/delete/user/{{$the_result->id}}">Delete</a></td>
            </tr>
        @endforeach
    @else
        <tr><td colspan="6"> No Records Found !</td>
        </tr>
@endif