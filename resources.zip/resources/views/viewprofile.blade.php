@extends('dashboard_layouts.user_dashboard_layout')
@section('content')
    <section id="horizontal-form-layouts">

        <div class="row">
            <div class="col-md-12">
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title">Your Profile Information</h4>
                                    <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                                    <div class="heading-elements">
                                        <ul class="list-inline mb-0">
                                            <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                                            <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                            <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                                            <li><a data-action="close"><i class="ft-x"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="card-content collapse show">
                                    <div class="card-body card-dashboard row">
                                        <div class="col-6 table-responsive card-body card-dashboard ">
                                            <?php echo (!empty($data->name))?'<p><strong>Name : </strong>'.$data->name.'</p>':''; ?>
                                            <?php echo (!empty($data->email))?'<p><strong>Email : </strong>'.$data->email.'</p>':''; ?>
                                            <?php echo (!empty($data->designation))?'<p><strong>Designation : </strong>'.$data->designation.'</p>':''; ?>
                                            <?php echo (!empty($data->address))?'<p><strong>Address : </strong>'.$data->address.'</p>':''; ?>
                                            <?php echo (!empty($data->phone))?'<p><strong>Phone : </strong>'.$data->phone.'</p>':''; ?>
                                            <?php echo (!empty($data->organization_name))?'<p><strong>Organisation : </strong>'.$data->organization_name.'</p>':''; ?>

                                        </div>
                                        <div class="col-6 table-responsive card-body card-dashboard ">
                                        </div>
                                        <div class="table-responsive card-body card-dashboard ">
                                            <p>
                                                <a href="{{url('/')}}/dashboard/profileupdate" class="btn btn-primary btn-xs mb-1">Update Profile</a>
                                                <a href="{{url('/')}}/dashboard/passwordupdate" class="btn btn-primary btn-xs mb-1">Update Password</a>
                                            </p>

                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
            </div>
        </div>
    </section>
@endsection