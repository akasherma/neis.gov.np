<!DOCTYPE html>
<html class="loading" lang="en" data-textdirection="ltr">  
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="description" content="Chameleon Admin is a modern Bootstrap 4 webapp &amp; admin dashboard html template with a large number of components, elegant design, clean and organized code.">
    <meta name="keywords" content="admin template, Chameleon admin template, dashboard template, gradient admin template, responsive admin template, webapp, eCommerce dashboard, analytic dashboard">
    <meta name="author" content="ThemeSelect">
    <title>NEIS</title>
    <link href="https://fonts.googleapis.com/css?family=Muli:400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="https://maxcdn.icons8.com/fonts/line-awesome/1.1/css/line-awesome-font-awesome.min.css" rel="stylesheet">
    <link rel="apple-touch-icon" href="{{ url('/') }}/resources/assets/ppentry/app-assets/images/ico/apple-icon-120.png">
    <link rel="shortcut icon" type="image/x-icon" href="{{ url('/') }}/resources/assets/ppentry/app-assets/images/ico/favicon.ico">
    
    <!-- BEGIN VENDOR CSS-->
    <link rel="stylesheet" type="text/css" href="{{ url('/') }}/resources/assets/ppentry/app-assets/css/vendors.min.css">
    <link rel="stylesheet" type="text/css" href="{{ url('/') }}/resources/assets/ppentry/app-assets/vendors/css/forms/toggle/switchery.min.css">
    <link rel="stylesheet" type="text/css" href="{{ url('/') }}/resources/assets/ppentry/app-assets/css/plugins/forms/switch.min.css">
    <link rel="stylesheet" type="text/css" href="{{ url('/') }}/resources/assets/ppentry/app-assets/css/core/colors/palette-switch.min.css">
    <!-- END VENDOR CSS-->
    <!-- BEGIN CHAMELEON  CSS-->
    <link rel="stylesheet" type="text/css" href="{{ url('/') }}/resources/assets/ppentry/app-assets/css/app.min.css">
    <!-- END CHAMELEON  CSS-->
    <!-- BEGIN Page Level CSS-->
    <link rel="stylesheet" type="text/css" href="{{ url('/') }}/resources/assets/ppentry/app-assets/css/core/menu/menu-types/vertical-menu.min.css">
    <link rel="stylesheet" type="text/css" href="{{ url('/') }}/resources/assets/ppentry/app-assets/css/core/colors/palette-gradient.min.css">
    <!-- END Page Level CSS-->
    <!-- BEGIN Custom CSS-->
    <link rel="stylesheet" type="text/css" href="{{ url('/') }}/resources/assets/ppentry/assets/css/style.css">
    <!-- END Custom CSS-->
    <script src="{{ url('/') }}/resources/assets/ppentry/app-assets/js/jquery-3.3.1.min.js" type="text/javascript"></script>

    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

    <style>
        .ui-widget.ui-widget-content {
            border: 1px solid #7043e4;
            box-shadow: 0 0 20px #5428c5;
        }
        .ui-widget-header {
            border: 1px solid #7043e4;
            background: #9084ff;
            color: #ffffff;
            font-weight: bold;
        }
        #dialog .ui-dialog-titlebar-close {
            position: absolute;
            right: .3em;
            top: 50%;
            width: 60px;
            margin: -10px 0 0 0;
            padding: 1px;
            height: 30px;
        }

    </style>

    
  </head>
<body class="vertical-layout vertical-menu 2-columns menu-expanded fixed-navbar" data-open="click" data-menu="vertical-menu" data-color="bg-gradient-x-purple-blue" data-col="2-columns">

@include("dashboard_layouts.inc.front_header")

<div class="main-menu menu-fixed menu-light menu-accordion menu-shadow " data-scroll-to-active="true" data-img="{{ url('/') }}/resources/assets/ppentry/app-assets/images/backgrounds/02.jpg">
    <div class="navbar-header">
        <img class="img-responsive brand-logo" alt="Logo" src="{{ url('/') }}/resources/assets/frontend/assets/images/logo.jpg"/>

    </div>
    <div class="main-menu-content">
        @include("dashboard_layouts.inc.front_sidebar")
    </div>
    <div class="navigation-background"></div>
</div>

<div class="app-content content">
    <div class="content-wrapper">
        <div class="content-wrapper-before"></div>
        <div class="content-header row">
        </div>
        <div class="content-body"><!-- Revenue, Hit Rate & Deals -->
        @yield('content')
        <!--/ Revenue, Hit Rate & Deals -->
            <!-- Emails Products & Avg Deals -->

            <!--/ Emails Products & Avg Deals -->
            <!--/ Total earning & Recent Sales  -->
        </div>
    </div>
</div>
<!-- ////////////////////////////////////////////////////////////////////////////-->

@include("dashboard_layouts.inc.front_footer")

    <!-- BEGIN VENDOR JS-->
    <script src="{{ url('/') }}/resources/assets/ppentry/app-assets/vendors/js/vendors.min.js" type="text/javascript"></script>
    <script src="{{ url('/') }}/resources/assets/ppentry/app-assets/vendors/js/forms/toggle/switchery.min.js" type="text/javascript"></script>
    <script src="{{ url('/') }}/resources/assets/ppentry/app-assets/js/scripts/forms/switch.min.js" type="text/javascript"></script>
    <!-- BEGIN VENDOR JS-->
    <!-- BEGIN PAGE VENDOR JS-->
    <!-- END PAGE VENDOR JS-->
    <!-- BEGIN CHAMELEON  JS-->
    <script src="{{ url('/') }}/resources/assets/ppentry/app-assets/js/core/app-menu.min.js" type="text/javascript"></script>
    <script src="{{ url('/') }}/resources/assets/ppentry/app-assets/js/core/app.min.js" type="text/javascript"></script>
    <script src="{{ url('/') }}/resources/assets/ppentry/app-assets/js/scripts/customizer.min.js" type="text/javascript"></script>
    <script src="{{ url('/') }}/resources/assets/ppentry/app-assets/vendors/js/jquery.sharrre.js" type="text/javascript"></script>
    <!-- END CHAMELEON  JS-->
    <!-- BEGIN PAGE LEVEL JS-->
    <!-- END PAGE LEVEL JS-->
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<script type="text/javascript" src="{{url('/')}}/resources/assets/js/tinymce/tinymce.min.js"></script>
<script type="text/javascript" src="{{url('/')}}/resources/assets/js/tinymce/init-tinymce.js"></script>

<script>
    function dialogboxpopup(){
       $( "#dialog" ).dialog();
    }

    $("#closedialog").click(function(){
        $( "#dialog" ).dialog('close');
    });
</script>

  </body>

<!-- Mirrored from themeselection.com/demo/chameleon-admin-template/html/ltr/vertical-menu-template/form-layout-horizontal.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 24 Oct 2018 10:19:01 GMT -->
</html>