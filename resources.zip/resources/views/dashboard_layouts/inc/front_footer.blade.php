
    
    <footer class="footer footer-static footer-light navbar-border navbar-shadow">
      <div class="clearfix blue-grey lighten-2 text-sm-center mb-0 px-2"><span class="float-md-left d-block d-md-inline-block">
          <?php echo date('Y'); ?>  &copy; Copyright 
          <a class="text-bold-800 grey darken-2" href="http://multitechnepal.com.np/" target="_blank">MultiTechNepal</a></span>
        <ul class="list-inline float-md-right d-block d-md-inline-blockd-none d-lg-block mb-0">
          <li class="list-inline-item"><a class="my-1" href="" target="_blank">&nbsp;</a></li>
        </ul>
      </div>
    </footer>