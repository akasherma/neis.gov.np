<?php
$current_url = Request::url();
//$current_url_part = (url('/dashboard') != $current_url)?str_replace(url('/user/dashboard').'/', '', $current_url):$current_url;
?>
<ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
    <?php /*
    <li class=" nav-item">
      <a href="{{url('/')}}/dashboard"><i class="ft-home"></i>
          <span class="menu-title" data-i18n="">Dashboard</span>
      </a>
    </li>
    <li class=" nav-item">
        <a href="{{url('/')}}/dashboard/energy_form"><i class="ft-layers"></i>
            <span class="menu-title" data-i18n="">Entry Form</span>
        </a>
    </li>
    <li class=" nav-item">
        <a href="{{url('/')}}/dashboard/location"><i class="ft-layers"></i>
            <span class="menu-title" data-i18n="">Location</span>
        </a>
    </li>
    <li class=" nav-item">
        <a href="{{url('/')}}/dashboard/report"><i class="ft-layers"></i>
            <span class="menu-title" data-i18n="">Report</span>
        </a>
    </li>
    <li class="nav-item has-sub">
        <a href="#">
            <i class="ft-zap"></i>
            <span class="menu-title" data-i18n="">Settings</span>
        </a>
        <ul class="menu-content" style="">
            <li class="is-shown">
                <a class="menu-item" href="{{url('/')}}/dashboard/menu"><i class="ft-layers"></i>
                    <span class="menu-title" data-i18n="">Menu</span>
                </a>
            </li>
            <li class="is-shown">
                <a class="menu-item" href="{{url('/')}}/dashboard/menu_type"><i class="ft-layers"></i>
                    <span class="menu-title" data-i18n="">Menu Type</span>
                </a>
            </li>
            <li class="is-shown">
                <a class="menu-item" href="{{url('/')}}/dashboard/user"><i class="ft-layers"></i>
                    <span class="menu-title" data-i18n="">User</span>
                </a>
            </li>
            <li class="is-shown">
                <a class="menu-item" href="{{url('/')}}/dashboard/user_group"><i class="ft-layers"></i>
                    <span class="menu-title" data-i18n="">User Group</span>
                </a>
            </li>
        </ul>
    </li>

    */ ?>

    <?php

//    $current_url = Request::url();

    $result = App\Menu::getSidebarMenuForAdmin(Auth::user()->id);

//    echo '<pre>';
//    print_r($result);
//    echo '</pre>';

//        $user_id = \Illuminate\Support\Facades\Session::get('user_id');
//        echo App\User::getParentList($user_id);

    ?>

    <li class="nav-item {{ ($current_url == url('/dashboard'))?'active':'' }}" title="{{ $current_url }}" name="{{ url('/dashboard') }}">
        <a href="{{ url('/') }}/dashboard"><i class="ft-home"></i>
            <span class="menu-title" data-i18n="">Dashboard</span>
        </a>
    </li>
    @if(!empty($result))
        @foreach ($result as $menu)
            <li class="nav-item {{ ($current_url == url('/dashboard').'/'.$menu->menu_slug)?'active':'' }}">
                <a href="{{ url('/dashboard') }}/{{$menu->menu_slug}}">
                    <i class="ft-layers"></i>
                    <span class="menu-title" data-i18n="">{{$menu->menu_name}}</span>
                </a>
            </li>
        @endforeach
    @endif

    <?php

    $current_url_part = str_replace(url('/')."/", "", $current_url);

    $arr = array("dashboard/sector","dashboard/energy_type","dashboard/user_group","dashboard/geographic-region","dashboard/land-type","dashboard/energy-year","dashboard/energy","dashboard/menu","dashboard/menu_type","dashboard/user","dashboard/location","dashboard/source","dashboard/river","dashboard/page","dashboard/fuel-type","dashboard/energy-conversion","dashboard/unit","dashboard/location-type");

    $open = (in_array($current_url_part, $arr))?'open':'';
    $is_shown = (in_array($current_url_part, $arr))?'is-shown':'';

    ?>

    <?php
    $result2 = App\Menu::getSidebarMenuForAdminSetting(Auth::user()->id);
    ?>
    @if(!empty($result2))
        <li class="nav-item has-sub {{ $open }} {{ $is_shown }}">
            <a href="#">
                <i class="ft-zap"></i>
                <span class="menu-title" data-i18n="">Settings</span>
            </a>
            <ul class="menu-content" style="">
                @foreach ($result2 as $menu)
                    <?php
                    $active = ($current_url == url('/dashboard')."/".$menu->menu_slug)?'active':'';
                    ?>
                    <li class=" {{ $is_shown }} {{ $active }}">
                        <a href="{{ url('/dashboard') }}/{{$menu->menu_slug}}">
                            <i class="ft-layers"></i>
                            <span class="menu-title" data-i18n="">{{$menu->menu_name}}</span>
                        </a>
                    </li>
                @endforeach
            </ul>
        </li>
    @endif
    
    <?php /* ?>

    <?php

    $arr = array("dashboard/production-energy-form","dashboard/consumption-energy-form","dashboard/import-energy-form","dashboard/export-energy-form","dashboard/resources-energy-form");

    $open = (in_array($current_url_part, $arr) || ((strpos($current_url, 'entry-form') !== false)))?'open':'';
    $is_shown = (in_array($current_url_part, $arr) || ((strpos($current_url, 'entry-form') !== false)))?'is-shown':'';

    $result3 = App\Menu::getSidebarMenuForEntryForm(Auth::user()->id);
    ?>
    @if(!empty($result3))
        <li class="nav-item has-sub {{ $open }} {{ $is_shown }}">
            <a href="#">
                <i class="ft-zap"></i>
                <span class="menu-title" data-i18n="">Entry Form Old</span>
            </a>
            <ul class="menu-content" style="">
                @foreach ($result3 as $menu)
                    <?php
                    $active = ($current_url == url('/dashboard')."/".$menu->menu_slug)?'active':'';
                    ?>
                    <li class=" {{ $is_shown }} {{ $active }}">
                        <a href="{{ url('/dashboard') }}/{{$menu->menu_slug}}">
                            <i class="ft-layers"></i>
                            <span class="menu-title" data-i18n="">{{$menu->menu_name}}</span>
                        </a>
                    </li>
                @endforeach
            </ul>
        </li>
    @endif
    
    <?php */ ?>

        <?php
        $result3 = App\Menu::getSidebarMenuForRecords(Auth::user()->id);
        $open = ((strpos($current_url, 'records') !== false))?'open':'';
        $is_shown = ((strpos($current_url, 'records') !== false))?'is-shown':'';
        ?>
        @if(!empty($result3))
            <li class="nav-item has-sub {{ $open }} {{ $is_shown }}">
                <a href="#">
                    <i class="ft-zap"></i>
                    <span class="menu-title" data-i18n="">Power Plants</span>
                </a>
                <ul class="menu-content" style="">
                    @foreach ($result3 as $menu)
                        <?php
                        $active = ($current_url == url('/dashboard/records')."/".$menu->menu_slug)?'active':'';
                        ?>
                        <li class=" {{ $is_shown }} {{ $active }}">
                            <a href="{{ url('/dashboard') }}/records/{{$menu->menu_slug}}">
                                <i class="ft-layers"></i>
                                <span class="menu-title" data-i18n="">{{$menu->menu_name}}</span>
                            </a>
                        </li>
                    @endforeach
                </ul>
            </li>
        @endif


        <?php
        $result4 = App\Menu::getSidebarMenuForEntryFormNew(Auth::user()->id);

//        $open = ((strpos($current_url, 'entryform') !== false))?'open':'';
//        $is_shown = ((strpos($current_url, 'entryform') !== false))?'is-shown':'';

        $open = '';
        $is_shown = '';
        ?>
        @if(!empty($result4))
            <li class="nav-item has-sub {{ $open }} {{ $is_shown }}">
                <a href="#">
                    <i class="ft-zap"></i>
                    <span class="menu-title" data-i18n="">Entry Form</span>
                </a>
                <ul class="menu-content" style="">
                    @foreach ($result4 as $menu)
                        <?php
                        $active = ($current_url == url('/dashboard/entryform')."/".$menu->menu_slug)?'active':'';
                        ?>
                        <li class=" {{ $is_shown }} {{ $active }}">
                            <a href="{{ url('/dashboard') }}/entryform/{{$menu->menu_slug}}">
                                <i class="ft-layers"></i>
                                <span class="menu-title" data-i18n="">{{$menu->menu_name}}</span>
                            </a>
                        </li>
                    @endforeach
                </ul>
            </li>
        @endif

        <?php
        $result4 = App\Menu::getSidebarMenuForReportNew(Auth::user()->id);
        $open = ((strpos($current_url, 'reportnew') !== false))?'open':'';
        $is_shown = ((strpos($current_url, 'reportnew') !== false))?'is-shown':'';
        ?>
        @if(!empty($result4))
            <li class="nav-item has-sub {{ $open }} {{ $is_shown }}">
                <a href="#">
                    <i class="ft-zap"></i>
                    <span class="menu-title" data-i18n="">Report New</span>
                </a>
                <ul class="menu-content" style="">
                    @foreach ($result4 as $menu)
                        <?php
                        $active = ($current_url == url('/dashboard/reportnew')."/".$menu->menu_slug)?'active':'';
                        ?>
                        <li class=" {{ $is_shown }} {{ $active }}">
                            <a href="{{ url('/dashboard') }}/reportnew/{{$menu->menu_slug}}">
                                <i class="ft-layers"></i>
                                <span class="menu-title" data-i18n="">{{$menu->menu_name}}</span>
                            </a>
                        </li>
                    @endforeach
                </ul>
            </li>
        @endif

        <li class="nav-item">
        <a href="{{ url('/') }}/logout" onclick="event.preventDefault();
                                             document.getElementById('logout-form').submit();">

                            <i class="ft-zap"></i>
            <span class="menu-text">Logout</span>

        </a>

        <form id="logout-form" action="{{ url('/')}}/logout" method="POST" style="display: none;">
            {{csrf_field()}}
        </form>
    </li>

</ul>